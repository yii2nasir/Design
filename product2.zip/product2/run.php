<?php
$check = 0;
$msg = array();
if (! $permission->CheckOperationPermission('product', 'access', $GLOBALS['user']->UserRoleID)) {
    Redirect("../index.php");
}

function filterx($filterArr){
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $filterOptions = $_POST;
    } else {
        $filterOptions = (isset($_COOKIE['admin_product_filter']) ? json_decode(stripslashes($_COOKIE['admin_product_filter']), true) : array());
    }


$c='<input type="button" name="filter" id="filter" class="ui-button" value="Show Filters"/>
<a href="index.php?mode=clearfilter"> Clear Filter</a>
<div id="filterbox"><form method="post">
<fieldset class="shortfields">';

foreach($filterArr as $k=>$v){
    $c.='<div class="formfield"> 
    <label class="formlabel" for="'.$v.'"> '.$v.' </label>
    <div class="forminputwrapper">
        <input type="text" name="'.$v.'" id="'.$v.'" class="forminput" value="' . (isset($filterOptions[$v]) ? $filterOptions[$v] : '') . '" />
    </div>
    <div class="clear"></div>
    </div>';
    }
                
    // $c.='<div class="formfield">
    //     <label class="formlabel" for="name"> Product Name </label>
    //     <div class="forminputwrapper">
    //         <input type="text" name="productname" id="name" class="forminput" value="' . (isset($filterOptions['productname']) ? $filterOptions['productname'] : '') . '" />
    //     </div>
    // <div class="clear"></div></div>
                
    // <div class="formfield">
    //     <label class="formlabel" for="search_quote"> Product Code </label>
    //     <div class="forminputwrapper">
    //         <input type="text" name="productcode" id="code" class="forminput numeric" value="' . (isset($filterOptions['productcode']) ? $filterOptions['productcode'] : '') . '" />
    //     </div>
    // <div class="clear"></div></div>';
    $c.='
    <p>&nbsp;</p>
    <div class="formfield"><br /><br />
        <button type="submit" name="submit" id="filtersubmit">Filter Report</button> <br />
    <div class="clear"></div></div>
</fieldset>
</form></div><br />';

  return $c;  


}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['delete']) && is_numeric($_GET['delete']) && $permission->CheckOperationPermission('product', 'delete', $GLOBALS['user']->UserRoleID)) {
       if (\TAS\Product::Delete((int) $_GET['delete'])) {
            $check = 1;
        } else {
            $check = 2;
        }
    }

    if (isset($check)) {
        switch ($check) {
            case 1:
                $messages[] = array(
                    "message" => _("Record delete Successfully!!!"),
                    "level" => 1
                );
                break;
            case 2:
                $messages[] = array(
                    "message" => _("Fail to delete this record"),
                    "level" => 10
                );
                break;
        }
    }
    if(isset($_SESSION['message']))
    {
        $messages[] = array(
            "message" => _("Status updates successfully"),
            "level" => 1
        );
        unset($_SESSION['message']);
    }
    
    if (isset($_GET['mode']) && $_GET['mode'] == 'clearfilter') {
        unset($_SESSION['product_orderby']);
        unset($_SESSION['product_direction']);
        setcookie('admin_product_filter', '', (time() - 25292000));
        Redirect("index.php?d=1");
    }

    if (isset($_GET['type']) && is_numeric($_GET['id'])) {
        if ($_GET['type'] == 'status') {
            $u = new \TAS\Product((int) $_GET['id']);
            if ($u->IsLoaded()) {
                $s = (($u->Status == 1) ? 0 : 1);
                $GLOBALS['db']->Execute("update " . $GLOBALS['Tables']['product'] . " set status=" . $s . " where productid=" . $u->ProductID);
                $_SESSION['message']='update';
                Redirect('index.php');
            } else {
                $messages[] = array(
                    "message" => _("No user found to update status"),
                    "level" => 10
                );
            }
        }
    }
}
/************************** */
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $filterOptions = $_POST;
} else {
    $filterOptions = (isset($_COOKIE['admin_product_filter']) ? json_decode(stripslashes($_COOKIE['admin_product_filter']), true) : array());
}
