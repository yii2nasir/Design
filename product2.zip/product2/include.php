<?php
require_once ("./DB.php");
function DisplayForm($edit = 0)
{
    $actionurl = ($edit > 0) ? "{AdminURL}/product/edit.php?id=" . $edit : "{AdminURL}/product/add.php";
    $formtitle = ($edit > 0) ? "Edit Product" : "Add Product";

    $fields = array();
    $fields = \TAS\Product::GetFields($edit);

    $param['Fields'] = $fields;
    $param['Group'] = array(
        'basic' => array(
            'legend' => ''
        )
    );
    // echo "<pre>" ;
    // print_r($param) ;
    // exit ;
    $form = '<h2>' . _($formtitle) . '</h2>' . \TAS\Utility::UIMessageDisplay($GLOBALS['messages']) . '
<form action="" method="post" class="validate">
<fieldset class="generalform">
	<legend></legend>
	' . \TAS\Utility::GetFormHTML($param) . '
	<div class="formbutton">
		<input type="hidden" name="mode" value="profile" />
		<input type="submit" name="btnsubmit" id="btnsubmit" class="ui-button ui-state-default ui-corner-all" value="' . _("Submit") . '" />			
	</div>
</fieldset>
</form>';
    return $form;
}

function DisplayGrid()
{
    global $SQLQuery;
    global $filterOption;
    global $param;
    
    $filterOptions = $filterOption;
    if (isset($_COOKIE['admin_product_filter']) && $_SERVER['REQUEST_METHOD'] == 'GET') {
        $filterOptions = json_decode(stripslashes($_COOKIE['admin_product_filter']), true);
    } else {
        $filterOptions = $_POST;
    }
    $filter = array();
 
    foreach($filterOption as $k=>$v){
        $filter[] = $v." LIKE '%" . DoSecure($filterOptions[$v]) . "%'";
    }

    // if (isset($filterOptions['productname']) && $filterOptions['productname'] != '') {
    //     $filter[] = "productname LIKE '%" . DoSecure($filterOptions['productname']) . "%'";
    // }
    // if (isset($filterOptions['productcode']) && $filterOptions['productcode'] != '') {
    //     $filter[] = "productcode LIKE '%" . DoSecure($filterOptions['productcode']) . "%'";
    // }

    if (count($filter) > 0) {
        $SQLQuery['where'] = ' where ' . implode(' and ', $filter) . ' ';
    } else {
        $SQLQuery['where'] = '';
    }

    // $SQLQuery['pagingQuery'] = "select count(*) from " . $GLOBALS['Tables']['product'];

    $_COOKIE['admin_product_filter'] = json_encode($filterOptions);
    setcookie('admin_product_filter', json_encode($filterOptions), (time() + 25292000));

    $pages['gridpage'] = $GLOBALS['AppConfig']['AdminURL'] . 'product/index.php';
    $pages['edit'] = $GLOBALS['AppConfig']['AdminURL'] . 'product/edit.php';
    $pages['delete'] = $GLOBALS['AppConfig']['AdminURL'] . 'product/index.php';
    
    
    $listing = \TAS\Utility::HTMLGridFromRecordSet($SQLQuery, $pages, $GLOBALS['TABLE_NAME'], $param);
    return $listing;
}