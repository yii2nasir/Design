<?php
require("../template.php");
require_once("./include.php");
$messages= array();
$productid = isset($_GET['id'])?(int)$_GET['id']:0;
$product= new \TAS\Product($productid );
if ($productid<= 0 || !$permission->CheckOperationPermission("product", "edit", $GLOBALS['user']->UserRoleID)) {
	Redirect("index.php");
}

$Check = 0;
if($_SERVER['REQUEST_METHOD'] =='POST') {
	$d=array();
	$d=\TAS\Entity::ParsePostToArray(\TAS\Product::GetFields($productid));
    
    $d['editdate']= date("Y-m-d H:i:s");
	
	
	$GLOBALS['db']->Execute("Delete from ". $GLOBALS['Tables']['productcategory']. " where productid=". $productid);	
	if(isset($_POST['categories']) && is_array($_POST['categories']) && count($_POST['categories'])>0) {
		foreach($_POST['categories'] as $catid) {
			
		    $GLOBALS['db']->Insert("productcategory", array('productid'=> $productid, 'categoryid'=> (int)$catid));
		}
	}
	$isupdated= $product->Update($d);
	if($isupdated) {
		$messages[] = array("message"=> _("Record updated successfully"), "level"=>1);
	} else {
		$messages[] = array("message"=> _("Unable to update record. Check data again!!!"), "level"=>10);
	}
}

$pageParse['Content'] = DisplayForm($productid);
\TAS\TemplateHandler::TemplateChooser(5);
