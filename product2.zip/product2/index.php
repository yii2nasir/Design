<?php
require ("../template.php");
require_once ("./include.php");
require_once ("./run.php");



$pageParse['Content'] .= '<h2>Product Management</h2>';
$pageParse['Content'] .= \TAS\Utility::UIMessageDisplay($messages);
$pageParse['Content'] .= '<p><a href="add.php">Add New Product</a></p>';
$pageParse['Content'] .=filterx($filterOption);


$pageParse['Content'] .= DisplayGrid();

$pageParse['MetaExtra'] .= '<script type="text/javascript">
$(function(){
	$("#filter").click(function(){
		$("#filterbox").slideToggle().queue(function(){;
			if($("#filterbox").is(":visible")) {
				$("#filter").val("Hide Filters");
			} else {
				$("#filter").val("Show Filters");
			}
			$(this).dequeue();
		});
	});
	$("#filterbox").hide();
});
	</script>';

\TAS\TemplateHandler::TemplateChooser(5);
