<?php

$filterOption=['productname','productcode'];
$TABLE_NAME='product';
$SQLQuery['basicquery'] = "select * from " . $TABLE_NAME . "";
$SQLQuery['pagingQuery'] = "select count(*) from " . $TABLE_NAME;


//$filterOptions=$filterOption;

$param['defaultorder'] = 'productid';
$param['defaultsort'] = 'desc';
$param['indexfield'] = 'productid';
$param['tablename'] = $TABLE_NAME;

$param['fields'] = [
    'productid' => ['type' => 'string','name' => '#'],
    'productname' => ['type' => 'string','name' => 'Product Name'],
    'productcode' => ['type' => 'string','name' => 'Product Code'],
    'costprice' => ['type' => 'currency','name' => 'Cost Price'],
    'price' => ['type' => 'currency','name' => 'Price'],
    'status' => ['type' => 'onoff','name' => 'Status','mode' => 'fa']
    ];

$param['allowselection'] = false;
$param['LinkFirstColumn'] = true;
$param['MultiTableSearch'] = true;

$extraicons[]=[
    'link' => $GLOBALS['AppConfig']['AdminURL'] . 'productimage/index.php',
    'iconclass' => 'fa-image',
    'tooltip' => 'Product Images',
    'tagname' => 'productimage',
    'paramname' => 'productid',
    'iconparent' => 'fa',
];
$fields = \TAS\Product::GetFields(0);

    $param['Fields'] = $fields;
$param['extraicons'] = $extraicons;

//echo "<pre>";print_r($fields);exit;
