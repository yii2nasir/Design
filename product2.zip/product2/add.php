<?php
require ("../template.php");
require_once ("./include.php");
if (! $permission->CheckOperationPermission('product', 'add', $GLOBALS['user']->UserRoleID)) {
    Redirect("index.php");
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $d = \TAS\Entity::ParsePostToArray(\TAS\Product::GetFields());
    /* $data['adddate'] = date("Y-m-d H:i:s");
    $data['productname']=DoSecure($d['productname']);
    $data['description']=DoSecure($d['description']);
    $data['shortdescription']=DoSecure($d['shortdescription']);
    $data['additionalinfo']=DoSecure($d['additionalinfo']);
    $data['costprice']=DoSecure((float)$d['costprice']);
    $data['price']=DoSecure((float)$d['price']);
    $data['productcode']=DoSecure($d['productcode']);
    $data['isfeatured']=DoSecure($d['isfeatured']);
    $data['orgid']=DoSecure((int)$d['orgid']);
    $data['status']=DoSecure($d['status']); */
   
    $productid = \TAS\Product::Add($d);
    
    if ($productid > 0) {
        if (isset($_POST['categories']) && is_array($_POST['categories']) && count($_POST['categories']) > 0) {
            foreach ($_POST['categories'] as $catid) {
                $GLOBALS['db']->Insert("productcategory", array(
                    'productid' => (int)$productid,
                    'categoryid' => (int) $catid
                ));
            }
        }
       /*  
        $GLOBALS['db']->Insert("productlist", array(
            'productid' => (int)$productid,
            'listid' => (int) $d['listid'],
            'timeperiod' => DoSecure($d['timeperiod']),
            'freeqty' => DoSecure((int)$d['freeqty'])
        )); */
        $messages[] = array(
            "message" => _("Product Created Successfully!!!"),
            "level" => 1
        );
    } else {
        if (count(\TAS\Product::GetErrors()) > 0) {
            $a = \TAS\Product::GetErrors();
            foreach ($a as $i => $v) {
                $messages[] = $v;
            }
        }
        $messages[] = array(
            "message" => _("Unable to create product at this moment. Please try again later!!!"),
            "level" => 10
        );
    }
}

$pageParse['Content'] .= DisplayForm();

\TAS\TemplateHandler::TemplateChooser(5);
