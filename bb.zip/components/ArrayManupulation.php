<?php
namespace app\components;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of unset key form 2D array
 *
 * @author amres
 */
use Yii;
use yii\base\Component;
use yii\base\InvalidConfigException;
class ArrayManupulation  extends Component{
    //put your code here
    public function UnsetKeyFrom2DArray($array = [],$keys=[]){
        foreach ($array as $key => $value) {
            foreach ($keys as $val) {
                if(isset($value[$val])){
                    unset($array[$key][$val]);
                }
            }
        }
        return $array;
    }
}
