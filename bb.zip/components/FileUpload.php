<?php
namespace app\components;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of FileUpload
 *
 * @author amres
 */
use Yii;
use yii\base\Component;
use yii\base\InvalidConfigException;
class FileUpload extends Component{
    //put your code here
    public function uploadMe($model,$dirName = FALSE,$keepRealName = FALSE) {
        if(!$dirName){
            $dirName = Yii::$app->controller->id;
        }
        $uploads_dir = \Yii::$app->params["imageBaseDir"].$dirName."/";
        foreach ($_FILES as $key=>$value){
            $columnNames = array_keys($_FILES[$key]["tmp_name"]);
            foreach ($columnNames as $columnName){
                if(isset($model->$columnName)){
                    $tmp_name = $_FILES[$key]["tmp_name"][$columnName]; 
                    $name = $keepRealName ? $_FILES[$key]["name"][$columnName] : $columnName."_".strtotime("now").".jpg";
                    
                    if (!file_exists($uploads_dir)) {
                        mkdir($uploads_dir, 0777, true);
                    }
                    if(move_uploaded_file($tmp_name, $uploads_dir.$name)){
                        if( (!$model->isNewRecord ) && !is_null($model->$columnName) && !empty($model->$columnName) && file_exists($uploads_dir.$model->$columnName) && ($name != $model->$columnName)){
                            try {
                                unlink($uploads_dir.$model->$columnName);
                            } catch (Exception $exc) {
                                echo $exc->getTraceAsString();
                            }
                        }// solve exception issues
                        $model->$columnName = $name;
                    }else{
                        unset($model->$columnName);
                    }
                }
            }      
        }
        if( (!$model->isNewRecord) && ( isset($model->updated_at) || $model->updated_at == NULL ) ){
            $model->updated_at = date("Y-m-d H:i:s");
        }
        return $model;
    }
    public function uploadApiFile($model,$dirName = FALSE,$keepRealName = FALSE){
        if(!$dirName){
            $dirName = Yii::$app->controller->id;
        }
        $uploads_dir = \Yii::$app->params["imageBaseDir"].$dirName."/";
        foreach ($_FILES as $columnName=>$file){
            if($this->isKeyExist($columnName,$model)){
                $tmp_name = $_FILES[$columnName]["tmp_name"]; 
                $name = $keepRealName ? $_FILES[$columnName]["name"] : $columnName."_".strtotime("now").".jpg";
                    
                if (!file_exists($uploads_dir)) {
                    mkdir($uploads_dir, 0777, true);
                }
                if(move_uploaded_file($tmp_name, $uploads_dir.$name)){
                    if( (!$model->isNewRecord ) && !is_null($model->$columnName) && !empty($model->$columnName) && file_exists($uploads_dir.$model->$columnName) && ($name != $model->$columnName)){
                        try {
                            unlink($uploads_dir.$model->$columnName);
                        } catch (Exception $exc) {
                            echo $exc->getTraceAsString();
                        }
                    }// solve exception issues
                    $model->$columnName = $name;
                }else{
                    unset($model->$columnName);
                }
            }
        }
        return $model;
    }
    protected function findFileKey($files){
        foreach ($files as $key=>$names){
            foreach ($names as $key=>$name){
                return $key;
            }
        }
    }
    protected function isKeyExist($key,$model){
        foreach ($model as $name => $value) {
            if($key == $name){
                return TRUE;
            }
        }
        return FALSE;
    }
}
