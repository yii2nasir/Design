<?php
namespace app\components;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of FileUpload
 *
 * @author amresh
 */
use Yii;
use yii\base\Component;
use yii\base\InvalidConfigException;
class GenerateUniqueId extends Component{
    //@getUniqueId: To create unique id ...
    public function uniqueId(){
        $session = \Yii::$app->session;
        if (!$session->isActive) { $session->open(); }
        $u_id = $session->get("login_id")."-".sprintf("%04s", $session->get("sessionCount"));
        $session->set("sessionCount", ($session->get("sessionCount")+1));
        return $u_id;
    }
}