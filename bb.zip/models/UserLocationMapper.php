<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "user_location_mapper".
 *
 * @property integer $id
 * @property integer $user_id
 * @property integer $location_id
 * @property string $updated_at
 * @property string $created_at
 */
class UserLocationMapper extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'user_location_mapper';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['user_id', 'location_id', 'level_id'], 'required'],
            [['user_id', 'location_id', 'level_id'], 'integer'],
            [['updated_at', 'created_at'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => Yii::t('app', 'ID'),
            'user_id' => Yii::t('app', 'User ID'),
            'location_id' => Yii::t('app', 'Location'),
            'level_id' => Yii::t('app', 'Level'),
            'updated_at' => Yii::t('app', 'Web Updated'),
            //'mobile_created_at' => Yii::t('app', 'Mobile Created'),
            'created_at' => Yii::t('app', 'Web Synced'),
        ];
    }

    public function getStateName($level, $location) {
        if ($level != NULL && $location != NULL) {
            if($level == 1){
                $stateName = \app\models\State::find()->select(['name'])->where(['id' => $location])->one();

                return $stateName['name'];
            }
            if($level == 33){
                $stateName = \app\models\State::find()
                    ->where(['state.id' => $location])
                    ->one();
                return $stateName['name'];
            }
            if($level == 35){
                $stateName = \app\models\District::find()
                    ->joinWith(['state'])
                    ->where(['district.id' => $location])
                    ->one();
                return $stateName['state']['name'];
            }
            if($level == 37){
            $query = new \yii\db\Query;
            $query->select(['state.name as stateName'])  
                    ->from('rpc_centre')
                    ->innerJoin("district",'rpc_centre.district_id = district.id')
                    ->innerJoin("state",'state.id = district.state_id')
                    ->where(['rpc_centre.id' => $location]);
            $command = $query->createCommand();
            $operations = $command->queryAll();
            if(!empty($operations) && $operations != null){
            return $operations[0]['stateName'];
            }else{
             return "";   
            }
            }
        } else {
            return "";
        }
     }

    public function getDistrictName($level, $location) {
        if ($level != NULL && $location != NULL) {
            $query = new \yii\db\Query;
            $query->select(['district.name as district_name'])  
                    ->from('state')
                    ->innerJoin("district",'state.id = district.state_id');
           if($level == 37){
               $query->innerJoin("rpc_centre",'rpc_centre.district_id = district.id')
                     ->where(['rpc_centre.id' => $location]);
           }else{
              $query->where(['district.id' => $location]);
           }  
            $command = $query->createCommand();
            $operations = $command->queryAll();

            if(!empty($operations) && $operations != null){
                return $operations[0]['district_name'];
            }else{
             return "";   
            }
        } else {
            return "";
        }
    }

    //  public function getDistrictName($level, $location) {
    //     if ($level != NULL && $location != NULL) {
    //         $query = new \yii\db\Query;
    //         $query->select(['district.name as district_name'])  
    //                 ->from('rpc_centre')
    //                 ->innerJoin("district",'district.id = rpc_centre.district_id')
    //                 ->where(['rpc_centre.id' => $location]);
    //         $command = $query->createCommand();
    //         $operations = $command->queryAll();
    //         if(!empty($operations) && $operations != null){
    //             return $operations[0]['district_name'];
    //         }else{
    //          return "";   
    //         }
            
    //     } else {
    //         return "";
    //     }
    // }


    public function getRpcCenterName($level, $location) {
        if ($level != NULL && $location != NULL) {
                $rpc_name = \app\models\RpcCentre::find()->select(['rpc_name'])->where(['id' => $location])->one();
                return isset($rpc_name['rpc_name']) && $rpc_name['rpc_name'] !="" ? $rpc_name['rpc_name'] :"";
            
        } else {
            return "";
        }
    }

}

