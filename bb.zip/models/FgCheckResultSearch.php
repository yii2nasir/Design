<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\FgCheckResult;

/**
 * FgCheckResultSearch represents the model behind the search form of `app\models\FgCheckResult`.
 */
class FgCheckResultSearch extends FgCheckResult
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'fg_qc_check_id', 'qc_parameter_id'], 'integer'],
            [['value', 'status', 'latitude', 'logtitude', 'entry_type', 'created_at', 'updated_at', 'unique_id'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = FgCheckResult::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'fg_qc_check_id' => $this->fg_qc_check_id,
            'qc_parameter_id' => $this->qc_parameter_id,
            'entry_type' => $this->entry_type,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ]);

        $query->andFilterWhere(['like', 'value', $this->value])
            ->andFilterWhere(['like', 'status', $this->status])
            ->andFilterWhere(['like', 'latitude', $this->latitude])
            ->andFilterWhere(['like', 'logtitude', $this->logtitude])
            ->andFilterWhere(['like', 'unique_id', $this->unique_id]);

        return $dataProvider;
    }
}
