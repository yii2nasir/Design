<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace backend\models\GraphModels;

/**
 * Description of agricultureGraphs
 *
 * @author amresh
 */
class AgricultureGraphs {
    //put your code here
    public function getPrimaryBeneficiarySolarIrrigationArea($year_month) {
        
        $query = new \yii\db\Query;
        $query->select([
                    "SUM(sip.area) as totalArea",
                ])
                ->from('sip')
                ->innerJoin("machinery_owner","sip.machinery_owner_id=machinery_owner.id")
                ->where("sip.beneficiary_id = machinery_owner.beneficiary_id");
                if($year_month){
                    $query = $query->andWhere(["DATE_FORMAT(sip.activity_date, '%Y-%m')"=>$year_month]);
                }
                //->andWhere(["DATE_FORMAT(sip.activity_date, '%Y-%m')"=>$year_month]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? floatval($Output[0]['totalArea']) : 0;
        
    }
    public function getSecondaryBeneficiarySolarIrrigationArea($year_month) {
        $query = new \yii\db\Query;
        $query->select([
                "SUM(sip.area) as totalArea"
            ])
            ->from('sip')
            ->innerJoin("machinery_owner","sip.machinery_owner_id=machinery_owner.id")
            ->where("sip.beneficiary_id != machinery_owner.beneficiary_id");
//            ->where("sip.machinery_owner_id != sip.beneficiary_id");
            if($year_month){
                $query = $query->andWhere(["DATE_FORMAT(sip.activity_date, '%Y-%m')"=>$year_month]);
            }
//            ->andWhere(["DATE_FORMAT(activity_date, '%Y-%m')"=>$year_month]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? floatval($Output[0]['totalArea']) : 0;
    }


    // Start System Installed
     public function getPrimarySystemInstalled($year_month,$crop_id,$system) {
        
        $query = new \yii\db\Query;
        $query->select([
                    "SUM(micro_irrigation.area_covered) as totalSystemInstalled",
                ])
                ->from('micro_irrigation');
                if($year_month){
                    $query = $query->andWhere(["DATE_FORMAT(micro_irrigation.installation_date, '%Y-%m')"=>$year_month]);
                }
                if($crop_id){
                    $query = $query->andWhere(["crop_id"=>$crop_id]);
                }
                if($system){
                    $query = $query->andWhere(["system_installed"=>$system]);
                }
        $command = $query->createCommand();
        $Output = $command->queryAll();
        $primary =  count($Output) > 0 ? floatval($Output[0]['totalSystemInstalled']) : 0;
        return $primary;
        
    }
    public function getSecondarySystemInstalled($year_month,$crop_id,$system) {
        $query = new \yii\db\Query;
        $query->select([
                "SUM(micro_irrigation.area_covered) as totalSystemInstalled",
            ])
            ->from('micro_irrigation');
            if($year_month){
                $query = $query->andWhere(["DATE_FORMAT(micro_irrigation.installation_date, '%Y-%m')"=>$year_month]);
            }
                if($crop_id){
                    $query = $query->andWhere(["crop_id"=>$crop_id]);
                }
                if($system){
                    $query = $query->andWhere(["system_installed"=>$system]);
                }
        $command = $query->createCommand();
        $Output = $command->queryAll();
        $secondary = count($Output) > 0 ? floatval($Output[0]['totalSystemInstalled']) : 0;
        return $secondary;
    }

            public function getYearTillDateSystemInstalled($year_month,$crop_id,$system) {
        $query = new \yii\db\Query;
        $query->select([
                "SUM(micro_irrigation.area_covered) as totalSystemInstalled",
                ])
                ->from('micro_irrigation');
                if($year_month){
                    $query = $query->andWhere("DATE_FORMAT(installation_date, '%Y-%m') < '".$year_month."' OR DATE_FORMAT(installation_date, '%Y-%m') = '".$year_month."'");
                }
                if($crop_id){
                    $query = $query->andWhere(["crop_id"=>$crop_id]);
                }
                if($system){
                    $query = $query->andWhere(["system_installed"=>$system]);
                }
        $command = $query->createCommand();
        $Output = $command->queryAll();
        $primary = count($Output) > 0 ? floatval($Output[0]['totalSystemInstalled']) : 0;
        /**/
        $query = new \yii\db\Query;
        $query->select([
                "SUM(micro_irrigation.area_covered) as totalSystemInstalled",
                ])
                ->from('micro_irrigation')
                ->andWhere("DATE_FORMAT(installation_date, '%Y-%m') < '".$year_month."' OR DATE_FORMAT(installation_date, '%Y-%m') = '".$year_month."'"); 
                if($crop_id){
                    $query = $query->andWhere(["crop_id"=>$crop_id]);
                }
                if($system){
                    $query = $query->andWhere(["system_installed"=>$system]);
                }     
        $command = $query->createCommand();
        $Output = $command->queryAll();
        $secondary = count($Output) > 0 ? floatval($Output[0]['totalSystemInstalled']) : 0;
        return $primary+$secondary;
        
    }
    // End: System Installed
    public function getTotalMonthlySolarIrrigationArea($year_month) {
        $query = new \yii\db\Query;
        $query->select([
                    "SUM(sip.area) as totalArea"
                ])
                ->from('sip')
                ->andWhere(["DATE_FORMAT(activity_date, '%Y-%m')"=>$year_month]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? floatval($Output[0]['totalArea']) : 0;
    }
//    nnv
    public function getYearTillDateSolarIrrigationArea($year_month) {
        $query = new \yii\db\Query;
        $query->select([
                    "SUM(sip.area) as totalArea"
                ])
                ->from('sip')
                ->innerJoin("machinery_owner","sip.machinery_owner_id=machinery_owner.id")
                ->where("sip.beneficiary_id = machinery_owner.beneficiary_id");
//                ->where("sip.machinery_owner_id = sip.beneficiary_id");
                if($year_month){
                    $query = $query->andWhere("DATE_FORMAT(activity_date, '%Y-%m') < '".$year_month."' OR DATE_FORMAT(activity_date, '%Y-%m') = '".$year_month."'");
                }
        $command = $query->createCommand();
        $Output = $command->queryAll();
        $primary = count($Output) > 0 ? floatval($Output[0]['totalArea']) : 0;
        /**/
        $query = new \yii\db\Query;
        $query->select([
                    "SUM(sip.area) as totalArea"
                ])
                ->from('sip')
                ->innerJoin("machinery_owner","sip.machinery_owner_id=machinery_owner.id")
                ->where("sip.beneficiary_id != machinery_owner.beneficiary_id")
                //->where("sip.machinery_owner_id != sip.beneficiary_id")
                ->andWhere("DATE_FORMAT(activity_date, '%Y-%m') < '".$year_month."' OR DATE_FORMAT(activity_date, '%Y-%m') = '".$year_month."'");      
        $command = $query->createCommand();
        $Output = $command->queryAll();
        $secondary = count($Output) > 0 ? floatval($Output[0]['totalArea']) : 0;
        return $primary+$secondary;
        
    }
    public function getPrimaryBeneficiarySolarIrrigationSavings($year_month) {
        
        $query = new \yii\db\Query;
        $query->select([
                    "SUM(sip.area * 900) as totalArea"
                ])
                ->from('sip')
                ->innerJoin("machinery_owner","sip.machinery_owner_id=machinery_owner.id")
                ->where("sip.beneficiary_id = machinery_owner.beneficiary_id");
//                ->where("sip.machinery_owner_id = sip.beneficiary_id");
        if($year_month){
            $query = $query->andWhere(["DATE_FORMAT(sip.activity_date, '%Y-%m')"=>$year_month]);
        }
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['totalArea']) : 0;
    }
    
    public function getSolarIrrigationOverallSavings() {
        
        $query = new \yii\db\Query;
        $query->select([
                    "SUM(sip.area * 900) as totalArea"
                ])
                ->from('sip')
                ->innerJoin("machinery_owner","sip.machinery_owner_id=machinery_owner.id")
                ->where("sip.beneficiary_id = machinery_owner.beneficiary_id");
//                ->where("sip.machinery_owner_id = sip.beneficiary_id");
        if($year_month){
            $query = $query->andWhere(["DATE_FORMAT(sip.activity_date, '%Y-%m')"=>$year_month]);
        }
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['totalArea']) : 0;
    }
    public function getSecondaryBeneficiarySolarIrrigationSavings($year_month) {
        $query = new \yii\db\Query;
        $query->select([
                    "SUM(sip.area * 600) as totalArea"
                ])
                ->from('sip')
                ->innerJoin("machinery_owner","sip.machinery_owner_id=machinery_owner.id")
                ->where("sip.beneficiary_id != machinery_owner.beneficiary_id")
//                ->where("sip.machinery_owner_id != sip.beneficiary_id")
                ->andWhere(["DATE_FORMAT(activity_date, '%Y-%m')"=>$year_month]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['totalArea']) : 0;
    }
    public function getTotalMonthlySolarIrrigationSavings($year_month) {
        $query = new \yii\db\Query;
        $query->select([
                    "SUM(sip.area) as totalArea"
                ])
                ->from('sip')
                ->andWhere(["DATE_FORMAT(activity_date, '%Y-%m')"=>$year_month]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['totalArea']) : 0;
    }
//    vrin
    public function getYearTillDateSolarIrrigationSavings($year_month) {
        
        $query = new \yii\db\Query;
        $query->select([
                    "SUM(sip.area * 900) as totalArea"
//                    "SUM(sip.area) as totalArea"
                ])
                ->from('sip')
                ->innerJoin("machinery_owner","sip.machinery_owner_id=machinery_owner.id")
                ->where("sip.beneficiary_id = machinery_owner.beneficiary_id");
//                 ->where("sip.machinery_owner_id = sip.beneficiary_id");
                if($year_month){
                    $query = $query->andWhere("DATE_FORMAT(activity_date, '%Y-%m') < '".$year_month."' OR DATE_FORMAT(activity_date, '%Y-%m') = '".$year_month."'");
                }        

        $command = $query->createCommand();
        $Output = $command->queryAll();
        $primary = count($Output) > 0 ? intval($Output[0]['totalArea']) : 0;
//        /**/
        $query = new \yii\db\Query;
        $query->select([
                    "SUM(sip.area * 600) as totalArea"
                ])
                ->from('sip')
                ->innerJoin("machinery_owner","sip.machinery_owner_id=machinery_owner.id")
                ->where("sip.beneficiary_id != machinery_owner.beneficiary_id")
//                ->where("sip.machinery_owner_id != sip.beneficiary_id")
                ->andWhere("DATE_FORMAT(activity_date, '%Y-%m') < '".$year_month."' OR DATE_FORMAT(activity_date, '%Y-%m') = '".$year_month."'");   
        $command = $query->createCommand();
        $Output = $command->queryAll();
        $secondary = count($Output) > 0 ? intval($Output[0]['totalArea']) : 0;
        return $primary+$secondary;
    }
//    nnv
    public function getSumOfArea($table,$val,$column,$condition,$year_month=FALSE){
       $query = new \yii\db\Query;
        $query->select([
                    "SUM(".$column." * $val) as total"
                ])
                ->from($table);
        if($condition){
            $query = $query->where($condition);
        }
        if($year_month){
            $query = $query->andWhere(["DATE_FORMAT(activity_date, '%Y-%m')"=>$year_month]);
        }        
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? floatval($Output[0]['total']) : 0; 
    }
    
     public function getSumOfFarmMechanizationArea($table,$column,$value,$year_month=FALSE){
       $query = new \yii\db\Query;
        $query->select([
                    "SUM(".$column." * $value) as total"
                ])
                ->from($table);
//        if($condition){
//            $query = $query->where($condition);
//        }
        if($year_month){
            $query = $query->andWhere(["DATE_FORMAT(activity_date, '%Y-%m')"=>$year_month]);
        }        
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? floatval($Output[0]['total']) : 0; 
    }
    
    public function getSumOfFarmMechanizationAreaOfZeroTillage($year_month=FALSE){
       $query = new \yii\db\Query;
        $query->select([
                    "SUM(area) as area",
                    "crop.crop as cropName"
                ])
                ->from("fm_zt")
                ->innerJoin("crop", "crop.id = fm_zt.crop_id");
        if($year_month){
            $query = $query->andWhere(["DATE_FORMAT(activity_date, '%Y-%m')"=>$year_month]);
        }
//        if($year_month){
//            $query = $query->andWhere("DATE_FORMAT(activity_date, '%Y-%m') < '".$year_month."' OR DATE_FORMAT(activity_date, '%Y-%m') = '".$year_month."'");
//        }
        $query = $query->groupBy("fm_zt.crop_id");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output; 
    }
//    
     public function getSumOfFarmMechanizationAreaOfZeroTillagePtd($year_month=FALSE){
       $query = new \yii\db\Query;
        $query->select([
                    "SUM(area) as area",
                    "crop.crop as cropName"
                ])
                ->from("fm_zt")
                ->innerJoin("crop", "crop.id = fm_zt.crop_id");
        if($year_month){
            $query = $query->andWhere("DATE_FORMAT(activity_date, '%Y-%m') < '".$year_month."' OR DATE_FORMAT(activity_date, '%Y-%m') = '".$year_month."'");
        }
        $query = $query->groupBy("fm_zt.crop_id");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output; 
    }
    public function getYearTillDateFarmMechanization($table,$column,$value,$year_month=FALSE){
       $query = new \yii\db\Query;
        $query->select([
                    "SUM(".$column." * $value) as total"
                ])
                ->from($table);
        if($year_month){
            $query = $query->andWhere("DATE_FORMAT(activity_date, '%Y-%m') < '".$year_month."' OR DATE_FORMAT(activity_date, '%Y-%m') = '".$year_month."'");
        }        
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? floatval($Output[0]['total']) : 0; 
    }
//    getSumOfAreaOfZeroTillage
    public function getPumpDetailsByMachinerId($machinery_id){
        $query = new \yii\db\Query;
        $query->select([
                    "machinery_code_mapping.id as mcm_id",
                    "machinery_code_mapping.machinery_id",
                    "machinery_owner.id as machinery_owner_id",
                    "machinery_code_mapping.machine_code",
                    "beneficiary.id as beneficiary_id",
                    "beneficiary.beneficiary_name",
                    "village.village"
                ])
                ->from('machinery_code_mapping')
                ->innerJoin("machinery_owner", "machinery_owner.mcm_id = machinery_code_mapping.id")
                ->innerJoin("beneficiary", "beneficiary.id = machinery_owner.beneficiary_id")
                ->innerJoin("village","village.id = beneficiary.village_id")
                ->where(["machinery_code_mapping.machinery_id"=>$machinery_id]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output; 
    }
    public function getCountOfSecondaryBeneficiary($table,$primaryBeneficiaries,$machinery_owner_id,$year_month){
        $ids = join("','",$primaryBeneficiaries);
        $query = new \yii\db\Query;
        $query->select([ 
            "COUNT(beneficiary_id) as beneficiary_id",
        ])
        ->from($table)
        ->where("beneficiary_id NOT IN ('".$ids."')")
        ->andWhere(["machinery_owner_id"=>$machinery_owner_id])
//        if($year_month){
//            $query = $query->andWhere(["DATE_FORMAT(activity_date, '%Y-%m')"=>$year_month]);
//        }        
        ->andWhere(["DATE_FORMAT(activity_date,'%Y-%m')"=>$year_month]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['beneficiary_id']) : 0; 
    }
    
    
    public function getPrimaryArea($table,$primaryBeneficiaries,$machinery_owner_id = FALSE,$year_month){
        $ids = join("','",$primaryBeneficiaries);
        $query = new \yii\db\Query;
        $query->select([ 
            "SUM(area) as area",
            
        ])
        ->from($table)
        ->where("beneficiary_id IN ('".$ids."')");
        if($machinery_owner_id){
            $query = $query->andWhere(["machinery_owner_id"=>$machinery_owner_id]);
        }
        $query = $query->andWhere(["DATE_FORMAT(activity_date,'%Y-%m')"=>$year_month]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        //display_array($Output);
        return count($Output) > 0 ? floatval($Output[0]['area']) : 0; 
    }
    public function getSecondaryArea($table,$primaryBeneficiaries,$machinery_owner_id = FALSE,$year_month){
        $ids = join("','",$primaryBeneficiaries);
        $query = new \yii\db\Query;
        $query->select([ 
            "SUM(area) as area"
        ])
        ->from($table)
        ->where("beneficiary_id NOT IN ('".$ids."')");
        if($machinery_owner_id){
            $query = $query->andWhere(["machinery_owner_id"=>$machinery_owner_id]);
        }
        if($year_month){
            $query = $query->andWhere(["DATE_FORMAT(activity_date, '%Y-%m')"=>$year_month]);
        }
        //->andWhere(["DATE_FORMAT(activity_date,'%Y-%m')"=>$year_month]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        //display_array($Output);exit;
        return count($Output) > 0 ? floatval($Output[0]['area']) : 0; 
    }
}
