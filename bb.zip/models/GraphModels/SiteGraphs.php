<?php

namespace backend\models\GraphModels;

class SiteGraphs {

    public function getGeographicalGenderDistribution() {
        $query = new \yii\db\Query;
        $query->select([
                    "COUNT(id) AS countOfMale"
                ])
                ->from("beneficiary")
                ->where(["gender" => 'male']);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output;
    }

    public function getCountOfBoys($tableName) {
        $query = new \yii\db\Query;
        $query->select([
                    // "beneficiary.gender",
                    "COUNT('boys_count') as count"
                ])
                ->from($tableName);
        // ->groupBy("beneficiary.gender");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['count']) : 0;
    }

    public function getCountOfGirls($tableName) {
        $query = new \yii\db\Query;
        $query->select([
                    // "beneficiary.gender",
                    "COUNT('girls_count') as count"
                ])
                ->from($tableName);
        // ->groupBy("beneficiary.gender");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['count']) : 0;
    }

    // created by anup on 23-09-2017

    public function getDataOrchardEstablishment($crop = null) {
        $query = new \yii\db\Query;
        $query->select([
                    "DATE_FORMAT(activity_date, '%Y') year",
                    "SUM(diversification_area) as totalArea",
                    "SUM(plant) as totalPlants",
                    "crop.crop as cropName"
                ])
                ->from('orchard_establishment')
                ->innerJoin("crop", "crop.id = orchard_establishment.crop_id");
        if ($crop != NULL) {
            $query->where(["crop_id" => $crop]);
        }
        $query->groupBy("year");
        $command = $query->createCommand();
        $Output = $command->queryAll();
//        display_array($Output);exit;
        return $Output;
    }

    //START OF API FOR: Crop Diversification Report data
    public function getOrchardEstablishmentReportData() {
        $query = new \yii\db\Query;
        $query->select([
                    "DATE_FORMAT(orchard_establishment.activity_date, '%M') AS monthName",
                    "DATE_FORMAT(orchard_establishment.activity_date, '%Y') AS yearName",
                    "DATE_FORMAT(orchard_establishment.activity_date,'%y%m') as monthYear",
                    "crop.crop as cropName",
                    "COUNT(orchard_establishment.beneficiary_id) AS beneficiary",
                    "SUM(orchard_establishment.diversification_area) as areaSum"
                ])
                ->from('orchard_establishment')
                ->join("INNER JOIN", "crop", "crop.id=orchard_establishment.crop_id")
                ->groupBy("cropName,monthYear");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output;
    }

    //END OF API FOR: Crop Diversification Report data
    //Common Function to get Average Productivity for Crop Demonstration, Stacking and Mulching ...
    public function getDataAverageProductivityByCommonFunction($crop = null, $table) {
        $query = new \yii\db\Query;
        $query->select([
                    "DATE_FORMAT(" . $table . ".activity_date, '%Y') year",
                    "(SUM(" . $table . ".dp_yeld)/ COUNT(" . $table . ".dp_yeld))as demoPlot",
                    "(SUM(" . $table . ".cp_yeld)/ COUNT(" . $table . ".cp_yeld))as controlPlot",
                    "crop.crop as cropName"
                ])
                ->from($table)
                ->innerJoin("crop", "crop.id = " . $table . ".crop_id");
        if ($crop != NULL) {
            $query->where([$table . ".crop_id" => $crop]);
            $query->andWhere(['!=', $table . ".dp_yeld", 0]);
            $query->andWhere(['!=', $table . ".cp_yeld", 0]);
        }
        $query->andWhere(['!=', $table . ".dp_yeld", 0]);
        $query->andWhere(['!=', $table . ".cp_yeld", 0]);
        $query->groupBy("year");

        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output;
    }

//    End Of: Stacking Average Productivity


    public function getDataCropDemonstrationYearList() {
        $query = new \yii\db\Query;
        $query->select([
                    "DATE_FORMAT(c_dem.activity_date,'%Y') as seasonYear",
                ])
                ->from('c_dem')
                ->groupBy("seasonYear");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output;
    }

    public function getDataStackingYearList() {
        $query = new \yii\db\Query;
        $query->select([
                    "DATE_FORMAT(activity_date,'%Y') as seasonYear",
                ])
                ->from('stacking')
                ->groupBy("seasonYear");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output;
    }

    public function getDataMulchingYearList() {
        $query = new \yii\db\Query;
        $query->select([
                    "DATE_FORMAT(activity_date,'%Y') as seasonYear",
                ])
                ->from('mulching')
                ->groupBy("seasonYear");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output;
    }

    public function getPrimarySecondarySolarIrrigationOverallSavings() {
        $query = new \yii\db\Query;
        $query->select([
                    "DATE_FORMAT(sip.activity_date,'%M') as month",
                    "DATE_FORMAT(sip.activity_date,'%Y') as year",
                    "DATE_FORMAT(sip.activity_date,'%m%Y') as monthYear",
                    "(SUM(sip.area * 900) + SUM(sip.area * 600)) as totalArea"
                ])
                ->from('sip')
                ->innerJoin("machinery_owner", "sip.machinery_owner_id=machinery_owner.id")
                ->where("sip.beneficiary_id = machinery_owner.beneficiary_id")
                ->groupBy("monthYear");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output;
    }

    public function getDataCropDemonstration($crop, $year) {
        $query = new \yii\db\Query;
        $query->select([
                    "DATE_FORMAT(activity_date,'%Y') as seasonYear",
                    "AVG(increase_percentage) as percentageIncrease"
                ])
                ->from('c_dem')
                ->where(["crop_id" => $crop])
                ->andWhere(['!=', 'increase_percentage', 0])
                ->andWhere(["DATE_FORMAT(c_dem.activity_date,'%Y')" => $year]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['percentageIncrease']) : 0;
    }

    public function getDataStacking($crop, $year) {
        $query = new \yii\db\Query;
        $query->select([
                    "DATE_FORMAT(activity_date,'%Y') as seasonYear",
                    "AVG(increase_percentage) as percentageIncrease"
                ])
                ->from('stacking')
                ->where(["crop_id" => $crop])
                ->andWhere(['!=', 'increase_percentage', 0])
                ->andWhere(["DATE_FORMAT(stacking.activity_date,'%Y')" => $year]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['percentageIncrease']) : 0;
    }

    public function getDataMulching($crop, $year) {
        $query = new \yii\db\Query;
        $query->select([
                    "DATE_FORMAT(activity_date,'%Y') as seasonYear",
                    "AVG(increase_percentage) as percentageIncrease"
                ])
                ->from('mulching')
                ->where(["crop_id" => $crop])
                ->andWhere(['!=', 'increase_percentage', 0])
                ->andWhere(["DATE_FORMAT(mulching.activity_date,'%Y')" => $year]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['percentageIncrease']) : 0;
    }

    //Start: Common function to get AVG of Increase Marketable Function ....
    public function getDataIncreaseInMarketableByCommonFunction($crop, $table, $year) {
        $query = new \yii\db\Query;
        $query->select([
                    "DATE_FORMAT(activity_date,'%Y') as seasonYear",
                    "AVG(increase_marketable) as percentageMarketable"
                ])
                ->from($table)
                ->where(["crop_id" => $crop])
                ->andWhere(['!=', 'increase_marketable', 0])
                ->andWhere(["DATE_FORMAT(activity_date,'%Y')" => $year]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['percentageMarketable']) : 0;
    }

    //End: Common function to get AVG of Increase Marketable Function ....


    public function getDataCropDemonstrationName($crop, $year) {
        $query = new \yii\db\Query;
        $query->select([
                    "crop.crop as crop_name"
                ])
                ->from('c_dem')
                ->join("INNER JOIN", "crop", "crop.id=$crop")
                ->andWhere(["DATE_FORMAT(c_dem.activity_date,'%Y')" => $year]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output[0]['crop_name'];
    }

    //Start: Common function to get crop name by function passing by table name .. 
    public function getCromNameByCommonFunction($crop, $table, $year) {
        $query = new \yii\db\Query;
        $query->select([
                    "crop.crop as crop_name"
                ])
                ->from($table)
                ->join("INNER JOIN", "crop", "crop.id=$crop")
                ->andWhere(["DATE_FORMAT(" . $table . ".activity_date,'%Y')" => $year]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output[0]['crop_name'];
    }

    //End: Common function to get crop name by function passing by table name .. 
    //START: Function to get crop id from Crop demonstration ....
    public function getDistinctCropIdFromCropDemonstration() {
        $query = new \yii\db\Query;
        $query->select([
                    "DISTINCT(crop_id)"
                ])
                ->from("c_dem");
        $command = $query->createCommand();
        $output = $command->queryAll();
        return $output;
    }

    //END: Function to get crop id from Crop demonstration ....
    //START: Function to get crop id from Stacking....
    public function getDistinctCropIdFromStacking() {
        $query = new \yii\db\Query;
        $query->select([
                    "DISTINCT(crop_id)"
                ])
                ->from("stacking");
        $command = $query->createCommand();
        $output = $command->queryAll();
        return $output;
    }

    //END: Function to get crop id from Stacking ....
    //START: Function to get crop id from Stacking....
    public function getDistinctCropIdFromMulching() {
        $query = new \yii\db\Query;
        $query->select([
                    "DISTINCT(crop_id)"
                ])
                ->from("mulching");
        $command = $query->createCommand();
        $output = $command->queryAll();
        return $output;
    }

    //END: Function to get crop id from Stacking ....

    public function getTargetActivityWise() {
        $query = new \yii\db\Query;
        $query->select([
                    "activity_list.activity_name as activityName",
                    "activity_target.target_activity"
                ])
                ->from('activity_target')
                ->join("INNER JOIN", "activity_list", "activity_list.id=activity_target.activity_id")
                ->groupBy("activity_target.activity_id");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        //display_array($Output);exit;
        return $Output;
    }

    public function getOverallProgramGenderDistributionActivityWise() {
        $query = new \yii\db\Query;
        $query->select([
                    "activity_list.activity_name as activityName"
                ])
                ->from('activity_target')
                ->join("INNER JOIN", "activity_list", "activity_list.id=activity_target.activity_id")
                ->groupBy("activity_target.activity_id");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        //display_array($Output);exit;
        return $Output;
    }

    public function getDistrictName() {
        $query = new \yii\db\Query;
        $query->select([
                    "district as districtName",
                    "id",
                ])
                ->from('district');
        $command = $query->createCommand();
        $Output = $command->queryAll();
        //display_array($Output);exit;
        return $Output;
    }

    public function getTargetBeneficiaryWise() {
        $query = new \yii\db\Query;
        $query->select([
                    "activity_list.activity_name as activityName",
                    "activity_target.target_beneficiary"
                ])
                ->from('activity_target')
                ->join("INNER JOIN", "activity_list", "activity_list.id=activity_target.activity_id")
                ->groupBy("activity_target.activity_id");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        //display_array($Output);exit;
        return $Output;
    }

    //working
    public function getCountOfColumnMember($tableName, $columnName, $isDistinct = "") {
        $query = new \yii\db\Query;
        $query->select([
                    "COUNT(" . $isDistinct . " " . $columnName . ") as count"
                ])
                ->from($tableName);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['count']) : 0;
    }

    public function getCountOfColumnMemberByMale($tableName) {
        $query = new \yii\db\Query;
        $query->select([
                    // "beneficiary.gender",
                    "COUNT('beneficiary.id') as count"
                ])
                ->from($tableName)
                ->innerJoin("beneficiary", "beneficiary.id =" . $tableName . ".beneficiary_id")
                ->where(["beneficiary.gender" => 'male']);
        // ->groupBy("beneficiary.gender");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['count']) : 0;
    }

    public function getCountOfColumnMemberByFemale($tableName) {
        $query = new \yii\db\Query;
        $query->select([
                    "COUNT('beneficiary.id') as count"
                ])
                ->from($tableName)
                ->innerJoin("beneficiary", "beneficiary.id =" . $tableName . ".beneficiary_id")
                ->where(["beneficiary.gender" => 'female']);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['count']) : 0;
    }

// Reports for male female count
//    Create by Anup
    public function getCountOfColumnMemberByMaleWithJoin($male) {
        $query = new \yii\db\Query;
        $query->select([
                    "COUNT('id') as count"
                ])
                ->from("beneficiary")
//                ->innerJoin("beneficiary", "beneficiary.id =" . $tableName . ".beneficiary_id")
//                ->innerJoin("village", "village.id = beneficiary.village_id")
//                ->innerJoin("block", "block.id = village.block_id")
//                ->innerJoin("district", "district.id = block.district_id")
                ->where(["beneficiary.gender" => 'male']);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['count']) : 0;
    }

    public function getCountOfColumnMemberByFemaleWithJoin($female) {
        $query = new \yii\db\Query;
        $query->select([
                    "COUNT('id') as count"
                ])
                ->from("beneficiary")
//                ->innerJoin("beneficiary", "beneficiary.id =" . $tableName . ".beneficiary_id")
//                ->innerJoin("village", "village.id = beneficiary.village_id")
//                ->innerJoin("block", "block.id = village.block_id")
//                ->innerJoin("district", "district.id = block.district_id")
                ->where(["beneficiary.gender" => 'female']);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['count']) : 0;
    }

    public function getCountOfColumnMemberByOthersWithJoin($tableName) {
        $query = new \yii\db\Query;
        $gender = ["female", "male"];
        $query->select([
                    "COUNT('id') as count"
                ])
                ->from($tableName)
//                ->innerJoin("beneficiary", "beneficiary.id =" . $tableName . ".beneficiary_id")
                ->where(["NOT IN", "beneficiary.gender", $gender]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['count']) : 0;
    }

    public function getGenderWiseCountOfActivityDistrict($table, $district) {
//         print_r($district);exit;
        $query = new \yii\db\Query;
        $query->select([
                    "beneficiary.gender",
                    "COUNT('beneficiary.id') as count"
                ])
                ->from($table)
//                ->innerJoin("beneficiary", "beneficiary.id = tbl.beneficiary_id")
                ->innerJoin("village", "village.id = beneficiary.village_id")
                ->innerJoin("block", "block.id = village.block_id")
                ->innerJoin("district", "district.id = block.district_id")
                ->where(["district.id" => $district])
                ->groupBy("beneficiary.gender");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        $arr = [];
        $male = 0;
        $female = 0;
        $other = 0;
        $total = 0;
        //display_array($Output);exit;
        foreach ($Output as $value) {
            if (strtolower($value["gender"]) == "male") {
                $male = $male + intval($value["count"]);
            } else if (strtolower($value["gender"]) == "female") {
                $female = $female + intval($value["count"]);
            } else {
                $other = $other + intval($value["count"]);
            }
        }
        $total = $male + $female + $other;
        $arr = [
            "male" => $male,
            "female" => $female,
            "others" => $other,
            "total" => $total
        ];
        return $arr;
    }

    public function getGenderWiseCountOfActivityBlock($table, $block) {
        $query = new \yii\db\Query;
        $query->select([
                    "beneficiary.gender",
                    "COUNT('beneficiary.id') as count"
                ])
                ->from($table)
//                ->innerJoin("beneficiary", "beneficiary.id = tbl.beneficiary_id")
                ->innerJoin("village", "village.id = beneficiary.village_id")
                ->innerJoin("block", "block.id = village.block_id")
                ->where(["block.id" => $block])
                ->groupBy("beneficiary.gender");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        $arr = [];
        $male = 0;
        $female = 0;
        $other = 0;
        $total = 0;
        //display_array($Output);exit;
        foreach ($Output as $value) {
            if (strtolower($value["gender"]) == "male") {
                $male = $male + intval($value["count"]);
            } else if (strtolower($value["gender"]) == "female") {
                $female = $female + intval($value["count"]);
            } else {
                $other = $other + intval($value["count"]);
            }
        }
        $total = $male + $female + $other;
        $arr = [
            "male" => $male,
            "female" => $female,
            "others" => $other,
            "total" => $total
        ];
        return $arr;
    }

    public function getGenderWiseCountOfActivityByVillage($table, $village) {
        $query = new \yii\db\Query;
        $query->select([
                    "beneficiary.gender",
                    "COUNT('id') as count"
                ])
                ->from($table)
//                ->innerJoin("beneficiary", "beneficiary.id =" . $table . ".beneficiary_id")
                ->where(["beneficiary.village_id" => $village])
                ->groupBy("beneficiary.gender");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        $arr = [];
        $male = 0;
        $female = 0;
        $other = 0;
        $total = 0;
//display_array($Output);exit;
        foreach ($Output as $value) {
            if (strtolower($value["gender"]) == "male") {
                $male = $male + intval($value["count"]);
            } else if (strtolower($value["gender"]) == "female") {
                $female = $female + intval($value["count"]);
            } else {
                $other = $other + intval($value["count"]);
            }
        }
        $total = $male + $female + $other;
        $arr = [
            "male" => $male,
            "female" => $female,
            "others" => $other,
            "total" => $total
        ];
        return $arr;
    }

// End reports for male female count    
//    Exit

    public function getCountOfColumnMemberByCondition($tableName, $columnName = "*", $conditionColumn = null, $condition = null) {
        $query = new \yii\db\Query;
        $query->select([
                    //"COUNT($columnName) as count"
                    "COUNT(" . $columnName . ") as count"
                ])
                ->from($tableName);
        if ($conditionColumn !== null && $condition !== null) {
            $query = $query->andWhere([$conditionColumn => $condition]);
        }
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['count']) : 0;
    }

    public function getValueOfTable($tableName, $columnName) {
        $query = new \yii\db\Query;
        $query->select([
                    "$columnName"
                ])
                ->from($tableName);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? $Output[0] : 0;
    }

    public function getValueOfTableForMLD($tableName, $columnName) {
        $query = new \yii\db\Query;
        $query->select([
                    "$columnName"
                ])
                ->from($tableName);
        $command = $query->createCommand();
        $Output = $command->queryAll();
//        return count($Output)>0?$Output[0]:0;
        return $Output;
    }

    public function getCountOfColumnMemberWithCondition($tableName, $columnName, $condition = "", $val) {
        $query = new \yii\db\Query;
        $query->select([
                    //"COUNT($columnName) as count"
                    "COUNT($columnName) as count"
                ])
                ->from($tableName)
                ->where([$condition => $val]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['count']) : 0;
    }

    public function getCountOfColumnMemberWithConditionOfSoilTesting($columnName, $type, $year = null, $village = null) {
        $query = new \yii\db\Query;
        $query->select([
                    "COUNT($columnName) as count"
                ])
                ->from("soil_testing")
                ->where([$columnName => $type]);
        if ($year) {
            $query = $query->andWhere(["DATE_FORMAT(date_of_sample_collection, '%Y')" => $year]);
        }
        if ($village) {
            $query = $query->innerJoin("beneficiary", "beneficiary.id = soil_testing.beneficiary_id");
            $query = $query->innerJoin("village", "village.id = beneficiary.village_id");
            $query = $query->andWhere(["village.village" => $village]);
        }
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['count']) : 0;
    }

    public function getCountOfMaleWithCondition($tableName, $columnName, $condition = "", $val) {
        $query = new \yii\db\Query;
        $query->select([
                    //"COUNT($columnName) as count"
                    "COUNT($columnName) as count"
                ])
                ->from($tableName)
                ->where([$condition => $val]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['count']) : 0;
    }

    public function getCountOfColumnMemberWithInnerjoin() {
        $query = new \yii\db\Query;
        $query->select([
                    "COUNT(beneficiary.id) as count"
                ])
                ->from('beneficiary')
                ->innerJoin("village", "beneficiary.village_id=village.id");
//            ->where(["village.village_type"=>'non intervention']);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['count']) : 0;
    }

    public function getCountOfColumnMemberWithGroupBy($tableName, $columnName, $table1, $InnerCondition1, $table2, $InnerCondition2, $table3, $InnerCondition3, $groupBy) {
        $query = new \yii\db\Query;
        $query->select([
                    //"COUNT($columnName) as count"
                    "COUNT($columnName) as activity_count"
                ])
                ->from($tableName)
//            ->join(".$joinType.,".$table1.",".$InnerCondition.")
                ->join("INNER JOIN", $table1, $InnerCondition1)
                ->join("INNER JOIN", $table2, $InnerCondition2)
                ->join("INNER JOIN", $table3, $InnerCondition3)
                ->groupBy($groupBy);
        $command = $query->createCommand();
        $Output = $command->queryAll();
//        return count($Output)>0?intval($Output[0]['count']):0;
        return $Output;
    }


      // Created By anup

      public function getCountOfColumnMemberDistnict($tableName, $columnName, $isDistinct = "") {
        $query = new \yii\db\Query;
        $query->select([
                    "COUNT(DISTINCT(" . $isDistinct . " " . $columnName . ")) as count"
                ])
                ->from($tableName);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['count']) : 0;
    }
      public function getCountOfColumnMemberByMaleDistnict($tableName, $columnName, $isDistinct = "") {
        $query = new \yii\db\Query;
        $query->select([
                    "COUNT(DISTINCT(" . $isDistinct . " " . $columnName . ")) as count"
                ])
                ->from($tableName)
                ->innerJoin("beneficiary" ,"beneficiary.id =".$tableName.".beneficiary_id")
                ->where(["beneficiary.gender"=>'male']);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['count']) : 0;
    }

     public function getCountOfColumnMemberByFemaleDistnict($tableName, $columnName, $isDistinct = "") {
        $query = new \yii\db\Query;
        $query->select([
                    "COUNT(DISTINCT(" . $isDistinct . " " . $columnName . ")) as count"
                ])
                ->from($tableName)
                ->innerJoin("beneficiary" ,"beneficiary.id =".$tableName.".beneficiary_id")
                ->where(["beneficiary.gender"=>'female']);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['count']) : 0;
    }

    public function getCountOfColumnMemberBeneficiaryByMale($tableName){
        $query = new \yii\db\Query;
        $query->select([
                "COUNT('beneficiary.id') as count"
            ])
            ->from($tableName)
            ->where(["beneficiary.gender"=>'male']);
        $command = $query->createCommand();
        $Output = $command->queryAll(); 
        return count($Output)>0?intval($Output[0]['count']):0;
    }

    public function getCountOfColumnMemberBeneficiaryByFemale($tableName){
        $query = new \yii\db\Query;
        $query->select([
                "COUNT('beneficiary.id') as count"
            ])
            ->from($tableName)
            ->where(["beneficiary.gender"=>'female']);
        $command = $query->createCommand();
        $Output = $command->queryAll(); 
        return count($Output)>0?intval($Output[0]['count']):0;
    }  
        // End here


    public function getCountOfColumnVillageWiseWithGroupBy($tableName, $columnName, $table1, $InnerCondition1, $table2, $InnerCondition2, $groupBy) {
        $query = new \yii\db\Query;
        $query->select([
                    //"COUNT($columnName) as count"
                    "COUNT($columnName) as activity_count"
                ])
                ->from($tableName)
//            ->join(".$joinType.,".$table1.",".$InnerCondition.")
                ->join("INNER JOIN", $table1, $InnerCondition1)
                ->join("INNER JOIN", $table2, $InnerCondition2)
                ->groupBy($groupBy);
        $command = $query->createCommand();
        $Output = $command->queryAll();
//        return count($Output)>0?intval($Output[0]['count']):0;
        return $Output;
    }

    public function getSumOfColumnMember($tableName, $columnName) {
        $query = new \yii\db\Query;
        $query->select([
                    "SUM($columnName) as sum"
                ])
                ->from($tableName);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? intval($Output[0]['sum']) : 0;
    }

    public function getAnimalNutrientManagement($monthyear) {
        $query = new \yii\db\Query;
        $query->select([
                    "cattle_type",
                    "COUNT(cattle_type) as cattleCount",
                    "DATE_FORMAT(activity_date, '%Y-%m') month",
                ])
                ->from('anm')
                ->where(["DATE_FORMAT(activity_date, '%Y-%m')" => $monthyear])
                ->groupBy('cattle_type');
        $command = $query->createCommand();
        //display_array($command);exit;
        $Output = $command->queryAll();

        return $Output;
    }

    public function getAnimalNutrientManagementTillDate($monthyear) {
        $query = new \yii\db\Query;
        $query->select([
                    "COUNT(cattle_type) as cattleCount",
                    "DATE_FORMAT(activity_date, '%Y-%m') month",
                ])
                ->from('anm')
                ->where("DATE_FORMAT(activity_date, '%Y-%m') < '" . $monthyear . "'" . " OR " . "DATE_FORMAT(activity_date, '%Y-%m') = '" . $monthyear . "'");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? $Output[0] : $Output;
    }

//    nnv
    public function getSaplingRecovery($year) {
        // echo $year;exit;
        $query = new \yii\db\Query;
        $query->select([
                    "crop.crop",
                    "crop.tr_recovery as Traditional",
                    "hvn.activity_date",
                    "SUM(hvn.recovery_percentage)/COUNT(hvn.crop_id) as protected",
                ])
                ->from('hvn')
                ->join("INNER JOIN", "crop", "crop.id = hvn.crop_id");
        if ($year) {
            $query = $query->where("DATE_FORMAT(hvn.activity_date, '%Y') =" . $year);
        }
        $query = $query->groupBy("hvn.crop_id");
        $command = $query->createCommand();
        $Output = $command->queryAll();

        return $Output;
    }

    public function getDataCapacityBuilding($monthyear, $topic) {
        //echo $topic;exit;
        $query = new \yii\db\Query;
        $query->select([
                    "cb.cb_topic_id",
                    "COUNT(cb.beneficiary_id) as benefMonthlyCount",
                    "DATE_FORMAT(cb.activity_date, '%Y-%m') month"
                ])
                ->from('cb')
                ->join("INNER JOIN", "exposure_topic_list", "exposure_topic_list.id = cb.cb_topic_id");
        if ($monthyear) {
            $query = $query->where(["DATE_FORMAT(cb.activity_date, '%Y-%m')" => $monthyear]);
        }
        if ($topic) {
            $query = $query->andWhere(["exposure_topic_list.cb_topic" => $topic]);
        }
        $command = $query->createCommand();
        $Output = $command->queryAll();
        //display_array($Output);exit;
        return count($Output) > 0 ? $Output[0] : $Output;
//        return $Output;
    }

    public function getDataCapacityBuildingTillDate($monthyear, $topic) {
        $query = new \yii\db\Query;
        $query->select([
                    "COUNT(cb.beneficiary_id) as benefPtdCount",
                    "DATE_FORMAT(cb.activity_date, '%Y-%m') month"
                ])
                ->from('cb')
                ->join("INNER JOIN", "exposure_topic_list", "exposure_topic_list.id = cb.cb_topic_id");
        if ($monthyear) {
            $query = $query->where("DATE_FORMAT(cb.activity_date, '%Y-%m') < '" . $monthyear . "'" . " OR " . "DATE_FORMAT(cb.activity_date, '%Y-%m') = '" . $monthyear . "'");
        }
        if ($topic) {
            $query = $query->andWhere(["exposure_topic_list.cb_topic" => $topic]);
        }
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? $Output[0] : $Output;
    }

//    Created by anup on 25-09-2017


    public function getDataEducationByCommonFunction($village = null, $year = null) {
        $query = new \yii\db\Query;
        $query->select([
                    "village.id as village_id",
                    "village.village as village",
                    "boys_count",
                    "girls_count",
                    "total",
                    "education.id as education_id",
                    "education.name"
                ])
                ->from("education")
                ->innerJoin('village', 'village.id = education.village_id');
        if ($village != NULL) {
            $query->where(["village_id" => $village]);
        }
        if ($year) {
            $query = $query->andWhere(["DATE_FORMAT(activity_date, '%Y')" => $year]);
        }
//        $query->andWhere(['!=', $table.".dp_yeld", 0]);
//        $query->andWhere(['!=', $table.".cp_yeld", 0]);
//        $query->groupBy("year");

        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output;
    }

    public function getDataEducationTillDate($monthyear, $village) {
        $query = new \yii\db\Query;
        $query->select([
                    "DATE_FORMAT(education.activity_date, '%Y-%m') month",
                ])
                ->from('education');
        if ($monthyear) {
            $query = $query->where("DATE_FORMAT(education.activity_date, '%Y-%m') < '" . $monthyear . "'" . " OR " . "DATE_FORMAT(education.activity_date, '%Y-%m') = '" . $monthyear . "'");
        }
        if ($village) {
            $query = $query->andWhere(["village_id" => $village]);
        }
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? $Output[0] : $Output;
    }

//   End education




    public function getDataKitchenGarden($monthyear) {
        //echo $monthyear; exit;
        $query = new \yii\db\Query;
        $query->select([
                    "count(beneficiary_id) as benefMonthlyCount",
                    "DATE_FORMAT(activity_date, '%Y-%m') month",
                ])
                ->from('kg')
                ->where(["DATE_FORMAT(activity_date, '%Y-%m')" => $monthyear]);
        $command = $query->createCommand();
        $Output = $command->queryAll();
        //display_array($Output);exit;
        return count($Output) > 0 ? $Output[0] : $Output;
    }

    public function getDataKitchenGardenTillDate($monthyear) {
        $query = new \yii\db\Query;
        $query->select([
                    "count(beneficiary_id) as benefTillDateCount",
                    "DATE_FORMAT(activity_date, '%Y-%m') month",
                ])
                ->from('kg')
                ->where("DATE_FORMAT(activity_date, '%Y-%m') < '" . $monthyear . "'" . " OR " . "DATE_FORMAT(activity_date, '%Y-%m') = '" . $monthyear . "'");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? $Output[0] : $Output;
    }

    public function getAnimalHealthCamp($monthyear) {
        $query = new \yii\db\Query;
        $query->select([
                    "SUM(cow_count) as cowSum",
                    "SUM(buffalo_count) as buffaloSum",
                    "( SUM(ahc.cow_calf) + SUM(ahc.buffalo_calf) + SUM(ahc.bullock) ) as otherSum",
                    "( SUM(ahc.cow_count) + SUM(ahc.buffalo_count) + SUM(ahc.cow_calf) + SUM(ahc.buffalo_calf) + SUM(ahc.bullock) ) as totalSum",
                ])
                ->from('ahc')
                ->where(["DATE_FORMAT(activity_date, '%Y-%m')" => $monthyear]);
        $command = $query->createCommand();
        //display_array($command);exit;
        $Output = $command->queryAll();
        return count($Output) > 0 ? $Output[0] : $Output;
//        return $Output;
    }

    public function getAnimalHealthCampTillDate($monthyear) {
        $query = new \yii\db\Query;
        $query->select([
                    "(SUM(ahc.cow_count) + SUM(ahc.buffalo_count) + SUM(ahc.cow_calf) + SUM(ahc.buffalo_calf) + SUM(ahc.bullock) ) as overallSum",
                    "DATE_FORMAT(activity_date, '%Y-%m') month",
                ])
                ->from('ahc')
                ->where("DATE_FORMAT(activity_date, '%Y-%m') < '" . $monthyear . "'" . " OR " . "DATE_FORMAT(activity_date, '%Y-%m') = '" . $monthyear . "'");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return count($Output) > 0 ? $Output[0] : $Output;
    }

    public function getDataGoatryPromotion($monthyear) {
        $query = new \yii\db\Query;
        $query->select([
                    "count(beneficiary_id) as beneficiaryCount"
                ])
                ->from('gp')
                ->where(["DATE_FORMAT(activity_date, '%Y-%m')" => $monthyear]);
        $command = $query->createCommand();
        //display_array($command);exit;
        $Output = $command->queryAll();
//        display_array($Output);exit;
        return count($Output) > 0 ? $Output[0] : $Output;
    }

    public function getDataGoatryPromotionTillDate($monthyear) {
        $query = new \yii\db\Query;
        $query->select([
                    "count(beneficiary_id) as beneficiaryCount"
                ])
                ->from('gp')
                ->where("DATE_FORMAT(activity_date, '%Y-%m') < '" . $monthyear . "'" . " OR " . "DATE_FORMAT(activity_date, '%Y-%m') = '" . $monthyear . "'");
        $command = $query->createCommand();
        //display_array($command);exit;
        $Output = $command->queryAll();
        //display_array($Output);exit;
        return count($Output) > 0 ? $Output[0] : $Output;
    }

    public function getDataGroupByColumn($table, $column, $grColumn) {
        $query = new \yii\db\Query;
        $query->select([$column])
                ->from($table)
                ->groupBy($grColumn);
        $command = $query->createCommand();
        return $command->queryAll();
    }

    //START OF API FOR: REPORT 
    //
    //START OF API FOR: Capacity Building Report data
    public function getCapacityBuildingReportData() {
        $query = new \yii\db\Query;
        $query->select([
                    "DATE_FORMAT(exposure_topic_list.topic_date, '%M') AS monthName",
                    "DATE_FORMAT(exposure_topic_list.topic_date, '%Y') AS yearName",
//                "exposure_topic_list.cb_topic AS exposureList",
                    "cbtopic.topic_name as exposureList",
                    "count(cb.beneficiary_id) AS benificiary",
                    "count(DISTINCT(exposure_topic_list.topic_date)) AS exposureTopicCount",
                    "village.village as villageName",
                    "village.village_type as villageType"
                ])
                ->from('cb')
                ->join("INNER JOIN", "exposure_topic_list", "exposure_topic_list.id = cb.cb_topic_id")
                ->join("INNER JOIN", "beneficiary", "beneficiary.id=cb.beneficiary_id")
                ->join("INNER JOIN", "village", "village.id=beneficiary.village_id")
                ->join("INNER JOIN", "cbtopic", "cbtopic.id = exposure_topic_list.cb_topic")
                ->groupBy("monthName,yearName,exposureList");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output;
    }

    //END OF API FOR: Capacity Building Report data
    public function getEducationReportData() {
        $query = new \yii\db\Query;
//        ccc
        $query->select([
                    "DATE_FORMAT(education.activity_date, '%M') AS monthName",
                    "DATE_FORMAT(education.activity_date, '%Y') AS yearName",
//                "exposure_topic_list.cb_topic AS exposureList",
                    "village_id",
                    "name",
                    "boys_count",
                    "girls_count",
                    "total"
                ])
                ->from('education');
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output;
    }

    public function getDataFromCommonFunction($table) {
        $query = new \yii\db\Query;
        $query->select([
                    "DATE_FORMAT(" . $table . ".activity_date,'%M') AS monthName",
                    "DATE_FORMAT(" . $table . ".activity_date,'%Y') AS yearName",
                    "DATE_FORMAT(" . $table . ".activity_date,'%y%m') as monthYear",
                    "machinery.machinery_name as machineName",
                    "crop.crop as cropName",
                    "COUNT(" . $table . ".beneficiary_id) as farmerCovered",
                    "SUM(" . $table . ".area) as areaCovered",
                    "(SUM(" . $table . ".area) * 25) as TotalSaving",
                ])
                ->from($table)
                ->join("INNER JOIN", "machinery_owner", "machinery_owner.id=" . $table . ".machinery_owner_id")
                ->join("INNER JOIN", "machinery_code_mapping", "machinery_code_mapping.id=machinery_owner.mcm_id")
                ->join("INNER JOIN", "machinery", "machinery.id=machinery_code_mapping.machinery_id")
                ->join("INNER JOIN", "crop", "crop.id=" . $table . ".crop_id")
                ->groupBy("cropName,monthYear");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output;
    }

    //END OF API FOR: Spray Machine Report data
    //START : Crop Demonstration Report data ... 
    public function getCropDemonstrationData() {
        $query = new \yii\db\Query;
        $query->select([
                    "CONCAT(c_dem.crop_seasons,'-' ,DATE_FORMAT(c_dem.activity_date,'%Y')) as seasonYear",
                    "crop.crop as cropName",
                    "COUNT(c_dem.crop_seasons) as seasonCount",
                    "(SUM(c_dem.dp_yeld)/COUNT(c_dem.dp_yeld)) - (SUM(c_dem.cp_yeld)/COUNT(c_dem.cp_yeld)) as increaseInYield",
                    "((SUM(c_dem.dp_yeld)/COUNT(c_dem.dp_yeld)) - (SUM(c_dem.cp_yeld)/COUNT(c_dem.cp_yeld)))/(SUM(c_dem.cp_yeld)/COUNT(c_dem.cp_yeld)) * 100 as percentageIncrease",
                ])
                ->from('c_dem')
                ->join("INNER JOIN", "crop", "crop.id=c_dem.crop_id")
                ->groupBy("c_dem.crop_seasons,c_dem.crop_id,seasonYear");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output;
    }

    //END: Crop Demonstration Report data ....

    //START : LAser Leveler Report data by Anup on date 23-09-2017... 
    public function getLaserLevelerData() {
        $query = new \yii\db\Query;
        $query->select([
                    "CONCAT(c_dem.crop_seasons,'-' ,DATE_FORMAT(c_dem.activity_date,'%Y')) as seasonYear",
                    "crop.crop as cropName",
                    "COUNT(c_dem.crop_seasons) as seasonCount",
                    "(SUM(c_dem.dp_yeld)/COUNT(c_dem.dp_yeld)) - (SUM(c_dem.cp_yeld)/COUNT(c_dem.cp_yeld)) as increaseInYield",
                    "((SUM(c_dem.dp_yeld)/COUNT(c_dem.dp_yeld)) - (SUM(c_dem.cp_yeld)/COUNT(c_dem.cp_yeld)))/(SUM(c_dem.cp_yeld)/COUNT(c_dem.cp_yeld)) * 100 as percentageIncrease",
                ])
                ->from('c_dem')
                ->join("INNER JOIN", "crop", "crop.id=c_dem.crop_id")
                ->groupBy("c_dem.crop_seasons,c_dem.crop_id,seasonYear");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output;
    }

    //END: Lase Leveler Report data by Anup on date 23-09-2017... 
    //START : Data From Common For Stacking Or Mulching By Table Name ... 
    public function getDataFromCommonForStackingOrMulchingByTableName($table) {
        $query = new \yii\db\Query;
        $query->select([
                    "CONCAT(" . $table . ".crop_seasons,'-' ,DATE_FORMAT(" . $table . ".activity_date,'%Y')) as seasonYear",
                    "crop.crop as cropName",
                    "COUNT(" . $table . ".crop_seasons) as seasonCount",
                    "(SUM(" . $table . ".dp_yeld)/COUNT(" . $table . ".dp_yeld)) - (SUM(" . $table . ".cp_yeld)/COUNT(" . $table . ".cp_yeld)) as increaseInYield",
                    "((SUM(" . $table . ".dp_yeld)/COUNT(" . $table . ".dp_yeld)) - (SUM(" . $table . ".cp_yeld)/COUNT(" . $table . ".cp_yeld)))/(SUM(" . $table . ".cp_yeld)/COUNT(" . $table . ".cp_yeld)) * 100 as percentageIncrease",
                    "(((SUM(" . $table . ".dp_marketable)/COUNT(" . $table . ".dp_marketable)) - (SUM(" . $table . ".cp_marketable)/COUNT(" . $table . ".cp_marketable))) / (SUM(" . $table . ".cp_marketable)/COUNT(" . $table . ".cp_marketable))) * 100 as increaseInMarketable"
                ])
                ->from($table)
                ->join("INNER JOIN", "crop", "crop.id=" . $table . ".crop_id")
                ->groupBy($table . ".crop_seasons," . $table . ".crop_id,seasonYear");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output;
    }

    //END: Data From Common For Stacking Or Mulching By Table Name ..

    //Laser Leveler Report .. 
    public function getLaserLevelerReportData() {
        $query = new \yii\db\Query;
        $query->select([
                    "DATE_FORMAT(fm_ll.activity_date,'%M') AS monthName",
                    "DATE_FORMAT(fm_ll.activity_date,'%Y') AS yearName",
                    "DATE_FORMAT(fm_ll.activity_date,'%y%m') as monthYear",
                    "machinery.machinery_name as machineName",
                    "COUNT(fm_ll.beneficiary_id) as farmerCovered",
                    "SUM(fm_ll.area) as areaCovered",
                ])
                ->from('fm_ll')
                ->join("INNER JOIN", "machinery_owner", "machinery_owner.id=fm_ll.machinery_owner_id")
                ->join("INNER JOIN", "machinery_code_mapping", "machinery_code_mapping.id=machinery_owner.mcm_id")
                ->join("INNER JOIN", "machinery", "machinery.id=machinery_code_mapping.machinery_id")
                ->groupBy("monthYear");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output;
    }

    //Get Report data Project Level ... 
    public function getProjectLevel() {
        $query = new \yii\db\Query;
        $query->select([
                    "ROUND((SUM(soil_moisture) / COUNT(soil_moisture)),2) as avg_of_soil_moisture",
                    "ROUND((SUM(water_table) / COUNT(water_table)),2) as avg_of_water_table"
                ])
                ->from("tracking");
        $command = $query->createCommand();
        $Output = $command->queryAll();
        return $Output;
    }

    //END
    //Get Report data Block Wise, Dam Wise, Tracking Point Wise, Tracking wise  
    public function getReportData($id, $type) {
        $query = new \yii\db\Query;
        $query->select([
                    "soil_moisture",
                    "water_table"
                ])
                ->from("tracking");

        //Join and Where Clause for Block level Data ...
        if ($type == "block") {
            $query->innerJoin("tracking_point", "tracking_point.id = tracking.tracking_point_id");
            $query->innerJoin("dam_profiling", "dam_profiling.id = tracking_point.dam_profiling_id");
            $query->innerJoin("village", "village.id = dam_profiling.village_id");
            $query->innerJoin("block", "block.id = village.block_id");
            $query->where(["block.id" => $id]);
        }

        //Join and Where Clause for Dam Profiling level Data ...
        if ($type == "dam_profiling") {
            $query->innerJoin("tracking_point", "tracking_point.id = tracking.tracking_point_id");
            $query->innerJoin("dam_profiling", "dam_profiling.id = tracking_point.dam_profiling_id");
            $query->where(["dam_profiling.id" => $id]);
        }

        //Join and Where clause for Tracking Point Data ... 
        if ($type == "tracking_point") {
            $query->innerJoin("tracking_point", "tracking_point.id = tracking.tracking_point_id");
            $query->where(["tracking_point.id" => $id]);
        }

        //Where clause for Tracking Data ... 
        if ($type == "tracking") {
            $query->where(["tracking.id" => $id]);
        }

        $command = $query->createCommand();
        $Output = $command->queryAll();


        //Calculate Average of Soil_moisture and Water_table ... 
        $arr = [];
        $count = 0;
        $soil = 0;
        $water = 0;
        foreach ($Output as $value) {
            $soil = $soil + floatval($value["soil_moisture"]);
            $water = $water + floatval($value["water_table"]);
            $count ++;
        }
        if ($count != 0) {
            $arr = [
                "soil" => ($soil / $count),
                "water" => ($water / $count)
            ];
        } else {
            $arr = [
                "soil" => ($soil / 1),
                "water" => ($water / 1)
            ];
        }
        return $arr;
    }

    //END
}
