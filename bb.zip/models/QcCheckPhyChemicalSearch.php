<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\QcCheckPhyChemical;

/**
 * QcCheckPhyChemicalSearch represents the model behind the search form of `app\models\QcCheckPhyChemical`.
 */
class QcCheckPhyChemicalSearch extends QcCheckPhyChemical
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id'], 'integer'],
            [['type', 'nature', 'category', 'name', 'option_1', 'option_2', 'status', 'entry_type', 'created_at', 'updated_at','product_id','order_wise'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = QcCheckPhyChemical::find()->joinWith('product');

        // add conditions that should always apply here
       // echo "<pre>";
        //print_r($params);
        //exit;
        $dataProvider = new ActiveDataProvider([
           'query' => $query,
           'sort'=> ['defaultOrder' => ['id' => SORT_DESC]]
       ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'qc_check_phy_chemical.id' => $this->id,
           // 'category.category_name' =>$this->category, 
            'qc_check_phy_chemical.created_at' => $this->created_at,
            'qc_check_phy_chemical.updated_at' => $this->updated_at,
        ]);

        $query->andFilterWhere(['like', 'qc_check_phy_chemical.type', $this->type])
            ->andFilterWhere(['like', 'nature', $this->nature])
            ->andFilterWhere(['like', 'product.name', $this->product_id])
            ->andFilterWhere(['like', 'qc_check_phy_chemical.category', $this->category])
            ->andFilterWhere(['like', 'qc_check_phy_chemical.name', $this->name])
            ->andFilterWhere(['like', 'qc_check_phy_chemical.option_1', $this->option_1])
            ->andFilterWhere(['like', 'qc_check_phy_chemical.option_2', $this->option_2])
            ->andFilterWhere(['like', 'qc_check_phy_chemical.status', $this->status])
            ->andFilterWhere(['like', 'qc_check_phy_chemical.entry_type', $this->entry_type]);

        return $dataProvider;
    }
}
