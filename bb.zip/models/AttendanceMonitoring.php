<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "attendance_monitoring".
 *
 * @property int $id
 * @property string $unique_id
 * @property int $nandghar_id
 * @property string $visit_time
 * @property string $child_status
 * @property string $attendance_date
 * @property string $updated_at
 * @property string $created_at
 * @property int $status
 */
class AttendanceMonitoring extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'attendance_monitoring';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['nandghar_id', 'status'], 'integer'],
            [['child_status'], 'string'],
            [['attendance_date', 'updated_at', 'created_at'], 'safe'],
            [['unique_id', 'visit_time'], 'string', 'max' => 100],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'unique_id' => 'Unique ID',
            'nandghar_id' => 'Nandghar',
            'visit_time' => 'Visit Time',
            'child_status' => 'Child Status',
            'attendance_date' => 'Attendance Date',
            'updated_at' => 'Updated At',
            'created_at' => 'Created At',
            'status' => 'Status',
        ];
    }

}
