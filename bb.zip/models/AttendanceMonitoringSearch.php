<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\AttendanceMonitoring;

/**
 * AttendanceMonitoringSearch represents the model behind the search form of `app\models\AttendanceMonitoring`.
 */
class AttendanceMonitoringSearch extends AttendanceMonitoring
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'status'], 'integer'],
            [['unique_id', 'visit_time', 'child_status', 'attendance_date', 'updated_at', 'created_at','nandghar_id'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = AttendanceMonitoring::find()
        ->leftJoin("nandghar","nandghar.id = attendance_monitoring.nandghar_id");
          if(isset($_REQUEST['AttendanceMonitoringSearch']['attendance_date']) && $_REQUEST['AttendanceMonitoringSearch']['attendance_date'] != "")
          {
            $query->andFilterWhere(['date_format(attendance_monitoring.attendance_date,"%d/%m/%Y")'=> $_REQUEST['AttendanceMonitoringSearch']['attendance_date']]);
          }
        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            // 'nandghar_id' => $this->nandghar_id,
            // 'attendance_date' => $this->attendance_date,
            'updated_at' => $this->updated_at,
            'created_at' => $this->created_at,
            'status' => $this->status,
        ]);

        $query->andFilterWhere(['like', 'unique_id', $this->unique_id])
            ->andFilterWhere(['like', 'visit_time', $this->visit_time])
            ->andFilterWhere(['like', 'nandghar.nandghar_center_name', $this->nandghar_id])
            ->andFilterWhere(['like', 'child_status', $this->child_status]);

        return $dataProvider;
    }
}
