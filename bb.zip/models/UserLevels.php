<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "user_levels".
 *
 * @property integer $id
 * @property string $level_name
 * @property integer $status
 * @property string $created_at
 * @property string $updated_at
 *
 * @property Users[] $users
 */
class UserLevels extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'user_levels';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['created_at', 'updated_at'], 'safe'],
            [['level_name'], 'string', 'max' => 100],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'level_name' => 'Level',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsers()
    {
        return $this->hasMany(Users::className(), ['level_id' => 'id']);
    }
}
