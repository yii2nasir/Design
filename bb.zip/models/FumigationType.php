<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "fumigation_type".
 *
 * @property int $fumigation_type_id
 * @property int $fumigation_days
 * @property string $created_at
 * @property string $updated_at
 */
class FumigationType extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'fumigation_type';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            // [['fumigation_days', 'created_at', 'updated_at'], 'required'],
            [['fumigation_days','sub_sub_category_id','rpc_ids','product_ids'], 'required'],
            [['fumigation_days'], 'integer'],
            [['rpc_ids', 'product_ids'], 'string'],
            [['fumigation_type_name'], 'string'],
            [['created_at', 'updated_at', 'rpc_ids', 'product_ids', 'sub_sub_category_id'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'fumigation_type_id' => 'Fumigation Type ID',
            'fumigation_days' => 'Fumigation Days',
            'sub_sub_category_id' => 'Sub Sub Category',
            'rpc_ids' => 'RPC',
            'product_ids' => 'Product',
            'fumigation_type_name' => 'Fumigation Type Name',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
}
