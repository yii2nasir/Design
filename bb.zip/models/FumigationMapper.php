<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "fumigation_mapper".
 *
 * @property int $id
 * @property int $fumigation_id
 * @property int $product_id
 * @property string $batch_id
 * @property string $available_qty
 * @property int $quantity_value
 *
 * @property Product $product
 * @property Fumigation $fumigation
 */
class FumigationMapper extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'fumigation_mapper';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            // [['fumigation_id', 'product_id', 'batch_id', 'available_qty', 'quantity_value'], 'required'],
            [['fumigation_id', 'product_id'], 'integer'],
            [['batch_id'], 'string', 'max' => 100],
            [['incoming_qc_uniq_id','available_qty','quantity_value','remaining_quantity','fumigation_complete','fumigation_unique_id'],'safe'],
            [['product_id'], 'exist', 'skipOnError' => true, 'targetClass' => Product::className(), 'targetAttribute' => ['product_id' => 'id']],
            [['fumigation_id'], 'exist', 'skipOnError' => true, 'targetClass' => Fumigation::className(), 'targetAttribute' => ['fumigation_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'fumigation_id' => 'Fumigation ID',
            'product_id' => 'Product ID',
            'batch_id' => 'Batch ID',
            'available_qty' => 'Available Qty',
            'quantity_value' => 'Quantity Value',
            'incoming_qc_uniq_id'=>'Incoming QC uniq id',
            'remaining_quantity'=>'Remainisng Quantity',
            'cleaning_status' =>'Cleaning Status',
            'fumigation_unique_id'=>'Fumigation unique id'
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProduct()
    {
        return $this->hasOne(Product::className(), ['id' => 'product_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getFumigation()
    {
        return $this->hasOne(Fumigation::className(), ['id' => 'fumigation_id']);
    }
}
