<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Cleaning;

/**
 * CleaningSearch represents the model behind the search form of `app\models\Cleaning`.
 */
class CleaningSearch extends Cleaning
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'user_id'], 'integer'],
            [['unique_id', 'fumigation_uniq_id', 'cleaning_checklist', 'overall_status', 'status', 'latitude', 'logtitude', 'mobile_created_at', 'entry_type', 'created_at', 'updated_at'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Cleaning::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'user_id' => $this->user_id,
            'mobile_created_at' => $this->mobile_created_at,
            'created_at' => $this->created_at,
        ]);

        $query->andFilterWhere(['like', 'unique_id', $this->unique_id])
            ->andFilterWhere(['like', 'fumigation_uniq_id', $this->fumigation_uniq_id])
            ->andFilterWhere(['like', 'cleaning_checklist', $this->cleaning_checklist])
            ->andFilterWhere(['like', 'overall_status', $this->overall_status])
            ->andFilterWhere(['like', 'status', $this->status])
            ->andFilterWhere(['like', 'latitude', $this->latitude])
            ->andFilterWhere(['like', 'logtitude', $this->logtitude])
            ->andFilterWhere(['like', 'entry_type', $this->entry_type])
            ->andFilterWhere(['like', 'updated_at', $this->updated_at]);

        return $dataProvider;
    }
}
