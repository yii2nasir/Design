<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "fg_qc_check".
 *
 * @property int $id
 * @property string $unique_id
 * @property string $qc_check_uniq_id
 * @property string $cleaning_uniq_id
 * @property string $batch_Id
 * @property string $overall_status
 * @property string $status
 * @property string $latitude
 * @property string $logtitude
 * @property string $entry_type
 * @property string $created_at
 * @property string $updated_at
 * @property string $mobile_created_at
 */
class FgQcCheck extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */

  

    public static function tableName()
    {
        return 'fg_qc_check';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            // [['unique_id', 'qc_check_uniq_id', 'cleaning_uniq_id', 'batch_Id', 'overall_status', 'latitude', 'logtitude', 'entry_type', 'updated_at', 'mobile_created_at'], 'required'],
            [['fgqc_date'], 'required'],
            [['overall_status', 'status', 'entry_type'], 'string'],
            [['created_at', 'updated_at', 'mobile_created_at','product_id','user_id','rpc_center_id','fgqc_date'], 'safe'],
            [['unique_id', 'qc_check_uniq_id', 'cleaning_uniq_id'], 'string', 'max' => 150],
            [['batch_Id'], 'string', 'max' => 100],
            [['latitude', 'logtitude'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'unique_id' => 'Unique ID',
            'qc_check_uniq_id' => 'Qc Check Uniq ID',
            'cleaning_uniq_id' => 'Cleaning Uniq ID',
            'batch_Id' => 'Batch  ID',
            'overall_status' => 'Overall Status',
            'status' => 'Status',
            'latitude' => 'Latitude',
            'logtitude' => 'Logtitude',
            'entry_type' => 'Entry Type',
            'fgqc_date' => 'FG QC Date',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'mobile_created_at' => 'Mobile Created At',
            'product_id'=>'product_id',
            'user_id'=>'user_id',
            'rpc_center_id' =>'RPC Center'
        ];
    }


}
