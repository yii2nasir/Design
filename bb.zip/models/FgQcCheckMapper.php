<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "fg_qc_check_mapper".
 *
 * @property int $id
 * @property string $fg_qc_uniq_id
 * @property string $packed_weight
 * @property string $packed_quantity
 */
class FgQcCheckMapper extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'fg_qc_check_mapper';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['fg_qc_uniq_id', 'packed_weight', 'packed_quantity'], 'required'],
            [['fg_qc_uniq_id'], 'string', 'max' => 150],
            [['packed_weight', 'packed_quantity'], 'string', 'max' => 100],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'fg_qc_uniq_id' => 'Fg Qc Uniq ID',
            'packed_weight' => 'Packed Weight',
            'packed_quantity' => 'Packed Quantity',
        ];
    }
}
