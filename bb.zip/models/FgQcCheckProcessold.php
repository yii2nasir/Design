<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "fg_qc_check_process".
 *
 * @property int $id
 * @property int $user_id
 * @property string $unique_id
 * @property int $product_id
 * @property int $batch_id
 * @property string $batch_number
 * @property string $balance_quantity
 * @property string $sealing_quality
 * @property string $label_declaration
 * @property string $weight_check
 * @property string $moisture
 * @property string $odor
 * @property string $Infestation
 * @property string $count
 * @property string $forign_matter
 * @property string $broken_damage
 * @property string $qc_done_by
 * @property string $packed_size
 * @property string $pack_date
 * @property string $pack_quantity
 * @property string $photo
 * @property string $comment
 * @property string $created_at
 * @property string $updated_at
 */
class FgQcCheckProcess extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'fg_qc_check_process';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            // [['user_id', 'unique_id', 'product_id', 'batch_id', 'batch_number', 'sealing_quality', 'label_declaration', 'weight_check', 'moisture', 'odor', 'Infestation', 'count', 'forign_matter', 'broken_damage', 'qc_done_by', 'packed_size', 'pack_date', 'pack_quantity', 'photo', 'comment', 'created_at', 'updated_at'], 'required'],
        
            [[ 'user_id', 'batch_id', 'batch_number', 'sealing_quality', 'label_declaration', 'weight_check', 'moisture', 'odor', 'Infestation', 'count', 'forign_matter', 'broken_damage', 'qc_done_by', 'packed_size', 'pack_date', 'pack_quantity', 'photo', 'comment'], 'required'],
            [['user_id', 'product_id', 'batch_id'], 'integer'],
            [['pack_date', 'created_at', 'updated_at'], 'safe'],
            [['comment'], 'string'],
            [['unique_id', 'batch_number', 'balance_quantity', 'sealing_quality', 'label_declaration', 'moisture', 'pack_quantity'], 'string', 'max' => 100],
            [['weight_check', 'odor', 'Infestation', 'count', 'forign_matter', 'broken_damage'], 'string', 'max' => 50],
            [['qc_done_by', 'packed_size'], 'string', 'max' => 255],
            [['photo'], 'string', 'max' => 200],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'User ID',
            'unique_id' => 'Unique ID',
            'product_id' => 'Product ID',
            'batch_id' => 'Batch ID',
            'batch_number' => 'Batch Number',
            'balance_quantity' => 'Balance Quantity',
            'sealing_quality' => 'Sealing Quality',
            'label_declaration' => 'Label Declaration',
            'weight_check' => 'Weight Check',
            'moisture' => 'Moisture',
            'odor' => 'Odor',
            'Infestation' => 'Infestation',
            'count' => 'Count',
            'forign_matter' => 'Forign Matter',
            'broken_damage' => 'Broken Damage',
            'qc_done_by' => 'Qc Done By',
            'packed_size' => 'Packed Size',
            'pack_date' => 'Pack Date',
            'pack_quantity' => 'Pack Quantity',
            'photo' => 'Photo',
            'comment' => 'Comment',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
     public function getUser()
    {
        return $this->hasOne(Users::className(), ['id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProduct()
    {
        return $this->hasOne(Product::className(), ['id' => 'product_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRequest()
    {
        return $this->hasOne(NewRequest::className(), ['id' => 'request_id']);
    }
}
