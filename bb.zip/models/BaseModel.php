<?php

namespace app\models;

use Yii;

class BaseModel extends \yii\db\ActiveRecord
{
 
    public function save($runValidation = true, $attributeNames = null) {
        $milliseconds = round(microtime(true) * 1000);
        
        
        
        $fromCreate = $this->isNewRecord;
        
		
        //$this->created_at = "2017-01-10 01:57:46";
		
		
		$dateM = date('Y-m-d h:i:s');
		if($fromCreate==true){
			$this->created_at = $dateM;	
		}
		else{
			$this->updated_at = $dateM;	
		}
		
		
        $this->timestamp = $milliseconds;
        $this->upload_status = "1";

        $returnP = parent::save($runValidation, $attributeNames);
        /*
		display_array($this);
		display_array($returnP);
		display_array($this->tableName());
		display_array($fromCreate);
		*/
		
        if($returnP==true){
            if($this->tableName()=="beneficiary"){
                if($fromCreate){
                    $this->createCodeAndUpdateTable($this);   
                }
            }
        }
        
        return $returnP;
        
    }
    
     function createCodeAndUpdateTable($model){
        $village = \app\models\Village::findOne(["id"=>$model->village_id]);
		
        $year = date("y");
        //$beneficiary_code = strtoupper(substr( $village['village'],0, 2)).$year.$model->beneficiary_id;
        $beneficiary_code = $village['village_code'].$year.(substr("00000".$model->id,-6));
        $beneficiary = Beneficiary::findOne($model->id);
        $beneficiary->beneficiary_code = $beneficiary_code;
        $beneficiary->update();
		/*
		display_array($beneficiary->beneficiary_code);
		exit;
		*/
        //display_array($beneficiary->update());           
    }
    
}
