<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "incoming_qc_check".
 *
 * @property int $id
 * @property string $unique_id
 * @property int $user_id
 * @property int $request_id
 * @property int $product_id
 * @property string $batch_id
 * @property int $arrived_qty
 * @property int $accepted_qty
 * @property string $overall_status
 * @property string $comments
 * @property string $status
 * @property string $latitude
 * @property string $logtitude
 * @property string $mobile_created_at
 * @property string $entry_type
 * @property string $created_at
 * @property string $updated_at
 *
 * @property Users $user
 * @property Product $product
 * @property NewRequest $request
 */
class IncomingQcCheck extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'incoming_qc_check';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            // [['arrived_qty','accepted_qty'], 'required'],
            [['arrived_qty','accepted_qty'], 'required'],
            [['incoming_date'], 'required'],
            [['overall_status', 'comments', 'status', 'entry_type'], 'string'],
            [['mobile_created_at', 'created_at','updated_at','product_image','request_id','fumigation_status','product_is_fumigation','product_is_cleaning','supplier_id','rpc_center_id','incoming_date'], 'safe'],
            [['unique_id'], 'string', 'max' => 150],
            [['batch_id', 'latitude', 'logtitude'], 'string', 'max' => 100],
            // [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['user_id' => 'id']],
            [['product_id'], 'exist', 'skipOnError' => true, 'targetClass' => Product::className(), 'targetAttribute' => ['product_id' => 'id']],
            // [['request_id'], 'exist', 'skipOnError' => true, 'targetClass' => NewRequest::className(), 'targetAttribute' => ['request_id' => 'id']],
        ];
    }
    
    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'unique_id' => 'Unique ID',
            'user_id' => 'User ID',
            'request_id' => 'Request ID',
            'product_id' => 'Product ID',
            'batch_id' => 'Batch ID',
            'arrived_qty' => 'Arrived Kg',
            'accepted_qty' => 'Accepted Kg',
            'overall_status' => 'Overall Status',
            'comments' => 'Comments',
            'status' => 'Status',
            'latitude' => 'Latitude',
            'logtitude' => 'Logtitude',
            'mobile_created_at' => 'Mobile Created At',
            'product_image'=>'Product Image',
            'entry_type' => 'Entry Type',
            'created_at' => 'Created At',
            'incoming_date' => "Incoming Date",
            'updated_at' => 'Updated At',
            'fumigation_status'=>'Fumigation Status',
            'rpc_center_id' =>'RPC Center'
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(Users::className(), ['id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProduct()
    {
        return $this->hasOne(Product::className(), ['id' => 'product_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRequest()
    {
        return $this->hasOne(NewRequest::className(), ['id' => 'request_id']);
    }
}
