<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "product".
 *
 * @property int $id
 * @property int $sub_sub_cat_id
 * @property string $name
 * @property string $created_at
 * @property string $updated_at
 *
 * @property SubSubCategory $subSubCat
 * @property SupplierProductMapping[] $supplierProductMappings
 */
class Product extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'product';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['sub_sub_cat_id'], 'required'],
            [['sub_sub_cat_id'], 'integer'],
            [['name','code'], 'required'],
            [['code','name'], 'unique'],
            [['created_at', 'updated_at'], 'safe'],
            [['name'], 'string', 'max' => 100],
            [['sub_sub_cat_id'], 'exist', 'skipOnError' => true, 'targetClass' => SubSubCategory::className(), 'targetAttribute' => ['sub_sub_cat_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'sub_sub_cat_id' => 'Sub Sub Cat ID',
            'name' => 'Product Name',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'code'=>'Product code'
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSubSubCat()
    {
        return $this->hasOne(SubSubCategory::className(), ['id' => 'sub_sub_cat_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSupplierProductMappings()
    {
        return $this->hasMany(SupplierProductMapping::className(), ['product_id' => 'id']);
    }
}
