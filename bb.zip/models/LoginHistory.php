<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "login_history".
 *
 * @property integer $id
 * @property integer $user_id
 * @property string $logged_in
 * @property string $logged_out
 * @property string $lat
 * @property string $lng
 * @property string $device_id
 * @property string $app_version
 * @property string $mdb_version
 * @property string $ip_address
 * @property string $created_at
 *
 * @property Users $user
 */
class LoginHistory extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'login_history';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_id', 'logged_in'], 'required'],
            [['user_id', 'logged_in', 'logged_out'], 'integer'],
            [['created_at'], 'safe'],
            [['lat', 'lng'], 'string', 'max' => 20],
            [['device_id', 'ip_address'], 'string', 'max' => 150],
            [['app_version', 'mdb_version'], 'string', 'max' => 50],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['user_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'User ID',
            'logged_in' => 'Logged In',
            'logged_out' => 'Logged Out',
            'lat' => 'Lat',
            'lng' => 'Lng',
            'device_id' => 'Device ID',
            'app_version' => 'App Version',
            'mdb_version' => 'Mdb Version',
            'ip_address' => 'Ip Address',
            'created_at' => 'Created At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(Users::className(), ['id' => 'user_id']);
    }
}