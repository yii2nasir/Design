<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "new_request".
 *
 * @property int $id
 * @property string $unique_id
 * @property int $supplier_id
 * @property string $vehicle_inspection_checklist
 * @property string $product_id
 * @property string $date
 * @property string $status
 * @property string $comments
 * @property string $vehicle_image
 * @property string $vehicle_status
 * @property string $latitude
 * @property string $logtitude
 * @property string $entry_type
 * @property string $created_at
 * @property string $updated_at
 * @property int $user_id
 * @property string $mobile_created_at
 *
 * @property IncomingQcCheck[] $incomingQcChecks
 * @property Supplier $supplier
 */
class NewRequest extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'new_request';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            // [['unique_id', 'supplier_id', 'vehicle_inspection_checklist', 'product_id', 'date', 'comments', 'vehicle_image', 'vehicle_status', 'latitude', 'logtitude', 'updated_at', 'user_id', 'mobile_created_at'], 'required'],
            [['user_id'], 'integer'],
            [['vehicle_date'],'required'],
            [['vehicle_inspection_checklist', 'product_id', 'status', 'comments', 'vehicle_status'], 'string'],
            [['date', 'created_at', 'mobile_created_at','updated_at','supplier_id','vehicle_date'], 'safe'],
            [['unique_id', 'vehicle_image'], 'string', 'max' => 150],
            [['latitude', 'logtitude', 'entry_type'], 'string', 'max' => 100],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'unique_id' => 'Unique ID',
            'supplier_id' => 'Supplier Name',
            'vehicle_inspection_checklist' => 'Vehicle Inspection Checklist',
            'product_id' => 'Product Name',
            'date' => 'Date',
            'status' => 'Status',
            'comments' => 'Comments',
            'vehicle_image' => 'Vehicle Image',
            'vehicle_status' => 'Vehicle Status',
            'vehicle_date' => 'Vehicle Date',
            'latitude' => 'Latitude',
            'logtitude' => 'Logtitude',
            'entry_type' => 'Entry Type',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'user_id' => 'User ID',
            'mobile_created_at' => 'Mobile Created At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIncomingQcChecks()
    {
        return $this->hasMany(IncomingQcCheck::className(), ['request_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSupplier()
    {
        return $this->hasOne(Supplier::className(), ['id' => 'supplier_id']);
    }
    public function getPdct()
    {
        //return "asdas";
        return $this->hasOne(Product::className(), ['id' => 'product_id']);
    }
}
