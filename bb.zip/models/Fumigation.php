<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "fumigation".
 *
 * @property int $id
 * @property int $user_id
 * @property string $qc_check_uniq_id
 * @property string $unique_id
 * @property string $start_time
 * @property string $end_time
 * @property string $chemical_used
 * @property string $qc_person_name
 * @property string $fumigation_effective
 * @property string $re_fumigate
 * @property string $status
 * @property string $mobile_created_at
 * @property string $created_at
 * @property string $updated_at
 * @property string $images
 * @property string $entry_type
 * @property string $latitude
 * @property string $logtitude
 *
 * @property RpcCentre $user
 * @property FumigationMapper[] $fumigationMappers
 */
class Fumigation extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'fumigation';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            // [['user_id', 'qc_check_uniq_id', 'unique_id', 'chemical_used', 'qc_person_name', 'fumigation_effective', 're_fumigate', 'status', 'mobile_created_at', 'updated_at', 'images', 'latitude', 'logtitude'], 'required'],
            [['user_id'], 'integer'],
            [['start_time', 'end_time', 'mobile_created_at', 'created_at','updated_at','overall_status','comments','fumigation_type','rpc_center_id'], 'safe'],
            [['fumigation_effective', 're_fumigate', 'status', 'entry_type'], 'string'],
            [['unique_id', 'chemical_used', 'qc_person_name', 'images', 'latitude', 'logtitude'], 'string', 'max' => 100],
            // [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => RpcCentre::className(), 'targetAttribute' => ['user_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'User ID',
            'unique_id' => 'Unique ID',
            'start_time' => 'Start Time',
            'fumigation_type'=>'Fumigation Type',
            'end_time' => 'End Time',
            'chemical_used' => 'Chemical Used',
            'qc_person_name' => 'QC Person Name',
            'fumigation_effective' => 'Fumigation Effective',
            're_fumigate' => 'Re Fumigate',
            'status' => 'Status',
            'mobile_created_at' => 'Mobile Created At',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'images' => 'Images',
            'entry_type' => 'Entry Type',
            'latitude' => 'Latitude',
            'logtitude' => 'Logtitude',
            'comments'=>'Comments',
            'overall_status'=>'Overall Status',
            'fumigation_type'=>'Fumigation type',
            'rpc_center_id' =>'RPC Center'
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(RpcCentre::className(), ['id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getFumigationMappers()
    {
        return $this->hasMany(FumigationMapper::className(), ['fumigation_id' => 'id']);
    }
}