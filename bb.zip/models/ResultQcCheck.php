<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "result_qc_check".
 *
 * @property int $id
 * @property string $unique_id
 * @property int $qc_check_id
 * @property int $qc_parameter_id
 * @property string $value
 * @property string $status
 * @property string $latitude
 * @property string $logtitude
 * @property string $entry_type
 * @property string $created_at
 * @property string $updated_at
 */
class ResultQcCheck extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'result_qc_check';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            // [['unique_id', 'qc_check_id', 'qc_parameter_id', 'value', 'latitude', 'logtitude', 'entry_type', 'updated_at'], 'required'],
            [['qc_check_id', 'qc_parameter_id'], 'integer'],
            [['status'], 'string'],
            [['entry_type', 'created_at', 'updated_at'], 'safe'],
            [['unique_id'], 'string', 'max' => 150],
            [['value'], 'string', 'max' => 100],
            [['latitude', 'logtitude'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'unique_id' => 'Unique ID',
            'qc_check_id' => 'Qc Check ID',
            'qc_parameter_id' => 'Qc Parameter ID',
            'value' => 'Value',
            'status' => 'Status',
            'latitude' => 'Latitude',
            'logtitude' => 'Logtitude',
            'entry_type' => 'Entry Type',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
}
