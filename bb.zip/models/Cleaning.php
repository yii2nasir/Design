<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "cleaning".
 *
 * @property int $id
 * @property string $unique_id
 * @property int $user_id
 * @property string $fumigation_uniq_id
 * @property string $cleaning_checklist
 * @property string $overall_status
 * @property string $status
 * @property string $latitude
 * @property string $logtitude
 * @property string $mobile_created_at
 * @property string $entry_type
 * @property string $created_at
 * @property string $updated_at
 *
 * @property CleaningMapper[] $cleaningMappers
 */
class Cleaning extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'cleaning';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            // [['unique_id', 'user_id', 'fumigation_uniq_id', 'cleaning_checklist', 'overall_status', 'latitude', 'logtitude', 'mobile_created_at', 'updated_at'], 'required'],
            [['user_id'], 'integer'],
            [['cleaning_date'],'required'],
            [['cleaning_checklist', 'overall_status', 'status', 'entry_type'], 'string'],
            [['mobile_created_at', 'created_at','image','cleaning_status','updated_at','rpc_center_id','cleaning_date'], 'safe'],
            [['unique_id', 'fumigation_uniq_id'], 'string', 'max' => 150],
            [['latitude', 'logtitude'], 'string', 'max' => 50],
            // [['updated_at'], 'string', 'max' => 100],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'unique_id' => 'Unique ID',
            'user_id' => 'User ID',
            'fumigation_uniq_id' => 'Fumigation Uniq ID',
            'cleaning_checklist' => 'Cleaning Checklist',
            'overall_status' => 'Overall Status',
            'status' => 'Status',
            'latitude' => 'Latitude',
            'logtitude' => 'Logtitude',
            'mobile_created_at' => 'Mobile Created At',
            'entry_type' => 'Entry Type',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'cleaning_date' => 'Cleaning Date',
            'image'=>'Image',
            'cleaning_status'=>'cleaning_status',
            'rpc_center_id' =>'RPC Center'
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCleaningMappers()
    {
        return $this->hasMany(CleaningMapper::className(), ['cleaning_id' => 'id']);
    }
}
