<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\NewRequest;

/**
 * NewRequestSearch represents the model behind the search form of `app\models\NewRequest`.
 */
class NewRequestSearch extends NewRequest
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id','latitude', 'logtitude'], 'integer'],
            [['unique_id','supplier_id', 'vehicle_inspection_checklist', 'product_id', 'date', 'status', 'comments', 'vehicle_image', 'vehicle_status', 'entry_type', 'created_at', 'updated_at'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = NewRequest::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
           'query' => $query,
           'sort'=> ['defaultOrder' => ['id' => SORT_DESC]]
       ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'new_request.id' => $this->id,
            'new_request.supplier_id' => $this->supplier_id,
            'new_request.date' => $this->date,
            'new_request.latitude' => $this->latitude,
            'new_request.logtitude' => $this->logtitude,
            'new_request.entry_type' => $this->entry_type,
            'new_request.created_at' => $this->created_at,
            'new_request.updated_at' => $this->updated_at,
        ]);

        $query->andFilterWhere(['like', 'unique_id', $this->unique_id])
            ->andFilterWhere(['like', 'vehicle_inspection_checklist', $this->vehicle_inspection_checklist])
            ->andFilterWhere(['like', 'product_id', $this->product_id])
            ->andFilterWhere(['like', 'status', $this->status])
            ->andFilterWhere(['like', 'comments', $this->comments])
            ->andFilterWhere(['like', 'vehicle_image', $this->vehicle_image])
            ->andFilterWhere(['like', 'vehicle_status', $this->vehicle_status]);

        return $dataProvider;
    }
}
