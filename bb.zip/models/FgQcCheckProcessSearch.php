<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\FgQcCheckProcess;

/**
 * FgQcCheckProcessSearch represents the model behind the search form of `app\models\FgQcCheckProcess`.
 */
class FgQcCheckProcessSearch extends FgQcCheckProcess
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'user_id', 'product_id', 'batch_id'], 'integer'],
            [['unique_id', 'batch_number', 'balance_quantity', 'sealing_quality', 'label_declaration', 'weight_check', 'moisture', 'odor', 'Infestation', 'count', 'forign_matter', 'broken_damage', 'qc_done_by', 'packed_size', 'pack_date', 'pack_quantity', 'photo', 'comment', 'created_at', 'updated_at'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = FgQcCheckProcess::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'user_id' => $this->user_id,
            'product_id' => $this->product_id,
            'batch_id' => $this->batch_id,
            'pack_date' => $this->pack_date,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ]);

        $query->andFilterWhere(['like', 'unique_id', $this->unique_id])
            ->andFilterWhere(['like', 'batch_number', $this->batch_number])
            ->andFilterWhere(['like', 'balance_quantity', $this->balance_quantity])
            ->andFilterWhere(['like', 'sealing_quality', $this->sealing_quality])
            ->andFilterWhere(['like', 'label_declaration', $this->label_declaration])
            ->andFilterWhere(['like', 'weight_check', $this->weight_check])
            ->andFilterWhere(['like', 'moisture', $this->moisture])
            ->andFilterWhere(['like', 'odor', $this->odor])
            ->andFilterWhere(['like', 'Infestation', $this->Infestation])
            ->andFilterWhere(['like', 'count', $this->count])
            ->andFilterWhere(['like', 'forign_matter', $this->forign_matter])
            ->andFilterWhere(['like', 'broken_damage', $this->broken_damage])
            ->andFilterWhere(['like', 'qc_done_by', $this->qc_done_by])
            ->andFilterWhere(['like', 'packed_size', $this->packed_size])
            ->andFilterWhere(['like', 'pack_quantity', $this->pack_quantity])
            ->andFilterWhere(['like', 'photo', $this->photo])
            ->andFilterWhere(['like', 'comment', $this->comment]);

        return $dataProvider;
    }
}
