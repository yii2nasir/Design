<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "users".
 *
 * @property integer $id
 * @property string $name
 * @property string $mobile
 * @property string $username
 * @property string $password
 * @property integer $level_id
 * @property integer $status
 * @property string $authKey
 * @property string $updated_at
 * @property string $created_at
 */
class Users extends \yii\db\ActiveRecord implements \yii\web\IdentityInterface {

    const USER_STATE = 33;
    const USER_DISTRICT = 35;
    const RPC_USER = 36;
    const RPC_CENTRE = 37;

    public function getUserOptions($id = null) {
        $list = array(
            self::USER_STATE => 'State Coordinator',
            self::USER_DISTRICT => 'District Coordinator',
            self::RPC_USER => 'RPC User',
            self::RPC_CENTRE => 'RPC Coordinator',
        );
        if ($id === null) {
            return $list;
        }
        if (is_numeric($id)) {

            return isset($list[$id]) ? $list[$id] : 'not defined';
        }
        return $id;
    }

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'users';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['name', 'mobile', 'username', 'password', 'level_id', 'authKey'], 'required'],
            [['level_id', 'status', 'sms_status'], 'integer'],
            [['updated_at', 'created_at', 'sms_delivered_datetime'], 'safe'],
            [['name', 'username', 'password'], 'string', 'max' => 150],
            [['mobile'], 'string', 'max' => 11],
            [['authKey'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => Yii::t('app', 'ID'),
            'name' => Yii::t('app', 'Name'),
            'mobile' => Yii::t('app', 'Mobile'),
            'username' => Yii::t('app', 'Username'),
            'password' => Yii::t('app', 'Password'),
            'level_id' => Yii::t('app', 'Level'),
            'sms_status' => Yii::t('app', 'SMS Status'),
            'sms_delivered_datetime' => Yii::t('app', 'SMS Deliver DateTime'),
            'status' => Yii::t('app', 'Status'),
            'authKey' => Yii::t('app', 'Auth Key'),
            'updated_at' => Yii::t('app', 'Web Updated'),
          //  'mobile_created_at' => Yii::t('app', 'Mobile Created'),
            'created_at' => Yii::t('app', 'Web Synced'),
        ];
    }

    public static function findIdentity($id) {
        return static::findOne($id);
    }

    public static function findIdentityByAccessToken($token, $type = null) {
        throw new NotSupportedException(); //I don't implement this method because I don't have any access token column in my database
    }

    public function getId() {
        return $this->id;
    }

    public function getAuthKey() {
        return $this->authKey; //Here I return a value of my authKey column
    }

    public function validateAuthKey($authKey) {
        return $this->authKey === $authKey;
    }

    public static function findByUsername($username) {
        return self::findOne(['username' => $username]);
    }

    public static function findByPassword($password) {
        return self::findOne(['password' => $password]);
    }

    public function validatePassword($password) {
        return $this->password === $password;
    }

    public function getUserLocationMapper() {
        return $this->hasMany(UserLocationMapper::className(), ['user_id' => 'id']);
    }

    public function getCooperativeProfiling() {
        return $this->hasMany(CooperativeProfiling::className(), ['user_id' => 'id']);
    }

    public function getVillage() {
        return $this->hasMany(Village::className(), ['id' => 'location_id'])->via("userLocationMapper");
    }

    public function getBlock() {
        return $this->hasOne(Block::className(), ['id' => 'block_id'])->via("village");
    }

    public function getDistrict() {
        return $this->hasOne(District::className(), ['id' => 'district_id'])->via("block");
    }

    public function getState() {
        return $this->hasOne(State::className(), ['id' => 'state_id'])->via("district");
    }

    // State Name
    public function getStateName($level, $user)
    {
        if($level != NULL && $user != NULL)
        {
            $user_location = UserLocationMapper::find()->where(['user_id' => $user])->andWhere(['level_id' => $level])->one();
            if($user_location){
                if($level == 36){
                    $block = Village::find()->where(['id' => $user_location->location_id])->one();
                    $district = Block::find()->where(['id'=>$block->block_id])->one();
                    $state = District::find()->where(['id'=>$district->district_id])->one();
                    $stateName = State::find()->where(['id' => $state->state_id])->one();
                    return $stateName->name;
                }
                if($level == 35){
                    $district = Block::find()->where(['id' => $user_location->location_id])->one();
                    $state = District::find()->where(['id'=>$district->district_id])->one();
                    $stateName = State::find()->where(['id'=>$state->state_id])->one();
                    return $stateName->name;
                }
                if($level == 33){
                    $state = District::find()->where(['id' => $user_location->location_id])->one();
                    $stateName = State::find()->where(['id'=> $state->state_id])->one();
                    return $stateName->name;
                }
                
            }else {
                return "";
            }
            
        } else {
            return "";
        }
    }

    // get districtt 
    public function getDistrictName($level, $user)
    {
        if($level != NULL && $user != NULL)
        {
            $user_location = UserLocationMapper::find()->where(['user_id' => $user])->andWhere(['level_id' => $level])->one();
            if($user_location){
                if($level ==36){
                    $block = Village::find()->where(['id' => $user_location->location_id])->one();
                    $district = Block::find()->where(['id'=>$block->block_id])->one();
                    $districtName = District::find()->where(['id'=>$district->district_id])->one();
                    //$stateName = State::find()->where(['id' => $state->state_id])->one();
                    return $districtName->name;
                }
                if($level == 35){
                    $district = Block::find()->where(['id' => $user_location->location_id])->one();
                    $districtName = District::find()->where(['id'=>$district->district_id])->one();
                    //$stateName = State::find()->where(['id'=>$state->state_id])->one();
                    return $districtName->name;
                }
            }else {
                return "";
            }
            
            
            
        } else {
            return "";
        }
    }

    // get block 
    public function getBlockName($level, $user)
    {
        if($level != NULL && $user != NULL)
        {
            $user_location = UserLocationMapper::find()->where(['user_id' => $user])->andWhere(['level_id' => $level])->one();
            if($user_location){
                if($level == 36){
                    $block = Village::find()->where(['id' => $user_location->location_id])->one();
                    $blockName = Block::find()->where(['id'=>$block->block_id])->one();
                    return $blockName->name;
                }
            }else {
                return "";
            }
            
            
            
            
        } else {
            return "";
        }
    }



    public function getLocations($level, $user) {

        if ($level != NULL && $user != NULL) {
            $user_location_mappers = UserLocationMapper::find()->where(['user_id' => $user])->andWhere(['level_id' => $level])->all();
            $location = "";
            $locationArr = [];
            foreach ($user_location_mappers as $user_location_mapper) {
                if ($user_location_mapper['level_id'] == 1) {
                    $locations = State::find()->select('name')->where(['id' => $user_location_mapper['location_id']])->all();
                    foreach($locations as $location){
                  
                        $locationArr[] = $location['name'];
                    }
                    
                }
                if ($user_location_mapper['level_id'] == 33) {
                    $locations = District::find()->select('name')->where(['id' => $user_location_mapper['location_id']])->all();
                    foreach($locations as $location){
                        $locationArr[] = $location['name'];
                    }
                }
                if ($user_location_mapper['level_id'] == 35) {
                    $locations = Block::find()->select('name')->where(['id' => $user_location_mapper['location_id']])->all();
                    foreach($locations as $location){
                        $locationArr[] = $location['name'];
                     }
                }
                if ($user_location_mapper['level_id'] == 36) {
                    $query = new \yii\db\Query;
                    $query->select(['district.name'])
                   ->from('user_location_mapper')
                   ->innerJoin('rpc_centre', 'user_location_mapper.location_id = rpc_centre.id')
                   ->innerJoin('district', 'rpc_centre.district_id = district.id')
                   ->where(['user_location_mapper.level_id'=>$user_location_mapper['level_id'],'user_location_mapper.user_id'=>$user_location_mapper['user_id']]);
                   $command = $query->createCommand();
                   $data = $command->queryOne();
                   return $data ? $data['name'] :"";
                }
                
            }
            $newArray = [];
            foreach($locationArr as $key => $loc){
                if($key % 4 == 1){
                    $newArray[] = "";
                }else{
                    $newArray[] = $loc;
                }
            }
            
            return implode(',', $newArray);
        } else {
            return "";
        }
    }

}
