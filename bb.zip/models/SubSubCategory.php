<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "sub_sub_category".
 *
 * @property int $id
 * @property int $sub_cat_id
 * @property string $name
 * @property string $created_at
 * @property string $updated_at
 * @property string $status
 *
 * @property SubCategory $subCat
 */
class SubSubCategory extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'sub_sub_category';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['sub_cat_id', 'name'], 'required'],
            [['sub_cat_id'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['status'], 'string'],
            [['name'], 'string', 'max' => 100],
            [['sub_cat_id'], 'exist', 'skipOnError' => true, 'targetClass' => SubCategory::className(), 'targetAttribute' => ['sub_cat_id' => 'id']],
            [['name'], 'unique','targetAttribute'=>['name'],'message' =>'Duplicate not allowed'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'sub_cat_id' => 'Sub Category Name',
            'name' => 'Sub-Sub Category',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'status' => 'Status',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSubCat()
    {
        return $this->hasOne(SubCategory::className(), ['id' => 'sub_cat_id']);
    }
}
