<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\RpcCentre;

/**
 * RpcCentreSearch represents the model behind the search form of `app\models\RpcCentre`.
 */
class RpcCentreSearch extends RpcCentre
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id'], 'integer'],
            [['rpc_name','district_id', 'created_at', 'updated_at'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = RpcCentre::find()->joinWith(['district']);

        // add conditions that should always apply here

         $dataProvider = new ActiveDataProvider([
           'query' => $query,
           'sort'=> ['defaultOrder' => ['id' => SORT_DESC]]
       ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'rpc_centre.id' => $this->id,
            'district.name' => $this->district_id,
            'rpc_centre.created_at' => $this->created_at,
            'rpc_centre.updated_at' => $this->updated_at,
            //'updated_at' => $this->updated_at,
        ]);

        $query->andFilterWhere(['like', 'rpc_centre.rpc_name', $this->rpc_name]);
            //->andFilterWhere(['like', 'rpc_centre.updated_at', $this->updated_at]);

        return $dataProvider;
    }
}
