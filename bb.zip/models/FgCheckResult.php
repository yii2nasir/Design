<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "fg_check_result".
 *
 * @property int $id
 * @property int $fg_qc_check_id
 * @property int $qc_parameter_id
 * @property string $value
 * @property string $status
 * @property string $latitude
 * @property string $logtitude
 * @property string $entry_type
 * @property string $created_at
 * @property string $updated_at
 * @property string $unique_id
 */
class FgCheckResult extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'fg_check_result';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            // [['fg_qc_check_id', 'qc_parameter_id', 'value', 'status', 'latitude', 'logtitude', 'entry_type', 'updated_at', 'unique_id'], 'required'],
            [['fg_qc_check_id', 'qc_parameter_id'], 'integer'],
            [['status'], 'string'],
            [['entry_type', 'created_at', 'updated_at'], 'safe'],
            [['value', 'unique_id'], 'string', 'max' => 100],
            [['latitude', 'logtitude'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'fg_qc_check_id' => 'Fg Qc Check ID',
            'qc_parameter_id' => 'Qc Parameter ID',
            'value' => 'Value',
            'status' => 'Status',
            'latitude' => 'Latitude',
            'logtitude' => 'Logtitude',
            'entry_type' => 'Entry Type',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'unique_id' => 'Unique ID',
        ];
    }
}
