<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "cleaning_mapper".
 *
 * @property int $id
 * @property int $cleaning_id
 * @property int $product_id
 * @property string $batch_id
 * @property string $incoming_uniq_id
 *
 * @property Cleaning $cleaning
 * @property Product $product
 */
class CleaningRpcMapper extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'cleaning_rpc_mapper';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            // [['cleaning_id', 'product_id', 'batch_id', 'incoming_uniq_id'], 'required'],
            [['qc_parameter', 'product_id', 'user_id'], 'integer'],
            [['rpc_id'], 'string'],
            [['qc_parameter', 'product_id', 'user_id', 'rpc_id', 'created_at', 'updated_at'],'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'qc_parameter' => 'Cleaning Parameter',
            'product_id' => 'Product ID',
            'user_id' => 'User',
            'rpc_id' => 'RPC',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
}
