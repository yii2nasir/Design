<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "supplier".
 *
 * @property int $id
 * @property string $name
 * @property string $created_at
 * @property string $updated_at
 *
 * @property SupplierProductMapping[] $supplierProductMappings
 */
class Supplier extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'supplier';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name','code'], 'required'],
             
            [['created_at', 'updated_at','unique_id','latitude','longitude','entry_type','mobile_created_at','status','gst_number','location'], 'safe'],
            [['name'], 'string', 'max' => 100],
            [['name'], 'unique','targetAttribute'=>['name'],'message' =>'Duplicate not allowed'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'code'=>'Code',
            'unique_id'=>'Unique ID',
            'latitude'=>'Latitude',
            'longitude'=>'Longitude',
            'entry_type'=>'Entry Type',
            'mobile_created_at'=>'Mobile Created At',
            'status'=>'status',
            'location'=>'Location',
            'gst_number'=>'GST Number'
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSupplierProductMappings()
    {
        return $this->hasMany(SupplierProductMapping::className(), ['supplier_id' => 'id']);
    }
}
