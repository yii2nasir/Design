<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "cleaning_mapper".
 *
 * @property int $id
 * @property int $cleaning_id
 * @property int $product_id
 * @property string $batch_id
 * @property string $incoming_uniq_id
 *
 * @property Cleaning $cleaning
 * @property Product $product
 */
class CleaningMapper extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'cleaning_mapper';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            // [['cleaning_id', 'product_id', 'batch_id', 'incoming_uniq_id'], 'required'],
            [['cleaning_id', 'product_id'], 'integer'],
            [['batch_id', 'incoming_uniq_id'], 'string', 'max' => 150],
            [['fumigation_uniq_id'],'safe'],
            [['cleaning_uniq_id'],'safe'],
            [['available_qty', 'quantity_value','remaining_quantity'], 'string', 'max' => 100],
            [['cleaning_id'], 'exist', 'skipOnError' => true, 'targetClass' => Cleaning::className(), 'targetAttribute' => ['cleaning_id' => 'id']],
            [['product_id'], 'exist', 'skipOnError' => true, 'targetClass' => Product::className(), 'targetAttribute' => ['product_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'cleaning_id' => 'Cleaning ID',
            'product_id' => 'Product ID',
            'batch_id' => 'Batch ID',
            'incoming_uniq_id' => 'Incoming Uniq ID',
            'available_qty' => 'Available Quantity',
            'quantity_value' => 'Quantity Value',
            'cleaning_uniq_id' => 'Cleaning Unique ID',
            'fumigation_uniq_id'=>'Fumigation Uniq ID'


        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCleaning()
    {
        return $this->hasOne(Cleaning::className(), ['id' => 'cleaning_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProduct()
    {
        return $this->hasOne(Product::className(), ['id' => 'product_id']);
    }
}
