<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "rpc_centre".
 *
 * @property int $id
 * @property string $rpc_name
 * @property int $district_id
 * @property string $created_at
 * @property string $updated_at
 *
 * @property District $district
 */
class RpcCentre extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'rpc_centre';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['rpc_name','code','district_id'], 'required'],
            [['district_id'], 'integer'],
            [['code'],'unique'],
            [['created_at','code'], 'safe'],
            [['rpc_name', 'updated_at'], 'string', 'max' => 100],
            [['district_id'], 'exist', 'skipOnError' => true, 'targetClass' => District::className(), 'targetAttribute' => ['district_id' => 'id']],
            [['rpc_name'], 'unique','targetAttribute'=>['rpc_name'],'message' =>'Duplicate not allowed'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'rpc_name' => 'RPC Name',
            'district_id' => 'District Name',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'code'=>'Code'
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDistrict()
    {
        return $this->hasOne(District::className(), ['id' => 'district_id']);
    }
}
