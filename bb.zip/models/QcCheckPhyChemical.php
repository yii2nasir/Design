<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "qc_check_phy_chemical".
 *
 * @property int $id
 * @property string $type
 * @property string $nature
 * @property string $category
 * @property string $name
 * @property string $option_1
 * @property string $option_2
 * @property string $status
 * @property string $entry_type
 * @property string $created_at
 * @property string $updated_at
 */
class QcCheckPhyChemical extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'qc_check_phy_chemical';
    }
   
    const CATEGORY_MIN_MAX_NUMERIC = 1;
    const CATEGORY_MIN_MAX_Percentage = 2;
    const CATEGORY_DROPDOWN = 3;
    const CATEGORY_RADIO = 4;
    const CATEGORY_TEXTBOX = 5;
    const CATEGORY_DATE = 6;
    const CATEGORY_NUMBER = 7;
  
  

 public function getCategory($id = null)
    {
        $list = array(
            self::CATEGORY_MIN_MAX_NUMERIC =>'Min-Max Numeric',
            self::CATEGORY_MIN_MAX_Percentage =>'Min-Max Percentage',
            self::CATEGORY_DROPDOWN =>'Dropdown',
            self::CATEGORY_RADIO =>'Radio Button',
            self::CATEGORY_TEXTBOX =>'Textbox',
            self::CATEGORY_DATE =>'Date',
            self::CATEGORY_NUMBER =>'Number',
        );
        if($id === null){
            return $list;
        }
        if(is_numeric($id))
            return isset($list[$id]) ? $list[$id] : 'not defined';
            //return $list [$id % count($list)];
        return $id;
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            // [['type', 'nature', 'category', 'name', 'option_1', 'option_2', 'entry_type', 'updated_at'], 'required'],

            [['order_wise','type','name','nature', 'category','mandatory','sub_sub_category_id','product_id'], 'required'],
            [['order_wise'],'integer'],
            [['status','expected_answer'], 'string'],
            //[['type', 'order_wise'], 'unique', 'targetAttribute' => ['order_wise']],
            [['created_at', 'updated_at','is_editable'], 'safe'],
            [['type', 'nature', 'category', 'name', 'option_1', 'option_2','option_3', 'option_4',], 'string', 'max' => 100],
            [['entry_type'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'type' => 'Type',
            'nature' => 'Nature',
            'category' => 'Input Type',
            'name' => 'Name',
            'option_1' => 'Option 1',
            'option_2' => 'Option 2',
            'option_3'=>'option 3',
            'option_4' =>'option 4',
            'order_wise'=>'Order',
            'status' => 'Status',
            'entry_type' => 'Entry Type',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'mandatory'=>'Mandatory',
            'sub_sub_category_id'=>'Sub Category',
            'product_id'=>'Product',
            'expected_answer'=>'Expected Answer',
            'is_editable'=> 'Is Editable'
        ];
    }
    public function getCat()
    {
        
        return $this->hasOne(Category::className(), ['id' => 'category']);
    }
   public function getProduct()
   {
        
        return $this->hasOne(Product::className(), ['id' => 'product_id']);
    }
}
