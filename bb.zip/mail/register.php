<?php
function getBody($username,$password){
     $string = 
        '<p style="font-size:medium;font-family:serif;color:grey;margin-left:3%;"><b>Username : </b>'.
        '<text style="color:red;">'.$username.'</text><br>'.
        '<b>Password : </b><text style="color:grey;">'.$password.'</text>'.
        '</p>';
        return $string;
}
echo getBody($model->user_name,$model->password);
?>