<?php

$params = require(__DIR__ . '/params.php');

$config = [
    'id' => 'basic',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'timeZone' => 'Asia/Calcutta',
    'components' => [
       
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => '1',
            'parsers' => [
                'application/json' => 'yii\web\JsonParser',
            ],
        ],
        // 'awssdk' => [
        //         'class' => 'fedemotta\awssdk\AwsSdk',
        //         'credentials' => [ //you can use a different method to grant access
        //             'key' => 'AKIAI6IFH5LXVIFYNXVA',
        //             'secret' => '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',
        //         ],
        //         'region' => 'ap-south-1', //i.e.: 'us-east-1'
        //         'version' => 'latest', //i.e.: 'latest'
        //     ],
            's3' => [
                'class' => 'frostealth\yii2\aws\s3\Service',
                'credentials' => [ // Aws\Credentials\CredentialsInterface|array|callable
                    'key' => 'AKIAI6IFH5LXVIFYNXVA',
                    'secret' => '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',
                ],
                'region' => 'ap-south-1',
                'defaultBucket' => 'stgifmr',
                'defaultAcl' => 'public-read',
            ],

//        'response' => [
//            'format' => yii\web\Response::FORMAT_JSON,
////            'charset' => 'UTF-8',
////            // ...
//        ],
        'fileupload' => [
            'class' => 'app\components\FileUpload',
        ],
        'uniqueid' => [
            'class' => 'app\components\GenerateUniqueId',
        ],
        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],
        'user' => [
            'identityClass' => 'app\models\User',
            'enableAutoLogin' => true,
        ],
        'errorHandler' => [
            'errorAction' => 'site/error',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@app/mail',
            'useFileTransport' => false,
            'transport' => [
                'class' => 'Swift_SmtpTransport',
                'host' => 'smtp.gmail.com',
                'username' => 'reachus@dhwaniris.com',
                'password' => 'Uabfocff.1',
                'port' => '587',
                'encryption' => 'tls',
            ],
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => true,
            'enableStrictParsing' => false,
            'rules' => [
                'v1/categories/update/<id:\d+>' => 'v1/categories/update',
                'v1/categories/view/<id:\d+>' => 'v1/categories/view',
                'v1/categories/delete/<id:\d+>' => 'v1/categories/delete',
                
                'v1/cattle/update/<id:\d+>' => 'v1/cattle/update',
                ['class' => 'yii\rest\UrlRule', 'controller' => 'v1/categories'],
            ],
        ],
        'db' => require(__DIR__ . '/db.php'),
    /*
      'urlManager' => [
      'enablePrettyUrl' => true,
      'showScriptName' => false,
      'rules' => [
      ],
      ],
     */
    ],
    'modules' => [//this is for APIs
        'gridview' => [
            'class' => '\kartik\grid\Module',
            'downloadAction' => 'export',
         ],   
        'v1' => [
            'class' => 'app\modules\v1\Module',
        ],
        'export' => [
            'class' => 'app\modules\export\Module',
        ],
    ],
    'params' => $params,
];

if (YII_ENV_DEV) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = [
        'class' => 'yii\debug\Module',
    ];
    
    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] = [
        'allowedIPs' => ['127.0.0.1', '::1', '192.168.1.2'],
        'class' => 'yii\gii\Module',
        
    ];
}

return $config;
