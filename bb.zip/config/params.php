<?php
return [
    'adminEmail' => 'admin@example.com',
    'brand'=>'Krishi Jyoti',
    'tokenSecret'=>"Krishi_jyoti@Dhwani",
    'isOffline'=>FALSE,
    'imageBaseDir'=>"../web/images/",
    'imageBaseDirEducation'=>"../web/images/education/",
//    'baseFileUrl'=> 'http://localhost/projects/krishijyoti_web/web/images/'
    'baseFileUrl'=> 'http://188.166.230.71/projects/krishi_jyoti/krishijyoti_web/web/images/'
];
