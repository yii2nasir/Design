<?php

$env = getenv("ENVIRONMENT");
$env = "development";
if( $env === "development" ) {
	return [
	    'class' => 'yii\db\Connection',
	    'dsn' => 'mysql:host=localhost;dbname=bigbasket_rpc',
	    'username' => 'root',
	    'password' => '',
	    'charset' => 'utf8',
	];
}
else if( $env === "staging" ) {
	return [
	    'class' => 'yii\db\Connection',
	    'dsn' => 'mysql:host=localhost;dbname=ifmr_staging',
	    'username' => 'root',
	    'password' => 'Jn0aX4SpjDb9uzi7',
	    'charset' => 'utf8',
	];
}
else {//For Production Environment
	return [
	    'class' => 'yii\db\Connection',
	    'dsn' => 'mysql:host=localhost;dbname=ifmr_web',
	    'username' => 'root',
	    'password' => 'Dhwani@123',
	    'charset' => 'utf8',
	];
}