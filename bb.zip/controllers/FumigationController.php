<?php

namespace app\controllers;

use Yii;
use app\models\Fumigation;
use app\models\FumigationSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\IncomingQcCheck;
use yii\helpers\ArrayHelper;
use app\models\FumigationMapper;
use yii\helpers\Url;

/**
 * FumigationController implements the CRUD actions for Fumigation model.
 */
class FumigationController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                // 'actions' => [
                //     'delete' => ['POST'],
                // ],
            ],
        ];
    }

    /**
     * Lists all Fumigation models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new FumigationSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Fumigation model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Fumigation model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Fumigation();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['index', 'id' => $model->id]);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Fumigation model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['index', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Fumigation model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Fumigation model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Fumigation the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Fumigation::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }



public function actionFumigationIndex(){
      $limit = 5;
      if(isset($_GET['page']) && $_GET['page'] !=""){
       $skip = ($_GET['page'] - 1) * $limit ;
      }else{
       $skip = 0;
      }


     $rpccenterId = getUserRpcCenterId();
     $query = new \yii\db\Query;
     $query->select(['incoming_qc_check.*',
         'product.name as product_name'])
     ->from('incoming_qc_check')
     ->innerJoin('product', 'product.id = incoming_qc_check.product_id')
     ->where(["<>",'incoming_qc_check.fumigation_status','Complete']);
     // ->andWhere(['IN','incoming_qc_check.user_id',$rpccenterId]);
     if(isset($_GET['product_id']) && $_GET['product_id'] !=""){
        $query->andWhere(['incoming_qc_check.product_id'=>$_GET['product_id']]);
     }
     $query->limit($limit)
     ->offset($skip);
     $command = $query->createCommand();
     $model = $command->queryAll();
     $query = new \yii\db\Query;
     $query->select(['incoming_qc_check.*',
         'product.name as product_name'])
     ->from('incoming_qc_check')
     ->innerJoin('product', 'product.id = incoming_qc_check.product_id')
     ->where(["<>",'incoming_qc_check.fumigation_status','Complete']);
     // ->andWhere(['IN','incoming_qc_check.user_id',$rpccenterId]);
     if(isset($_GET['product_id']) && $_GET['product_id'] !=""){
        $query->andWhere(['incoming_qc_check.product_id'=>$_GET['product_id']]);
     }
     $command = $query->createCommand();
     $countM = $command->queryAll();


     return $this->render('fumigationIndex',['model'=>$model,'count' => count($countM),'skip'=>$skip]); 
 }

public function actionFumigationOption(){
     // return $this->render('fumigation_option');
     $rpccenterId = getUserRpcCenterId();
     $query = new \yii\db\Query;
     $query->select(['incoming_qc_check.*',
         'product.name as product_name'])
     ->from('incoming_qc_check')
     ->innerJoin('product', 'product.id = incoming_qc_check.product_id')
     ->where(["<>",'incoming_qc_check.fumigation_status','Complete']);
     // ->andWhere(['IN','incoming_qc_check.user_id',$rpccenterId]);
     if(isset($_GET['product_id']) && $_GET['product_id'] !=""){
        $query->andWhere(['incoming_qc_check.product_id'=>$_GET['product_id']]);
     }
     $command = $query->createCommand();
     $model = $command->queryAll();
     return $this->render('fumigation_option',['model'=>$model]); 
}


public function actionFumigationProceed(){
  // if(isset($_POST['submit']) && !empty($_POST['submit'])){ 
    if(isset($_POST['Fumigation']) && !empty($_POST['Fumigation'])){ 
        $ids =  ArrayHelper::getColumn(array_values($_POST['Fumigation']), 'unique_id');
       foreach($ids as $key => $value)
        {
           if($value!='No'){
                 $query = new \yii\db\Query;
                 $query->select(['incoming_qc_check.*',
                     'product.name as product_name'])
                 ->from('incoming_qc_check')
                 ->innerJoin('product', 'product.id = incoming_qc_check.product_id')
                 ->where(['IN','incoming_qc_check.unique_id',$ids]);
                $command = $query->createCommand();
                $data = $command->queryAll();
                $f_type = new \yii\db\Query;
                $f_type->select(['*'])
                        ->from('fumigation_type');
                $commands = $f_type->createCommand();
                $f_type = $commands->queryAll();

                $model = new Fumigation();
                 return $this->render('fumigation_form',['data'=>$data,'model'=>$model,'f_type'=>$f_type]);
                 return $this->redirect(Url::toRoute('fumigation/fumigation-proceed'));

            }
            else{ 
                return $this->redirect(Url::toRoute('cleaning/index'));
           }
        }
    }
    else{
        echo '<script type="text/javascript">
        alert("Please choose Product for fumigation process");
        window.location.href="' . Url::to(['fumigation-option']) . '";
        </script>';
            return false;
   }
}

public function actionFumigationCreate(){
    $model = new Fumigation();
    if ($model->load(Yii::$app->request->post()) && $model->save()) {
        $this->quantity_taken($_POST['Fumigation'],$model->id);
        return $this->redirect(['fumigation-index']);
    }
}

function quantity_taken($post,$id){
    if(isset($post['quantity_taken']) && !empty($post['quantity_taken'])){
            if(isset($post['quantity_taken']) && !empty($post['quantity_taken'])){
                foreach ($post['quantity_taken'] as $value){
                  $quantityTaken = new FumigationMapper();
                  $quantityTaken->fumigation_id = $id;
                  $quantityTaken->product_id = $value['product_id'];
                  $quantityTaken->incoming_qc_uniq_id = $value['incoming_qc_uniq_id'];
                  $quantityTaken->batch_id = $value['batch_id'];
                  $quantityTaken->available_qty = $value['accepted_qty'];
                  $quantityTaken->quantity_value = $value['quantity_value'];
                  $quantityTaken->remaining_quantity = ($value['accepted_qty'])-($value['quantity_value']);
                  if($quantityTaken->save()){
                      $remaining_quantity = ($value['accepted_qty'])-($value['quantity_value']);
                        if($remaining_quantity == 0){
                          $model = IncomingQcCheck::find()->where(['unique_id'=>$value['incoming_qc_uniq_id']])->one();
                           if($model){
                              $model->fumigation_status = "Complete";
                              $model->save();
                            }
                        }
                  }
              }
          }
      }
    }   

  public function actionViewData(){
     if(isset($_GET['unique_id']) && $_GET['unique_id'] !=""){
         $ids = $_GET['unique_id'];
         $query = new \yii\db\Query;
         $query->select(['product.name as product_name',
                         'product.code as product_code',
                         'supplier.name as supplier_name',
                         'supplier.code as supplier_code',
                         'new_request.vehicle_inspection_checklist',
                         'incoming_qc_check.accepted_qty as total_quantity'
                        ])
         ->from('incoming_qc_check')
         ->leftJoin('product', 'product.id = incoming_qc_check.product_id')
         ->leftJoin('new_request', 'new_request.unique_id = incoming_qc_check.request_id')
         ->leftJoin('supplier', 'supplier.id = new_request.supplier_id')
         ->where(['incoming_qc_check.unique_id'=> $ids]);
         $command = $query->createCommand();
         $data = $command->queryOne();
        
         $array = [];
         if($data){
           $array['product_name'] = $data['product_name'];
           $array['product_code'] = $data['product_code'];
           $array['supplier_name'] = $data['supplier_name'];
           $array['supplier_code'] = $data['supplier_code'];
           $array['vehicle_inspection_checklist'] = count(json_decode($data['vehicle_inspection_checklist']));
           $array['total_quantity'] = $data['total_quantity'];
         }else{
           $array['product_name'] = "";
           $array['product_code'] = "";
           $array['supplier_name'] = "";
           $array['supplier_code'] = "";
           $array['vehicle_inspection_checklist'] = 0;
           $array['total_quantity'] =0;
         }
     }
      return json_encode($array);
  }
}
