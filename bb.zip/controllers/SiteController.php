<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use \app\models\GraphModels;
use yii\widgets\ActiveForm;
use Aws\Credentials\CredentialProvider;
use Aws\S3\S3Client;
use yii\helpers\Url;
use app\models\UserLocationMapper;

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

class SiteController extends Controller {

    public $enableCsrfValidation = false;

    public function behaviors() {
        return [
//            'access' => [
//                'class' => AccessControl::className(),
//                'only' => ['logout', 'index'],
//                'rules' => [
//                    [
//                        'actions' => ['logout', 'index'],
//                        'allow' => true,
//                        'roles' => ['@'],
//                    ],
//                ],
//            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
//                    'logout' => ['post'],
                ],
            ],
        ];
    }

    public function actions() {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    public function actionFarmerDetails() {
        checkAuthentication($this);
        return $this->render('graph_of_farmer_details');
    }

    public function actionIndex() {
        checkAuthentication($this);
        return $this->render('index');
    }

    public function actionLogin() {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }
        return $this->renderPartial('login', [
                    'model' => $model,
        ]);
    }

    public function actionLogout() {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    public function actionContact() {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('contact', [
                    'model' => $model,
        ]);
    }

    public function actionDashboard() {
        checkAuthentication($this);
        return $this->render('dashboard');
    }

    public function actionSample() {
        $request = Yii::$app->request;
        $response = Yii::$app->response;
        if ($request->isPost) {
            $data = $request->post();
//            display_array($data);   exit;
//            $searchname = explode(":", $data['searchname']);
            $response->format = \yii\web\Response::FORMAT_JSON;
            $successCode = $response->statusCode = 200;
            $response->data = ['searchName' => $data['searchname'], 'message' => 'Success world', "status" => $successCode];
            return $response;
        } else {
            throw new \yii\web\HttpException(400, 'Invalid request.');
        }
    }

    /* .....................START OF....................... */
    /*           Operational Level Dashbord               */
    /*     Control Function to call API For AGRICULTURE   */
    /* .................................................... */

// Get dependendlist For District Block Village
    public function actionLists()
    {
        $post = Yii::$app->request->post();
        if($post['type'] == 1){
            $query = new \yii\db\Query;
                     $query->select(['id','name'])  
                           ->from('district')
                           ->where(['state_id' => $post['id']]);
            $command = $query->createCommand();
            $operations = $command->queryAll();
            return json_encode($operations); 
        }
         
        if($post['type'] == 2) {
            $query = new \yii\db\Query;
                     $query->select(['id','rpc_name'])  
                           ->from('rpc_centre')
                           ->where(['district_id' => $post['id']]);
            $command = $query->createCommand();
            $operations = $command->queryAll();
            return json_encode($operations); 
      }
        if($post['type'] == 3){
            $query = new \yii\db\Query;
                     $query->select(['id','sub_cat_name'])  
                           ->from('sub_category')
                           ->where(['category_id' => $post['id']]);
            $command = $query->createCommand();
            $operations = $command->queryAll();
       
            return json_encode($operations); 
        }

         if($post['type'] == 4){
            $query = new \yii\db\Query;
                     $query->select(['id','name'])  
                           ->from('sub_sub_category')
                           ->where(['sub_cat_id' => $post['id']]);
            $command = $query->createCommand();
            $operations = $command->queryAll();
       
            return json_encode($operations); 
        }
        if($post['type'] == 5){
            $query = new \yii\db\Query;
                     $query->select(['id','sub_cat_name'])  
                           ->from('sub_category')
                           ->where(['category_id' => $post['id']]);
            $command = $query->createCommand();
            $operations = $command->queryAll();
            return json_encode($operations); 
        }

    }
    // End Here


    // Get Dependent List when update 

    public function actionGetDependentLists()
    {
       if ($id = Yii::$app->request->post('id')) {
                $operationPosts = \app\models\Nandghar::find()
                    ->where(['village_id' => $id])
                    ->count();
                if ($operationPosts > 0) {
                $query = new \yii\db\Query;
                $query->select(['village.id as villageId',
                                'district.id as districtId',
                                'block.id as blockId',
                                'state.id as stateId'
                               ])  
                ->from('state')
                ->innerJoin("district","district.state_id = state.id")
                ->innerJoin("block","block.district_id = district.id")
                ->innerJoin("village","village.block_id = block.id")
                ->where(['village.id' => $id]);
                $command = $query->createCommand();
                $operations = $command->queryAll();
                return json_encode($operations);
                    
            }
        }
    }

 public function actionGetAlert($id,$controller)
    {
     ?>
      <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title" id="myModalLabel" style="color: rgb(47,62,86)">Alert</h3>
              </div>
              <div class="modal-body">
                  Are you sure to delete this entry?
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" style="background-color: cadetblue !important; border-style: none; margin-top: -5px;" onclick="window.location = '../<?php echo $controller."/delete?id=".$id; ?>';">Yes</button>
              </div>
            </div>
          </div>
        </div>
      <?php
    }



  public function actionUploadCsvModal($controller,$action)
    {
      
     ?>
      <div class="modal fade" id="uploadCsv" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
          <div class="modal-dialog" role="document">
           <form action="<?= $action ?>" method="POST" enctype="multipart/form-data">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title" id="myModalLabel" style="color: rgb(47,62,86);">Upload <?= ucfirst($controller) ?>  Data</h3>
              </div>
              <div class="modal-body">
                  <input type="file" name="file_csv">
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary" onclick="" style="margin-bottom: 5px;background-color: cadetblue;border-style: none;">Upload</button>
              </div>
            </div>
            </form>
          </div>
        </div>
      <?php
    }


   //Uploded CSV type question
  //   protected function actionCsvUpload($model){
  //       $model->file_csv = UploadedFile::getInstance($model, 'file_csv');
  //       if($model->file_csv){
  //         $import_data = [];  
  //         $time = time();
  //         $model->file_csv->saveAs('uploads_csv/' .$time. '-' . $model->file_csv->name);
  //         $model->file_csv = 'uploads_csv/' .$time. '-' . $model->file_csv->name;
  //         if (($getdata = fopen($model->file_csv, "r")) !== FALSE) { 
  //              while (($data = fgetcsv($getdata)) !== FALSE) {
  //               $modelQuestion = New Questions();
  //                   $fieldCount = count($data);
  //                   for ($c=0; $c < $fieldCount; $c++) {
  //                     $columnData[$c] = $data[$c];
  //                   }
  //             $import_data[]= $columnData[0];
  //             $modelQuestion->questions_master_id = $model->id;
  //             $modelQuestion->questions = $columnData[0];
  //             $modelQuestion->save();
  //            }
  //         }
  //         fclose($getdata);
  //     }
  // }   

    public function actionProductList()
    {
        $post = Yii::$app->request->post();
        if($post['type'] == 1){
            $query = new \yii\db\Query;
                     $query->select(['id','name'])  
                           ->from('product')
                           ->where(['sub_sub_cat_id' => $post['id']]);
            $command = $query->createCommand();
            $operations = $command->queryAll();
            return json_encode($operations); 
        }
    }
 
public function actionGetUserLocationList() 
    {
        $obj = new UserLocationMapper();
        if ($postData = Yii::$app->request->post()) 
        {
          if($postData['level_id'] == 33){
            $location = UserLocationMapper::find()->where(["user_id"=>$postData['user_id']])->andWhere(['level_id' => $postData['level_id']])->asArray()->all();
                   $data =  $this->getStateDetail($location);
                   // return $data; 
            }else if($postData['level_id'] == 35){
            $location = UserLocationMapper::find()->where(["user_id"=>$postData['user_id']])->andWhere(['level_id' => $postData['level_id']])->asArray()->all();
               $data =  $this->getDistrictDetail($location);
               // return $data; 
            }else if($postData['level_id'] == 36){
            $location = UserLocationMapper::find()->where(["user_id"=>$postData['user_id']])->andWhere(['level_id' => $postData['level_id']])->asArray()->all();
               $data =  $this->getRPCDetail($location);
               // return $data; 
            }else if($postData['level_id'] == 37){
            $location = UserLocationMapper::find()->where(["user_id"=>$postData['user_id']])->andWhere(['level_id' => $postData['level_id']])->asArray()->all();
               $data =  $this->getRPCDetail($location);
               // return $data; 
            }else{
                return "Invalid User Level";
            }
            return $this->generateTable($data,$postData['level_id']);
        }
    }

    private function getStateDetail($location){
        foreach ($location as $value) {
            $loc[] = $value['location_id'];
        }
        $query = new \yii\db\Query;
        $query->select(['state.name as state_name'
                       ])  
        ->from('state')
        ->where(['state.id' => $loc]);
        $command = $query->createCommand();
        $masterData = $command->queryAll();
        return isset($masterData) && $masterData !="" ? $masterData:"";  
    }


    private function getDistrictDetail($location){
        foreach ($location as $value) {
            $loc[] = $value['location_id'];
        }
        $query = new \yii\db\Query;
        $query->select(['state.name as state_name',
                        'district.name as district_name'
                       ])  
        ->from('district')
        ->innerJoin('state',"state.id = district.state_id")
        ->where(['district.id' => $loc]);
        $command = $query->createCommand();
        $masterData = $command->queryAll();
        return isset($masterData) && $masterData !="" ?$masterData:"";  
    }
   
   private function getRPCDetail($location){
        $loc = [];
        foreach ($location as $value) {
            $loc[] = $value['location_id'];
        }
        
        $query = new \yii\db\Query;
        $query->select(['state.name as state_name',
                        'district.name as district_name',
                        'rpc_centre.rpc_name'  
                       ])  
        ->from('rpc_centre')
        ->innerJoin('district',"district.id = rpc_centre.district_id")
        ->innerJoin('state',"state.id = district.state_id")
        ->where(['rpc_centre.id' => $loc]);
        $command = $query->createCommand();
        $masterData = $command->queryAll();
        return isset($masterData) && $masterData !="" ?$masterData:"";  
    }

  private function generateTable($data,$level_id){
           $table = "<table width='100%' class='table table-bordered'>";
           $table .= "<thead style='width:50px;'>";
           $table .= "<tr>";

           if($level_id == 33){
           $table .= "<th style='width:70px;'>S. No.</th>";
           $table .= "<th style='width:100px;'>State</th>";
           }else if($level_id == 35){
           $table .= "<th style='width:70px;'>S. No.</th>";
           $table .= "<th style='width:100px;'>State</th>";
           $table .= "<th style='width:100px;'>District</th>";
           }else if($level_id == 36){
           $table .= "<th style='width:70px;'>S. No.</th>";
           $table .= "<th style='width:100px;'>State</th>";
           $table .= "<th style='width:100px;'>District</th>";
           $table .= "<th style='width:100px;'>RPC Center</th>";
           }else{
           $table .= "<th style='width:70px;'>S. No.</th>";
           $table .= "<th style='width:100px;'>State</th>";
           $table .= "<th style='width:100px;'>District</th>";
           $table .= "<th style='width:100px;'>RPC Centre</th>";
           }
           $table .= "</tr>";
           $table .= "</thead>"; 
           $sr_no = 1;
        foreach ($data as $value) {
           $table .= "<tr style='width:50px; height:20px;'>";
          if($level_id == 33){
            $table .= "<td>".$sr_no."</td>";
            $table .= "<td>".$value['state_name']."</td>";
          }else if($level_id == 35){
           $table .= "<td>".$sr_no."</td>";
           $table .= "<td>".$value['state_name']."</td>";
           $table .= "<td>".$value['district_name']."</td>";
          }else if($level_id == 36){
           $table .= "<td>".$sr_no."</td>";
           $table .= "<td>".$value['state_name']."</td>";
           $table .= "<td>".$value['district_name']."</td>";
           $table .= "<td>".$value['rpc_name']."</td>";
          }else{
           $table .= "<td>".$sr_no."</td>";
           $table .= "<td>".$value['state_name']."</td>";
           $table .= "<td>".$value['district_name']."</td>";
           $table .= "<td>".$value['rpc_name']."</td>";
          }
           $table .= "</tr></th></th>";
           $sr_no++;
        }
           $table .= "</thead>";
           $table .= "</tbody>"; 
           $table .= "</table>";
           return $table;          
    }
}
