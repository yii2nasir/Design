<?php

namespace app\controllers;

use Yii;
use app\models\IncomingQcCheck;
use app\models\IncomingQcCheckSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\QcCheckPhyChemical;
use app\models\ResultQcCheck;
use yii\web\UploadedFile;
use app\models\NewRequest;
use app\models\Product;

/**
 * IncomingQcCheckController implements the CRUD actions for IncomingQcCheck model.
 */
class IncomingQcCheckController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all IncomingQcCheck models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new IncomingQcCheckSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single IncomingQcCheck model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new IncomingQcCheck model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new IncomingQcCheck();
        $model->unique_id = uniqid();
        $model->updated_at = strtotime("now");
        $model->user_id = getUserId();
        $product_id=$_GET['p'];
        $model->product_image = UploadedFile::getInstance($model,'product_image');
        if($model->product_image){
                $product = strtotime("now").'.'.$model->product_image->extension;
                $model->product_image->saveAs('images/product/'.$product);
                $_POST['IncomingQcCheck']['product_image'] = $product;
        }
        $qcCheckPhyChemy =  QcCheckPhyChemical::find()->where('type="Incoming"')->andwhere('product_id='.$product_id)->all();
            // print_r($qcCheckPhyChemy);
        if ($model->load($_POST) && $model->save()){
             if(isset($_POST['IncomingQcCheck']['resultQcCheck']) && !empty($_POST['IncomingQcCheck']['resultQcCheck'])){
                $resultQcCheck = $_POST['IncomingQcCheck']['resultQcCheck'];
                
                foreach ($resultQcCheck as $value){
                  $resultQcCheck = new ResultQcCheck();
                  $resultQcCheck->value = $value['value'];
                  $resultQcCheck->qc_parameter_id = $value['id'];
                  $resultQcCheck->qc_check_id = $model->id;
                  $resultQcCheck->unique_id = uniqid();
                  $resultQcCheck->save();
                }
             }
            $status = $_POST['IncomingQcCheck']['overall_status'];
            if($status == "Onhold" || $status == "Accept"){
                if($status =="Onhold"){
                    $type = "o";
                }else{
                    $type = "a";
                }

                $request_id = $_POST['IncomingQcCheck']['request_id'];
                $product_id =  $_POST['IncomingQcCheck']['product_id'];
                if(isset($product_id,$request_id) && $product_id !="" && $request_id !=""){
                    return $this->redirect(['qc-check-update?rq_id='.$request_id.'&p='.$product_id.'&status='.$type.'']);
                }else{
                   return $this->redirect(['new-request/index']);
                }
             }
        }

        ////// Find User Id
        if(isset($_GET['rq_id'],$_GET['p']) && $_GET['rq_id'] && $_GET['p'] !=""){
           $newUserId = NewRequest::find()->where(['unique_id'=>$_GET['rq_id']])->one()->user_id;
           $productM = Product::find()->where(['id'=>$_GET['p']])->one();
           
        if(!$newUserId){
             return $this->redirect(['new-request/index']);    
        }else{
               $userId = $newUserId;
         } 
        }else{
             return $this->redirect(['new-request/index']);   
        }
        /// End User

        return $this->render('create', [
             'model' => $model,
             'qcCheckPhyChemy'=>$qcCheckPhyChemy,
             'userId'=>$userId,
             'productM'=>$productM
        ]);
    }

       public function actionQcCheckUpdate(){
          if(isset($_POST) && !empty($_POST)){
                 $request_id = $_POST['IncomingQcCheck']['request_id'];
                 $product_id =  $_POST['IncomingQcCheck']['product_id'];
                 $model = IncomingQcCheck::find()->where(['request_id'=>$request_id,'product_id'=>$product_id])->one();
                if ($model->load(Yii::$app->request->post()) && $model->save()) {
                    return $this->redirect(['new-request/index']);
                }
          }else if(isset($_GET['rq_id'],$_GET['p'],$_GET['status']) && $_GET['rq_id'] !="" && $_GET['p'] !="" && $_GET['status'] !=""){
               $newSupplierId = NewRequest::find()->where(['unique_id'=>$_GET['rq_id']])->one()->supplier_id;
               $model = IncomingQcCheck::find()->where(['request_id'=>$_GET['rq_id'],'product_id'=>$_GET['p']])->one(); 

              return $this->render('qc_check_update',['model' => $model,'supplierId'=>$newSupplierId,'status'=>$_GET['status']]);
          }else{
               return $this->redirect(['new-request']);   
          }
       }

    /**
     * Updates an existing IncomingQcCheck model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing IncomingQcCheck model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the IncomingQcCheck model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return IncomingQcCheck the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = IncomingQcCheck::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
