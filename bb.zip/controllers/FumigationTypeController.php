<?php

namespace app\controllers;

use Yii;
use app\models\Product;
use app\models\RpcCentre;
use app\models\FumigationType;
use app\models\FumigationTypeSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * FumigationTypeController implements the CRUD actions for FumigationType model.
 */
class FumigationTypeController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public $enableCsrfValidation = false;
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                // 'actions' => [
                //     'delete' => ['POST'],
                // ],
            ],
        ];
    }

    /**
     * Lists all FumigationType models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new FumigationTypeSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single FumigationType model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new FumigationType model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new FumigationType();
        if($_POST)
        {
            $model->load($_POST);
            $model->rpc_ids = json_encode($_POST['FumigationType']['rpc_ids']);
            $model->product_ids = json_encode($_POST['FumigationType']['product_ids']);
            if ($model->save()) {
                return $this->redirect(['view', 'id' => $model->fumigation_type_id]);
            }
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing FumigationType model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        if($_POST)
        {
            $model->load($_POST);
            $model->rpc_ids = json_encode($_POST['FumigationType']['rpc_ids']);
            $model->product_ids = json_encode($_POST['FumigationType']['product_ids']);
            if ($model->save()) {
                return $this->redirect(['index']);
                // return $this->redirect(['view', 'id' => $model->fumigation_type_id]);
            }
        }
        

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    public function actionFetchProducts()
    {
        if($_POST['type'] == 'Product')
        {
            $all_entries = FumigationType::find()->select(['product_ids'])->where(['fumigation_type_id'=> $_POST['id']])->one()->product_ids;
            $all_entries = json_decode($all_entries,true);
            $all_entries = Product::find()->select(['name'])->where(['in', 'id', $all_entries])->asArray()->all();
        }else{
            $all_entries = FumigationType::find()->select(['rpc_ids'])->where(['fumigation_type_id'=> $_POST['id']])->one()->rpc_ids;
            $all_entries = json_decode($all_entries,true);
            $all_entries = RpcCentre::find()->select(['rpc_name name'])->where(['in', 'id', $all_entries])->asArray()->all();
        }
        if(COUNT($all_entries) > 0)
        {
            $html = '<table class="table table-bordered">
                            <tr>
                               <th width="10%" >#</th>
                               <th>'.$_POST["type"].'</th>
                            </tr>';
            foreach ($all_entries as $key => $value) 
            {
                $key++;
                $html .= '<tr>
                       <td>
                         '.$key.'
                       </td>
                       <td>
                          '.$value ["name"].'
                       </td>
                    </tr>';       
            }

            $html .= '</table>';
            $response = ['status' => 200, 'type' => 'success', 'msg' => '', 'data' => $html];
        }else{
            $response = ['status' => 200, 'type' => 'error', 'msg' => 'No '.$_POST["type"].' Found', 'data' => ""];
        }
        

        echo json_encode($response);
    }

    /**
     * Deletes an existing FumigationType model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the FumigationType model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return FumigationType the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = FumigationType::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
