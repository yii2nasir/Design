<?php

namespace app\controllers;

use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
/**
 * ActivityController implements the CRUD actions for ActivityList model.
 */

class BaseController extends Controller
{
    public $user;
    public function beforeAction($action)
    {
        checkAuthentication($this);
        if (isset($_SESSION['login_info'])) {
            $this->user = $_SESSION['login_info']; 
        }
        return true;
    }
    
    public function uploaFile() {
        $tmp_name = $_FILES["file"]["tmp_name"];
        
        $arr = explode(".",$_FILES["file"]["name"]);
        
        $name = $arr[0].'_'.strtotime("now").'_'.$arr[1];
        $uploads_dir = \Yii::$app->params["imageBaseDirEducation"];
        //print_R($uploads_dir); exit;
        if (!file_exists($uploads_dir)) {
            mkdir($uploads_dir, 0777, true);
        }
        if (move_uploaded_file($tmp_name, $uploads_dir . $name)) {
            return $name;
        } else {
            return FALSE;
        }
        return FALSE;
    }
}
