<?php

namespace app\controllers;
use Yii;
use app\models\NewRequest;
use app\models\NewRequestSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\UploadedFile;
use app\models\IncomingQcCheck;
use app\models\Product;
use app\models\Supplier;
use yii\helpers\Url;




/**
 * NewRequestController implements the CRUD actions for NewRequest model.
 */
class NewRequestController extends Controller
{
    /**
     * @inheritdoc
     */

    public $enableCsrfValidation = false;
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                // 'actions' => [
                //     'delete' => ['POST'],
                // ],
            ],
        ];
    }
    /**
     * Lists all NewRequest models.
     * @return mixed
     */
    public function actionIndex()
    {
       $rpccenterId = getUserRpcCenterId();
       $newRequestM = NewRequest::find()->andWhere(['vehicle_status'=>'Accept'])->asArray()->orderBy(['id'=>SORT_DESC])->all();
       $arrayMain = [];
       if($newRequestM){
        foreach ($newRequestM as $value) {
               $supplierM = Supplier::find()->where(['unique_id'=>$value['supplier_id']])->one();
            
               if($supplierM){
                   $supplierName = $supplierM->name;
                   $supplierCode = $supplierM->code;
               }else{
                   $supplierName = "";
                   $supplierCode = "";
               }
               if($value['product_id']){
                 $product = json_decode($value['product_id']);
                  foreach ($product  as  $singleProduct) {
                     $incomingQCM = IncomingQcCheck::find()->where(['request_id'=>$value['unique_id']])->andWhere(['product_id'=>$singleProduct])->one();
                     if(!$incomingQCM){
                       $productM =Product::find()->where(['id'=>$singleProduct])->one();
                       if($productM){
                         $arrayMain[] = [
                                'id'=>$value['id'],
                                'supplier_name'=>$supplierName,
                                'supplier_code'=>$supplierCode,
                                'product_name'=>$productM->name,
                                'product_code'=>$productM->code,
                                'product_id'=>$productM->id,
                                'unique_id'=>$value['unique_id'],
                                'supplier_id'=>$value['supplier_id'],
                                'vehicle_inspection_checklist'=>$value['vehicle_inspection_checklist'],
                                'vehicle_status'=>$value['vehicle_status'],
                                'updated_at'=>$value['updated_at']
                           ];
                          
                       }
                    } 
                  }
               }
         }

       }
        $searchModel = new NewRequestSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'mainArray' =>$arrayMain
        ]);
    }

    /**
     * Displays a single NewRequest model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }
     
    /**
     * Creates a new NewRequest model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    function multiselect(){
        if(isset($_POST['NewRequest']['product_id']) && !empty($_POST['NewRequest']['product_id'])){
          $_POST['NewRequest']['product_id'] = json_encode($_POST['NewRequest']['product_id']);
      }
      if(isset($_POST['NewRequest']['vehicle_inspection_checklist']) && !empty($_POST['NewRequest']['vehicle_inspection_checklist'])){
          $_POST['NewRequest']['vehicle_inspection_checklist'] = json_encode($_POST['NewRequest']['vehicle_inspection_checklist']);
      }   

  }

  public function actionCreate()
  {
    $model = new NewRequest();
    $this->multiselect();
    $model->unique_id = uniqid();
    $model->updated_at = strtotime("now");   
    $model->vehicle_image = UploadedFile::getInstance($model,'vehicle_image');
    if($model->vehicle_image){
        $new_request = strtotime("now").'.'.$model->vehicle_image->extension;
        $model->vehicle_image->saveAs('images/new-request/'.$new_request);
        $_POST['NewRequest']['vehicle_image'] = $new_request;
    }

    if ($model->load($_POST)) {
        if($model->save()){
            return $this->redirect(['index', 'id' => $model->id]);
        }

    }
   
   
    ////CordinatorWise Rpc Centre
     $query = new \yii\db\Query;
     $query->select(['rpc_centre.rpc_name','rpc_centre.id'])
               ->from('rpc_centre')
               ->innerJoin('user_location_mapper','user_location_mapper.location_id = rpc_centre.id')
               ->innerJoin('users', 'users.id = user_location_mapper.user_id')
               ->innerJoin('district','district.id = rpc_centre.district_id')
               ->innerJoin('state','state.id = district.state_id');
               if(getUserLevelID() != 1){
                $query->where(['users.id'=> getUserId()]);
               }
    $command = $query->createCommand();
    $rpc_data = $command->queryall();


    return $this->render('create', [
        'model' => $model,
        'rpc_data'=>$rpc_data
    ]);
}

    /**
     * Updates an existing NewRequest model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);


        $this->multiselect();
        $model->unique_id = uniqid();
        $model->updated_at = strtotime("now");
        if ($model->load($_POST) && $model->save()) {
            return $this->redirect(['index', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing NewRequest model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the NewRequest model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return NewRequest the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = NewRequest::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }


    public function actionFindProduct(){
        $div = ''; 
        if(isset($_POST['product_id']) && $_POST['product_id'] !=""){
         $findProduct = Product::find()->where(['IN','id',$_POST['product_id']])->asArray()->all();
         $supplierName = Supplier::find()->where(['id'=>$_POST['suplier_id']])->one()->name;
         $div .='<div class="alert alert-success" align="center"><b>Supplier Name:</b> '.$supplierName.'</div><br><br>';
            if($findProduct){
                foreach ($findProduct as  $value) { 
                   $div .= '<div class="col-md-4"><div class="panel panel-default">';
                   $div.='<div class="panel-body">'.$value['name'].'</div>';
                   $div.='</div></div>';
                } 
            }
        }
    return $div;
    }

    public function actionProductWiseQcCheck(){
        if(isset($_GET['req_id']) && $_GET['req_id'] !=""){
           $id = $_GET['req_id'];
           $model =NewRequest::find()->where(['unique_id'=>$id])->one();
           $findSupplierName = Supplier::find()->where(['id'=>$model->supplier_id])->one();
          // echo "<pre>";print_r($findSupplierName);
               $result = [];
               if($model){
                    if($model->product_id){
                        $productList = json_decode($model->product_id);
                        foreach ($productList as $value) {
                            $product = Product::find()->where(['id'=>$value])->one();
                            if($product){
                                $result[]=[
                                    'request_id'=>$id,
                                    'user_id'=>$model->user_id,
                                    'supplier' => $findSupplierName ? $findSupplierName->name:"",
                                    'supplier_code' => $findSupplierName ? $findSupplierName->code:"",
                                    'product_id'=> $product->id,
                                    'product_nane'=> $product->name,
                                    'product_code'=> $product->code
                                ];
                            }
                        }

                    }
                    return $this->render('product_view', [
                      'result' => $result,
                   ]);  
                }
        }else{
        return $this->redirect(['index']); 
        }
     }


    public function actionOnholdproduct(){

       $rpccenterId = getUserRpcCenterId();
       $query = new \yii\db\Query;
       $query->select(['incoming_qc_check.*',
                'product.name as product_name'])
                 ->from('incoming_qc_check')
                 ->innerJoin('product', 'product.id = incoming_qc_check.product_id')
                 ->where(["=",'overall_status','Onhold']);
                 if(isset($_GET['product_id']) && $_GET['product_id'] !=""){
                    $query->andWhere(['incoming_qc_check.product_id'=>$_GET['product_id']]);
                 }
       $command = $query->createCommand();
       $model = $command->queryAll();       
        // echo $query->createCommand()->getRawSql();exit;
       return $this->render('On_hold_product',['model'=>$model]); 
   }
  public function actionOnholdproductprocess(){

         $rpccenterId = getUserRpcCenterId();
         $query = new \yii\db\Query;
         $query->select(['incoming_qc_check.*','incoming_qc_check.id as incomming_id',
             'product.id as productId','product.name as product_name','new_request.*','supplier.id as supplier_id','supplier.name as supplier_name'])
         ->from('incoming_qc_check')
         ->innerJoin('product', 'product.id = incoming_qc_check.product_id')
          ->innerJoin('new_request', 'new_request.unique_id = incoming_qc_check.request_id')
          ->innerJoin('supplier', 'supplier.id = new_request.supplier_id')

         ->where(["=",'overall_status','Onhold'])
         ->andWhere(['=','incoming_qc_check.id',$_GET['id']]);

         $command = $query->createCommand();
         $value = $command->queryOne();
         // echo $query->createCommand()->getRawSql();exit;
        if(isset($_POST['accept']) && !empty($_POST['accept'])){ 
           return $this->redirect(['incoming-qc-check/qc-check-update?rq_id='.$_GET['rq_id'].'&p='.$_GET['p']]);
        }
        if(isset($_POST['reject']) && !empty($_POST['reject'])){ 
          $update= \Yii::$app->db->createCommand()
                      ->update('incoming_qc_check', ['overall_status' =>'Reject'], 'id ='.$value['incomming_id'])
                       ->execute();   
          return $this->redirect(['new-request/onholdproduct']);
        }
         return $this->render('on_hold_product_process',['value'=>$value]); 

     }

    public function actionNewRequestList(){  
      $rpccenterId = getUserRpcCenterId();
         $query = new \yii\db\Query;
         $query->select(['new_request.*','supplier.name'])
         ->from('new_request')
          ->innerJoin('supplier', 'supplier.unique_id = new_request.supplier_id')
         // ->andWhere(['IN','new_request.user_id',$rpccenterId])
         ->orderBy(['new_request.id' => SORT_DESC]);
         $command = $query->createCommand();
         $data = $command->queryAll();
         // display_array($data);
         // exit;
          $i = 0;
         foreach ($data as  $value) {
           $data[$i]['product_id'] = $this->productList($value['product_id']); 
           $data[$i]['vehicle_inspection_checklist'] = $this->vehicleInspectionChecklist($value['vehicle_inspection_checklist']); 
           $i++;   
         }
       return $this->render('new_request_list',['data'=>$data]);
    }


    function productList($product){
         if($product){
            $productList = "";
            $i = 0;
             $productDecode = json_decode($product);
             foreach ($productDecode as  $singleValue) {
                 $productName = Product::find()->where(['id'=>$singleValue])->one()->name;
                 if($i==0){
                     $productList = $productName;
                 }else{
                    $productList = $productList .",". $productName;
                 }
                 $i++;
             }
         }
          return $productList;
    }
   function vehicleInspectionChecklist($vehicleCheckLict){
         if($vehicleCheckLict){
            $vehicleCheckList = "";
            $i = 0;
             $productDecode = json_decode($vehicleCheckLict);
             foreach ($productDecode as  $singleValue) {
                 if($i==0){
                     $vehicleCheckList = $singleValue;
                 }else{
                    $vehicleCheckList = $vehicleCheckList .",". $singleValue;
                 }
                 $i++;
             }
         }
          return $vehicleCheckList;
    }

}


