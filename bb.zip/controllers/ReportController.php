<?php

namespace app\controllers;

use Yii;
use app\models\Supplier;
use app\models\Users;
use app\models\Product;
use app\models\ProductSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\RpcCentre;
use yii\helpers\Url;
use yii\phpoffice\phpexcel; 
use Lib;

/**
* ProductController implements the CRUD actions for Product model.
*/
class ReportController extends Controller
{
   public $enableCsrfValidation = false;
/**
* @inheritdoc
*/
public $S=1;
public function behaviors()
{
   return [
      'verbs' => [
         'class' => VerbFilter::className(),
// 'actions' => [
//     'delete' => ['POST'],
// ],
      ],
   ];
}

public function actionIncomingBulkInspection(){
   return $this->render('index');

}

public function actionIncomingBulkData(){
   $post = Yii::$app->request->post();

   $query = new \yii\db\Query;
   $query->select([
      'incoming_qc_check.id',
      'incoming_qc_check.created_at',
      'date_format(incoming_qc_check.created_at,"%d-%m-%Y") as created_date',
      'result_qc_check.value',
      'qc_check_phy_chemical.name',
      'qc_check_phy_chemical.option_1',
      'qc_check_phy_chemical.option_2',
      'qc_check_phy_chemical.option_3',
      'qc_check_phy_chemical.option_4',
      'supplier.name as supplier_name',
      'product.name as product_name',
      'incoming_qc_check.product_image',
      'incoming_qc_check.overall_status',
      'incoming_qc_check.accepted_qty',
      'incoming_qc_check.arrived_qty',
      'incoming_qc_check.comments',
      'incoming_qc_check.batch_id',
      'user_location_mapper.location_id'

   ])  
   ->from('incoming_qc_check')
   ->innerJoin('result_qc_check','result_qc_check.qc_check_id =incoming_qc_check.id')
   ->innerJoin('qc_check_phy_chemical','qc_check_phy_chemical.id =result_qc_check.qc_parameter_id')
   ->innerJoin('product','product.id = incoming_qc_check.product_id')
   ->innerJoin('supplier','supplier.unique_id =incoming_qc_check.supplier_id') 
   ->innerJoin('user_location_mapper','incoming_qc_check.user_id = user_location_mapper.user_id'); 
   $RpcName = "";
   if(isset($post['rpc_centre']) && $post['rpc_centre'] !=""){
      $RpcName  = RpcCentre::find()->where(['id'=>$post['rpc_centre']])->one()->rpc_name;
      $query->where(['user_location_mapper.location_id'=>$post['rpc_centre']]); 
   }

   if(isset($post['from_date'],$post['to_date']) && $post['from_date'] !="" && $post['to_date'] !=""){
      $query->andWhere(['between', 'date_format(incoming_qc_check.created_at,"%Y-%m-%d")',$post['from_date'], $post['to_date']]);
   }

   $command = $query->createCommand();
   $data = $command->queryAll();
   $mainArray = [];
   $incomingArray = [];
   $i = 0;
   foreach ($data as  $value) {
      if(!in_array($value['id'], $incomingArray)){

         if($value['product_image'] !=""){
            $url =  "https://" . $_SERVER['SERVER_NAME'].Url::base()."/images/incoming-qc-check/";
            $value['product_image'] =  $url.$value['product_image'];
         }else{
            $value['product_image'] = "";
         }

         $mainArray[$value['id']]['supplier_name'] = $value['supplier_name'];
         $mainArray[$value['id']]['product_name'] = $value['product_name'];
         $mainArray[$value['id']]['created_date'] = $value['created_date'];
         $mainArray[$value['id']]['product_image'] = $value['product_image'];
         $mainArray[$value['id']]['bulk'][$i]['value'] = $value['value'];
         $mainArray[$value['id']]['bulk'][$i]['name'] = $value['name'];
         $mainArray[$value['id']]['bulk'][$i]['option_1'] = $value['option_1'];
         $mainArray[$value['id']]['bulk'][$i]['option_2'] = $value['option_2'];
         $mainArray[$value['id']]['bulk'][$i]['option_3'] = $value['option_3'];
         $mainArray[$value['id']]['bulk'][$i]['option_4'] = $value['option_4'];
         $mainArray[$value['id']]['overall_status'] = $value['overall_status'];
         $mainArray[$value['id']]['accepted_qty'] = $value['accepted_qty'];
         $mainArray[$value['id']]['arrived_qty'] = $value['arrived_qty'];
         $mainArray[$value['id']]['comments'] = $value['comments'];
         $mainArray[$value['id']]['batch_id'] = $value['batch_id'];
         $incomingArray[] = $value['id'];
         $i++;
      }else{
         $mainArray[$value['id']]['bulk'][$i]['value'] = $value['value'];
         $mainArray[$value['id']]['bulk'][$i]['value'] = $value['value'];
         $mainArray[$value['id']]['bulk'][$i]['name'] = $value['name'];
         $mainArray[$value['id']]['bulk'][$i]['option_1'] = $value['option_1'];
         $mainArray[$value['id']]['bulk'][$i]['option_2'] = $value['option_2'];
         $mainArray[$value['id']]['bulk'][$i]['option_3'] = $value['option_3'];
         $mainArray[$value['id']]['bulk'][$i]['option_4'] = $value['option_4'];
         $i++;
      }

   }

// echo '<pre>';print_r($mainArray);exit;
   $html = '<table id="toExcel" class="display nowrap table table-bordered" style="width:100%; font-size: 14px;">';
   $html .= "<thead><tr>";
   $html .= '<th colspan="16" style="background-color : #78a6e0">Incoming Bulk Inspection Report</th>';
   $html .= '</tr><tr></thead><tbody>';
   $html .= '<tr>';
   $html .= '<th colspan="1">Processing Center</th>';
   $html .= '<td colspan="15">'.$RpcName.'</td>';
   $html .= '</tr>';
   $html .= '<tr>';
   $html .= '<th colspan="1">Date</th>';
   $html .= '<td colspan="15">'.date('d-m-Y').'</td>';
   $html .= '</tr>';

   $html .= '<tr >';
   $html .= '<th>Sr.No</th>';
   $html .= '<th>Received On</th>';
   $html .= '<th>Article Name</th>';
   $html .= ' <th>Supplier Name</th>';
// $html .= '<th>COA received</th>';
   $html .= '<th>Image</th>';
// $html .= '<th>Brand Name</th>';
   $html .= '<th>Qty Received in kgs</th>';
   $html .= '<th colspan="4">Specification</th>';
   $html .= '<th>Accepted/Rejected</th>';
   $html .= '<th>Incoming Batch Number</th>';
   $html .= '<th style="padding-right:20% !important">Remarks</th>';
   $html .= '<th>Action Taken</th>';
   $html .= '</tr>';
   $srNo = 1; 
   if(array_values($mainArray)){
      $dataAll = array_values($mainArray);
      foreach ($dataAll as $singleValue) {
         $bulkData = array_values($singleValue['bulk']);
         $count = count(array_values($singleValue['bulk']));


         $html .= '<tr>';
         $html .= '<td rowspan='.($count + 1).'>'.$srNo.'</td>';
         $html .= '<td rowspan='.($count + 1).'>'.$singleValue['created_date'].'</td>';
         $html .= '<td rowspan='.($count + 1).'>'.$singleValue['product_name'].'</td>';
         $html .= '<td rowspan='.($count + 1).'>'.$singleValue['supplier_name'].'</td>';
// $html .= '<td rowspan='.($count + 1).'></td>';
         if($singleValue['product_image'] !=""){
            $html .= '<td rowspan='.($count + 1).'><a href="'.$singleValue["product_image"].'" style="cursor:pointer;" class="img_popup" >view image</a></td>';
         }else{
            $html .='<td rowspan='.($count + 1).'></td>';
         }
// $html .= '<td rowspan='.($count + 1).'></td>';
         $html .= '<td rowspan='.($count + 1).'>'.$singleValue['accepted_qty'].'</td>';
         $html .= '<th>Parameters</th>';
         $html .= '<th>Min</th>';
         $html .= '<th>Max</th>';
         $html .= '<th>Actual</th>';
         $html .= '<td rowspan='.($count + 1).'>'.$singleValue['overall_status'].'</td>';
         $html .= '<td rowspan='.($count + 1).'>'.$singleValue['batch_id'].'</td>';
         $html .= '<td rowspan='.($count + 1).'>'.$singleValue['comments'].'</td>';
         $html .= ' <td rowspan='.($count + 1).'></td>';
         $html .= '</tr>';
         foreach ($bulkData as $singleBulk) {
            $html .= '<tr>';
            $html .= '<td>'.$singleBulk['name'].'</td>';
            $html .= '<td>'.$singleBulk['option_1'].'</td>';
            $html .= '<td>'.$singleBulk['option_2'].'</td>';
            $html .= '<td>'.$singleBulk['value'].'</td>';
            $html .= '</tr>';
         }
         $srNo ++;
      }
   }else{
      $html .="<tr>";
      $html .="<td colspan='15'>No record found</td>";
      $html .="</tr>";
   }    
   $html .= '</tbody>';
   $html .= '</table>';  
   return $html;
}
public function actionFinalGoodsInspection(){
   return $this->render('final_good_inspection');
}

public function actionFinalGoodsInspectionData(){
   $post = Yii::$app->request->post();
   $query = new \yii\db\Query;
   $query->select([
      'fg_qc_check.id',
      'fg_qc_check.product_id',
      'qc_check_phy_chemical.name',
      'date_format(fg_qc_check.created_at,"%Y-%m-%d") as created_date',
      'product.name as product_name',
      'qc_check_phy_chemical.option_1',
      'qc_check_phy_chemical.option_2',
      'qc_check_phy_chemical.option_3',
      'qc_check_phy_chemical.option_4',
      'fg_check_result.value',
      'fg_qc_check.photo',
      'fg_qc_check.overall_status',
      'fg_qc_check.comment',
      'fg_qc_check.batch_id',
      'user_location_mapper.location_id'
   ])  
   ->from('fg_qc_check')
   ->innerJoin('fg_check_result','fg_qc_check.id = fg_check_result.fg_qc_check_id')
   ->innerJoin('qc_check_phy_chemical','qc_check_phy_chemical.id = fg_check_result.qc_parameter_id')
   ->innerJoin('product','product.id = fg_qc_check.product_id')
   ->innerJoin('user_location_mapper','fg_qc_check.user_id = user_location_mapper.user_id');

   $RpcName = "";
   if(isset($post['rpc_centre']) && $post['rpc_centre'] !=""){
      $RpcName  = RpcCentre::find()->where(['id'=>$post['rpc_centre']])->one()->rpc_name;
      $query->where(['user_location_mapper.location_id'=>$post['rpc_centre']]); 
   }

   if(isset($post['from_date'],$post['to_date']) && $post['from_date'] !="" && $post['to_date'] !=""){
      $query->andWhere(['between', 'date_format(fg_qc_check.created_at,"%Y-%m-%d")',$post['from_date'], $post['to_date']]);
   }
   $command = $query->createCommand();
   $data = $command->queryAll();


   $mainArray = [];
   $incomingArray = [];
   $i = 0;
   foreach ($data as  $value) {
      if(!in_array($value['id'], $incomingArray)){

         if($value['photo'] !=""){
            $url =  "https://" . $_SERVER['SERVER_NAME'].Url::base()."/images/fg-qc-check/";
            $value['photo'] =  $url.$value['photo'];
         }else{
            $value['photo'] = "";
         }

         $mainArray[$value['id']]['paked_size'] = $this->findPackedSize($value['id']); 
         $mainArray[$value['id']]['product_name'] = $value['product_name'];
         $mainArray[$value['id']]['created_date'] = $value['created_date'];
         $mainArray[$value['id']]['photo'] = $value['photo'];
         $mainArray[$value['id']]['bulk'][$i]['value'] = $value['value'];
         $mainArray[$value['id']]['bulk'][$i]['name'] = $value['name'];
         $mainArray[$value['id']]['bulk'][$i]['option_1'] = $value['option_1'];
         $mainArray[$value['id']]['bulk'][$i]['option_2'] = $value['option_2'];
         $mainArray[$value['id']]['bulk'][$i]['option_3'] = $value['option_3'];
         $mainArray[$value['id']]['bulk'][$i]['option_4'] = $value['option_4'];
         $mainArray[$value['id']]['overall_status'] = $value['overall_status'];
         $mainArray[$value['id']]['comment'] = $value['comment'];
         $mainArray[$value['id']]['batch_id'] = $value['batch_id'];
         $mainArray[$value['id']]['id'] = $value['id'];
         $incomingArray[] = $value['id'];
         $i++;
      }else{
         $mainArray[$value['id']]['bulk'][$i]['value'] = $value['value'];
         $mainArray[$value['id']]['bulk'][$i]['value'] = $value['value'];
         $mainArray[$value['id']]['bulk'][$i]['name'] = $value['name'];
         $mainArray[$value['id']]['bulk'][$i]['option_1'] = $value['option_1'];
         $mainArray[$value['id']]['bulk'][$i]['option_2'] = $value['option_2'];
         $mainArray[$value['id']]['bulk'][$i]['option_3'] = $value['option_3'];
         $mainArray[$value['id']]['bulk'][$i]['option_4'] = $value['option_4'];
         $i++;
      }

   }

// display_array($mainArray);
// exit;

   $html = '<table id="toExcel" class="display nowrap table table-bordered" style="width:100%; font-size: 14px;">';
   $html .= "<thead><tr>";
   $html .= '<th colspan="19" style="background-color : #78a6e0">Final Goods Inspection Report</th>';
   $html .= '</tr><tr></thead><tbody>';
   $html .= '<tr>';
   $html .= '<th colspan="1">Processing Center</th>';
   $html .= '<td colspan="18">'.$RpcName.'</td>';
   $html .= '</tr>';
   $html .= '<tr>';
   $html .= '<th colspan="1">Date</th>';
   $html .= '<td colspan="18">'.date('d-m-Y').'</td>';
   $html .= '</tr>';

   $html .= '<tr >';
   $html .= '<th>Sr.No</th>';
   $html .= '<th>Product Name</th>';
   $html .= '<th>Raw material Batch No.</th>';

   $html .= '<th colspan="4">Specification</th>';
// $html .= '<th>Accepted/Rejected</th>';
$html .= '<th>Packed Size(Kg&#8217;s)</th>'; //  weight of individual packet
$html .= '<th>No. of Packs</th>'; //  no of packet
$html .= '<th>Packed Weight (Kg&#8217;s)</th>'; //  total weight of material
// $html .= '<th>Balance Quantity</th>';
// $html .= '<th>Lot No FG</th>';
// $html .= '<th>Checked By</th>';
$html .= '<th>Total Packed Quantity</th>';
$html .= '<th style="padding-right:20% !important">Remarks</th>';
$html .= '<th>Action Taken</th>';
$html .= '</tr>';

$srNo = 1; 
if(array_values($mainArray)){
   $dataAll = array_values($mainArray);
   foreach ($dataAll as $singleValue) {
      $bulkData = array_values($singleValue['bulk']);
      $pakedQuantity = $singleValue['paked_size'];
      $count = count(array_values($singleValue['bulk']));  

      $html .= '<tr>';
      $html .= '<td rowspan='.($count + 1).'>'.$srNo.'</td>';
      $html .= '<td rowspan='.($count + 1).'>'.$singleValue['product_name'].'</td>';
      $html .= '<td rowspan='.($count + 1).'>'.$singleValue['batch_id'].'</td>';
      $html .= '<th>Parameters</th>';
      $html .= '<th>Min</th>';
      $html .= '<th>Max</th>';
      $html .= '<th>Actual</th>';
// $html .= '<td rowspan='.($count + 1).'>'.$singleValue['overall_status'].'</td>';
      list($PackedSize,$NoofPacks,$PackedWeight) = "";
      $totalCount = 0;
      if($pakedQuantity){ 
         foreach ($pakedQuantity as $singlePacked) {
            $PackedSize .='<p>'.$singlePacked['packed_weight'].'</p>';
            $NoofPacks .='<p>'.($singlePacked['packed_quantity']).'</p>';
            $PackedWeight .='<p>'.($singlePacked['packed_weight']) * ($singlePacked['packed_quantity']).'</p>';
            $totalCount = $totalCount + ($singlePacked['packed_weight']) * ($singlePacked['packed_quantity']);
         }
      }
      $html .= '<td rowspan='.($count + 1).'>'.$PackedSize.'</td>';
      $html .= '<td rowspan='.($count + 1).'>'.$NoofPacks.'</td>';
      $html .= '<td rowspan='.($count + 1).'>'.$PackedWeight.'</td>';
      $html .= '<td rowspan='.($count + 1).'>'.$totalCount.'</td>';
// $html .= '<td rowspan='.($count + 1).'></td>';
// $html .= '<td rowspan='.($count + 1).'></td>';
// $html .= '<td rowspan='.($count + 1).'></td>';

      $html .= '<td rowspan='.($count + 1).'>'.$singleValue['comment'].'</td>';
      $html .= '<td rowspan='.($count + 1).'><a href="fg-analysis?a_id='.$singleValue['id'].'" class="btn btn-success">Analysis</a></td>';
      $html .= '</tr>';
      foreach ($bulkData as $singleBulk) {
         $html .= '<tr>';
         $html .= '<td>'.$singleBulk['name'].'</td>';
         $html .= '<td>'.$singleBulk['option_1'].'</td>';
         $html .= '<td>'.$singleBulk['option_2'].'</td>';
         $html .= '<td>'.$singleBulk['value'].'</td>';
         $html .= '</tr>';
      }
      $srNo ++;
   }
}else{
   $html .="<tr>";
   $html .="<td colspan='15'>No record found</td>";
   $html .="</tr>";
}  

$html .= '</tbody>';
$html .= '</table>';  
return $html; 
}

public function findPackedSize($id){
   $query = new \yii\db\Query;
   $query->select([
      'fg_qc_check_mapper.packed_weight',
      'fg_qc_check_mapper.packed_quantity'
   ])  
   ->from('fg_qc_check')
   ->innerJoin('fg_qc_check_mapper','fg_qc_check_mapper.fg_qc_uniq_id = fg_qc_check.unique_id')
   ->where(['fg_qc_check.id'=>$id]);
   $command = $query->createCommand();
   return $command->queryAll();

}

public function actionFgAnalysis(){

   if(isset($_GET['a_id']) && $_GET['a_id'] !=""){
      $query = new \yii\db\Query;
      $query->select([
         'fg_qc_check.id',
         'fg_qc_check.product_id',
         'qc_check_phy_chemical.name',
         'date_format(fg_qc_check.created_at,"%Y-%m-%d") as created_date',
         'product.name as product_name',
         'qc_check_phy_chemical.option_1',
         'qc_check_phy_chemical.option_2',
         'qc_check_phy_chemical.option_3',
         'qc_check_phy_chemical.option_4',
         'fg_check_result.value',
         'fg_qc_check.photo',
         'fg_qc_check.overall_status',
         'fg_qc_check.comment',
         'fg_qc_check.batch_id',
         'user_location_mapper.location_id',
         'supplier.name as supplier_name',
         'district.name as district_name',
         'rpc_centre.rpc_name',
         'users.name as user_name'

      ])  
      ->from('fg_qc_check')
      ->innerJoin('fg_check_result','fg_qc_check.id = fg_check_result.fg_qc_check_id')
      ->innerJoin('qc_check_phy_chemical','qc_check_phy_chemical.id = fg_check_result.qc_parameter_id')
      ->innerJoin('product','product.id = fg_qc_check.product_id')
      ->innerJoin('user_location_mapper','fg_qc_check.user_id = user_location_mapper.user_id')
      ->innerJoin('users','users.id = user_location_mapper.user_id')
      ->innerJoin('rpc_centre','rpc_centre.id = user_location_mapper.location_id')
      ->innerJoin('district','district.id = rpc_centre.district_id')
      ->innerJoin('incoming_qc_check','incoming_qc_check.batch_id =fg_qc_check.batch_id') 
      ->innerJoin('supplier','supplier.unique_id =incoming_qc_check.supplier_id') 
      ->where(['fg_qc_check.id'=>$_GET['a_id']]);
      $command = $query->createCommand();
      $data = $command->queryAll();


      $query = new \yii\db\Query;
      $query->select([
         'fg_qc_check_mapper.packed_weight',
         'fg_qc_check_mapper.packed_quantity'
      ])  
      ->from('fg_qc_check')
      ->innerJoin('fg_qc_check_mapper','fg_qc_check_mapper.fg_qc_uniq_id = fg_qc_check.unique_id')
      ->where(['fg_qc_check.id'=>$_GET['a_id']]);
      $command = $query->createCommand();
      $packSizeAll = $command->queryAll();

      $mainArray = [];
      $incomingArray = [];
      $i = 0;
      foreach ($data as  $value) {
         if(!in_array($value['id'], $incomingArray)){
            $mainArray[$value['id']]['district_name'] = $value['district_name'];
            $mainArray[$value['id']]['rpc_name'] = $value['rpc_name'];
            $mainArray[$value['id']]['user_name'] = $value['user_name'];
            $mainArray[$value['id']]['supplier_name'] = $value['supplier_name'];
            $mainArray[$value['id']]['product_name'] = $value['product_name'];
            $mainArray[$value['id']]['created_date'] = $value['created_date'];
// $mainArray[$value['id']]['photo'] = $value['photo'];
            $mainArray[$value['id']]['bulk'][$i]['value'] = $value['value'];
            $mainArray[$value['id']]['bulk'][$i]['name'] = $value['name'];
            $mainArray[$value['id']]['bulk'][$i]['option_1'] = $value['option_1'];
            $mainArray[$value['id']]['bulk'][$i]['option_2'] = $value['option_2'];
            $mainArray[$value['id']]['bulk'][$i]['option_3'] = $value['option_3'];
            $mainArray[$value['id']]['bulk'][$i]['option_4'] = $value['option_4'];
            $mainArray[$value['id']]['overall_status'] = $value['overall_status'];
            $mainArray[$value['id']]['comment'] = $value['comment'];
            $mainArray[$value['id']]['batch_id'] = $value['batch_id'];
            $mainArray[$value['id']]['id'] = $value['id'];
            $incomingArray[] = $value['id'];
            $i++;
         }else{
            $mainArray[$value['id']]['bulk'][$i]['value'] = $value['value'];
            $mainArray[$value['id']]['bulk'][$i]['value'] = $value['value'];
            $mainArray[$value['id']]['bulk'][$i]['name'] = $value['name'];
            $mainArray[$value['id']]['bulk'][$i]['option_1'] = $value['option_1'];
            $mainArray[$value['id']]['bulk'][$i]['option_2'] = $value['option_2'];
            $mainArray[$value['id']]['bulk'][$i]['option_3'] = $value['option_3'];
            $mainArray[$value['id']]['bulk'][$i]['option_4'] = $value['option_4'];
            $i++;
         }

      }
      return $this->render('fg_analysis',['data'=>array_values($mainArray),'packSizeAll'=>$packSizeAll]);
   }
}

public function actionFgListTemplate(){

// SELECT
//     fg_qc_check.id
// FROM
//     `new_request`
// INNER JOIN incoming_qc_check ON incoming_qc_check.request_id = new_request.unique_id   
// RIGHT JOIN fumigation_mapper ON fumigation_mapper.batch_id = incoming_qc_check.batch_Id
// RIGHT JOIN fumigation ON fumigation.id = fumigation_mapper.fumigation_id
// RIGHT JOIN cleaning_mapper ON cleaning_mapper.batch_id = fumigation_mapper.batch_Id
// RIGHT JOIN cleaning ON cleaning.id = cleaning_mapper.cleaning_id
// INNER JOIN fg_qc_check ON fg_qc_check.batch_id = cleaning_mapper.batch_id

   $query = new \yii\db\Query;
   $query->select([
      'fg_qc_check.id',
      'concat(fg_check_result.value,"-",product.name) as value',
   ])  
   ->from('fg_qc_check')
   ->innerJoin('fg_check_result','fg_check_result.fg_qc_check_id = fg_qc_check.id')
   ->innerJoin('qc_check_phy_chemical',' qc_check_phy_chemical.id = fg_check_result.qc_parameter_id')
   ->innerJoin('product','product.id = fg_qc_check.product_id')
   ->where(['qc_check_phy_chemical.name'=>"FG Batch Number *"]);
   $command = $query->createCommand();

   $data = $command->queryAll();
   return $this->render('fg_list_template',['data'=>$data]);
}

public function actionAllListFg(){

   $data = [];
   if(isset($_POST['fg_batch']) &&  $_POST['fg_batch'] !=""){
      $query = new \yii\db\Query;
      $query->select([
         'fg_qc_check.id',
         'product.name as product_name',
         'fg_qc_check.overall_status as fg_status',
         'fg_qc_check.created_at as fg_qc_check_date',
         'cleaning.created_at as cleaning_date',
         'cleaning.overall_status as cleaning_status',
         'fumigation.created_at as fumigation_date',
         'fumigation.fumigation_effective',
         'fumigation.re_fumigate',
         'fumigation.fumigation_type',
         'fumigation.overall_status as fumigation_status',
         'incoming_qc_check.created_at as incoming_date',
         'incoming_qc_check.batch_id as incoming_batch_id',
         'incoming_qc_check.arrived_qty',
         'incoming_qc_check.accepted_qty',
         'incoming_qc_check.overall_status',
         'new_request.created_at as vehicle_inspection_date',
         'new_request.vehicle_inspection_checklist',
         'new_request.vehicle_status',
         'SUM(fg_qc_check_mapper.packed_quantity) as packed_quantity',
         'cleaning.cleaning_checklist'

      ])  
      ->from('new_request')
      ->innerJoin('incoming_qc_check','incoming_qc_check.request_id = new_request.unique_id')
      ->leftJoin('fumigation_mapper','fumigation_mapper.batch_id = incoming_qc_check.batch_Id')
      ->leftJoin('fumigation','fumigation.id = fumigation_mapper.fumigation_id')
      ->leftJoin('cleaning_mapper','cleaning_mapper.batch_id = incoming_qc_check.batch_Id')
      ->leftJoin('cleaning','cleaning.id = cleaning_mapper.cleaning_id')
      ->innerJoin('fg_qc_check','fg_qc_check.batch_id = incoming_qc_check.batch_id')
      ->innerJoin('fg_qc_check_mapper','fg_qc_check_mapper.fg_qc_uniq_id = fg_qc_check.unique_id')
      ->innerJoin('product','product.id = fg_qc_check.product_id')
      ->andWhere(['fg_qc_check.id'=>$_POST['fg_batch']]);
      $command = $query->createCommand();
      $data = $command->queryAll();
   }

   $query = new \yii\db\Query;
   $query->select([
      'fg_check_result.value',
   ])  
   ->from('fg_qc_check')
   ->innerJoin('fg_check_result','fg_check_result.fg_qc_check_id = fg_qc_check.id')
   ->innerJoin('qc_check_phy_chemical',' qc_check_phy_chemical.id = fg_check_result.qc_parameter_id')
   ->where(['qc_check_phy_chemical.name'=>"FG Batch Number *"])
   ->andWhere(['fg_qc_check.id'=>$_POST['fg_batch']])
   ->groupBy('fg_check_result.value');
   $command = $query->createCommand();
   $dataBatch = $command->queryOne();

   if(isset($dataBatch['value']) && $dataBatch['value'] !=""){
      $batchName = $dataBatch['value'];
   }else{
      $batchName = "";
   }



   $html = '<table class="table table-bordered">';
   $html .='<tbody>';
   if($data){

      $html .='<tr><td>FG Batch Number </td><td>'.$batchName.'</td></tr>';
      $html .='<tr><td>Product Name</td><td>'.$data[0]['product_name'].'</td></tr>';

      $html .='<tr><td>Packed Quantity</td><td>'.$data[0]['packed_quantity'].'</td></tr>';
      $html .='<tr><td>FG QC Check Date</td><td>'.$data[0]['fg_qc_check_date'].'</td></tr>';
// $html .='<tr><td>Status</td><td>'.$data[0]['fg_status'].'</td></tr>';


      $html .='<tr><td>Cleaning Date </td><td>'.$data[0]['cleaning_date'].'</td></tr>';
// $i= 0;
// $checkList = "";
// if(isset($data[0]['cleaning_checklist']) && $data[0]['cleaning_checklist'] !=""){
//    $jsonDecode = json_decode($data[0]['cleaning_checklist'],true);

//    if($jsonDecode){
//     // $checkList = "";
//     $i= 0;
//      foreach ($jsonDecode as $cleanList) {
//          if($i== 0){
//           $checkList = $cleanList['value'];

//          }else{
//            $checkList = $checkList .",". $checkList['value'];
//          }
//          $i++;
//      }
//               echo "<pre>";
//    print_r($checkList);
//    exit;
//    }

// }

// $html .='<tr><td>Cleaning Checks </td><td>'.$checkList.'</td></tr>';

// $html .='<tr><td>Quantity Cleaned</td><td>'.$data[0]['product_name'].'</td></tr>';
      $html .='<tr><td>Status</td><td>'.$data[0]['cleaning_status'].'</td></tr>';

      $html .='<tr><td>Fumigation Date </td><td>'.$data[0]['fumigation_date'].'</td></tr>';
      $html .='<tr><td>Fumigation Type</td><td>'.$data[0]['fumigation_type'].'</td></tr>';

      $html .='<tr><td>Fumigation Effective </td><td>'.$data[0]['fumigation_effective'].'</td></tr>';
      $html .='<tr><td>Re - Fumigation </td><td>'.$data[0]['re_fumigate'].'</td></tr>';

      $html .='<tr><td>Status </td><td>'.$data[0]['fumigation_status'].'</td></tr>';

      $html .='<tr><td>Incoming QC Check Date </td><td>'.$data[0]['incoming_date'].'</td></tr>';
      $html .='<tr><td>Incoming QC Batch ID</td><td>'.$data[0]['incoming_batch_id'].'</td></tr>';

      $html .='<tr><td>Total Quantity </td><td>'.$data[0]['arrived_qty'].'</td></tr>';
      $html .='<tr><td>Accepted Quantity </td><td>'.$data[0]['accepted_qty'].'</td></tr>';

      $html .='<tr><td>Status </td><td>'.$data[0]['overall_status'].'</td></tr>';
      $html .='<tr><td>Vehicle Inspection Date </td><td>'.$data[0]['vehicle_inspection_date'].'</td></tr>';

      $html .='<tr><td>Checklist </td><td>'.$data[0]['vehicle_inspection_checklist'].'</td></tr>';
      $html .='<tr><td>Status</td><td>'.$data[0]['vehicle_status'].'</td></tr>';
   }
   $html .= '</tbody></table>';
   return $html;
}

   /*public function actionRpcReport()
   {
      $col_qc_check = $p_ar = [];
      $get_rpc_id = Yii::$app->request->get('rpc_id','');
      $get_product_id = Yii::$app->request->get('product_id','');

      $get_from_date = Yii::$app->request->get('from_date',date("Y-m-d H:i:s"));
      $get_to_date = Yii::$app->request->get('to_date',date("Y-m-d H:i:s"));
      $get_fg_batch_id = Yii::$app->request->get('batch_id','');
      list($whrstring,$string1,$string2) = '';
      if(!empty($get_product_id))
      {
         $p_ar[] = $get_product_id;
      }
      if(!empty($get_fg_batch_id))
      {
         $p_ar[] = $get_fg_batch_id;
      }
      $where = '';
      if(!empty($get_rpc_id))
      {
         $where .= " AND rpc.id = '".$get_rpc_id."' ";
      }
      if(COUNT($p_ar) > 0)
      {
         $where .= ' AND (';
         foreach ($p_ar as $key => $value) {
            $value = '"'.$value.'"';
            if($key == (COUNT($p_ar)-1))
            {
               $where .= " JSON_CONTAINS(nr.product_id, '".$value."') ";
            }else{
               $where .= " JSON_CONTAINS(nr.product_id, '".$value."') OR ";
            }
         }
         $where .=")";
      }

      $connection = Yii::$app->getDb();
      $command = $connection->createCommand("SELECT nr.unique_id nr_unique_id,
         nr.product_id nr_product_id FROM rpc_centre rpc
         inner join new_request nr on rpc.id = nr.rpc_center_id
         WHERE date(nr.vehicle_date) >= '".$get_from_date."' && date(nr.vehicle_date) <= '".$get_to_date."'
            ".$where);

      $check_data = $command->queryAll();

      if(COUNT($check_data) > 0)
      {
         foreach ($check_data as $key => $value) 
         {
            $nr_query = new \yii\db\Query;
            $nr_query->select([
               'iqc.product_id iqc_product_id',
               'iqc.batch_id iqc_batch_id',
            ]) 
            ->from('incoming_qc_check iqc')
            ->innerJoin('fg_qc_check fgc','iqc.batch_id = fgc.batch_id')
            ->where(['request_id' => $value['nr_unique_id']])
            ->andWhere('iqc.product_id IN ('.implode(',', json_decode($value['nr_product_id'],true)).')');
            $nr_command = $nr_query->createCommand();
            $vaid_data[$value['nr_unique_id']] = $nr_command->queryAll();
         }
         if(COUNT($vaid_data) > 0)
         {
            foreach ($vaid_data as $k => $val) 
            {
               if(COUNT($val) > 0)
               {
                  foreach ($val as $ke => $valu) 
                  {
                     $final_Ar[$k][] = $valu['iqc_product_id'];
                  }
               }
            }

            foreach ($final_Ar as $req_id => $product_ids) 
            {
               $final_query = new \yii\db\Query;
               $final_query->select([
                  'rpc.rpc_name rpc_rpc_name',
                  'nr.supplier_id rpc_supplier_id',
                  'nr.vehicle_date nr_vehicle_date',
                  'nr.user_id nr_user_id',
                  'nr.vehicle_image nr_vehicle_image',
                  'nr.vehicle_status nr_vehicle_status',
                  'nr.vehicle_date nr_vehicle_date',
                  'nr.product_id nr_product_id',
                  'nr.vehicle_inspection_checklist nr_vehicle_inspection_checklist',
                  'iqc.request_id iqc_req_id',
                  'iqc.product_id iqc_product_id',
                  'iqc.batch_id iqc_batch_id',
                  'iqc.incoming_date iqc_incoming_date',
                  'iqc.product_is_fumigation iqc_product_is_fumigation',
                  'iqc.product_is_cleaning iqc_product_is_cleaning',
                  'iqc.product_image iqc_product_image',
                  'iqc.user_id iqc_user_id',
                  'iqc.arrived_qty iqc_arrived_qty',
                  'iqc.accepted_qty iqc_accepted_qty',
                  'f.fumigation_type f_fumigation_type',
                  'f.start_time f_start_time',
                  'f.end_time f_end_time',
                  'f.rpc_center_id f_rpc_center_id',
                  'f.images f_images',
                  'f.user_id f_user_id',
                  'f.chemical_used f_chemical_used',
                  'f.fumigation_effective f_fumigation_effective',
                  'f.re_fumigate f_re_fumigate',
                  'fm.quantity_value fm_quantity_value',
                  'c.cleaning_date c_cleaning_date',
                  'c.cleaning_checklist c_cleaning_checklist',
                  'c.image c_image',
                  'c.user_id c_cleaning_user',
                  'cm.quantity_value c_quantity_value',
                  'fgc.overall_status fgc_overall_status',
                  'fgc.user_id fgc_fguser',
                  'fgcm.packed_weight fgcm_packed_weight',
                  'fgcm.packed_quantity fgcm_packed_quantity',
               ]) 
               ->from('rpc_centre rpc')
               ->innerJoin('new_request nr','rpc.id = nr.rpc_center_id')
               ->innerJoin('incoming_qc_check iqc','iqc.request_id = nr.unique_id')
               ->innerJoin('(SELECT MAX(id) max_id, quantity_value, batch_id, fumigation_id, fumigation_unique_id FROM fumigation_mapper GROUP BY fumigation_id) fm','fm.batch_id = iqc.batch_id')
               ->innerJoin('fumigation f','fm.fumigation_id = f.id')

               ->innerJoin('cleaning_mapper cm','cm.fumigation_uniq_id = fm.fumigation_unique_id')
               ->innerJoin('cleaning c','c.id = cm.cleaning_id')

               ->innerJoin('fg_qc_check fgc','iqc.batch_id = fgc.batch_id')
               ->innerJoin('fg_qc_check_mapper fgcm','fgcm.fg_qc_uniq_id = fgc.unique_id')
               ->where(
                  [
                     'iqc.request_id'=> $req_id
                  ])
               ->andWhere("iqc.product_id IN (".implode(',', $product_ids).")");

               // echo $final_query = $final_query->createCommand()->sql; exit;
               $final_query = $final_query->createCommand();
               $final_data[$req_id] = $final_query->queryAll();



               $ques_query = new \yii\db\Query;
               $ques_query->select([
                  'qcq.type type',
                  'qcq.name name',
                  'qcq.product_id product_id',
                  'rqc.value inc_value',
                  'rfg.value fg_value'
               ]) 
               ->from('qc_check_phy_chemical qcq')
               ->leftJoin('result_qc_check rqc','qcq.id = rqc.qc_parameter_id')
               ->leftJoin('fg_check_result rfg','qcq.id = rfg.qc_parameter_id')
               ->where("product_id IN (".implode(',', $product_ids).")");
               // echo $ques_command = $ques_query->createCommand()->sql;exit;
               $ques_command = $ques_query->createCommand();
               $ques_data = $ques_command->queryAll();

               if(COUNT($ques_data) > 0)
               {
                  foreach ($ques_data as $ki => $vlu) 
                  {
                     $ans = ($vlu['type'] == 'Incoming') ? $vlu['inc_value'] : $vlu['fg_value'];
                     $col_qc_check[$vlu['product_id']][$vlu['type']][$vlu['name']] = $ans;
                     $all_col_qc_check[$vlu['type']][] = $vlu['name'];
                  }
               }else{
                  exit("No Questions Found For A Product");
               }
            }
            foreach ($col_qc_check as $key => $value) {
               foreach ($value['FG QC Check'] as $k => $val) 
               {
                  $col_qc_check[$key]['fg_batch'] = $val;
                  unset($col_qc_check[$key]['FG QC Check'][$k]);
                  break;
               }  
            }

            foreach ($final_data as $key => $value) {
               foreach ($value as $k => $row) 
               {
                  $row['nr_checklist'] = json_decode($row['nr_vehicle_inspection_checklist'],true);
                  $row['c_checklist'] = json_decode($row['c_cleaning_checklist'],true);
                  foreach ($row['c_checklist'] as $index => $carr) {
                     $cleaning_chk[$carr['id']] = $carr['value'];
                  }

                  // echo '<pre>';print_r($cleaning_chk);exit;

                  $col_qc_check[$row['iqc_product_id']]['details'] = 
                  [
                     'rpc_name' => $row['rpc_rpc_name'],
                     'supplier_name' => $row['rpc_supplier_id'],
                     'raw_material_batch_number' => $row['iqc_batch_id']
                  ];
                  $Users = Users::find()->where(['id'=>$row['nr_user_id']])->one();
                  $col_qc_check[$row['iqc_product_id']]['vehicle'] = 
                  [
                     'incoming_date' => date("Y-m-d",strtotime($row['nr_vehicle_date'])),
                     'cleanliness' => (in_array('Cleanliness', $row['nr_checklist'])) ? "Yes" : "No",
                     'no_chemical, liquor, fertilizer residue found' => (in_array('No Chemical, Liquor, Fertilizer Residue Found', $row['nr_checklist'])) ? "Yes" : "No",
                     'odourless' => (in_array('Odourless', $row['nr_checklist'])) ? "Yes" : "No",
                     'covered' => (in_array('Covered', $row['nr_checklist'])) ? "Yes" : "No",
                     'status' => $row['nr_vehicle_status'],
                     'image_link' => '<a href="'."https://" . $_SERVER['SERVER_NAME'].Url::base()."/images/new-request/".$row['nr_vehicle_image'].'" >View Image</a>',
                     'updated_by' => $Users->name
                  ];
                  $Users = Users::find()->where(['id'=>$row['iqc_user_id']])->one();                  
                  $col_qc_check[$row['iqc_product_id']]['Incoming'] = 
                  array_merge(
                     $col_qc_check[$row['iqc_product_id']]['Incoming'],
                     [
                        'qc_check_date' => date("Y-m-d",strtotime($row['iqc_incoming_date'])),
                        'image_link' => $row['iqc_product_image'],
                        'total_qty_received(kgs)' => $row['iqc_arrived_qty'],
                        'accepted_qty(kgs)' => $row['iqc_accepted_qty'],
                        'fumigation_needed' => ($row['iqc_product_is_fumigation']) ? "Yes" : "No",
                        'cleaning_needed' => ($row['iqc_product_is_cleaning']) ? "Yes" : "No",
                        'updated_by' => $Users->name,
                        'remarks' => '',
                     ]);
                  $Users = Users::find()->where(['id'=>$row['f_user_id']])->one();
                  $col_qc_check[$row['iqc_product_id']]['fumigation'] = 
                  [
                     'fumigant_type' => $row['f_fumigation_type'],
                     'start_date' => date("Y-m-d",strtotime($row['f_start_time'])),
                     'end_date(kgs)' => date("Y-m-d",strtotime($row['f_end_time'])),
                     'qty_taken_for_fumigation(kgs)' => $row['fm_quantity_value'],
                     'agency_name' => $row['f_chemical_used'],
                     'image_link' => $row['f_images'],
                     'fumigation_effective' => $row['f_fumigation_effective'],
                     'refumigation_required' => $row['f_re_fumigate'],
                     'updated_by' => $Users->name
                  ];
                  $Users = Users::find()->where(['id'=>$row['c_cleaning_user']])->one();
                  $col_qc_check[$row['iqc_product_id']]['cleaning'] = 
                  [
                     'date' => date("Y-m-d",strtotime($row['c_cleaning_date'])),
                     'qty_taken_for_cleaning(kgs)' => $row['c_quantity_value'],
                     'destoner' => (array_key_exists('Destoner*', $cleaning_chk)) ? $cleaning_chk['Destoner*'] : 'N/A',
                     'vibro_shifter' => (array_key_exists('Vibro-shifter*', $cleaning_chk)) ? $cleaning_chk['Vibro-shifter*'] : 'N/A',
                     'vibro_shifter_with_magnet' => (array_key_exists('Vibro-shifter with magnet*', $cleaning_chk)) ? $cleaning_chk['Vibro-shifter with magnet*'] : 'N/A',
                     'manual_cleaning' => (array_key_exists('Manual cleaning*', $cleaning_chk)) ? $cleaning_chk['Manual cleaning*'] : 'N/A',
                     'blower' => (array_key_exists('Blower*', $cleaning_chk)) ? $cleaning_chk['Blower*'] : 'N/A',
                     'table_grading' => (array_key_exists('Table Grading*', $cleaning_chk)) ? $cleaning_chk['Table Grading*'] : 'N/A',
                     'automated_mechanial_sieving, mechanical_blower' => (array_key_exists('Automated-Mechanical sieving , Mechanical Blower*', $cleaning_chk)) ? $cleaning_chk['Automated-Mechanical sieving , Mechanical Blower*'] : 'N/A',
                     'manual_filling/ffs_filling_check' => (array_key_exists('Manual filling / FFS filling check*', $cleaning_chk)) ? $cleaning_chk['Manual filling / FFS filling check*'] : 'N/A',
                     'image_link' => $row['c_image'],
                     'updated_by' => $Users->name,
                     'remarks' => '',
                  ];

                  $Users = Users::find()->where(['id'=>$row['fgc_fguser']])->one();
                  $col_qc_check[$row['iqc_product_id']]['FG QC Check'] = 
                  array_merge(
                     $col_qc_check[$row['iqc_product_id']]['FG QC Check'],         
                     [
                        'package_size(kgs)' => $row['fgcm_packed_weight'],
                        'no.of_packs' => $row['fgcm_packed_quantity'],
                        'total_packed_size(kgs)' => ($row['fgcm_packed_quantity']*$row['fgcm_packed_weight']),
                        'status' => $row['fgc_overall_status'],
                        'updated_by' => $Users->name,
                        'remarks' => '',
                     ]
                  );

               }
            }
         }

      }  //END IF

      $query = new \yii\db\Query;
         $query->select([
            'fg_qc_check.id',
            'product.id as pid',
            'concat(fg_check_result.value,"-",product.name) as value',
         ])  
         ->from('fg_qc_check')
         ->innerJoin('fg_check_result','fg_check_result.fg_qc_check_id = fg_qc_check.id')
         ->innerJoin('qc_check_phy_chemical',' qc_check_phy_chemical.id = fg_check_result.qc_parameter_id')
         ->innerJoin('product','product.id = fg_qc_check.product_id')
         ->where(['qc_check_phy_chemical.name'=>"FG Batch Number *"]);
         $command = $query->createCommand();
         $fg_batch = $command->queryAll();
      return $this->render('ap_modified',[
                                 'data' => $col_qc_check,
                                 'fgbatch'   => $fg_batch,
                              ]);
   }*/
/*
   private function Report_push($ar,$re,$St=null,$concat_process=null){
    
      if(isset($re['qc_parameter_id'])){
         $r= new Lib;
         $res=$r->qc_pera($re['qc_parameter_id']);
         $ar['process']='In Fg Qc'.$res['name'];
         $ar['Parameter']=$res['option_1'].'-'.$res['option_2'];
         $ar['Actual']=$re['value'];
      }
      if($St==1){
         $ar['created_at']=$re['created_at'];
         $ar['Parameter']=$re['Parameter'];
         $ar['process']='Vehile Inspected';
      }elseif($St==2){
         $ar['created_at']=$re['created_at'];
      }elseif($St==3){
         $ar['process']='Fg Qc Mapping';
         $ar['Parameter']='';
         @$ar['created_at']=$re['created_at'];
         $ar['Actual']='';
      }elseif($St==4){
         $ar['created_at']=$re['created_at'];
      }elseif($St==5){
         $ar['process']='Fumigation Process';
         $ar['Parameter']='Quantity- '.$re['available_qty'].'-'.$re['quantity_value'].'='.$re['remaining_quantity'];
         //$ar['created_at']=$re['created_at'];
         $ar['Actual']=$re['fumigation_complete'];
      }elseif($St==6){
         $ar['process']='Fumigation Result';
         @$ar['Parameter']='Camical used= '.$re['chemical_used'].'-'.$re['quantity_value'].'='.$re['remaining_quantity'];
         if($re['images']!=''){
            $IMG='<a href="'."https://" . $_SERVER['SERVER_NAME'].Url::base()."/images/incoming-qc-check/".$re['images'].'" >View Image</a>';
            $ar['Parameter'].=$IMG;
         }
         $ar['created_at']=$re['created_at'];
         if($re['fumigation_effective']){
            $ar['Actual']='fumigation_effective='.$re['fumigation_effective'];
         }elseif($re['re_fumigate']){
            $ar['Actual']='Re fumigation='.$re['re_fumigate'];
         }
         
      }elseif($St==7){
         $ar['process']='Cleaning';
         $ar['Parameter']='Quantity- '.$re['available_qty'].'-'.$re['quantity_value'].'='.$re['remaining_quantity'];
         $ar['created_at']=$re['result'][0]['created_at'];
         $ar['Actual']=' In Cleaning';
      }elseif($St==8){
         $ar['process']=' In Cleaning';
         $param=json_decode($re['cleaning_checklist']);
        
         $ar['Parameter']='';
         foreach($param as $v){
            //var_dump($v);exit;
            if($v->value=='Yes'){
               $ar['Parameter'].=$v->id."\n";
            }
         }
         if($re['image']!=''){$IMG='<a href="'."https://" . $_SERVER['SERVER_NAME'].Url::base()."/images/incoming-qc-check/".$re['image'].'" >View Image</a>';
            $ar['Parameter'].=$IMG;
         }
         //$ar['Parameter']=$param[0]['id'];
         $ar['created_at']=$re['created_at'];
         $ar['Actual']=$re['overall_status'];
      }

       return $ar;
   
   }
   */

   private function new_push($ar,$par,$serial=null){
      $r=new Lib;
         if($par=='cus'){
         
            $np['process']=ltrim($ar['process']," ");
            $np['Parameter']=$ar['Parameter'];
            $np['Actual']=$ar['Actual'];
            $np['created_at']=$ar['created_at'];
            $np['sn']=$this->S++;
            
         }
      if($par==1){
         foreach($ar as $v){
         
         $np['process']='Vehicle Inspection';
         $np['Parameter']=$ar['Parameter'];
         $np['Actual']=$ar['Actual'];
         /*$np['Parameter']='<table>';
         $cl=json_decode($v['vehicle_inspection_checklist']);
         foreach($cl as $clv){
            $np['Parameter'].='<tr><td>'.$clv.'</td></tr>';
         }
         $np['Parameter'].='</table>';
         //$v['vehicle_inspection_checklist'];
         $np['Actual']='Yes';*/
         //$np['Actual']=$v['vehicle_image'];
         $np['created_at']=$ar['created_at'];
         $np['sn']=$this->S++;
      }}

      if($par==2){
         $np['process']='Incoming QC Check';
         $np['Parameter']=$ar['Parameter'];
         $np['Actual']=$ar['Actual'];
        /* $np['Parameter']='Total Quantity- '.$ar['arrived_qty'];
         $np['Actual']='Accepted- '.$ar['accepted_qty'];*/
         $np['created_at']=$ar['created_at'];
         $np['sn']=$this->S++;
      }
      if($par==3){
         $par=$r->qc_pera($ar['qc_parameter_id']);
         //print_r($par);exit;
         $np['process']='Incoming QC Check';
         $np['Parameter']=$par['name'];
        // $np['Parameter']=$par['option_1'].'-'.$par['option_2'];
         $np['Actual']=$ar['value'];
         $np['created_at']=$ar['created_at'];
         $np['sn']=$this->S++;
      }
      if($par==4){
         $np['process']='Fumigation';
         @$np['Parameter']='Agency Name';
         $np['Actual']=$ar['chemical_used'];
         //$np['Actual']=$ar['fumigation_effective'];
         $np['created_at']=$ar['created_at'];
         $np['sn']=$this->S++;
      }if($par==5){
         $np['process']='Cleaning Process';
         $np['Parameter']=$ar['Parameter'];
         $np['Actual']=$ar['Actual'];
        /* $ckl=json_decode($ar['cleaning_checklist']);
         $np['Parameter']='<table>';
         foreach($ckl as $k=>$cklv){
            $np['Parameter'].='<tr><td>'.$cklv->id.'</td><td>'.$cklv->value.'</td></tr>';
         }
         $np['Parameter'].='</table>';*/
         /*$np['Parameter']=$ar['cleaning_checklist'];
         $np['Actual']=$ar['overall_status'];*/
         $np['created_at']=$ar['created_at'];
         $np['sn']=$this->S++;
      }if($par==6){
         $par=$r->qc_pera($ar['qc_parameter_id']);
         //print_r($par);exit;
         $np['process']=$par['type'];
         $np['Parameter']=$par['name'];
         $np['Actual']=$ar['value'];
         $np['created_at']=$ar['created_at'];
         $np['sn']=$this->S++;
      }
if(isset($np)){
   return $np;
}
     
   }

   function actionTest($condition=null){
      $REP=[];
      $REP_COM=[];
      $_SESSION['sn']=1;
      $SN=$_SESSION['sn'];
      //$_SESSION['sn']++;
      //echo $_SESSION['sn'];exit;
      $r=new Lib;
      if($condition==null){
         $condition='a05b1177-8b19-47fb-96de-a1edc1c46b79';
      }     
      
      /*********************** */
      $nr= $r->allreq($condition);
      
      if(sizeof($nr)>0){
         foreach($nr as $vi){
            //echo "1116<pre>";print_r($vi);exit;   
            array_push($REP,$this->new_push(['process'=>'Vehicle Inspection','Parameter'=>'Incoming Date','Actual'=>$vi['vehicle_date'],'created_at'=>$vi['created_at']],'cus'));           
           $IMG='<a href="'."https://" . $_SERVER['SERVER_NAME'].Url::base()."/images/new-request/".$vi['vehicle_image'].'" >View Image</a>';
           // $ar['Parameter'].=$IMG;
           $vicl=json_decode($vi['vehicle_inspection_checklist']);
      foreach($vicl as $viclk){
      array_push($REP,$this->new_push(['Parameter'=>$viclk,'Actual'=>'Yes','created_at'=>$vi['created_at']],1));
           }
      array_push($REP,$this->new_push(['process'=>'Vehicle Inspection','Parameter'=>'Status','Actual'=>$vi['vehicle_status'],'created_at'=>$vi['created_at']],'cus'));
      array_push($REP,$this->new_push(['process'=>'Vehicle Inspection','Parameter'=>'Image Link','Actual'=>$IMG,'created_at'=>$vi['created_at']],'cus'));
      array_push($REP,$this->new_push(['process'=>'Vehicle Inspection','Parameter'=>'Updated By','Actual'=>$r->UserName($vi['user_id']),'created_at'=>$vi['created_at']],'cus'));
      array_push($REP,$this->new_push(['process'=>'Vehicle Inspection','Parameter'=>'Remarks','Actual'=>($vi['comments']),'created_at'=>$vi['created_at']],'cus'));
      
      }
        // echo "<pre>1125 ";print_r($vi);exit;
      }
       //array_push($REP,$this->new_push($nr,1));
      foreach($nr as $nrv){
         $ins_res=$r->incomequalitycheck($nrv['unique_id']);
        // echo "1130<pre>";print_r(( $ins_res));exit;
         if(sizeof($ins_res)>0 and  @$REP_COM['batch_id']==''){
            $REP_COM['batch_id']=$ins_res[0]['batch_id'];
         }
         
         if(sizeof($ins_res)>0 and  @$REP_COM['supplier_name']==''){
            $REP_COM['supplier_name']=$r->supplier_name($ins_res[0]['supplier_id']);
         }
         if(sizeof($ins_res)>0 and  @$REP_COM['product_name']==''){
            //$REP_COM['product_name']=$r->product_name($ins_res[0]['product_id']);
            $REP_COM['product_name']=($ins_res[0]['product_id']);
         }
         if(sizeof($ins_res)>0 and  @$REP_COM['rpc_name']==''){
            //$REP_COM['rpc_name']=$r->rpc_name($ins_res[0]['rpc_center_id']);
            $REP_COM['rpc_name']=($ins_res[0]['rpc_center_id']);
         }

         foreach($ins_res as $inrv){
           
         /************RESULT QC */
         if(isset($REP_COM['batch_id']) and $REP_COM['batch_id']!=''){
            $res_qc=$r->resultqc($inrv['id']);
           
            /*if(sizeof($ins_res)>0 and  @$REP_COM['fg_batch_num']==''){
               $REP_COM['fg_batch_num']=$r->fg_batch_num($res_qc);
            }*/
            foreach($res_qc as $res_qcv){
               //echo "<pre>";print_r($inrv);exit;
              array_push($REP,$this->new_push($res_qcv,3));
              $last_update=$res_qcv['created_at'];
               //print_r($res_qcv);exit;
            }
          // echo "1167<pre>";print_r($nrv);exit;
            array_push($REP,$this->new_push(['process'=>'Incoming QC Check','Parameter'=>'Qc Check Date','Actual'=>$inrv['incoming_date'],'created_at'=>$vi['created_at']],'cus'));
            array_push($REP,$this->new_push(['Parameter'=>'Total Qty Received(kgs)','Actual'=>$inrv['arrived_qty'],'created_at'=>$inrv['created_at']],2));
            array_push($REP,$this->new_push(['Parameter'=>'Accepted Qty(kgs)','Actual'=>$inrv['accepted_qty'],'created_at'=>$inrv['created_at']],2));
            $fumigation_needed = ($inrv['product_is_fumigation'] == 1) ? "Yes" : "No";
            $cleaning_needed = ($inrv['product_is_cleaning'] == 1) ? "Yes" : "No";
            array_push($REP,$this->new_push(['process'=>'Incoming QC Check','Parameter'=>'Fumigation Needed','Actual'=>$fumigation_needed,'created_at'=>$vi['created_at']],'cus'));
            array_push($REP,$this->new_push(['process'=>'Incoming QC Check','Parameter'=>'Cleaning Needed','Actual'=>$cleaning_needed,'created_at'=>$vi['created_at']],'cus'));
            array_push($REP,$this->new_push(['process'=>'Incoming QC Check','Parameter'=>'Updated By','Actual'=>$r->UserName($vi['user_id']),'created_at'=>$vi['created_at']],'cus'));
            array_push($REP,$this->new_push(['process'=>'Incoming QC Check','Parameter'=>'Remarks','Actual'=>$vi['comments'],'created_at'=>$vi['created_at']],'cus'));
            
            

             //echo "<pre>";print_r($vi);exit;
            //array_push($REP,$this->new_push(['process'=>'Incoming QC Check','Parameter'=>'Updated By','Actual'=>$cleaning_needed,'created_at'=>$vi['created_at']],'cus'));
        
/*******END QC********* */
/*** $np['process']=$ar['process'];
   $np['Parameter']=$ar['Parameter'];
   $np['Actual']=$ar['Actual'];
   $np['created_at']=$ar['created_at']; */
/*********FUMIGATION******* */

         $fum=$r->fumigation_mapper($REP_COM['batch_id']);
         $cln=$r->cleaning_mapper($REP_COM['batch_id']);
        
         $fgqc=$r->fg_qc_check($REP_COM['batch_id']);
         //echo "<pre>";print_r($fgqc);exit;
         foreach($fum as $fumv){
            //echo "<pre>";print_r($res_qc);exit;
             //array_push($REP,$this->new_push(['process'=>'Fumigation','Parameter'=>'Accepted Quantity','Actual'=>'','created_at'=>''],'cus'));
            $fumr=$r->fumigation($fumv['fumigation_id']);
               //echo "<pre>";print_r($fumr);exit;
            foreach($fumr as $ffumr){
               //echo "1197<pre>";print_r($ffumr);exit;
              // fumigation_type

            array_push($REP,$this->new_push(['process'=>'Fumigation','Parameter'=>'Fumigation Start Date','Actual'=>$ffumr['start_time'],'created_at'=> $last_update],'cus'));
            array_push($REP,$this->new_push(['process'=>'Fumigation','Parameter'=>'Fumigation End Date','Actual'=>$ffumr['end_time'],'created_at'=> $last_update],'cus'));
           // array_push($REP,$this->new_push(['process'=>'Fumigation','Parameter'=>'Fumigated Product name','Actual'=>$r->product_name($fumv['product_id']),'created_at'=> $last_update],'cus'));
            array_push($REP,$this->new_push(['process'=>'Fumigation','Parameter'=>'Person Name','Actual'=>$ffumr['qc_person_name'],'created_at'=> $last_update],'cus'));
            array_push($REP,$this->new_push($ffumr,4));
             }
            array_push($REP,$this->new_push(['process'=>'Fumigation','Parameter'=>'Qty Taken For Fumigation(kgs)','Actual'=>$fumv['quantity_value'],'created_at'=> $last_update],'cus'));
            $image_link = (!empty($ffumr['images'])) ? '<a href="'."https://" . $_SERVER['SERVER_NAME'].Url::base()."/images/fumigation/".$ffumr['images'].'" >View Image</a>' : 'N/A';
            array_push($REP,$this->new_push(['process'=>'Fumigation','Parameter'=>'Image Link','Actual'=>$image_link,'created_at'=> $last_update],'cus')); 
           // array_push($REP,$this->new_push(['process'=>'Fumigation','Parameter'=>'Updated By','Actual'=>$r->UserName($vi['user_id']),'created_at'=>$vi['created_at']],'cus'));
            array_push($REP,$this->new_push(['process'=>'Fumigation','Parameter'=>'Fumigation Effective','Actual'=>($ffumr['fumigation_effective']),'created_at'=>$vi['created_at']],'cus'));
            array_push($REP,$this->new_push(['process'=>'Fumigation','Parameter'=>'Refumigation Required','Actual'=>($ffumr['re_fumigate']),'created_at'=>$vi['created_at']],'cus'));
            array_push($REP,$this->new_push(['process'=>'Fumigation','Parameter'=>'Updated By','Actual'=>$r->UserName($ffumr['user_id']),'created_at'=>$vi['created_at']],'cus'));
                             
         }
         //array_push($REP,$this->new_push(['process'=>'Fumigation','Parameter'=>'Fumigated Quantity','Actual'=>$fumv['quantity_value'],'created_at'=> $last_update],'cus'));
           
         foreach($cln as $clnv){
            $clr=$r->cleaning($clnv['cleaning_id']);
            // echo "1221<pre>";print_r($clnv);exit;
           foreach($clr as $clrs){
            //echo "1208<pre>";print_r($clrs);exit;
            array_push($REP,$this->new_push(['process'=>'Cleaning','Parameter'=>'Cleaning Date','Actual'=>$clrs['cleaning_date'],'created_at'=>$vi['created_at']],'cus'));
               $chklst=json_decode($clrs['cleaning_checklist']);
               //echo "1211<pre>";print_r($chklst);exit;
               foreach($chklst as $chklstval){
                  //echo "1208<pre>";print_r($clrs);exit;
                  $par=$chklstval->id;
                  $par=str_replace('*','',$par);
                  $par=str_replace('-',' ',$par);
                  array_push($REP,$this->new_push(['process'=>'Cleaning','Parameter'=>$par,'Actual'=>$chklstval->value,'created_at'=> $last_update],'cus'));  
                  //array_push($REP,$this->new_push(['Parameter'=>$chklstval->id,'Actual'=>$chklstval->value,'created_at'=>$clrs['created_at']],5));
               }
            }
            //echo "1233<pre>";print_r($clnv);exit;
         array_push($REP,$this->new_push(['process'=>'Cleaning','Parameter'=>'Quantity Cleaned','Actual'=>$clnv['quantity_value'],'created_at'=> $last_update],'cus'));  
         $image_link = (!empty($ffumr['image'])) ? '<a href="'."https://" . $_SERVER['SERVER_NAME'].Url::base()."/images/cleaning/".$clr['image'].'" >Image</a>' : 'N/A';
         array_push($REP,$this->new_push(['process'=>'Cleaning','Parameter'=>'View Image','Actual'=>$image_link,'created_at'=> $last_update],'cus'));
         array_push($REP,$this->new_push(['process'=>'Cleaning','Parameter'=>'Updated By','Actual'=>$r->UserName($vi['user_id']),'created_at'=>$vi['created_at']],'cus'));
         array_push($REP,$this->new_push(['process'=>'Cleaning','Parameter'=>'Remarks','Actual'=>'','created_at'=>$vi['created_at']],'cus'));
           
         }

         foreach($fgqc as $fg){
            //echo "1242 <pre>";print_r($fg);exit;
             array_push($REP,$this->new_push(['process'=>'FG QC Check','Parameter'=>'Date','Actual'=>$fg['fgqc_date'],'created_at'=> $last_update],'cus'));
             //echo "1224<pre>";print_r($fg);exit;
             $last_update=$fg['created_at'];
            // echo $last_update;exit;
             $fgqcmap=$r->fg_qc_check_mapper($fg['unique_id']);
            //echo "1228<pre>";print_r($fgqcmap);exit;
            $fgr=$r->fg_qc_result($fg['id']);
           // echo "<pre>";print_r($fum);exit;
            if(sizeof($fgr)>0 and  @$REP_COM['fg_batch_num']==''){
               $REP_COM['fg_batch_num']=$r->getfg_batch_num($fgr);
            }
            
            //print_r($fgr);exit;
            foreach($fgr as $fgrs){
               array_push($REP,$this->new_push($fgrs,6,$SN++));
            }
            $total=0;
            //echo "1264<pre>";print_r($fg);exit;
            foreach($fgqcmap as $fgqcmapval){
               $total+=($fgqcmapval['packed_quantity']*$fgqcmapval['packed_weight']);
               array_push($REP,$this->new_push(['process'=>'FG QC Check','Parameter'=>'No.of Packs','Actual'=>$fgqcmapval['packed_quantity'],'created_at'=> $last_update],'cus'));
               array_push($REP,$this->new_push(['process'=>'FG QC Check','Parameter'=>'Package Size(Kgs)','Actual'=>$fgqcmapval['packed_weight'],'created_at'=> $last_update],'cus'));
            }
         array_push($REP,$this->new_push(['process'=>'FG QC Check','Parameter'=>'Total Packed Size(Kgs)','Actual'=>$total,'created_at'=> $last_update],'cus'));
       // $fgqcstatus=($fg['status'])?"Accept":"";
         array_push($REP,$this->new_push(['process'=>'FG QC Check','Parameter'=>'Status','Actual'=>$fg['overall_status'],'created_at'=>$vi['created_at']],'cus'));
        
         array_push($REP,$this->new_push(['process'=>'FG QC Check','Parameter'=>'Updated By','Actual'=>$r->UserName($fg['user_id']),'created_at'=>$vi['created_at']],'cus'));
         array_push($REP,$this->new_push(['process'=>'FG QC Check','Parameter'=>'Remark','Actual'=>$fg['comment'],'created_at'=>$vi['created_at']],'cus'));
        
         }

         }
         $FINAL=[];
         if(isset($REP_COM['fg_batch_num']) and @$REP_COM['fg_batch_num']!=''){
            foreach($REP as $pu){
               //ECHO "1221<pre>";print_r($FINAL);exit;
               if(is_array($pu)){
                  $combine=array_merge($REP_COM,$pu);
                  array_push($FINAL,$combine);
               }
            }
            $date = array();
            foreach ($FINAL as $key => $row){
            $date[$key] = $row['created_at'];
                }
            array_multisort($date, SORT_DESC, $FINAL);
         }else{
            $FINAL='';
         }
         
         //print_r($FINAL);exit;
         return $FINAL;
      }
   }
}


public function actionRpcReport(){
   //echo "hi";exit;
   $col_qc_check = $p_ar = $vaid_data = $report_arr =$REPORT= [];
   $get_rpc_id = Yii::$app->request->get('rpc_id','');
   $get_product_id = Yii::$app->request->get('product_id','');
   $get_from_date = Yii::$app->request->get('from_date',date("Y-m-d"));
   $get_to_date = Yii::$app->request->get('to_date',date("Y-m-d"));
   $get_fg_batch_id = Yii::$app->request->get('batch_id','');
   
/**********WHERE CONDITION CHECKER*******/
$condition='';
   if(!empty($get_rpc_id)){
      $condition=" and rpc_center_id=".$get_rpc_id;
      }if(!empty($get_from_date)){
         $condition.=' and vehicle_date >= "'.$get_from_date.'" ';
      }
      if(!empty($get_to_date)){
         $condition.=' and vehicle_date <= "'.$get_to_date.'" ';
        
      }
      if(empty($get_fg_batch_id)){
         if(!empty($get_product_id)){
            $asd = '"'.$get_product_id.'"';
            $condition.=" and `product_id` like '%".$asd."%'";
         }
      }
      
      
      if($condition!=''){
        // WHERE (date_field BETWEEN '2010-09-29 10:15:55' AND '2010-01-30 14:15:55')
         $condition=trim($condition,' and');
         $condition=' where '.$condition;
      }
      
      //echo $condition;exit;
/******* END *********/

      $r=new Lib;
     $nr= $r->newrequest($condition);
     //echo "<pre>";print_r($nr);exit;
    
   $R=[];
   $F_REP=[];
  
   if(sizeof($nr)>0){
      $i=0;
      $key='';
for($i=0;$i<sizeof($nr);$i++){
//$key.=$nr[$i]['unique_id'].'~';

$F_P=$this->actionTest($nr[$i]['unique_id']);
if($F_P!=''){
   for($ij=0;$ij<sizeof($F_P);$ij++){
      array_push($F_REP,$F_P[$ij]);
   }
}
}}
$Pass_result=[];
/*if($get_fg_batch_id!=null){
for($i=sizeof($Pass_result);$i>0;$i--){
   if($v['fg_batch_num']==$get_fg_batch_id){

   }
}
}
*/
//echo "<pre>";print_r($F_REP);exit;
if($get_fg_batch_id!=null or $get_product_id!=null){
   foreach($F_REP as $v){
      if($v['fg_batch_num']==$get_fg_batch_id or $v['product_name']==$get_product_id){
         array_push($Pass_result,$v);
      }
   }
}else{
   $Pass_result=$F_REP;
}

/*
echo "<pre>";print_r($F_REP);exit;
if($get_fg_batch_id!=null){
   foreach($F_REP as $v){
      if($v['fg_batch_num']==$get_fg_batch_id){
            array_push($Pass_result,$v);
      }
   }

}elseif($get_product_id!=null){
   //echo $get_product_id;exit;
   foreach($F_REP as $v){
      if($v['product_name']==$get_product_id){
            array_push($Pass_result,$v);
      }
   }
}else{
   $Pass_result=$F_REP;
}*/

   $query = new \yii\db\Query;
   $query->select([
      'fg_qc_check.id',
      'product.id as pid',
      'concat(fg_check_result.value,"-",product.name) as value',
      'fg_check_result.id as b_id' ,
   ])  
   ->from('fg_qc_check')
   ->innerJoin('fg_check_result','fg_check_result.fg_qc_check_id = fg_qc_check.id')
   ->innerJoin('qc_check_phy_chemical',' qc_check_phy_chemical.id = fg_check_result.qc_parameter_id')
   ->innerJoin('product','product.id = fg_qc_check.product_id')
   ->where(['qc_check_phy_chemical.name'=>"FG Batch Number *"]);
   $command = $query->createCommand();
   //echo $nr_command = $query->createCommand()->sql;exit;
    if(isset($_GET['csv'])){
     // echo "<pre>";print_r($Pass_result);exit; 
     ini_set('max_execution_time', 600); //300 seconds = 5 minutes 
     ini_set('memory_limit', '900 M'); 
      $this->actionCsvdownload($Pass_result);}
   //echo "<pre>";print_r($REPORT);exit;
   $fg_batch = $command->queryAll();
   //echo "<pre>";print_r($Pass_result);exit;
   return $this->render('ap_report_final',[
  // return $this->render('ap_modified_new',[
      'allrecords' => $Pass_result,
      'fgbatch'   => $fg_batch,
   ]);
}

   public function actionRpcReport_old()
   {
      $col_qc_check = $p_ar = $vaid_data = $report_arr = [];
      $get_rpc_id = Yii::$app->request->get('rpc_id','');
      $get_product_id = Yii::$app->request->get('product_id','');
      $get_from_date = Yii::$app->request->get('from_date',date("Y-m-d"));
      $get_to_date = Yii::$app->request->get('to_date',date("Y-m-d"));
      $get_fg_batch_id = Yii::$app->request->get('batch_id','');
      list($whrstring,$string1,$string2) = '';
      if(!empty($get_product_id))
      {
         $p_ar[] = $get_product_id;
      }
      if(!empty($get_fg_batch_id))
      {
         $p_ar[] = $get_fg_batch_id;
      }
      $where = '';
      if(!empty($get_rpc_id))
      {
         $where .= " AND rpc.id = '".$get_rpc_id."' ";
      }

     
      if(COUNT($p_ar) > 0)
      {
         $where .= ' AND (';
         foreach ($p_ar as $key => $value) {
            $value = '"'.$value.'"';
            if($key == (COUNT($p_ar)-1))
            {
               $where .= " JSON_CONTAINS(nr.product_id, '".$value."') ";
            }else{
               $where .= " JSON_CONTAINS(nr.product_id, '".$value."') OR ";
            }
         }
         $where .=")";
      }
     
      //echo "<pre>";print_r($where);exit;
      $sql = "SELECT nr.unique_id nr_unique_id,
         nr.product_id nr_product_id FROM rpc_centre rpc
         inner join new_request nr on rpc.id = nr.rpc_center_id
         WHERE date(nr.vehicle_date) >= '".$get_from_date."' && date(nr.vehicle_date) <= '".$get_to_date."'
            ".$where; 
/***RESULT
nr_unique_id                           nr_product_id
30e10fd4-93b9-48f4-a240-fecfdf98c28e   ["102"]
575d01dd-b3d9-4aef-98db-a2f6772d9536   ["180","282"]

  */

      $connection = Yii::$app->getDb();
      // echo $command = $connection->createCommand($sql)->sql;exit;
      $command = $connection->createCommand($sql);
     
      //echo "<pre>";print_r($command);exit;
      $check_data = $command->queryAll();
      // echo '<pre>';print_r($check_data);exit;
      if(COUNT($check_data) > 0)
      {
         foreach ($check_data as $key => $value) 
         {
            $nr_query = new \yii\db\Query;
            $nr_query->select([
               'iqc.product_id iqc_product_id',
               'iqc.batch_id iqc_batch_id',
            ]) 
            ->from('incoming_qc_check iqc')
            ->innerJoin('fg_qc_check fgc','iqc.batch_id = fgc.batch_id')
            ->where(['request_id' => $value['nr_unique_id']])
            ->andWhere('iqc.product_id IN ('.implode(',', json_decode($value['nr_product_id'],true)).')');
             //echo $nr_command = $nr_query->createCommand()->sql;exit;
            $nr_command = $nr_query->createCommand();
            if(COUNT($nr_command->queryAll()) > 0)
            {
               $vaid_data[$value['nr_unique_id']] = $nr_command->queryAll();
            }
         }
          //echo '<pre>';print_r($vaid_data);exit;
         if(COUNT($vaid_data) > 0)
         {
            foreach ($vaid_data as $k => $val) 
            {
               if(COUNT($val) > 0)
               {
                  foreach ($val as $ke => $valu) 
                  {
                     if(!empty($get_product_id) && ($get_product_id == $valu['iqc_product_id']))
                     {
                        $final_Ar[$k][] = $valu['iqc_product_id'];
                     }elseif(empty($get_product_id)){
                        $final_Ar[$k][] = $valu['iqc_product_id'];
                     }
                     $final_Ar[$k] = array_unique($final_Ar[$k]);
                  }
               }
            }
            // echo '<pre>';print_r($final_Ar);exit;
            foreach ($final_Ar as $req_id => $product_ids) 
            {
               $final_query = new \yii\db\Query;
               $final_query->select([
                  'rpc.rpc_name rpc_rpc_name',
                  'nr.unique_id nrid',
                  'nr.supplier_id rpc_supplier_id',
                  'nr.vehicle_date nr_vehicle_date',
                  'nr.user_id nr_user_id',
                  'nr.vehicle_image nr_vehicle_image',
                  'nr.vehicle_status nr_vehicle_status',
                  'nr.vehicle_date nr_vehicle_date',
                  'nr.product_id nr_product_id',
                  'nr.vehicle_inspection_checklist nr_vehicle_inspection_checklist',
                  'iqc.unique_id iqcid',
                  'iqc.request_id iqc_req_id',
                  'iqc.product_id iqc_product_id',
                  'iqc.batch_id iqc_batch_id',
                  'iqc.incoming_date iqc_incoming_date',
                  'iqc.product_is_fumigation iqc_product_is_fumigation',
                  'iqc.product_is_cleaning iqc_product_is_cleaning',
                  'iqc.product_image iqc_product_image',
                  'iqc.user_id iqc_user_id',
                  'iqc.arrived_qty iqc_arrived_qty',
                  'iqc.accepted_qty iqc_accepted_qty',
                  'f.id fid',
                  'f.fumigation_type f_fumigation_type',
                  'f.start_time f_start_time',
                  'f.end_time f_end_time',
                  'f.rpc_center_id f_rpc_center_id',
                  'f.images f_images',
                  'f.overall_status f_overall_status',
                  'f.user_id f_user_id',
                  'f.chemical_used f_chemical_used',
                  'f.fumigation_effective f_fumigation_effective',
                  'f.re_fumigate f_re_fumigate',
                  'fm.id fmid',
                  'fm.quantity_value fm_quantity_value',
                  'c.unique_id cid',
                  'c.overall_status c_overall_status',
                  'c.cleaning_date c_cleaning_date',
                  'c.cleaning_checklist c_cleaning_checklist',
                  'c.image c_image',
                  'c.user_id c_cleaning_user',
                  'cm.quantity_value c_quantity_value',
                  'fgc.id fgcid',
                  'fgc.overall_status fgc_overall_status',
                  'fgc.user_id fgc_fguser',
                  'fgc.fgqc_date fgqc_date',
                  'fgcm.id AS fgcmid',
                  'fgcm.packed_weight fgcm_packed_weight',
                  'fgcm.packed_quantity fgcm_packed_quantity',
               ]) 
               ->from('rpc_centre rpc')
               ->innerJoin('new_request nr','rpc.id = nr.rpc_center_id')
               ->innerJoin('incoming_qc_check iqc','iqc.request_id = nr.unique_id')
               ->leftJoin('fumigation_mapper fm','fm.incoming_qc_uniq_id = iqc.unique_id')
               ->leftJoin('fumigation f','fm.fumigation_id = f.id')

               ->leftJoin('cleaning_mapper cm','cm.incoming_uniq_id = iqc.unique_id')
               ->leftJoin('cleaning c','c.id = cm.cleaning_id')

               ->innerJoin('fg_qc_check fgc','fgc.batch_id = iqc.batch_id')
               ->innerJoin('fg_qc_check_mapper fgcm','fgcm.fg_qc_uniq_id = fgc.unique_id')
               ->where([
                     'iqc.request_id'=> $req_id,
                     'fgc.overall_status'=> 'Accept'
                  ])
               ->andWhere("iqc.product_id IN (".implode(',', $product_ids).")");

               // echo "<pre>"; print_r($final_query->createCommand()->sql); exit;
               $final_query = $final_query->createCommand();
               $final_data[$req_id] = $final_query->queryAll();

               // echo '<pre>';print_r($final_data);exit;



               $ques_query = new \yii\db\Query;
               $ques_query->select([
                  'qcq.type type',
                  'rfg.fg_qc_check_id fg_check_id',
                  'qcq.name name',
                  'qcq.product_id product_id',
                  'rqc.value inc_value',
                  'rfg.value fg_value'
               ]) 
               ->from('qc_check_phy_chemical qcq')
               ->leftJoin('result_qc_check rqc','qcq.id = rqc.qc_parameter_id')
               ->leftJoin('fg_check_result rfg','qcq.id = rfg.qc_parameter_id')
               ->where("product_id IN (".implode(',', $product_ids).")");
               // echo $ques_command = $ques_query->createCommand()->sql;exit;
               $ques_command = $ques_query->createCommand();
               $ques_data = $ques_command->queryAll();
               // echo '<pre>';print_r($ques_data);exit;
               if(COUNT($ques_data) > 0)
               {
                  foreach ($ques_data as $ki => $vlu) 
                  {
                     if(($vlu['type'] == 'Incoming'))
                     {
                        $col_qc_check[$vlu['product_id']][$vlu['type']][$vlu['name']] = $vlu['inc_value'];
                     }else{
                        $col_qc_check[$vlu['product_id']][$vlu['type']][$vlu['fg_check_id']][$vlu['name']] = $vlu['fg_value'];
                     }
                  }
               }else{
                  exit("No Questions Found For A Product");
               }
            }
            foreach ($col_qc_check as $key => $value) {
               foreach ($value['FG QC Check'] as $k => $val) 
               {
                  $col_qc_check[$key]['fg_batch'] = $val['FG Batch Number *'];
                  break;
               }  
            }
            
            foreach ($final_data as $key => $value) 
            {
               foreach ($value as $k => $row) 
               {
                  $row['nr_checklist'] = json_decode($row['nr_vehicle_inspection_checklist'],true);
                  $row['c_checklist'] = json_decode($row['c_cleaning_checklist'],true);
                  if(COUNT($row['c_checklist']) > 0)
                  {
                     foreach ($row['c_checklist'] as $index => $carr) {
                        $cleaning_chk[$carr['id']] = $carr['value'];
                     }
                  }

                  $report_arr[$key][$row['iqc_product_id']]['details'] = 
                  [
                     'rpc_name' => $row['rpc_rpc_name'],
                     'supplier_name' => $row['rpc_supplier_id'],
                     'raw_material_batch_number' => $row['iqc_batch_id']
                  ];
                  $Users = Users::find()->where(['id'=>$row['nr_user_id']])->one();
                  $report_arr[$key][$row['iqc_product_id']]['vehicle'] = 
                  [
                     'incoming_date' => date("Y-m-d",strtotime($row['nr_vehicle_date'])),
                     'cleanliness' => (in_array('Cleaning', $row['nr_checklist'])) ? "Yes" : "No",
                     'no_chemical, liquor, fertilizer residue found' => (in_array('No chemical, liquor, fertilizer residue found', $row['nr_checklist'])) ? "Yes" : "No",
                     'odourless' => (in_array('Odourless', $row['nr_checklist'])) ? "Yes" : "No",
                     'covered' => (in_array('Covered', $row['nr_checklist'])) ? "Yes" : "No",
                     'status' => $row['nr_vehicle_status'],
                     'image_link' => (!empty($row['nr_vehicle_image'])) ? '<a href="'."https://" . $_SERVER['SERVER_NAME'].Url::base()."/images/new-request/".$row['nr_vehicle_image'].'" >View Image</a>' : "N/A",
                     'updated_by' => $Users->name
                  ];
                  $Users = Users::find()->where(['id'=>$row['iqc_user_id']])->one();                  
                  $report_arr[$key][$row['iqc_product_id']]['Incoming'] = 
                  array_merge(
                     $col_qc_check[$row['iqc_product_id']]['Incoming'],
                     [
                        'qc_check_date' => date("Y-m-d",strtotime($row['iqc_incoming_date'])),
                        'image_link' => (!empty($row['iqc_product_image'])) ? '<a href="'."https://" . $_SERVER['SERVER_NAME'].Url::base()."/images/incoming-qc-check/".$row['iqc_product_image'].'" >View Image</a>' : 'N/A',
                        'total_qty_received(kgs)' => $row['iqc_arrived_qty'],
                        'accepted_qty(kgs)' => $row['iqc_accepted_qty'],
                        'fumigation_needed' => ($row['iqc_product_is_fumigation'] == 1) ? "Yes" : "No",
                        'cleaning_needed' => ($row['iqc_product_is_cleaning'] == 1) ? "Yes" : "No",
                        'updated_by' => $Users->name,
                        'remarks' => '',
                     ]);
                  if(!isset($report_arr[$key][$row['iqc_product_id']]['fumigation']))
                     $report_arr[$key][$row['iqc_product_id']]['fumigation'] = [];

                  if(!array_key_exists($row['fid'], $report_arr[$key][$row['iqc_product_id']]['fumigation']) && 
                     ($row['f_overall_status'] == 'Accept')
                     )
                  {
                     $Users = Users::find()->where(['id'=>$row['f_user_id']])->one();
                     $report_arr[$key][$row['iqc_product_id']]['fumigation'][$row['fid']] = 
                     [
                        'fumigant_type' => $row['f_fumigation_type'],
                        'start_date' => date("Y-m-d",strtotime($row['f_start_time'])),
                        'end_date' => date("Y-m-d",strtotime($row['f_end_time'])),
                        'qty_taken_for_fumigation(kgs)' => $row['fm_quantity_value'],
                        'agency_name' => $row['f_chemical_used'],
                        'image_link' => (!empty($row['f_images'])) ? '<a href="'."https://" . $_SERVER['SERVER_NAME'].Url::base()."/images/fumigation/".$row['f_images'].'" >View Image</a>' : 'N/A',
                        'fumigation_effective' => $row['f_fumigation_effective'],
                        'refumigation_required' => $row['f_re_fumigate'],
                        'updated_by' => $Users->name
                     ];
                     
                  }

                  if(!isset($report_arr[$key][$row['iqc_product_id']]['cleaning']))
                     $report_arr[$key][$row['iqc_product_id']]['cleaning'] = [];

                  if(!array_key_exists($row['cid'], $report_arr[$key][$row['iqc_product_id']]['cleaning']) && 
                  ($row['c_overall_status'] == 'Accept')
                  )
                  {
                     $Users = Users::find()->where(['id'=>$row['c_cleaning_user']])->one();
                     $report_arr[$key][$row['iqc_product_id']]['cleaning'][$row['cid']] = 
                     [
                        'date' => date("Y-m-d",strtotime($row['c_cleaning_date'])),
                        'qty_taken_for_cleaning(kgs)' => $row['c_quantity_value'],
                        'destoner' => (array_key_exists('Destoner*', $cleaning_chk)) ? $cleaning_chk['Destoner*'] : 'N/A',
                        'vibro_shifter' => (array_key_exists('Vibro-shifter*', $cleaning_chk)) ? $cleaning_chk['Vibro-shifter*'] : 'N/A',
                        'vibro_shifter_with_magnet' => (array_key_exists('Vibro-shifter with magnet*', $cleaning_chk)) ? $cleaning_chk['Vibro-shifter with magnet*'] : 'N/A',
                        'manual_cleaning' => (array_key_exists('Manual cleaning*', $cleaning_chk)) ? $cleaning_chk['Manual cleaning*'] : 'N/A',
                        'blower' => (array_key_exists('Blower*', $cleaning_chk)) ? $cleaning_chk['Blower*'] : 'N/A',
                        'table_grading' => (array_key_exists('Table Grading*', $cleaning_chk)) ? $cleaning_chk['Table Grading*'] : 'N/A',
                        'automated_mechanial_sieving, mechanical_blower' => (array_key_exists('Automated-Mechanical sieving , Mechanical Blower*', $cleaning_chk)) ? $cleaning_chk['Automated-Mechanical sieving , Mechanical Blower*'] : 'N/A',
                        'manual_filling/ffs_filling_check' => (array_key_exists('Manual filling / FFS filling check*', $cleaning_chk)) ? $cleaning_chk['Manual filling / FFS filling check*'] : 'N/A',
                        'image_link' => (!empty($row['c_image'])) ? '<a href="'."https://" . $_SERVER['SERVER_NAME'].Url::base()."/images/cleaning/".$row['c_image'].'" >View Image</a>' : 'N/A',
                        'updated_by' => $Users->name,
                        'remarks' => '',
                     ];
                  }

                  $report_arr[$key][$row['iqc_product_id']]['FG QC Check'] = $col_qc_check[$row['iqc_product_id']]['FG QC Check'];

                  if(!isset($report_arr[$key][$row['iqc_product_id']]['fgqc_entries']))
                     $report_arr[$key][$row['iqc_product_id']]['fgqc_entries'] = [];

                  if(!isset($report_arr[$key][$row['iqc_product_id']]['fgqc_entries'][$row['fgcid']]))
                     $report_arr[$key][$row['iqc_product_id']]['fgqc_entries'][$row['fgcid']] = [];

                  if(!array_key_exists($row['fgcmid'], $report_arr[$key][$row['iqc_product_id']]['fgqc_entries'][$row['fgcid']]))
                  {
                     $Users = Users::find()->where(['id'=>$row['fgc_fguser']])->one();
                     $report_arr[$key][$row['iqc_product_id']]['fgqc_entries'][$row['fgcid']][$row['fgcmid']] = 
                           [
                              'FG_QC_date' => $row['fgqc_date'],
                              'package_size(kgs)' => $row['fgcm_packed_weight'],
                              'no.of_packs' => $row['fgcm_packed_quantity'],
                              'total_packed_size(kgs)' => ($row['fgcm_packed_quantity']*$row['fgcm_packed_weight']),
                              'status' => $row['fgc_overall_status'],
                              'updated_by' => $Users->name,
                              'remarks' => '',
                           ];
                  }

                  if(isset($col_qc_check[$row['iqc_product_id']]['fg_batch']))
                  {
                     $report_arr[$key][$row['iqc_product_id']]['fg_batch'] = $col_qc_check[$row['iqc_product_id']]['fg_batch'];
                     unset($col_qc_check[$key]['fg_batch']);
                  }

                  
               }
            }
         }

      }  //END IF
      //echo '<pre>';print_r($report_arr);exit;

      $query = new \yii\db\Query;
         $query->select([
            'fg_qc_check.id',
            'product.id as pid',
            'concat(fg_check_result.value,"-",product.name) as value',
         ])  
         ->from('fg_qc_check')
         ->innerJoin('fg_check_result','fg_check_result.fg_qc_check_id = fg_qc_check.id')
         ->innerJoin('qc_check_phy_chemical',' qc_check_phy_chemical.id = fg_check_result.qc_parameter_id')
         ->innerJoin('product','product.id = fg_qc_check.product_id')
         ->where(['qc_check_phy_chemical.name'=>"FG Batch Number *"]);
         //echo $ques_command = $query->createCommand()->sql;exit;
         //echo "<pre>";print_r($query->createCommand()->row());exit;
         $command = $query->createCommand();
         
         $fg_batch = $command->queryAll();
      // echo '<pre>';print_r($fg_batch);exit;
      if(isset($_GET['csv']))
      {
         $this->actionDownload($report_arr);
      }

      return $this->render('ap_modified_new',[
                                 'allrecords' => $report_arr,
                                 'fgbatch'   => $fg_batch,
                              ]);
   }

   public function actionCsvdownload($allrecords){
      ob_end_clean();
      if(sizeof($allrecords)>0){
         $date = array();
     foreach ($allrecords as $key => $row){
     $date[$key] = $row['sn'];
         }
     array_multisort($date, SORT_ASC, $allrecords);
     //array_multisort($date, SORT_ASC, $allrecords);
         $count=0;
         $obj=new Lib;
         $count = 1;
       $exceld = 'SN,RPC,Product,Supplier,Raw Material,FG Batch Number,Process,Parameter,Actual'."\r\n";
         //echo "<pre>";print_r($allrecords);exit;
         foreach($allrecords as $v){
             
             if(!empty($v)){
               // str_replace(,'|');
               $exceld .=++$count.','.$obj->rpc_name($v['rpc_name']).','.$obj->product_name($v['product_name']).','.$v['supplier_name'].','.$v['batch_id'].','.$obj->getfg_batch_name($v['fg_batch_num']).','.$v['process'].','. str_replace(',','|',$v['Parameter']).',';
               if (strpos($v['Actual'], 'href=') !== false) 
                     {
                        $v['Actual'] = explode('"', $v['Actual'])[1];
                        $img =$v['Actual'];
                        //$img ='=HYPERLINK("'.$v['Actual'].'";"View image")';
                        $exceld .=$img;
                     }else{ 
                        
                        $exceld .=str_replace(',','|',$v['Actual']);
                     }
                     $exceld .="\r\n";
             }  
         }
     }
     
      header('Content-Type: text/csv; charset=utf-8');
      header('Content-Disposition: attachment; filename="All Stages Report ' . date('d.m.Y') . '.csv"');
      echo $exceld;
      exit;
   }

   public function actionDownload($report_arr)
   {
      ob_end_clean();
      $count = 1;
      $exceld = 'RPC,Product,Supplier,Raw Material,FG Batch Number,Process,Parameter,Actual'."\r\n";

      foreach ($report_arr as $reqid => $data) 
      {
         foreach ($data as $product_id => $value) 
         {
            foreach ($value['vehicle'] as $parameter => $actual) 
            {
               $Prod = Product::find()->where(['id'=>$product_id])->one();
               $Supp = Supplier::find()->where(['unique_id'=>$value['details']['supplier_name']])->one();
               $label = "Vehicle Status";
               $parameter = str_replace(",", " | ", $parameter);
               if (strpos($actual, 'href=') !== false) 
               {
                  $actual = explode('"', $actual)[1];
                  $actual = '=HYPERLINK("'.$actual.'";"View image")';
               }

               $exceld .= $value['details']['rpc_name'] .',' . $Prod->name .',' . $Supp->name .','. $value['details']['raw_material_batch_number'] . ',' . $value['fg_batch'] . ',' . $label . ',' . ucwords(str_replace("_", " ", $parameter)) . ',' . $actual . "\r\n";
               $count++;
            }  /*vehicle FOREACH ENDS*/


            foreach ($value['Incoming'] as $parameter => $actual) 
            {
               $Prod = Product::find()->where(['id'=>$product_id])->one();
               $Supp = Supplier::find()->where(['unique_id'=>$value['details']['supplier_name']])->one();
               $label = "Incoming QC Check";

               if (strpos($actual, 'href=') !== false) 
               {
                  $actual = explode('"', $actual)[1];
                  $actual = '=HYPERLINK("'.$actual.'";"View image")';
               }

               $exceld .= $value['details']['rpc_name'] .',' . $Prod->name .',' . $Supp->name .','. $value['details']['raw_material_batch_number'] . ',' . $value['fg_batch'] . ',' . $label . ',' . ucwords(str_replace("_", " ", $parameter)) . ',' . $actual . "\r\n";
               $count++;
            }  /*Incoming FOREACH ENDS*/



            foreach ($value['fumigation'] as $fid => $sub_fumigation) 
            {
               if(COUNT($sub_fumigation) > 0)
               {
                  foreach ($sub_fumigation as $parameter => $actual) 
                  {
                     $Prod = Product::find()->where(['id'=>$product_id])->one();
                     $Supp = Supplier::find()->where(['unique_id'=>$value['details']['supplier_name']])->one();
                     $label = "Fumigation";

                     if (strpos($actual, 'href=') !== false) 
                     {
                        $actual = explode('"', $actual)[1];
                        $actual = '=HYPERLINK("'.$actual.'";"View image")';
                     }

                     $exceld .= $value['details']['rpc_name'] .',' . $Prod->name .',' . $Supp->name .','. $value['details']['raw_material_batch_number'] . ',' . $value['fg_batch'] . ',' . $label . ',' . ucwords(str_replace("_", " ", $parameter)) . ',' . $actual . "\r\n";
                     $count++;
                  }
               }  // if fumigation was done
            }  /*fumigation FOREACH ENDS*/


            foreach ($value['cleaning'] as $cid => $sub_cleaning) 
            {
               if(COUNT($sub_cleaning) > 0)
               {
                  foreach ($sub_cleaning as $parameter => $actual) 
                  {
                     $Prod = Product::find()->where(['id'=>$product_id])->one();
                     $Supp = Supplier::find()->where(['unique_id'=>$value['details']['supplier_name']])->one();
                     $label = "Cleaning Process";
                     $parameter = str_replace(",", " | ", $parameter);
                     if (strpos($actual, 'href=') !== false) 
                     {
                        $actual = explode('"', $actual)[1];
                        $actual = '=HYPERLINK("'.$actual.'";"View image")';
                     }

                     $exceld .= $value['details']['rpc_name'] .',' . $Prod->name .',' . $Supp->name .','. $value['details']['raw_material_batch_number'] . ',' . $value['fg_batch'] . ',' . $label . ',' . ucwords(str_replace("_", " ", $parameter)) . ',' . $actual . "\r\n";
                     $count++;
                  }
               }  // if cleaning was done
            }  /*cleaning FOREACH ENDS*/




          
               

            foreach ($value['FG QC Check'] as $fgid => $fg_array) 
            {

               foreach ($fg_array as $fg_parameter => $fg_actual) 
               {
                  $Prod = Product::find()->where(['id'=>$product_id])->one();
                  $Supp = Supplier::find()->where(['unique_id'=>$value['details']['supplier_name']])->one();
                  $label = "FG QC Check";

                  if (strpos($actual, 'href=') !== false) 
                  {
                     $actual = explode('"', $actual)[1];
                     $actual = '=HYPERLINK("'.$actual.'";"View image")';
                  }
                  $fg_array['FG Batch Number *'] = (!isset($fg_array['FG Batch Number *'])) ? "" : $fg_array['FG Batch Number *'];
                  $exceld .= $value['details']['rpc_name'] .',' . $Prod->name .',' . $Supp->name .','. $value['details']['raw_material_batch_number'] . ',' . $fg_array['FG Batch Number *'] . ',' . $label . ',' . ucwords(str_replace("_", " ", $fg_parameter)) . ',' . $fg_actual . "\r\n";
                  $count++;
               }  /*FG QC Check FOREACH ENDS*/

               if((isset($value['fgqc_entries'][$fgid])) && (COUNT($value['fgqc_entries'][$fgid]) > 0))
               {
                  foreach ($value['fgqc_entries'][$fgid] as $fgm_id => $fgm_ar) 
                  {
                     foreach ($fgm_ar as $fgm_parameter => $fgm_actual) 
                     {
                        $Prod = Product::find()->where(['id'=>$product_id])->one();
                        $Supp = Supplier::find()->where(['unique_id'=>$value['details']['supplier_name']])->one();
                        $label = "FG QC Check";

                        if (strpos($actual, 'href=') !== false) 
                        {
                           $actual = explode('"', $actual)[1];
                           $actual = '=HYPERLINK("'.$actual.'";"View image")';
                        }
                        $fg_array['FG Batch Number *'] = (!isset($fg_array['FG Batch Number *'])) ? "" : $fg_array['FG Batch Number *'];
                        $exceld .= $value['details']['rpc_name'] .',' . $Prod->name .',' . $Supp->name .','. $value['details']['raw_material_batch_number'] . ',' . $fg_array['FG Batch Number *'] . ',' . $label . ',' . ucwords(str_replace("_", " ", $fgm_parameter)) . ',' . $fgm_actual . "\r\n";
                        $count++;
                     }  /*FG QC Check FOREACH ENDS*/
                  }  /*FG QC Check entries FOREACH ENDS*/
               }
            }  /*FG QC Check FOREACH ENDS*/
         }
      }

      header('Content-Type: text/csv; charset=utf-8');
      header('Content-Disposition: attachment; filename="Training' . date('d.m.Y') . '.csv"');
      echo $exceld;
      exit;

   }

}
