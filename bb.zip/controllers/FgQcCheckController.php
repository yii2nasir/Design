<?php

namespace app\controllers;

use Yii;
use app\models\FgQcCheck;
use app\models\FgQcCheckSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;

use yii\web\UploadedFile;
use app\models\Product;
use app\models\QcCheckPhyChemical;
use app\models\IncomingQcCheck;
use app\models\FgCheckResult;
use app\models\CleaningMapper;


/**
 * FgQcCheckController implements the CRUD actions for FgQcCheck model.
 */
class FgQcCheckController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all FgQcCheck models.
     * @return mixed
     */
    public function actionIndex()
    {
          
         $rpccenterId = getUserRpcCenterId();
         $query = new \yii\db\Query;
         $query->select(['fumigation.*',
             'product.name as product_name'])
         ->from('fumigation')
         ->innerJoin('fumigation_mapper', 'fumigation_mapper.fumigation_id = fumigation.id')
         ->innerJoin('incoming_qc_check', 'incoming_qc_check.unique_id = fumigation_mapper.incoming_qc_uniq_id')
         ->innerJoin('product', 'product.id = incoming_qc_check.product_id')

         ->where(["<>",'fumigation_mapper.cleaning_status','0'])
         ->andWhere(["<>",'fumigation.overall_status','Accept']);
         // ->andWhere(['IN','fumigation.user_id',$rpccenterId]);
         if(isset($_GET['product_id']) && $_GET['product_id'] !=""){
            $query->andWhere(['incoming_qc_check.product_id'=>$_GET['product_id']]);
         }
         $command = $query->createCommand();
         $mainArrayFumigation = $command->queryAll();

         // display_array($mainArrayFumigation);
         // exit;
        $searchModel = new FgQcCheckSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $rpccenterId = getUserRpcCenterId();
         $model = new FgQcCheck();

        // return $this->render('index', [
        //     'searchModel' => $searchModel,
        //     'dataProvider' => $dataProvider,
        // ]);

       /// INDEX PAGE DATA 
     $query = new \yii\db\Query;
     $query->select(['cleaning.*',
       'product.name as product_name',
       'product.id as product_id',
       'cleaning_mapper.incoming_uniq_id',
       'cleaning_mapper.batch_id'])
     ->from('cleaning')
     ->innerJoin('cleaning_mapper', 'cleaning_mapper.cleaning_id = cleaning.id')
     ->innerJoin('product', 'product.id = cleaning_mapper.product_id')
     // ->where(['IN','cleaning.user_id',$rpccenterId])
     ->andWhere(['cleaning_mapper.fg_qc_status'=>'Incomplete']);
     if(isset($_GET['product_id']) && $_GET['product_id'] !=""){
      $query->andWhere(['cleaning_mapper.product_id'=>$_GET['product_id']]);
    }

    $command = $query->createCommand();
         // echo $query->createCommand()->getRawSql();exit;

    $data = $command->queryAll();

    return $this->render('index', [
      'searchModel' => $searchModel,
      'dataProvider' => $dataProvider,
      'data'=>$data
    ]);
    }

    /**
     * Displays a single FgQcCheck model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new FgQcCheck model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    // public function actionCreate()
    // {
    //     $model = new FgQcCheck();

    //     if ($model->load(Yii::$app->request->post()) && $model->save()) {
    //         return $this->redirect(['view', 'id' => $model->id]);
    //     }

    //     return $this->render('create', [
    //         'model' => $model,
    //     ]);
    // }

    /**
     * Updates an existing FgQcCheck model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing FgQcCheck model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the FgQcCheck model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return FgQcCheck the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = FgQcCheck::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }




 public function actionCreate()
    {
        $model = new FgQcCheck();
        $model->unique_id = uniqid();
        $model->updated_at = strtotime("now");
        $model->user_id = getUserId();
        $model->photo = UploadedFile::getInstance($model,'photo');
        $model->cleaning_uniq_id = $_GET['c_Uid'];

        if($model->photo){
                $product = strtotime("now").'.'.$model->photo->extension;
                $model->photo->saveAs('images/product/'.$product);
                $_POST['FgQcCheck']['photo'] = $product;
        }
        $qcCheckPhyChemy =  QcCheckPhyChemical::find()->where(['type'=>'FG QC Check'])->all();
        if ($model->load(Yii::$app->request->post()) && $model->save()){
            if(isset($_POST['FgQcCheck']['resultQcCheck']) && !empty($_POST['FgQcCheck']['resultQcCheck'])){
                $resultQcCheck = $_POST['FgQcCheck']['resultQcCheck'];
                foreach ($resultQcCheck as $value){
                  $resultQcCheck = new FgCheckResult();
                  $resultQcCheck->value = $value['value'];
                  $resultQcCheck->qc_parameter_id = $value['id'];
                  $resultQcCheck->fg_qc_check_id = $model->id;
                  $resultQcCheck->unique_id = uniqid();
                  $resultQcCheck->save();
                }
            }
            $status = $_POST['FgQcCheck']['overall_status'];
            if($status=='Accept'){
                $request_id = $_GET['rq_id'];
                $product_id =  $_POST['FgQcCheck']['product_id'];
                //fg qc complete
                $cleaning = CleaningMapper::find()->where(['cleaning_id'=>$_GET['c_id'],'product_id'=>$_GET['p']])->one();
                  if($cleaning){
                   $cleaning->fg_qc_status = "Complete"; 
                   $cleaning->save();
                 }
                if(isset($product_id,$request_id) && $product_id !="" && $request_id !=""){
                    return $this->redirect(['fg-qc-result?req_id='.$request_id.'&p='.$product_id]);
                }else{
                   return $this->redirect(['fg-qc-check/index']);
                }
             }
            
            elseif($status=='Reject'){
                $request_id = $_GET['rq_id'];
                $product_id =  $_POST['FgQcCheck']['product_id'];
                //fg qc complete
                $cleaning = CleaningMapper::find()->where(['cleaning_id'=>$_GET['c_id'],'product_id'=>$_GET['p']])->one();
                if($cleaning){
                   $cleaning->fg_qc_status = "Reject"; 
                   $cleaning->save();
                }
                return $this->redirect(['fg-qc-check/index']);
            }
        }

        ////// Find User Id

        if(isset($_GET['rq_id'],$_GET['p']) && $_GET['rq_id'] && $_GET['p'] !=""){
            $newUserId = IncomingQcCheck::find()->where(['unique_id'=>$_GET['rq_id']])->one()->user_id;
            $batch_id = IncomingQcCheck::find()->where(['unique_id'=>$_GET['rq_id']])->one()->batch_id;

            $productM = Product::find()->where(['id'=>$_GET['p']])->one();
           
        if(!$newUserId){
             return $this->redirect(['fg-qc-check/index']);    
        }else{
               $userId = $newUserId;
         } 
        }else{
             return $this->redirect(['fg-qc-check/index']);   
        }
        /// End User

        return $this->render('create', [
             'model' => $model,
             'qcCheckPhyChemy'=>$qcCheckPhyChemy,
             'userId'=>$userId,
             'rpccenterId' =>getUserRpcCenterId(),
             'productM'=>$productM,
             'batch_id'=>$batch_id
        ]);
    }

    public function actionFgQcResult(){
        return $this->render('fg_qc_result'); 
    }
 


}
