<?php

namespace app\controllers;

use Yii;
use app\models\Category;
use app\models\CategorySearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * CategoryController implements the CRUD actions for Category model.
 */
class AllProccessController extends Controller
{

    public $enableCsrfValidation = false;

    public function actionIndex(){
       return $this->render('index');
    }
    
}
