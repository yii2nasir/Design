<?php
namespace app\controllers;

use Yii;
use app\models\UserLocationMapper;
use app\models\UserLocationMapperSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

use app\models\Users;
/**
 * UserLocationMapperController implements the CRUD actions for UserLocationMapper model.
 */
class UserLocationMapperController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                // 'actions' => [
                //     'delete' => ['POST'],
                // ],
            ],
        ];
    }

    /**
     * Lists all UserLocationMapper models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new UserLocationMapperSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'user_id' => $user_id,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single UserLocationMapper model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new UserLocationMapper model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
        */
    public function actionCreate()
    {
        $user_id = $_GET['user_id'];
        if($user_id != NULL){
            $model = new UserLocationMapper();
            
            $searchModel = new UserLocationMapperSearch();
            $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

            $user = Users::find()->select(['id','level_id'])->where(['id' => $user_id])->one();

            if ($model->load(Yii::$app->request->post())) {
                
                if($user->level_id != "36"){
                    foreach($model['location_id'] as $loc){
                        $newModel = new UserLocationMapper();
                        $newModel->user_id = $user->id;
                        $newModel->level_id = $user->level_id;
                        $newModel->location_id = $loc;
                        $newModel->save();
                        }
                    }else{
                        $newModel = new UserLocationMapper();
                        $newModel->user_id = $user->id;
                        $newModel->level_id = $user->level_id;
                        $newModel->location_id = $model['location_id'];
                        $newModel->save(); 
                    }
                   
                 return $this->redirect(['users/index']); 
                
            } else {
                $model->level_id =    $user->level_id;
                return $this->render('create', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
                    'user_id' => $user_id,
                    'model' => $model,
                ]);
            }
        }else{
            $model = new Users();
            return $this->render('create', [
                    'model' => $model
                ]);
        }
    }

    public function actionCreateCommon($model,$user){
        $locations = $model->location_id;
        $model->save();
       
        return $this->redirect(['users/index']);
    }

    /**
     * Updates an existing UserLocationMapper model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate()
    {
        $user_id = $_GET['user_id'];
        $searchModel = new UserLocationMapperSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        if(isset($user_id) && !empty($user_id)){
            
            $model = new UserLocationMapper();
            
            $location = [];
            $old_models = UserLocationMapper::find()->where(['user_id' => $user_id])->asArray()->all();
    
            foreach($old_models as $data){
                
                $model->user_id = $data['user_id'];
                $model->level_id = $data['level_id'];
                $location[] = $data['location_id'];
                
            }
            $model->location_id = $location;  
            $data = Yii::$app->request->post();    
            // display_array($data);
            // exit;
            if ($model->load(Yii::$app->request->post())) {
                if($data['UserLocationMapper']['level_id'] == 1){
                    $this->actionUpdateCommon($old_models,$model);
                }
                if($data['UserLocationMapper']['level_id'] == 33){
                        $this->actionUpdateCommon($old_models,$model);
                }
                if($data['UserLocationMapper']['level_id'] == 35){
                    if($data['State']['id']){
                        $this->actionUpdateCommon($old_models,$model);
                    }else{
                        echo "<script> alert('Please Select District Coordinator'); </script>";
                        return $this->render('update', [
                            'model' => $model,
                            'user_id' => $user_id,
                            'searchModel' => $searchModel,
                            'dataProvider' => $dataProvider,

                        ]);
                    }
                }
                if($data['UserLocationMapper']['level_id'] == 37){
                    if($data['District']['id']){
                        $this->actionUpdateCommon($old_models,$model);
                    }else{
                        echo "<script> alert('Please Select RPC Coordinator'); </script>";
                        return $this->render('update', [
                            'model' => $model,
                            'user_id' => $user_id,
                            'searchModel' => $searchModel,
                            'dataProvider' => $dataProvider,
                        ]);
                    }
                }
            } else {
                return $this->render('update', [
                        'model' => $model,
                        'user_id' => $user_id,
                        'searchModel' => $searchModel,
                        'dataProvider' => $dataProvider,
                    ]);
            }
        }
    }

    public function actionUpdateCommon($old_models,$model){
        // foreach($old_models as $data){
        //     $this->actionDelete($data['id']);
        // }
        $locations = $model->location_id;
        $level = $model->level_id;
        $user = $model->user_id;
        foreach($locations as $location){
            $old_model = $this->findModelByUserAndlocation($model->user_id, $location);
            $model = new UserLocationMapper();
            $model->location_id = $location;
            $model->level_id = $level;
            $model->user_id = $user;
            $model->save();
        }
        return $this->redirect(['users/index']); 
    }
    /**
     * Deletes an existing UserLocationMapper model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id,$user_id)
    {

        $this->findModel($id)->delete();

        return $this->redirect(['update?user_id='.$user_id]);
    }

    /**
     * Finds the UserLocationMapper model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return UserLocationMapper the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = UserLocationMapper::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
    protected function findModelByUserAndlocation($user_id,$location_id)
    {
        $model = UserLocationMapper::find()->where(["location_id"=>$location_id])->andWhere(["user_id"=>$user_id])->one();
        if (($model) !== null) {
            return $model->delete();
        } else {
            return new UserLocationMapper();
        }
    }
}
