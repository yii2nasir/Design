<?php

namespace app\controllers;

use Yii;
use app\models\SubSubCategory;
use app\models\SubSubCategorySearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * SubSubCategoryController implements the CRUD actions for SubSubCategory model.
 */
class SubSubCategoryController extends Controller
{
    public $enableCsrfValidation = false;

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                // 'actions' => [
                //     'delete' => ['POST'],
                // ],
            ],
        ];
    }

    /**
     * Lists all SubSubCategory models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new SubSubCategorySearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single SubSubCategory model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new SubSubCategory model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new SubSubCategory();

        if ($model->load(Yii::$app->request->post())) {
            $model->updated_at = date("Y-m-d H:i:s");
            if($model->save()){
                return $this->redirect(['index', 'id' => $model->id]);
            }            
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing SubSubCategory model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post())) {
            $model->updated_at = date("Y-m-d H:i:s");
            if($model->save()){
                return $this->redirect(['index', 'id' => $model->id]);
            }            
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing SubSubCategory model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the SubSubCategory model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return SubSubCategory the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = SubSubCategory::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }

    public function actionList(){
        echo "kuchh v han...";
        exit;
    }

    public function actionSubSubCategoryUpload(){

         $controllerName= $this->id;
         $modelName = findModelName($controllerName);
         $modelName = 'app\\models\\'.$modelName;
         $model= new $modelName();
         if(isset($_FILES['file_csv']["tmp_name"])){
              $noc_document_1 = $_FILES['file_csv']["tmp_name"];
              $noc_document = "sub-sub-category.csv";
              $uploads_noc_document_1_dir = "UploadCsv/".$noc_document;
              if(move_uploaded_file($noc_document_1, $uploads_noc_document_1_dir)){
              if (($getdata = fopen($uploads_noc_document_1_dir, "r")) !== FALSE) { 
               while (($data = fgetcsv($getdata)) !== FALSE) {
                    $modelSubSubCategory = new $modelName();
                    $fieldCount = count($data);
                    for ($c=0; $c < $fieldCount; $c++) {
                      $columnData[$c] = $data[$c];
                    }
              $import_data[]= $columnData[0];
              $modelSubSubCategory->name = $columnData[0];
              $modelSubSubCategory->sub_cat_id = $columnData[0];
              $modelSubSubCategory->save();
             }
          }
          fclose($getdata);
          }
          return $this->redirect(['index']);
        }
    }

    // Here we write code for download csv

    public function actionDownload()
    {
        $data = "Sr.No, Sub Category Name,Sub_Sub-Category Name, Created_at, Updated_at\r\n";

        $rows = SubSubCategory::find() ->select(["sub_sub_category.*","sub_category.sub_cat_name as sub_category"])
            ->innerJoin("sub_category","sub_category.id = sub_sub_category.sub_cat_id")->asArray()->all();

          $count = 1;
          foreach ($rows as $value) {
              $data .= $count.',' .$value['sub_category'] .','. $value['name']. ','. $value['created_at'] .',' . $value['updated_at'] ."\r\n";
              $count++;
          }
          header('Content-type: text/csv');
          header('Content-Disposition: attachment; filename="Sub_Sub Category' . date("Y-m-d H:i:s") . '.csv"');
          echo $data;
          exit;
    }

}
