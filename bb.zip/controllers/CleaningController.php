<?php

namespace app\controllers;

use Yii;
use app\models\Cleaning;
use app\models\CleaningMapper;
use app\models\CleaningSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;
use app\models\FumigationMapper;

/**
 * CleaningController implements the CRUD actions for Cleaning model.
 */
class CleaningController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
      return [
        'verbs' => [
          'class' => VerbFilter::className(),
          // 'actions' => [
          //   'delete' => ['POST'],
          // ],
        ],
      ];
    }

    /**
     * Lists all Cleaning models.
     * @return mixed
     */
    public function actionIndex()
    {
      $searchModel = new CleaningSearch();
      $model = new Cleaning();
      $rpccenterId = getUserRpcCenterId();
      $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        // Data Proceed
      if(isset($_POST['Cleaning']['index']) && !empty($_POST['Cleaning']['index'])){ 
       $ids =  ArrayHelper::getColumn(array_values($_POST['Cleaning']), 'unique_id');
       $query = new \yii\db\Query;
       $query->select(['fumigation.*',
         'product.name as product_name',
         'fumigation_mapper.batch_id',
         'fumigation_mapper.product_id',
         'fumigation_mapper.incoming_qc_uniq_id'

       ])
       ->from('fumigation')
       ->innerJoin('fumigation_mapper', 'fumigation_mapper.fumigation_id = fumigation.id')
       ->innerJoin('product', 'product.id = fumigation_mapper.product_id')
       ->where(['IN','fumigation.unique_id',$ids]);
       $command = $query->createCommand();
       $data = $command->queryAll();
       return $this->render('create', ['data'=>$data,'model'=>$model]);
     }    
       // end


       /// INDEX PAGE DATA 
     $query = new \yii\db\Query;
     $query->select(['fumigation.*',
       'product.name as product_name',
       'product.id as product_id',
       'fumigation_mapper.incoming_qc_uniq_id',
       'fumigation_mapper.batch_id'])
     ->from('fumigation')
     ->innerJoin('fumigation_mapper', 'fumigation_mapper.fumigation_id = fumigation.id')
     ->innerJoin('product', 'product.id = fumigation_mapper.product_id')
     // ->where(['IN','fumigation.user_id',$rpccenterId])
     ->andWhere(['fumigation_mapper.cleaning_status'=>'0']);
     if(isset($_GET['product_id']) && $_GET['product_id'] !=""){
      $query->andWhere(['fumigation_mapper.product_id'=>$_GET['product_id']]);
    }
    $command = $query->createCommand();
    $data = $command->queryAll();

    return $this->render('index', [
      'searchModel' => $searchModel,
      'dataProvider' => $dataProvider,
      'data'=>$data
    ]);
  }

    /**
     * Displays a single Cleaning model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
      return $this->render('view', [
        'model' => $this->findModel($id),
      ]);
    }

    /**
     * Creates a new Cleaning model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
      $model = new Cleaning();
      $this->checkListJsonArray();
      $model->unique_id = uniqid();
      $model->updated_at = strtotime("now");
      if($model->load($_POST)){
       if($model->save()) {
        $this->cleaningMapper($_POST,$model->id);
        // return $this->redirect(['view', 'id' => $model->id]);
      }
    }
    return $this->redirect(['index']); 
  }

function checkListJsonArray(){
   if(isset($_POST['Cleaning']['cleaning_checklist']) && !empty($_POST['Cleaning']['cleaning_checklist'])){
     $checkList = $_POST['Cleaning']['cleaning_checklist'];
     $arrayMulti = [];
     $i=0;
     foreach ($checkList as $value) {
      if(isset($value['status']) && $value['status'] !=""){
        $arrayMulti[$i]['id'] =$value['value'];
        $arrayMulti[$i]['value'] =$value['status'];
        $i++; 
      }
    }
    $_POST['Cleaning']['cleaning_checklist'] = json_encode($arrayMulti);
  }
}

  function cleaningMapper($post,$id){
    if(isset($_POST['Cleaning']['cleaning_mapper']) && !empty($_POST['Cleaning']['cleaning_mapper'])){
      $data = $_POST['Cleaning']['cleaning_mapper'];
      foreach ($data as  $value) {
        $model = New CleaningMapper();
        $model->cleaning_id = $id;
        $model->product_id = $value['product_id'];
        $model->batch_id = $value['batch_id'];
        $model->incoming_uniq_id = $value['incoming_qc_uniq_id'];
        $model->save();
        // Fumigation Complete
        $fumigation = FumigationMapper::find()->where(['fumigation_id'=>$value['fmid']])->one();
        if($fumigation){
         $fumigation->cleaning_status = "1"; 
         $fumigation->save();
       }
     }
   }
  }
    /**
     * Updates an existing Cleaning model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
      $model = $this->findModel($id);

      if ($model->load(Yii::$app->request->post()) && $model->save()) {
        return $this->redirect(['view', 'id' => $model->id]);
      }

      return $this->render('update', [
        'model' => $model,
      ]);
    }

    /**
     * Deletes an existing Cleaning model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
      $this->findModel($id)->delete();

      return $this->redirect(['index']);
    }

    /**
     * Finds the Cleaning model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Cleaning the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
      if (($model = Cleaning::findOne($id)) !== null) {
        return $model;
      }

      throw new NotFoundHttpException('The requested page does not exist.');
    }

    public function actionViewData(){
       if(isset($_GET['unique_id']) && $_GET['unique_id'] !=""){
           $ids = $_GET['unique_id'];
           $query = new \yii\db\Query;
           $query->select(['product.name as product_name',
                           'product.code as product_code',
                           'supplier.name as supplier_name',
                           'supplier.code as supplier_code',
                           'new_request.vehicle_inspection_checklist',
                           'incoming_qc_check.accepted_qty as total_quantity'
                          ])
           ->from('incoming_qc_check')
           ->leftJoin('product', 'product.id = incoming_qc_check.product_id')
           ->leftJoin('new_request', 'new_request.unique_id = incoming_qc_check.request_id')
           ->leftJoin('supplier', 'supplier.id = new_request.supplier_id')
           ->where(['incoming_qc_check.unique_id'=> $ids]);
           $command = $query->createCommand();
           $data = $command->queryOne();
          
           $array = [];
           if($data){
             $array['product_name'] = $data['product_name'];
             $array['product_code'] = $data['product_code'];
             $array['supplier_name'] = $data['supplier_name'];
             $array['supplier_code'] = $data['supplier_code'];
             $array['vehicle_inspection_checklist'] = count(json_decode($data['vehicle_inspection_checklist']));
             $array['total_quantity'] = $data['total_quantity'];
           }else{
             $array['product_name'] = "";
             $array['product_code'] = "";
             $array['supplier_name'] = "";
             $array['supplier_code'] = "";
             $array['vehicle_inspection_checklist'] = 0;
             $array['total_quantity'] =0;
           }
       }
        return json_encode($array);
    }

    function actionApoorv()
    {
      $query = new \yii\db\Query;
      $query->select([
        'cleaning_mapper.id',
        'cleaning_mapper.product_id',
        'cleaning.cleaning_checklist'
      ])
      ->from('cleaning_mapper')
      ->innerJoin('cleaning', 'cleaning.id = cleaning_mapper.cleaning_id')
      ->innerJoin('product', 'product.id = cleaning_mapper.product_id');
      $command = $query->createCommand();
      $data = $command->queryAll();
      foreach ($data as $key => $value) 
      {
        $ques = json_decode($value['cleaning_checklist'],true);
        foreach ($ques as $k => $val) 
        {
          $val['value'] = ($val['value'] == 'NA') ? "No" : $val['value'];

          $q = new \yii\db\Query;
          $q->select(['id'])
          ->from('qc_check_phy_chemical')
          ->where(['name' => $val['id']])
          ->andWhere(['product_id' => $value['product_id']]);
          $command = $q->createCommand();
          $dat = $command->queryOne();
          if(isset($dat['id']) && !empty($dat['id']))
          {
            $dta[] = ['', uniqid(), $value['id'], $dat['id'], $val['value'], 1, NULL, NULL, "MOBILE", date("Y-m-d H:i:s"), date("Y-m-d H:i:s")];
          }
        }
      }
      Yii::$app->db->createCommand()->batchInsert('cleaning_qc_check', ['id', 'unique_id', 'cleaning_id', 'qc_parameter_id', 'value', 'status', 'latitude', 'logtitude', 'entry_type', 'created_at', 'updated_at'],$dta)
      ->execute();
      echo 'done';exit;
    }
  }
