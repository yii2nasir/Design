<?php

namespace app\controllers;

use Yii;
use app\models\Product;
use app\models\QcCheckPhyChemical;
use app\models\QcCheckPhyChemicalSearch;
use app\models\CleaningRpcMapper;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\helpers\Html;
use app\models\RpcCentre;

/**
 * QcCheckPhyChemicalController implements the CRUD actions for QcCheckPhyChemical model.
 */
class QcCheckPhyChemicalController extends Controller
{
    public $enableCsrfValidation = false;
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                // 'actions' => [
                //     'delete' => ['POST'],
                // ],
            ],
        ];
    }

    /**
     * Lists all QcCheckPhyChemical models. 
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new QcCheckPhyChemicalSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single QcCheckPhyChemical model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new QcCheckPhyChemical model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */

    public function actionCreate()
    {
      return $this->render('create', []);
    }

    public function actionProcessingMapper()
    {
      return $this->render('cleaning', []);
    }

    public function actionFetchCleanMapper()
    {
      $check_if_exist = CleaningRpcMapper::find()->asArray()->where(['product_id' => $_POST['product_id']])->all();
      if(COUNT($check_if_exist) > 0)
      {
        foreach ($check_if_exist as $key => $value) {
          $exist[$value['qc_parameter']] = json_decode($value['rpc_id'],true);
        }
      }

      $ques = QcCheckPhyChemical::find()->where(['product_id' => $_POST['product_id'], 'type' => 'processing'])->all();
      if(COUNT($ques) > 0)
      {
        $rpcs = RpcCentre::find()->all();
        if(COUNT($rpcs) > 0)
        {
          $html = '<table class="table table-bordered">';
          $html .= '<tr>';
          $html .= '<th>Questions</th>';
          foreach ($rpcs as $key => $value) 
          {
            $html .= '<th>'.$value["rpc_name"].' <font size="2" style="font-weight:lighter;padding">( Select All <input type="checkbox" id="'.$value['id'].'" class="select_all"> )</font></th>';
          }
          $html .= '</tr>';

          foreach ($ques as $key => $value) 
          {
            $html .= '<tr>';
            $html .= '<td>'.$value["name"].'</td>';
            foreach ($rpcs as $key => $val) 
            {
              if(COUNT($check_if_exist) > 0)
              {
                if(isset($exist[$value["id"]]) && in_array($val["id"], $exist[$value["id"]]))
                {
                  $checked_check = "checked";
                }else{
                  $checked_check = "";
                }
                $html .= '<td><input type="checkbox"  class="select_all_'.$val['id'].'" name="param['.$value["id"].']['.$val["id"].']" value="1" '.$checked_check.' ></td>';
              }else{
                $html .= '<td><input type="checkbox" class="select_all_'.$val['id'].'" name="param['.$value["id"].']['.$val["id"].']" value="1" ></td>';
              }
            }
            $html .= '</tr>';
          }
          $html .= '</table>';  
          $response = ['status' => 200, 'type' => 'success', 'msg' => 'success', 'data' => $html];
        }else{
          $response = ['status' => 200, 'type' => 'error', 'msg' => 'No RPC Found', 'data' => ""];
        }
      }else{
        $response = ['status' => 200, 'type' => 'error', 'msg' => 'No Questions Found', 'data' => ""];
      }
      echo json_encode($response);
    }

    public function actionCleanmUpdate()
    {
      // echo '<pre>';print_r($_POST);exit;
      if (isset($_SESSION['login_info'])) {
        $user = $_SESSION['login_info']; 
      }else{
        Yii::$app->session->setFlash('error', "Invalid Access");
        return $this->redirect(['index']);
      }
      if(isset($_POST['param']))
      {
        $flag = true;
        foreach ($_POST['param'] as $key => $value) 
        {
          $model = CleaningRpcMapper::find()->where(['product_id' => $_POST['product_id'], 'qc_parameter' => $key])->one();
          if($model != null)
          {
            $model->rpc_id = json_encode(array_keys($value));
            $model->user_id = $user->id;
            $model->updated_at = date("Y-m-d H:i:s");
          }else{
            $model = new CleaningRpcMapper();
            $model->product_id = $_POST['product_id'];
            $model->qc_parameter = $key;
            $model->rpc_id = json_encode(array_keys($value));
            $model->user_id = $user->id;
            $model->created_at = date("Y-m-d H:i:s");
            $model->updated_at = date("Y-m-d H:i:s");
          }
          if(!$model->save())
          {
            $flag = false;
          }
        } // end foreach
      }
      if($flag)
      {
        $response = ['status' => 200, 'type' => 'success', 'msg' => 'Data has been saved successfully', 'data' => ""];
      }else{
        $response = ['status' => 200, 'type' => 'error', 'msg' => 'An error occured while saving data. Please try again.', 'data' => ""];
      }
      echo json_encode($response);
    }


    /*public function actionCreate()
    {


         $model = new QcCheckPhyChemical();
         $this->orderWiseData();
         $model->updated_at = date("Y-m-d H:i:s");
        if ($model->load($_POST)) {
            if($model->save()){     
                return $this->redirect(['index', 'id' => $model->id]);
            }
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }
     

     function orderWiseData(){
          if(isset($_POST['QcCheckPhyChemical']['product_id']) && $_POST['QcCheckPhyChemical']['product_id'] !=""){
            $singleData = $_POST['QcCheckPhyChemical'];
            // display_array($singleData);
            // exit;
            $QcCheckPhyM = QcCheckPhyChemical::find()->where(['type'=>$singleData['type']])->andWhere(['product_id'=>$singleData['product_id']])->orderBy(['order_wise' => SORT_DESC])->one();
            if($QcCheckPhyM){
                 $_POST['QcCheckPhyChemical']['order_wise'] = $QcCheckPhyM['order_wise'] + 1 ;
            }else{
                 $_POST['QcCheckPhyChemical']['order_wise'] = 1;
            }
          }
     }*/

    

    /**
     * Updates an existing QcCheckPhyChemical model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    // public function actionUpdate($id)
    // {
    //     $model = $this->findModel($id);
    //     // $this->orderWiseData();
    //      $model->updated_at = date("Y-m-d H:i:s");
    //     if ($model->load($_POST)) {
    //         if ($model->save()) {
    //             return $this->redirect(['index', 'id' => $model->id]);
    //         }
    //     }
    //     return $this->render('update', [
    //         'model' => $model,
    //     ]);
    // }

    public function actionUpdate($id,$type)
    {
        $prod_data = Product::find()->asArray()->select([
          'product.id product_id',
          'product.name pname',
          'sub_sub_category.id sub_sub_id',
          'sub_sub_category.name sub_sub_name',
            ])
        ->leftJoin('sub_sub_category','sub_sub_category.id = product.sub_sub_cat_id')
        ->where(["product.id" => $id])->all();

        if(COUNT($prod_data) > 0)
        {
            $all_entries = QcCheckPhyChemical::find()->where(['product_id'=> $id, 'type'=> $type])->all();
            return $this->render('update', [
                'prod_data' => $prod_data[0],
                'type' => $type,
                'all_entries' => $all_entries,
            ]);
        }else{
          Yii::$app->session->setFlash('error', "No Product found. Kindly try again.");
            return $this->redirect(['index']);
        }
    }

    public function actionSubmitQform()
    {
      if($_POST)
      {
        $check = QcCheckPhyChemical::find()->where(['product_id'=> $_POST['product_id'], 'type'=> $_POST['type']])->all();
        if(COUNT($check) > 0)
        {
            $response = ['status' => 200, 'type' => 'error', 'msg' => 'Selected product already have questions in the database. Kindly update the details from update section', 'data' => ""];
        }else{
          $i = 1;
          foreach ($_POST['new'] as $key => $value) 
          {
              if(!$value['delete'])
              {
                  $model = new QcCheckPhyChemical();
                  $model->type = $_POST['type'];
                  $model->nature = $value['nature'];
                  $model->category = $value['category'];
                  $model->name = $value['name'];
                  $model->option_1 = $value['option_1'];
                  $model->option_2 = $value['option_2'];
                  $model->option_3 = $value['option_3'];
                  $model->option_4 = $value['option_4'];
                  $model->status = 1;
                  $model->entry_type = '';
                  $model->created_at = date("Y-m-d H:i:s");
                  $model->updated_at = date("Y-m-d H:i:s");
                  $model->order_wise = $i;
                  $model->mandatory = $value['mandatory'];
                  $model->sub_sub_category_id = $_POST['sub_sub_category_id'];
                  $model->product_id = $_POST['product_id'];
                  $model->expected_answer = $value['expected_answer'];
                  $model->is_editable = 1;
                  $i++;
                  $model->save(false);
              }
          }
          $response = ['status' => 200, 'type' => 'success', 'msg' => 'Data has been added successfully', 'data' => ""];
        }
      }       
      echo json_encode($response);
    }

    public function actionUpdateQform()
    {
      if($_POST)
      {
        $check = QcCheckPhyChemical::find()->where(['product_id'=> $_POST['product_id'], 'type'=> $_POST['type']])->all();
        if(COUNT($check) > 0)
        {
          $i = 1;
          if(isset($_POST['Q']))
          {
            foreach ($_POST['Q'] as $key => $value) 
            {
              if(!$value['delete'])
              {
                $model = $this->findModel($key);
                $model->type = $_POST['type'];
                $model->nature = $value['nature'];
                $model->category = $value['category'];
                $model->name = $value['name'];
                $model->option_1 = $value['option_1'];
                $model->option_2 = $value['option_2'];
                $model->option_3 = $value['option_3'];
                $model->option_4 = $value['option_4'];
                $model->status = 1;
                $model->entry_type = '';
                $model->updated_at = date("Y-m-d H:i:s");
                $model->order_wise = $i;
                $model->mandatory = $value['mandatory'];
                $model->sub_sub_category_id = $_POST['sub_sub_category_id'];
                $model->product_id = $_POST['product_id'];
                $model->expected_answer = $value['expected_answer'];
                $i++;
                $model->save(false);
              }else{
                $model = $this->findModel($key);
                $model->delete();
              }
            } //  end foreach
          }

          if(isset($_POST['new']))
          {
            foreach ($_POST['new'] as $key => $value) 
            {
              if(!$value['delete'])
              {
                $model = new QcCheckPhyChemical();
                $model->type = $_POST['type'];
                $model->nature = $value['nature'];
                $model->category = $value['category'];
                $model->name = $value['name'];
                $model->option_1 = $value['option_1'];
                $model->option_2 = $value['option_2'];
                $model->option_3 = $value['option_3'];
                $model->option_4 = $value['option_4'];
                $model->status = 1;
                $model->entry_type = '';
                $model->created_at = date("Y-m-d H:i:s");
                $model->updated_at = date("Y-m-d H:i:s");
                $model->order_wise = $i;
                $model->mandatory = $value['mandatory'];
                $model->sub_sub_category_id = $_POST['sub_sub_category_id'];
                $model->product_id = $_POST['product_id'];
                $model->expected_answer = $value['expected_answer'];
                $model->is_editable = 1;
                $i++;
                $model->save(false);
              }
            } //  end foreach
          }
          $response = ['status' => 200, 'type' => 'success', 'msg' => 'Data has been updated successfully', 'data' => ""];
        }else{
          $response = ['status' => 200, 'type' => 'error', 'msg' => 'Invalid Request', 'data' => ""];
        }
        echo json_encode($response);
      }
    }


    public function actionAddMore()
    {
      if(isset($_POST['type']) && ($_POST['type'] == 'Processing' || $_POST['type'] == 'processing'))
      {
        $options_ar = ['4'=>'radio button'];
      }else{
        $options_ar = ['1'=>"min-max numeric",'2'=>'min-max percentage','3'=>'dropdown','4'=>'radio button','5'=>'textbox','6'=>'date','7'=>'number'];
      }
        $rand = mt_rand(11111,99999);
        $html = '<div id="div_'.$rand.'" class="x_panel sub_entries" style="margin-top:10px;background: #f6fff6;">
               <div class="x_content">
                  <div class="row">
                     <table class="table table-bordered">
                        <tr>
                           <td width="10%" >Nature</td>
                           <td width="15%" >Question Type</td>
                           <td width="15%" >Name</td>
                           <td width="10%" >Option 1</td>
                           <td width="10%" >Option 2</td>
                           <td width="10%" >Option 3</td>
                           <td width="10%" >Option 4</td>
                           <td width="10%" >Expected Answers</td>
                           <td width="10%" >Mendatory</td>
                        </tr>';
        $html .= '<tr>
                   <td>
                     '.Html::dropDownList('new['.$rand.'][nature]', null,['Physical' => 'Physical','Chemical' => 'Chemical'],['prompt' => 'Select',
                         'id' => 'type',
                         'class'=>'form-control',
                      ]).'
                   </td>
                   <td>
                      '.Html::dropDownList('new['.$rand.'][category]', null,$options_ar,
                      ['prompt' => 'Select',
                         'data-id' => $rand,
                         'id' => "qtype_".$rand,
                         'class'=>'form-control qtype',
                      ]).'
                   </td>
                    <td>
                      '.Html::textInput('new['.$rand.'][name]', null,[ 'class' => 'form-control']).'
                   </td>
                   <td>
                      '.Html::textInput('new['.$rand.'][option_1]', null,[ 'data-id' => $rand, 'data-option' => 'ans_option_1', 'class' => 'option_changed form-control one_'.$rand.'']).'
                   </td>
                   <td>
                      '.Html::textInput('new['.$rand.'][option_2]', null,[ 'data-id' => $rand, 'data-option' => 'ans_option_2', 'class' => 'option_changed form-control two_'.$rand.'']).'
                   </td>
                   <td>
                      '.Html::textInput('new['.$rand.'][option_3]', null,[ 'data-id' => $rand, 'data-option' => 'ans_option_3', 'class' => 'option_changed form-control three_'.$rand.'']).'
                   </td>
                   <td>
                      '.Html::textInput('new['.$rand.'][option_4]', null,[ 'data-id' => $rand, 'data-option' => 'ans_option_4', 'class' => 'option_changed form-control four_'.$rand.'']).'
                   </td>
                   <td>
                      <select class="form-control" id="expected_answer_'.$rand.'" name="new['.$rand.'][expected_answer]">
                         <option value="">Select</option>
                         <option value="" id ="ans_option_1">option 1</option>
                         <option value="" id ="ans_option_2">option 2</option>
                         <option value="" id ="ans_option_3">option 3</option>
                         <option value="" id ="ans_option_4">option 4</option>
                      </select>
                   </td>
                   <td>
                      '.Html::dropDownList('new['.$rand.'][mandatory]', 1,['1'=>"Yes",'0'=>'No'],
                      ['prompt' => 'Select',
                         'id' => 'mandatory',
                         'class'=>'form-control',
                      ]).'
                   </td>
                </tr>';

        $html .= '</table>
                     
                  </div>
               </div>
               <span data-id="'.$rand.'" class="close_button"><i class="fa fa-close"></i></span>
               <input type="hidden" name="new['.$rand.'][delete]" id="Q_'.$rand.'"/>
            </div>';
        echo $html;
    }

    /**
     * Deletes an existing QcCheckPhyChemical model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $singleData  = $this->findModel($id);
        $product_id = $singleData['product_id'];
        $type = $singleData['type'];
        $singleData->delete();
       
           // After Delete Oder Changes  
        $QcCheckPhyM = QcCheckPhyChemical::find()->where(['type'=>$singleData['type']])->andWhere(['product_id'=>$singleData['product_id']])->orderBy(['order_wise' => SORT_ASC])->all();
        $i = 1;
        foreach ($QcCheckPhyM as  $value) {
            $model =  QcCheckPhyChemical::find()->where(['id'=>$value['id']])->one();
            if($model){
                 $model->order_wise =$i;
                 $model->save();
                 $i++;  
            }
        }
        return $this->redirect(['index']);
    }

    /**
     * Finds the QcCheckPhyChemical model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return QcCheckPhyChemical the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = QcCheckPhyChemical::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }

    public function actionQcCheckPhyChemicalUpload(){

         $controllerName= $this->id;
         $modelName = findModelName($controllerName);
         $modelName = 'app\\models\\'.$modelName;
         $model= new $modelName();
         if(isset($_FILES['file_csv']["tmp_name"])){
              $noc_document_1 = $_FILES['file_csv']["tmp_name"];
              $noc_document = "qc-check-phy-chemical.csv";
              $uploads_noc_document_1_dir = "UploadCsv/".$noc_document;
              if(move_uploaded_file($noc_document_1, $uploads_noc_document_1_dir)){
              if (($getdata = fopen($uploads_noc_document_1_dir, "r")) !== FALSE) { 
               while (($data = fgetcsv($getdata)) !== FALSE) {
                    $modelQcCheckPhyChemical = new $modelName();
                    $fieldCount = count($data);
                    for ($c=0; $c < $fieldCount; $c++) {
                      $columnData[$c] = $data[$c];
                    }
              $import_data[]= $columnData[0];
              $modelQcCheckPhyChemical->name = $columnData[0];
              // $modelQcCheckPhyChemical->district_id = $columnData[0];
              $modelQcCheckPhyChemical->save();
             }
          }
          fclose($getdata);
          }
          return $this->redirect(['index']);
        }
    }


    // public function actionDownload()
    // {
    //     $data = "Sr.No,Type,nature,Category,Created_at,Updated_at\r\n";
    //     $rows = QcCheckPhyChemical::find() ->select(["qc_check_phy-_chemical.*","qc_check_phy_chemical.name as qc_check_phy_chemical"])
            
    //         // ->innerJoin("district","district.id = rpc_centre.district_id")
    //         // ->innerJoin("state","state.id= district.state_id")->asArray()->all();
    //       $count = 1;
    //       foreach ($rows as $value) {
    //           $data .= $count.',' . $value['type'] .','. $value['nature']. ',' .$value['category'].','. $value['created_at'] .',' . $value['updated_at'] ."\r\n";
    //           $count++;
    //       }
    //       header('Content-type: text/csv');
    //       header('Content-Disposition: attachment; filename="QcCheckPhyChemical Centre' . date('d.m.Y') . '.csv"');
    //       echo $data;
    //       exit;
    // }
}
