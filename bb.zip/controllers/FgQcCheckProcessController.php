<?php

namespace app\controllers;

use Yii;
use app\models\FgQcCheckProcess;
use app\models\FgQcCheckProcessSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\UploadedFile;
use app\models\NewRequest;
use app\models\Product;
use app\models\QcCheckPhyChemical;
use app\models\IncomingQcCheck;
use app\models\FgCheckResult;




/**
 * FgQcCheckProcessController implements the CRUD actions for FgQcCheckProcess model.
 */
class FgQcCheckProcessController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all FgQcCheckProcess models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new FgQcCheckProcessSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single FgQcCheckProcess model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new FgQcCheckProcess model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */

    
    // public function actionCreate()
    // {
    //     $model = new FgQcCheckProcess();

    //     if ($model->load(Yii::$app->request->post()) && $model->save()) {
    //         return $this->redirect(['view', 'id' => $model->id]);
    //     }

    //     return $this->render('create', [
    //         'model' => $model,
    //     ]);
    // }


    public function actionCreate()
    {
        $model = new FgQcCheckProcess();
        $model->unique_id = uniqid();
        $model->updated_at = strtotime("now");
        $model->user_id = getUserId();
        $model->photo = UploadedFile::getInstance($model,'photo');
        if($model->photo){
                $product = strtotime("now").'.'.$model->photo->extension;
                $model->photo->saveAs('images/product/'.$product);
                $_POST['FgQcCheckProcess']['photo'] = $product;
        }
        $qcCheckPhyChemy =  QcCheckPhyChemical::find()->where(['type'=>'FG QC Check'])->all();
        if ($model->load(Yii::$app->request->post()) && $model->save()){
             if(isset($_POST['FgQcCheckProcess']['resultQcCheck']) && !empty($_POST['FgQcCheckProcess']['resultQcCheck'])){
                $resultQcCheck = $_POST['FgQcCheckProcess']['resultQcCheck'];
                foreach ($resultQcCheck as $value){
                  $resultQcCheck = new FgCheckResult();
                  $resultQcCheck->value = $value['value'];
                  $resultQcCheck->qc_parameter_id = $value['id'];
                  $resultQcCheck->fg_qc_check_id = $model->id;
                  $resultQcCheck->unique_id = uniqid();
                  $resultQcCheck->save();
                }
             }
            $status = $_POST['FgQcCheckProcess']['overall_status'];
            if(!$status){
               //  echo "<pre>";
               // print_r($_POST['FgQcCheckProcess']); exit;
                $request_id = $_GET['rq_id'];
                $product_id =  $_POST['FgQcCheckProcess']['product_id'];
                if(isset($product_id,$request_id) && $product_id !="" && $request_id !=""){
                    return $this->redirect(['fg-qc-result?req_id='.$request_id.'&p='.$product_id]);
                }else{
                   return $this->redirect(['fg-qc-check-process/index']);
                }
             }
        }

        ////// Find User Id

        if(isset($_GET['rq_id'],$_GET['p']) && $_GET['rq_id'] && $_GET['p'] !=""){
            $newUserId = IncomingQcCheck::find()->where(['unique_id'=>$_GET['rq_id']])->one()->user_id;
            $productM = Product::find()->where(['id'=>$_GET['p']])->one();
           
        if(!$newUserId){
             return $this->redirect(['fg-qc-check-process/index']);    
        }else{
               $userId = $newUserId;
         } 
        }else{
             return $this->redirect(['fg-qc-check-process/index']);   
        }
        /// End User

        return $this->render('create', [
             'model' => $model,
             'qcCheckPhyChemy'=>$qcCheckPhyChemy,
             'userId'=>$userId,
             'productM'=>$productM
        ]);
    }

    public function actionFgQcResult(){
        return $this->render('fg_qc_result'); 
    }
 



    /**
     * Updates an existing FgQcCheckProcess model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing FgQcCheckProcess model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the FgQcCheckProcess model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return FgQcCheckProcess the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = FgQcCheckProcess::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }

    public function actionFgQcProceed()
    {
        // $model = $this->findModel($id);

        // if ($model->load(Yii::$app->request->post()) && $model->save()) {
        //     return $this->redirect(['view', 'id' => $model->id]);
        // }
        return $this->render('fg_qc_form');
            
    }
}
