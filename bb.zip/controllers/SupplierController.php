<?php

namespace app\controllers;

use Yii;
use app\models\Supplier;
use app\models\Product;
use app\models\SupplierSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\SupplierProductMapping;

/**
 * SupplierController implements the CRUD actions for Supplier model.
 */
class SupplierController extends Controller
{
    public $enableCsrfValidation = false;
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                // 'actions' => [
                //     'delete' => ['POST'],
                // ],
            ],
        ];
    }

    /**
     * Lists all Supplier models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new SupplierSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Supplier model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Supplier model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Supplier();
       
        if ($model->load(Yii::$app->request->post())) {
            $model->updated_at = strtotime("now");
            $model->unique_id = uniqid();
            if($model->save()){
                if(isset($_GET['type']) && $_GET['type'] !="" && $_GET['type'] =="new"){
                  return $this->redirect(['new-request/create']);
                }else{
                  return $this->redirect(['index', 'id' => $model->id]);
                }    
            }
        }
        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Supplier model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        $product = Product::find()->all();
        
        if ($model->load(Yii::$app->request->post())) {
            $model->updated_at = strtotime("now"); 
            if ($model->save()) {
               return $this->redirect(['index', 'id' => $model->id]);
            }       
           
        }

        return $this->render('update', [
            'model' => $model,
            // 'product'=>$product
        ]);
    }

    /**
     * Deletes an existing Supplier model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Supplier model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Supplier the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Supplier::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }

    public function actionSupplierUpload(){

         $controllerName= $this->id;
         $modelName = findModelName($controllerName);
         $modelName = 'app\\models\\'.$modelName;
         $model= new $modelName();
         if(isset($_FILES['file_csv']["tmp_name"])){
              $noc_document_1 = $_FILES['file_csv']["tmp_name"];
              $noc_document = "supplier.csv";
              $uploads_noc_document_1_dir = "UploadCsv/".$noc_document;
              if(move_uploaded_file($noc_document_1, $uploads_noc_document_1_dir)){
              if (($getdata = fopen($uploads_noc_document_1_dir, "r")) !== FALSE) { 
               while (($data = fgetcsv($getdata)) !== FALSE) {
                    $modelSupplier = new $modelName();
                    $fieldCount = count($data);
                    for ($c=0; $c < $fieldCount; $c++) {
                      $columnData[$c] = $data[$c];
                    }
              $import_data[]= $columnData[0];
              $modelSupplier->name = $columnData[0];
              // $modelSupplier->district_id = $columnData[0];
              $modelSupplier->save();
             }
          }
          fclose($getdata);
          }
          return $this->redirect(['index']);
        }
    }

   public function actionDownload()
    {
        $data = "Sr.No,Name,created_at,updated_at\r\n";
        // $rows = District::find() ->select(["district.*","state.name as state","country.name as country"])
        //     ->innerJoin("state","state.id= district.state_id")
        //     ->innerJoin("country","country.id= district.country_id")->asArray()->all();
          $count = 1;
          $Datafind = Supplier::find()->all();
          foreach ($Datafind as $value) {
              $data .= $count.',' . $value['name'] .',' . $value['created_at'] .',' . $value['updated_at'] ."\r\n";
              $count++;
          }
          header('Content-type: text/csv');
          header('Content-Disposition: attachment; filename="Supplier' . date('d.m.Y') . '.csv"');
          echo $data;
          exit;
    }

}
