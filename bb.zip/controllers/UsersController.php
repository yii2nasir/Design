<?php
namespace app\controllers;

use Yii;
use app\models\Users;
use app\models\UserLocationMapper;
use app\models\UserLocationMapperSearch;
use app\models\Village;
use app\models\LoginHistory;
use app\models\State;
use app\models\District;
use app\models\Block;
use app\models\UsersSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * UserController implements the CRUD actions for User model.
 */
class UsersController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                // 'actions' => [
                //     'delete' => ['POST'],
                // ],
            ],
        ];
    }

    /**
     * Lists all User models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new UsersSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single User model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new User model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Users();

        if ($model->load(Yii::$app->request->post())){ 
            $model->authKey = md5($model->username);
            $usernmaes = Users::find()->select(['MAX(CAST(username AS UNSIGNED)) as username'])->all();
            $uniusername = $usernmaes[0]->username;

            if($uniusername == "" || $uniusername == "0")
            {
               $uniusername = 1000;
            }
            else {
                 $uniusername = $uniusername+1;
            }
            $model->username = (string)$uniusername;
            $model->password = (string)rand(1000, 100000);
            if($model->save()){
                return $this->redirect(['user-location-mapper/create?user_id='.$model->id]);
            }
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    private function sendSms($url){
        $ch=curl_init();
        $optArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
        );
        curl_setopt_array($ch, $optArray);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
    /**
     * Updates an existing User model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['user-location-mapper/update', 'user_id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing User model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the User model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return User the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Users::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
    public function actionChangePassword() {
        if (isset($_SESSION['login_info'])) {
            $user_id = $_SESSION['login_info']['id'];
        }
        $model = $this->findModel($user_id);
        $user_level = NULL;
        $errorMessage = "";
        if (isset($_POST["current_password"])) {
            if ($_POST["current_password"] != $model->password) {
                $errorMessage = "Please enter correct password in Current Password";
            }
            if ($_POST["current_password"] == "") {
                $errorMessage = "Please enter Current Password";
            }
        } else {
            if (isset($_POST['Users'])) {
                $errorMessage = "Please enter current password";
            }
        }
        if ($errorMessage == "" && $model->load($_POST) && $model->save()) {

            $model->changed_password_once = "1";
            $model->save();

            return $this->redirect(['site/index', "message" => "Password changed successfully"]);
        } else {
            return $this->render('change_password', [
                        'model' => $model,
                        'errorMessage' => $errorMessage
            ]);
        }
    }

    /**
     * Updates an existing Users model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
  

    public function actionLogout() {
            if (session_status() == PHP_SESSION_NONE) {
                session_start();
            }
            unset($_SESSION['login_info']);
            return $this->goHome();
    }

    public function actionLogin() {
        $post = \Yii::$app->request->post();
        // print_r($post);exit;
        $session = \Yii::$app->session;
        if (isset($post['Users'])) {
            if (($model = Users::find()->where(['username' => $post['Users']['user_name'], 'password' => $post['Users']['password']])->one()) !== null) {
                if ($model->status == 1 || $model->status == "1") {
                    if (!$session->isActive) {
                        $session->open();
                    }
                    $session->set("login_info", $model);
                    $LoginHistoryModel = new LoginHistory();
                    $LoginHistoryModel->user_id = $model->id;
                    $LoginHistoryModel->logged_in = strtotime("now");
                    if (!$LoginHistoryModel->save()) {
                        $session->destroy();
                        return $this->renderPartial('login', [
                                    'model' => $model,
                                    'error' => 'Something went wrong,Please login again!'
                        ]);
                    }
                    $session->set("login_id", $LoginHistoryModel->id);
                    $session->set("sessionCount", $LoginHistoryModel->id);
                    ob_start();

                    if (isset($_GET['goback'])) {
                       
                        echo '<script>window.location="' . \yii\helpers\Url::to(['site/index']) . '";</script>';
                        exit;
                    } else {
                        echo '<script>window.location="' . \yii\helpers\Url::to(['site/index']) . '";</script>';
                        exit;
                    }
                } else {
                    return $this->renderPartial('login', [
                                'model' => $model,
                                'error' => 'Your account is blocked'
                    ]);
                }
            } else {
                $model = new Users();
                return $this->renderPartial('login', [
                            'model' => $model,
                            'error' => 'Please enter valid username and password'
                ]);
            }
        } else {
            $model = new Users();
            return $this->renderPartial('login', [
                        'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Users model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
   

    protected function findModelUserPass($user, $pass) {

        if (($model = Users::find()->where(['user_name' => $user, 'password' => $pass])->one()) !== null) {
            return true;
        } else {
            return false;
        }
    }


}
