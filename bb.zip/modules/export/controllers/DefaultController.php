<?php

namespace app\modules\export\controllers;

use yii\web\Controller;
use app\modules\export\models\ExportConfig;

/**
 * Default controller for the `export` module
 */
class DefaultController extends Controller
{
    /**
     * Renders the index view for the module
     * @return string
     */
    public function actionIndex()
    {
//        if(file_exists(ExportConfig::$pathOfCache))
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
//        display_array($_SESSION);
//        exit;
        if(isset($_SESSION[ExportConfig::$pathOfCache."-".$_GET['token']]))
        {
            $params = $_SESSION[ExportConfig::$pathOfCache."-".$_GET['token']];
            $params = unserialize($params);
            if(isset($params[ExportConfig::$configModel]) &&
                    isset($params[ExportConfig::$configMethod]) && 
                    isset($params[ExportConfig::$modelName]))
            {
                $_GET = $params;
                $config = $params[ExportConfig::$configModel]::$params[ExportConfig::$configMethod]($params);
                \app\modules\export\models\ExportGrid::generateExportFile($config,"tempData.csv",$params[ExportConfig::$modelName]);
                header('Content-Type: application/csv');
                $fileNameString = str_replace("\\", "", $params[ExportConfig::$modelName]);
                header('Content-Disposition: attachment; filename="'.$fileNameString.'.csv"');
                readfile('tempData.csv');
            }
        }
//        $_SESSION[ExportConfig::$pathOfCache]['token'] = "";
//        unset($_SESSION[ExportConfig::$pathOfCache]['token']);
    }
}
