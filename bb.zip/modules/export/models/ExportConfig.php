<?php
namespace app\modules\export\models;

class ExportConfig{
    public static $modelName = "model_name001";
    public static $configModel = "config_model001";
    public static $configMethod = "config_method001";
    public static $csv = "csv";
    public static $btnText = "text";
    public static $btnOptions = "options";
    
    
    public static $url = "/export";
    public static $pathOfCache = "serialize_store";
    public static $pathOfCacheInd = "export_dataprovider";
    
    
    public static $defaultBtnText = "Download CSV";
    public static $defaultBtnOptions = ["class"=>"btn btn-success pull-right"];
}