<?php

namespace app\modules\export\models;

/**
 *  Inside the method   
    $dataProvider = $gridviewConfigArray["dataProvider"];
    $searchModel = $gridviewConfigArray["searchModel"];
    return gridviewArray
 *  forEx..
    return [
            'dataProvider' => $dataProvider,
            'filterModel' => $searchModel,
            'columns' => []
    ]
*/
interface InitGrid{
    public static function getColumnConfigOfIndex($gridviewConfigArray);
}
