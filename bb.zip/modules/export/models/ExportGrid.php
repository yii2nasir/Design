<?php

namespace app\modules\export\models;
use Yii;
use app\modules\export\models\ExportUtils;
use app\modules\export\models\ExportConfig;

class ExportGrid {

    /*
     * @params 
     *  $params = params that need to be searched by dataprovider -- Required
     *  $modelName = specify which table's Model it is - Optional
     *              if you will no specify it it will take it from controller->id
     *  $configModel = specify which model/class the gridview config does resids
     *              if you will no specify it it will take it from controller->id
     *  $configMethod = specify which mehod the gridview config does resids
     *              by default it will be getColumnConfigOfIndex method
     *  $options = array type | it can have following parameter in array
     *              [
     *                  ExportConfig::$btnText => "Download CSV something"
     *                  ExportConfig::$btnOptions => ['class'=>'btn btn-success']
     *              ]
     */
    public static function exportButton($params,$options=[],$modelName="",$configModel="",$configMethod="")
    {
        if($configMethod==""){
            $configMethod = "getColumnConfigOfIndex";
        }
        if($modelName==""){
            $modelName = ExportUtils::getModelName(Yii::$app->controller->id);
            $modelName = 'app\\models\\'.$modelName;
            $configModel = $modelName.'Search';
        }
        $params[ExportConfig::$modelName] = $modelName;
        $params[ExportConfig::$configModel] = $configModel;
        $params[ExportConfig::$configMethod] = $configMethod;
        $params[ExportConfig::$csv] = "1";
        $randm = rand(1,1000);
//        $_COOKIE[ExportConfig::$pathOfCache][rand(1,1000)]=$params;
        
        $_SESSION[ExportConfig::$pathOfCache."-".$randm]=serialize($params); // 86400 = 1 day
//        display_array($_COOKIE[ExportConfig::$pathOfCache."-".$randm]);
//        exit;
        
//        file_put_contents(ExportConfig::$pathOfCache, serialize($params));
        
        $btnText = isset($options[ExportConfig::$btnText])?$options[ExportConfig::$btnText]:ExportConfig::$defaultBtnText;
        $btnOptions = isset($options[ExportConfig::$btnOptions])?$options[ExportConfig::$btnOptions]:ExportConfig::$defaultBtnOptions;
        echo \yii\helpers\Html::a("Download CSV", \yii\helpers\Url::to([ExportConfig::$url,"token"=>$randm]),$btnOptions);
    }
    
    
    public static function generateExportFile($config,$fileName,$modelName)
    {
        $outputArray = array();
        $oCounter = 0;
        
        $columns = $config["columns"];
        
        $config["dataProvider"]->pagination = false;
        $dataProviders = $config["dataProvider"]->models;

        
        
//        $isModel = true;
//        if(isset($dataProviders[0]) && is_array($dataProviders[0])){
//            $isModel = false;
//        }
        

        if(file_exists($fileName)){
            unlink($fileName);
        }    
        $output = fopen($fileName, 'w');

        if(isset($dataProviders[$oCounter]))
        {

            $dataProvidersSingle = (object) $dataProviders[$oCounter];

            for($j=0;$j<count($columns);$j++)
            {
                $columnsSingle = $columns[$j];

                
                
                if(is_array($columnsSingle))
                {
                    if(isset($columnsSingle["class"]) && $columnsSingle["class"]=="yii\grid\ActionColumn")
                    {
                    }
                    else if(isset($columnsSingle["header"]))
                    {
                        $outputArray[$j] = $columnsSingle["header"]; 
                    }
                    else if(isset($columnsSingle["label"]))
                    {
                        $outputArray[$j] = $columnsSingle["label"]; 
                    }
//                    else if(isset($columnsSingle["content"]))
//                    {
//                        $outputArray[$j] = getLabelNameFromColumnName($columnsSingle["attribute"], $dataProvidersSingle);   
//                    }
                    else if(isset($columnsSingle["attribute"]))
                    {
                        $outputArray[$j] = ExportUtils::getLabelNameFromColumnName($columnsSingle["attribute"], $modelName);   
                    }
                    else if(isset($columnsSingle["class"]) && $columnsSingle["class"]=="yii\grid\SerialColumn")
                    {
                        $outputArray[$j] = "S. No";
                    }
                }
                else
                {
                    $outputArray[$j] = ExportUtils::getLabelNameFromColumnName($columnsSingle, $modelName);   
    //                $outputArray[$oCounter][$j] = $dataProvidersSingle->$columnsSingle;
                }
            }

            fputcsv($output, $outputArray);
            $oCounter++;
        }
        
        for($i=0;$i<count($config["dataProvider"]->models);$i++)
        {

            $outputArray = array();
            $dataProvidersSingleB = $dataProviders[$i];
            $dataProvidersSingle = (object) $dataProvidersSingleB;
            
            for($j=0;$j<count($columns);$j++)
            {
                $columnsSingle = $columns[$j];

                
                if(is_array($columnsSingle))
                {
                    
                    if(isset($columnsSingle["class"]) && $columnsSingle["class"]=="yii\grid\ActionColumn")
                    {
                    }
                    else if(isset($columnsSingle["content"]))
                    {
                        $outputArray[$j] = strip_tags($columnsSingle["content"]($dataProvidersSingleB)); 
                        if($outputArray[$j]==null)
                        {
                            $outputArray[$j] = "";
                        }
                    }
                    else if(isset($columnsSingle["class"]) && $columnsSingle["class"]=="yii\grid\SerialColumn")
                    {
                        $outputArray[$j] = $i+1;
                    }
                    else if(isset($columnsSingle["attribute"]) && 
                            isset ($dataProvidersSingle->$columnsSingle["attribute"])){
                        $outputArray[$j] = $dataProvidersSingle->$columnsSingle["attribute"];
                    }
                }
                else
                {
                    $outputArray[$j] = isset($dataProvidersSingle->$columnsSingle)?$dataProvidersSingle->$columnsSingle:$dataProvidersSingle[$columnsSingle];
                }
                
                
            }
            
            
//            display_array($columns);
//            display_array($outputArray);
//            exit;
            fputcsv($output, $outputArray);

            $oCounter++;

        }
        //return $outputArray;

    }
    
    public static function getParams($params){
        if($params==null){
            $params = file_get_contents('serialize_store');
        }
        return $params;
    }
}