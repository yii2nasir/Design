<?php
namespace app\modules\export\models;

use app\modules\export\models\ExportConfig;

class ExportInd{
    public static function cacheDataProvider($dataProvider){
        file_put_contents(ExportConfig::$pathOfCacheInd, serialize($dataProvider));
    }
    public static function checkAndDownloadCsv($columns){
        if(isset($_GET['is_csv']) && file_exists(ExportConfig::$pathOfCacheInd)){
            $dataProvider = unserialize(file_get_contents(ExportConfig::$pathOfCacheInd));
            
            
            unlink("traning_report.csv");
            $output = fopen("traning_report.csv", 'w');
            $columnLabels = array();
            foreach ($columns as $key => $value) {
                $columnLabels[] = $value["label"];
            }
            fputcsv($output, $columnLabels);

            foreach ($dataProvider->models as $key => $value) {
                $columnValues = array();
                foreach ($columns as $key => $valueF) {
                    if(isset($valueF["content"])){
                        $columnValues[] = $valueF["content"]($value);   
                    }
                    else{
                        $columnValues[] = $value->$valueF["attribute"];
                    }
                }
                fputcsv($output, $columnValues);
            }
            header('Content-Type: application/csv');    
            header('Content-Disposition: attachment; filename="training.csv"');
            readfile('traning_report.csv');
            exit;
        }
    }
}


//            unlink("traning_report.csv");
//            
//            $output = fopen("traning_report.csv", 'w');
//            
////            fputcsv($output,["d","dd"]);
//            
//            fputcsv($output, ["Id",
//                                "Name",
//                                "Attendance in percentage",
//                                "Profile Status",
//                                "Batch",
//                                "Training Status",
//                                "Gender",
//                                "Age",
//                                "Contact No",
//                                "Qualification",
//                                "Alternate Contact No",
//                                "Area"]);
//            
//            foreach ($temp_dataprovider->models as $key => $value) {
//                fputcsv($output, [
////                                "id",
////                                [
////                                    "attribute"=>"name",
////                                    "content"=>function($value){
////                                        return $value->name;
////                                    }
////                                ],
//                                $value->id,
//                                $value->name,
//                                $value->attendance_in_percentage,
//                                $value->profile_status=="1"?"Profile Updatede":"Updation Pending",
//                                $value->batch_id,
//                                $value->graduation_status,
//                                $value->gender,
//                                $value->age,
//                                $value->mobile_phone_number,
//                                $value->qualification,
//                                $value->other_contact_number,
//                                $value->area]);
//            }
//            header('Content-Type: application/csv');    
//            header('Content-Disposition: attachment; filename="training.csv"');
//            readfile('traning_report.csv');
//            exit;


//-------

//        if(isset($_GET['is_csv']) && file_exists("temp_dataprovider")){
//            $temp_dataprovider = unserialize(file_get_contents("temp_dataprovider"));
//            
//            \app\modules\export\models\ExportInd::checkAndDownloadCsv(
//                    [
//                        ["attribute"=>"id",'label'=>"Id"],
//                        ["attribute"=>"name",'label'=>"Name"],
//                        ["attribute"=>"attendance_in_percentage",'label'=>"Attendance in percentage"],
//                        ["attribute"=>"profile_status",'label'=>"Profile Status",
//                            "content"=>function($data){
//                                return $data->profile_status=="1"?"Profile Updatede":"Updation Pending";
//                            }],
//                        ["attribute"=>"batch_id",'label'=>"Batch"],
//                        ["attribute"=>"graduation_status",'label'=>"Training Status"],
//                        ["attribute"=>"gender",'label'=>"Gender"],
//                        ["attribute"=>"age",'label'=>"Age"],
//                        ["attribute"=>"mobile_phone_number",'label'=>"Contact No"],
//                        ["attribute"=>"qualification",'label'=>"Qualification"],
//                        ["attribute"=>"other_contact_number",'label'=>"Alternate Contact No"],
//                        ["attribute"=>"area",'label'=>"Area"]
//                    ]
//                    , $temp_dataprovider);
//            
//        }
        