<?php

namespace app\modules\v1\controllers;

use Yii;
use app\modules\v1\models\Config;
use app\modules\v1\models\Handlers;
use yii\web\Controller;
use app\models\NewRequest;
use app\models\FgQcCheck;
use app\models\FgCheckResult;
use app\models\FgQcCheckMapper;
use app\models\QcCheckPhyChemical;

class FgQcCheckController extends ApiController {
  
  
    public function actionCreate() {
        $post = Yii::$app->request->post();
        $this->keepLogActionWise(json_encode(["post" => $post, "file" => $_FILES]), TRUE, FALSE);
        Yii::$app->response->statusCode = 400;
        if (!isset($post["unique_id"]) || empty($post["unique_id"])) {
            $return = [
                'success' => FALSE,
                'status' => 400,
                'message' => "Unique Id is required"
            ];
            $this->keepLogActionWise(json_encode($return), false, true);
            return $return;
        } 

        $model = $this->getModel($post['unique_id']);
        $mages = $model->photo;
        $fgQcCheck["FgQcCheck"] = $post;
        $model->entry_type = "MOBILE";
        $model->updated_at = strtotime("now");
         
        if ($model->load($fgQcCheck)) {
            $user_id = $this->user; 
            $model->user_id = $user_id->id;
            $model->rpc_center_id = $user_id->rpc_id;
            if(isset($_FILES) && !empty($_FILES)){
                 $model = \Yii::$app->fileupload->uploadApiFile($model,FALSE,TRUE);
                }else{
                 $model->photo =  $mages;
            }

            if($post['status'] != '1')
            {
              $validn = false; 
              if(empty($model->fgqc_date) || is_null($model->fgqc_date))
              {
               $model->fgqc_date = '0000-00-00 00:00:00';
             }
            }else{
              $validn = true;
              if($model->fgqc_date == '0000-00-00 00:00:00')
              {
               $model->fgqc_date = '';
             }
           }
           
            if ($model->save()) {
                $this->result_fg_qc_check($post,$model->id);
                Yii::$app->response->statusCode = 200;
                $return = [
                    'success' => TRUE,
                    'status' => 200,
                    'message' => "Operation performed successfully",
                    "unique_id" => $model->unique_id
                ];
                $this->keepLogActionWise(json_encode($return), false, true);
                return $return;
            } else {
                $return = [
                    'success' => FALSE,
                    'status' => 400,
                    'message' => "Got error while saving",
                    "ERROR" => $model->getErrors()
                ];
                $this->keepLogActionWise(json_encode($return), false, true);
                return $return;
            }
        } else {
            $return = [
                'success' => TRUE,
                'status' => FALSE,
                'message' => "Got error while loading model",
                "ERROR" => $model->getErrors()
            ];
            $this->keepLogActionWise(json_encode($return), false, true);
            return $return;
        }
    }

   function result_fg_qc_check($post,$id){

        if(isset($post['result_qc_check']) && $post['result_qc_check'] !=""){
          foreach (FgCheckResult::find()->where("fg_qc_check_id='".$id."'")->all() as $row)
         {
            $row->delete();
         }
             $resultQcM = FgCheckResult::find()->where(['fg_qc_check_id'=>$id])->all();
             if(!$resultQcM){
                $resultQcCheck = json_decode($this->cleanJsonString($post['result_qc_check']),true);
                    foreach ($resultQcCheck as $value){
                      $parameter_id = QcCheckPhyChemical::find()->where(['product_id'=>$post['product_id']])->andWhere(['type'=>'FG QC Check'])->andWhere(['order_wise'=>$value['qc_parameter_id']])->one()->id;
                   
                      $resultQcCheck = new FgCheckResult();
                      $resultQcCheck->value = $value['value'];
                      $resultQcCheck->qc_parameter_id = $parameter_id;
                      $resultQcCheck->entry_type = "MOBILE";
                      $resultQcCheck->updated_at = strtotime("now");
                      $resultQcCheck->fg_qc_check_id = $id;
                      $resultQcCheck->save();
                    }
             }
        }
        if(isset($post['product_packing']) && $post['product_packing'] !=""){
             $fgMappertQcM = FgQcCheckMapper::find()->where(['fg_qc_uniq_id'=>$post['unique_id']])->all();
             if(!$fgMappertQcM){
                $fgQcCheck = json_decode($this->cleanJsonString($post['product_packing']),true);
                    foreach ($fgQcCheck as $value){
                      $fgQcCheck = new FgQcCheckMapper();
                      $fgQcCheck->fg_qc_uniq_id = $post['unique_id'];
                      $fgQcCheck->packed_weight = (String) $value['packed_weight'];
                      $fgQcCheck->packed_quantity = (String) $value['packed_quantity'];
                      $fgQcCheck->save();
                    }
             }
        }
   }

  function cleanJsonString($jsonStr){
      $len = strlen($jsonStr);
      if($len > 0){
        if( 
          ($jsonStr[0] == '"' || $jsonStr[0] == "'") 
          && 
          ($jsonStr[($len - 1)] == '"' || $jsonStr[($len - 1)] == "'") 
        ){
          $jsonStr = substr_replace($jsonStr,"",0,1);
          $len = strlen($jsonStr);
          $jsonStr = substr_replace($jsonStr,"",($len - 1),1);
        }
      }
      return $jsonStr; 
 }


    //END OF API: Function to insert New Request ...

    protected function getModel($unique_id) {
        $model = FgQcCheck::find()->where(["unique_id" => $unique_id])->one();
        return $model ? $model : new FgQcCheck();
    }
    


    //START OF API: Function to View/Get Beneficiary Record
    public function actionView() {
        Yii::$app->response->statusCode = 200;
        $return = [
            'success' => TRUE,
            'status' => 200,
            'message' => "Data fetched",
            "data" => $this->getIncomingQcCheckData(),
            "timestamp" => strtotime("now")
        ];
        return $return;
    }
    //END OF API: Function to View/Get Beneficiary Record
    
  
    
    //Get Beneficiary Data ...
    protected function getIncomingQcCheckData(){

        $user_id = $this->user; 
        $logginUser = $user_id->id;
        $select = ["*"];
        $incomingQcCheck = FgQcCheck::find()->select($select);
       
        if($this->headerTimestamp){
            $condition = [">","updated_at", intval($this->headerTimestamp)];
            $incomingQcCheck = $incomingQcCheck->where($condition);
        }
        $data = $incomingQcCheck->andWhere(['rpc_center_id'=>$user_id->rpc_id])->asArray()->all();
        
        $result = [];
         if($data){
           foreach ($data as  $value) {
              $result[] = [
              'quantity_taken'=>$this->fgCheckResult($value['id']),
              'product_packing'=>$this->product_packing($value['unique_id']),
              'unique_id'=>$value['unique_id'],
              'qc_check_uniq_id'=>$value['qc_check_uniq_id'],
              'cleaning_uniq_id'=>$value['cleaning_uniq_id'],
              'batch_Id'=>$value['batch_Id'],
              'product_id'=>$value['product_id'],
              'overall_status'=>$value['overall_status'],
              'status'=>$value['status'],
              'created_at'=>$value['created_at'],
              'overall_status' =>$value['overall_status'],
              'fgqc_date' =>$value['fgqc_date'],
              'updated_at' =>$value['updated_at'],
              'latitude' =>$value['latitude'],
              'logtitude' =>$value['logtitude']
               ];
           }
       }
        return $result; 
     }

      function fgCheckResult($id){
        $fgCheckResultQcM = FgCheckResult::find()->select(['qc_parameter_id','value'])->where(['fg_qc_check_id'=>$id])->all();
        $result = [];
        if($fgCheckResultQcM){
           foreach ($fgCheckResultQcM as $value) {
             $result[] = [
                 'qc_parameter_id'=>$this->findOrder($value['qc_parameter_id']),
                 'value'=>$value['value'],
                 ];
           }  
        } 
        return $result;
      }

      function findOrder($parm_id){
       $orderM = QcCheckPhyChemical::find()->select(['order_wise'])->where(['id'=>$parm_id])->andWhere(['type'=>'FG QC Check'])->one();
       return $orderM ? $orderM->order_wise :""; 
   }

      function product_packing($uniqid){
        $productPackingQcM = FgQcCheckMapper::find()->select(['fg_qc_uniq_id','packed_weight','packed_quantity'])->where(['fg_qc_uniq_id'=>$uniqid])->all();
        if(!$productPackingQcM){
          $productPackingQcM = [];
        }
        return $productPackingQcM;
      }
}
