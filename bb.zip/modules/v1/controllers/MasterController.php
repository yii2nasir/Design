<?php

namespace app\modules\v1\controllers;

use Yii;
use app\modules\v1\models\Config;
use app\modules\v1\models\Handlers;
use yii\web\Controller;
use app\models\Product;
use app\models\Supplier;
use app\models\QcCheckPhyChemical;


class MasterController extends ApiController {
    public function actionProduct() {
        Yii::$app->response->statusCode = 200;
        $return = [
            'success' => TRUE,
            'status' => 200,
            'message' => "Data fetched",
            "data" => $this->getProduct(),
            "timestamp" => strtotime("now")
        ];
        return $return;
    } 
    protected function getProduct() {
        $model = Product::find()->select(['id','name','code'])->all();
        return $model ? $model : [];
    }
     public function actionViewQcPhysiacalChemical() {
        Yii::$app->response->statusCode = 200;
        $return = [
            'success' => TRUE,
            'status' => 200,
            'message' => "Data fetched",
            "data" => $this->ViewQcPhysiacalChemical(),
            "timestamp" => strtotime("now")
        ];
        return $return;
    } 


    protected function ViewQcPhysiacalChemical() {
        $query = new \yii\db\Query;
        $select=('`product`.`id` AS `product_ids`,
            `product`.`name` AS `product_name`,
            `qc_check_phy_chemical`.`id`,
            `qc_check_phy_chemical`.`type`,
            `qc_check_phy_chemical`.`nature`,
            `qc_check_phy_chemical`.`category`,
            `qc_check_phy_chemical`.`name`,
            `qc_check_phy_chemical`.`option_1`,
            `qc_check_phy_chemical`.`option_2`,
            `qc_check_phy_chemical`.`option_3`,
            `qc_check_phy_chemical`.`option_4`,
            `qc_check_phy_chemical`.`order_wise`,
            `qc_check_phy_chemical`.`mandatory`,
            `qc_check_phy_chemical`.`expected_answer`,
            `qc_check_phy_chemical`.`product_id`,
            `qc_check_phy_chemical`.`updated_at`');
        $query->select($select)
                ->from('qc_check_phy_chemical')
                ->innerjoin('product','product.id=qc_check_phy_chemical.product_id')
                ->where('qc_check_phy_chemical.type ="Incoming"')
                ->andWhere('qc_check_phy_chemical.category!="6"')
                // ->andWhere('qc_check_phy_chemical.category!="7"')
                 ->orderBy(['qc_check_phy_chemical.product_id' => SORT_ASC,'qc_check_phy_chemical.order_wise' => SORT_ASC]);
                 
            // echo $query->createCommand()->getRawSql();exit;

        $qccheck_res=$query->createCommand()->queryAll();
        $productArray = [];
        $mainArray = [];
        // $i = 0;
        foreach ($qccheck_res as $value) {
            if(!in_array($value['product_id'], $productArray)){
                $i = 0;
                $mainArray[$value['product_id']]['product_id'] = $value['product_ids'];
                $mainArray[$value['product_id']]['product_name'] = $value['product_name'];
                $mainArray[$value['product_id']]['question'][$i]['product_id']=$value['product_id'];
                $mainArray[$value['product_id']]['question'][$i]['question_id'] = $value['id'];
                $mainArray[$value['product_id']]['question'][$i]['type'] = $value['type'];
                $mainArray[$value['product_id']]['question'][$i]['nature'] = $value['nature'];
                $mainArray[$value['product_id']]['question'][$i]['input_type'] = $value['category'];
                $mainArray[$value['product_id']]['question'][$i]['name'] = $value['name'];
                $mainArray[$value['product_id']]['question'][$i]['option_1'] = $value['option_1'];
                $mainArray[$value['product_id']]['question'][$i]['option_2'] = $value['option_2'];
                $mainArray[$value['product_id']]['question'][$i]['option_3'] = $value['option_3'];
                $mainArray[$value['product_id']]['question'][$i]['option_4'] = $value['option_4'];
                $mainArray[$value['product_id']]['question'][$i]['order_wise']=$value['order_wise'];
                $mainArray[$value['product_id']]['question'][$i]['mandatory'] = $value['mandatory'];
                $mainArray[$value['product_id']]['question'][$i]['expected_answer'] = $value['expected_answer'];
              //  $mainArray[$value['product_id']]['question'][$i]['updated_at'] = $value['updated_at'];
               $productArray [] = $value['product_id'];   

            }else{
                if(in_array($value['product_id'], $productArray)){
                 $i++;
                }
                $mainArray[$value['product_id']]['question'][$i]['product_id']=$value['product_ids'];
                $mainArray[$value['product_id']]['question'][$i]['question_id'] = $value['id'];
                $mainArray[$value['product_id']]['question'][$i]['type'] = $value['type'];
                $mainArray[$value['product_id']]['question'][$i]['nature'] = $value['nature'];
                $mainArray[$value['product_id']]['question'][$i]['input_type'] = $value['category'];
                $mainArray[$value['product_id']]['question'][$i]['name'] = $value['name'];
                $mainArray[$value['product_id']]['question'][$i]['option_1'] = $value['option_1'];
                $mainArray[$value['product_id']]['question'][$i]['option_2'] = $value['option_2'];
                $mainArray[$value['product_id']]['question'][$i]['option_3'] = $value['option_3'];
                $mainArray[$value['product_id']]['question'][$i]['option_4'] = $value['option_4'];
                $mainArray[$value['product_id']]['question'][$i]['order_wise']=$value['order_wise'];
                $mainArray[$value['product_id']]['question'][$i]['mandatory'] = $value['mandatory'];
                $mainArray[$value['product_id']]['question'][$i]['expected_answer'] = $value['expected_answer'];
               // $mainArray[$value['product_id']]['question'][$i]['updated_at'] = $value['updated_at'];

            }
        }   
        return array_values($mainArray);
    }
    

    public function actionViewCleaningQues() {
        Yii::$app->response->statusCode = 200;
        $return = [
            'success' => TRUE,
            'status' => 200,
            'message' => "Data fetched",
            "data" => $this->cleaning_view(),
            "timestamp" => strtotime("now")
        ];
        return $return;
    } 

    protected function cleaning_view() {
        // $model = QcCheckPhyChemical::find()->select(['id','type','nature','category','name','option_1','option_2','option_3','option_4','order_wise','mandatory','status'])->where(['type'=>'FG QC Check'])->all();
        // return $model ? $model : [];
        $rpc_id = ApiController::findInToken('rpc_id');
         $query = new \yii\db\Query;
        $select=('`product`.`id` AS `product_ids`,
            `product`.`name` AS `product_name`,
            `qc_check_phy_chemical`.`id`,
            `qc_check_phy_chemical`.`type`,
            `qc_check_phy_chemical`.`nature`,
            `qc_check_phy_chemical`.`category`,
            `qc_check_phy_chemical`.`name`,
            `qc_check_phy_chemical`.`option_1`,
            `qc_check_phy_chemical`.`option_2`,
            `qc_check_phy_chemical`.`option_3`,
            `qc_check_phy_chemical`.`option_4`,
            `qc_check_phy_chemical`.`order_wise`,
            `qc_check_phy_chemical`.`mandatory`,
            `qc_check_phy_chemical`.`expected_answer`,
            `qc_check_phy_chemical`.`product_id`,
             `qc_check_phy_chemical`.`is_editable`,
            `qc_check_phy_chemical`.`updated_at`');
        $query->select($select)
              ->from('qc_check_phy_chemical')
              ->innerjoin('product','product.id=qc_check_phy_chemical.product_id')
              ->innerjoin('cleaning_rpc_mapper','cleaning_rpc_mapper.qc_parameter = qc_check_phy_chemical.id')
              ->where('qc_check_phy_chemical.type ="Processing"')
              ->andWhere(['like','cleaning_rpc_mapper.rpc_id',",".$rpc_id.","])
              ->orderBy(['qc_check_phy_chemical.product_id' => SORT_ASC,'qc_check_phy_chemical.order_wise' => SORT_ASC]);


        // if($this->headerTimestamp){

        //     $condition = [">","updated_at", intval($this->headerTimestamp)];
        //      $query->where($condition);
        // }
              // ->orderby('updated_at desc');
        $qccheck_res=$query->createCommand()->queryAll();
        $productArray = [];
        $mainArray = [];
        // $i = 0;
        foreach ($qccheck_res as $value) {
            if(!in_array($value['product_id'], $productArray)){
                $i = 0;
                $mainArray[$value['product_id']]['product_id'] = $value['product_ids'];
                $mainArray[$value['product_id']]['product_name'] = $value['product_name'];
                $mainArray[$value['product_id']]['question'][$i]['product_id']=$value['product_id'];
                $mainArray[$value['product_id']]['question'][$i]['question_id'] = $value['id'];
                $mainArray[$value['product_id']]['question'][$i]['type'] = $value['type'];
                $mainArray[$value['product_id']]['question'][$i]['nature'] = $value['nature'];
                $mainArray[$value['product_id']]['question'][$i]['input_type'] = $value['category'];
                $mainArray[$value['product_id']]['question'][$i]['name'] = $value['name'];
                $mainArray[$value['product_id']]['question'][$i]['option_1'] = $value['option_1'];
                $mainArray[$value['product_id']]['question'][$i]['option_2'] = $value['option_2'];
                $mainArray[$value['product_id']]['question'][$i]['option_3'] = $value['option_3'];
                $mainArray[$value['product_id']]['question'][$i]['option_4'] = $value['option_4'];
                $mainArray[$value['product_id']]['question'][$i]['order_wise']=$value['order_wise'];
                $mainArray[$value['product_id']]['question'][$i]['mandatory'] = $value['mandatory'];
                $mainArray[$value['product_id']]['question'][$i]['expected_answer'] = $value['expected_answer'];
                $mainArray[$value['product_id']]['question'][$i]['is_editable'] = $value['is_editable'];
              //  $mainArray[$value['product_id']]['question'][$i]['updated_at'] = $value['updated_at'];
               $productArray [] = $value['product_id'];   

            }else{
                if(in_array($value['product_id'], $productArray)){
                 $i++;
                }
                $mainArray[$value['product_id']]['question'][$i]['product_id']=$value['product_ids'];
                $mainArray[$value['product_id']]['question'][$i]['question_id'] = $value['id'];
                $mainArray[$value['product_id']]['question'][$i]['type'] = $value['type'];
                $mainArray[$value['product_id']]['question'][$i]['nature'] = $value['nature'];
                $mainArray[$value['product_id']]['question'][$i]['input_type'] = $value['category'];
                $mainArray[$value['product_id']]['question'][$i]['name'] = $value['name'];
                $mainArray[$value['product_id']]['question'][$i]['option_1'] = $value['option_1'];
                $mainArray[$value['product_id']]['question'][$i]['option_2'] = $value['option_2'];
                $mainArray[$value['product_id']]['question'][$i]['option_3'] = $value['option_3'];
                $mainArray[$value['product_id']]['question'][$i]['option_4'] = $value['option_4'];
                $mainArray[$value['product_id']]['question'][$i]['order_wise']=$value['order_wise'];
                $mainArray[$value['product_id']]['question'][$i]['mandatory'] = $value['mandatory'];
                $mainArray[$value['product_id']]['question'][$i]['expected_answer'] = $value['expected_answer'];
                $mainArray[$value['product_id']]['question'][$i]['is_editable'] = $value['is_editable'];
               // $mainArray[$value['product_id']]['question'][$i]['updated_at'] = $value['updated_at'];

            }
        }   
        return array_values($mainArray);
    }


    public function actionViewFgQcCheck() {
        Yii::$app->response->statusCode = 200;
        $return = [
            'success' => TRUE,
            'status' => 200,
            'message' => "Data fetched",
            "data" => $this->fgQcPhysiacalChemical(),
            "timestamp" => strtotime("now")
        ];
        return $return;
    } 

    protected function fgQcPhysiacalChemical() {
        // $model = QcCheckPhyChemical::find()->select(['id','type','nature','category','name','option_1','option_2','option_3','option_4','order_wise','mandatory','status'])->where(['type'=>'FG QC Check'])->all();
        // return $model ? $model : [];
         $query = new \yii\db\Query;
        $select=('`product`.`id` AS `product_ids`,
            `product`.`name` AS `product_name`,
            `qc_check_phy_chemical`.`id`,
            `qc_check_phy_chemical`.`type`,
            `qc_check_phy_chemical`.`nature`,
            `qc_check_phy_chemical`.`category`,
            `qc_check_phy_chemical`.`name`,
            `qc_check_phy_chemical`.`option_1`,
            `qc_check_phy_chemical`.`option_2`,
            `qc_check_phy_chemical`.`option_3`,
            `qc_check_phy_chemical`.`option_4`,
            `qc_check_phy_chemical`.`order_wise`,
            `qc_check_phy_chemical`.`mandatory`,
            `qc_check_phy_chemical`.`expected_answer`,
            `qc_check_phy_chemical`.`product_id`,
             `qc_check_phy_chemical`.`is_editable`,
            `qc_check_phy_chemical`.`updated_at`');
        $query->select($select)
              ->from('qc_check_phy_chemical')
              ->innerjoin('product','product.id=qc_check_phy_chemical.product_id')
              ->where('qc_check_phy_chemical.type ="FG QC Check"')
              ->andWhere('qc_check_phy_chemical.category!="6"')
              ->andWhere('qc_check_phy_chemical.category!="7"')
              ->orderBy(['qc_check_phy_chemical.product_id' => SORT_ASC,'qc_check_phy_chemical.order_wise' => SORT_ASC]);


        // if($this->headerTimestamp){

        //     $condition = [">","updated_at", intval($this->headerTimestamp)];
        //      $query->where($condition);
        // }
              // ->orderby('updated_at desc');
        $qccheck_res=$query->createCommand()->queryAll();
        $productArray = [];
        $mainArray = [];
        // $i = 0;
        foreach ($qccheck_res as $value) {
            if(!in_array($value['product_id'], $productArray)){
                $i = 0;
                $mainArray[$value['product_id']]['product_id'] = $value['product_ids'];
                $mainArray[$value['product_id']]['product_name'] = $value['product_name'];
                $mainArray[$value['product_id']]['question'][$i]['product_id']=$value['product_id'];
                $mainArray[$value['product_id']]['question'][$i]['question_id'] = $value['id'];
                $mainArray[$value['product_id']]['question'][$i]['type'] = $value['type'];
                $mainArray[$value['product_id']]['question'][$i]['nature'] = $value['nature'];
                $mainArray[$value['product_id']]['question'][$i]['input_type'] = $value['category'];
                $mainArray[$value['product_id']]['question'][$i]['name'] = $value['name'];
                $mainArray[$value['product_id']]['question'][$i]['option_1'] = $value['option_1'];
                $mainArray[$value['product_id']]['question'][$i]['option_2'] = $value['option_2'];
                $mainArray[$value['product_id']]['question'][$i]['option_3'] = $value['option_3'];
                $mainArray[$value['product_id']]['question'][$i]['option_4'] = $value['option_4'];
                $mainArray[$value['product_id']]['question'][$i]['order_wise']=$value['order_wise'];
                $mainArray[$value['product_id']]['question'][$i]['mandatory'] = $value['mandatory'];
                $mainArray[$value['product_id']]['question'][$i]['expected_answer'] = $value['expected_answer'];
                $mainArray[$value['product_id']]['question'][$i]['is_editable'] = $value['is_editable'];
              //  $mainArray[$value['product_id']]['question'][$i]['updated_at'] = $value['updated_at'];
               $productArray [] = $value['product_id'];   

            }else{
                if(in_array($value['product_id'], $productArray)){
                 $i++;
                }
                $mainArray[$value['product_id']]['question'][$i]['product_id']=$value['product_ids'];
                $mainArray[$value['product_id']]['question'][$i]['question_id'] = $value['id'];
                $mainArray[$value['product_id']]['question'][$i]['type'] = $value['type'];
                $mainArray[$value['product_id']]['question'][$i]['nature'] = $value['nature'];
                $mainArray[$value['product_id']]['question'][$i]['input_type'] = $value['category'];
                $mainArray[$value['product_id']]['question'][$i]['name'] = $value['name'];
                $mainArray[$value['product_id']]['question'][$i]['option_1'] = $value['option_1'];
                $mainArray[$value['product_id']]['question'][$i]['option_2'] = $value['option_2'];
                $mainArray[$value['product_id']]['question'][$i]['option_3'] = $value['option_3'];
                $mainArray[$value['product_id']]['question'][$i]['option_4'] = $value['option_4'];
                $mainArray[$value['product_id']]['question'][$i]['order_wise']=$value['order_wise'];
                $mainArray[$value['product_id']]['question'][$i]['mandatory'] = $value['mandatory'];
                $mainArray[$value['product_id']]['question'][$i]['expected_answer'] = $value['expected_answer'];
                $mainArray[$value['product_id']]['question'][$i]['is_editable'] = $value['is_editable'];
               // $mainArray[$value['product_id']]['question'][$i]['updated_at'] = $value['updated_at'];

            }
        }   
        return array_values($mainArray);
    }


}
