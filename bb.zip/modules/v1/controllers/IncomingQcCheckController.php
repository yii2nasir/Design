<?php

namespace app\modules\v1\controllers;

use Yii;
use app\modules\v1\models\Config;
use app\modules\v1\models\Handlers;
use yii\web\Controller;
use app\models\NewRequest;
use app\models\IncomingQcCheck;
use app\models\ResultQcCheck;
use app\models\QcCheckPhyChemical;
use yii\helpers\Url;
class IncomingQcCheckController extends ApiController {
   public function actionCreate() {
      $post = Yii::$app->request->post();
      $this->keepLogActionWise(json_encode(["post" => $post, "file" => $_FILES]), TRUE, FALSE);
      Yii::$app->response->statusCode = 400;
      if (!isset($post["unique_id"]) || empty($post["unique_id"])) {
         $return = [
            'success' => FALSE,
            'status' => 400,
            'message' => "Unique Id is required"
         ];
         $this->keepLogActionWise(json_encode($return), false, true);
         return $return;
      } 

      $model = $this->getModel($post['unique_id']);
      $mages = $model->product_image;
      $IncomingQcCheck["IncomingQcCheck"] = $post;
      $model->entry_type = "MOBILE";
      $model->updated_at = strtotime("now");
      
      if ($model->load($IncomingQcCheck)) {
         $model->user_id = $this->user->id;
         $model->rpc_center_id = $this->user->rpc_id;
         if(isset($_FILES) && !empty($_FILES)){
            $model = \Yii::$app->fileupload->uploadApiFile($model,FALSE,TRUE);
         }else{
            $model->product_image =  $mages;
         }

         if($post['status'] != '1')
         {
            $validn = false;
            if(empty($model->incoming_date) || is_null($model->incoming_date))
            {
               $model->incoming_date = '0000-00-00 00:00:00';
            }
         }else{
            $validn = true;
            if($model->incoming_date == '0000-00-00 00:00:00')
            {
               $model->incoming_date = '';
            }
         }

         if ($model->save($validn)) {

            $this->result_qc_check($post,$model->id);
            Yii::$app->response->statusCode = 200;
            $return = [
               'success' => TRUE,
               'status' => 200,
               'message' => "Operation performed successfully",
               "unique_id" => $model->unique_id
            ];
            $this->keepLogActionWise(json_encode($return), false, true);
            return $return;
         } else {
            $return = [
               'success' => FALSE,
               'status' => 400,
               'message' => "Got error while saving",
               "ERROR" => $model->getErrors()
            ];
            $this->keepLogActionWise(json_encode($return), false, true);
            return $return;
         }
      } else {
         $return = [
            'success' => TRUE,
            'status' => FALSE,
            'message' => "Got error while loading model",
            "ERROR" => $model->getErrors()
         ];
         $this->keepLogActionWise(json_encode($return), false, true);
         return $return;
      }
   }

   function result_qc_check($post,$id){
      if(isset($post['result_qc_check']) && $post['result_qc_check'] !="")
      {

         foreach (ResultQcCheck::find()->where("qc_check_id='".$id."'")->all() as $row)
         {
            $row->delete();
         }
         $resultQcM = ResultQcCheck::find()->where(['qc_check_id'=>$id])->all();
         if(!$resultQcM){
            $resultQcCheck = json_decode($this->cleanJsonString($post['result_qc_check']),true);
            foreach ($resultQcCheck as $value){
               $parameter_id = QcCheckPhyChemical::find()->where(['product_id'=>$post['product_id']])->andWhere(['type'=>'Incoming'])->andWhere(['order_wise'=>$value['id']])->one()->id;
               $resultQcCheck = new ResultQcCheck();
               $resultQcCheck->value = $value['value'];
               $resultQcCheck->qc_parameter_id = $parameter_id;
               $resultQcCheck->entry_type = "MOBILE";
               $resultQcCheck->updated_at = strtotime("now");
               $resultQcCheck->qc_check_id = $id;
               $resultQcCheck->unique_id = uniqid();
               $resultQcCheck->save();
            }
         }
      }
   }

   function cleanJsonString($jsonStr){
      $len = strlen($jsonStr);
      if($len > 0){
         if( 
            ($jsonStr[0] == '"' || $jsonStr[0] == "'") 
            && 
            ($jsonStr[($len - 1)] == '"' || $jsonStr[($len - 1)] == "'") 
         ){
            $jsonStr = substr_replace($jsonStr,"",0,1);
            $len = strlen($jsonStr);
            $jsonStr = substr_replace($jsonStr,"",($len - 1),1);
         }
      }
      return $jsonStr; 
   }


//END OF API: Function to insert New Request ...

   protected function getModel($unique_id) {
      $model = IncomingQcCheck::find()->where(["unique_id" => $unique_id])->one();
      return $model ? $model : new IncomingQcCheck();
   }



//START OF API: Function to View/Get Beneficiary Record
   public function actionView() {
      Yii::$app->response->statusCode = 200;
      $return = [
         'success' => TRUE,
         'status' => 200,
         'message' => "Data fetched",
         "data" => $this->getIncomingQcCheckData(),
         "timestamp" => strtotime("now")
      ];
      return $return;
   }
//END OF API: Function to View/Get Beneficiary Record



//Get Beneficiary Data ...
   protected function getIncomingQcCheckData(){
      $user_id = $this->user; 
      $logginUser = $user_id->id;
      $select = ["*"];
      $incomingQcCheck = IncomingQcCheck::find()->select($select);
      if($this->headerTimestamp){
         $condition = [">","updated_at", intval($this->headerTimestamp)];
         $incomingQcCheck = $incomingQcCheck->where($condition);
      }
      $data = $incomingQcCheck->andWhere(['rpc_center_id'=>$user_id->rpc_id])->asArray()->all();
      $i = 0;
      foreach ($data as $value) {
         $data[$i]['qCanswerList'] = $this->qcCheckResult($value['id']);
         if($value['product_image'] !=""){
            $url =  "http://" . $_SERVER['SERVER_NAME'].Url::base()."/images/incoming-qc-check/";
            $data[$i]['product_image'] =   $url.$value['product_image'];
         }else{
            $data[$i]['product_image'] = $value['product_image'] = "";
         }
         $data[$i]['incoming_date'] = $value['incoming_date'];

         $i++;
      }        
      if($data){
         $incomingData = $data;
      }else{
         $incomingData = [];
      }
      return $incomingData;
   }

   function qcCheckResult($id){
         // echo $id;
         // exit;
        $incomingQcResultQcM = ResultQcCheck::find()->select(['qc_parameter_id','value'])->where(['qc_check_id'=>$id])->all();
       // print_r($incomingQcResultQcM);
       // exit;
        $result = [];
        if($incomingQcResultQcM){
           foreach ($incomingQcResultQcM as $value) {
             $result[] = [
                 'id'=>$this->findOrder($value['qc_parameter_id']),
                 'value'=>$value['value'],
                 ];
           }  
        } 
        return $result;
   }

   function findOrder($parm_id){
       $orderM = QcCheckPhyChemical::find()->select(['order_wise'])->where(['id'=>$parm_id])->andWhere(['type'=>'Incoming'])->one();
       return $orderM ? $orderM->order_wise :""; 
   }
}
