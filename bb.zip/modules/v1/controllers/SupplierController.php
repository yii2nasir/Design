<?php

namespace app\modules\v1\controllers;

use Yii;
use app\modules\v1\models\Config;
use app\modules\v1\models\Handlers;
use yii\web\Controller;
use app\models\Supplier;

class SupplierController extends ApiController {
    public function actionCreate() {
        $post = Yii::$app->request->post();
        $this->keepLogActionWise(json_encode(["post" => $post, "file" => $_FILES]), TRUE, FALSE);
        Yii::$app->response->statusCode = 400;
        if (!isset($post["unique_id"]) || empty($post["unique_id"])) {
            $return = [
                'success' => FALSE,
                'status' => 400,
                'message' => "Unique Id is required"
            ];
            $this->keepLogActionWise(json_encode($return), false, true);
            return $return;
        } 
        $post['name'] = $post['name']." ".(date('z') + 1);
        $model = $this->getModel($post['unique_id']);
        $supplierM["Supplier"] = $post;
        $model->entry_type = "MOBILE";
        $model->updated_at = strtotime("now");

        if ($model->load($supplierM)) {
            if ($model->save()) {
                Yii::$app->response->statusCode = 200;
                $return = [
                    'success' => TRUE,
                    'status' => 200,
                    'message' => "Operation performed successfully",
                    "unique_id" => $model->unique_id
                ];
                $this->keepLogActionWise(json_encode($return), false, true);
                return $return;
            } else {
                $return = [
                    'success' => FALSE,
                    'status' => 400,
                    'message' => "Got error while saving",
                    "ERROR" => $model->getErrors()
                ];
                $this->keepLogActionWise(json_encode($return), false, true);
                return $return;
            }
        } else {
            $return = [
                'success' => TRUE,
                'status' => FALSE,
                'message' => "Got error while loading model",
                "ERROR" => $model->getErrors()
            ];
            $this->keepLogActionWise(json_encode($return), false, true);
            return $return;
        }
    }

    //END OF API: Function to insert New Request ...

    protected function getModel($unique_id) {
        $model = Supplier::find()->where(["unique_id" => $unique_id])->one();
        return $model ? $model : new Supplier();
    }
  

    public function actionView() {
        Yii::$app->response->statusCode = 200;
        $return = [
            'success' => TRUE,
            'status' => 200,
            'message' => "Data fetched",
            "data" => $this->getSupplier(),
            "timestamp" => strtotime("now")
        ];
        return $return;
    } 

    protected function getSupplier() {
        $query = Supplier::find();

        // comment
        // if($this->headerTimestamp){
        //     $condition = [">","updated_at", intval($this->headerTimestamp)];
        //     $query->where($condition);
        // }
        $model= $query->all();
        return $model ? $model : [];
    }

}
