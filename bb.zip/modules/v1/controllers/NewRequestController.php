<?php

namespace app\modules\v1\controllers;

use Yii;
use app\modules\v1\models\Config;
use app\modules\v1\models\Handlers;
use yii\web\Controller;
use app\models\NewRequest;
use yii\helpers\Url;
class NewRequestController extends ApiController {
//START OF API: Function to insert Beneficiary ...
   public function actionCreate() {
      $post = Yii::$app->request->post();
      $this->keepLogActionWise(json_encode(["post" => $post, "file" => $_FILES]), TRUE, FALSE);
      Yii::$app->response->statusCode = 400;
      if (!isset($post["unique_id"]) || empty($post["unique_id"])) {
         $return = [
            'success' => FALSE,
            'status' => 400,
            'message' => "Unique Id is required"
         ];
         $this->keepLogActionWise(json_encode($return), false, true);
         return $return;
      } 
      if(isset($post['vehicle_inspection_checklist']) && $post['vehicle_inspection_checklist'] !=""){
         $post['vehicle_inspection_checklist'] = $this->cleanJsonString($post['vehicle_inspection_checklist']);
      }

      if(isset($post['product_id']) && $post['product_id'] !=""){
         $post['product_id'] = $this->cleanJsonString($post['product_id']);
      }

      $model = $this->getModel($post['unique_id']);

      $mages = $model->vehicle_image;
      $NewRequest = [];
      $NewRequest["NewRequest"] = $post;
      $model->entry_type = "MOBILE";
      $model->updated_at = strtotime("now");

      if ($model->load($NewRequest)) {
         $model->user_id = $this->user->id;
         $model->date = date("Y-m-d");
         $model->rpc_center_id = $this->user->rpc_id;
         if(isset($_FILES) && !empty($_FILES)){
            $model = \Yii::$app->fileupload->uploadApiFile($model,FALSE,TRUE);
         }else{

            $model->vehicle_image = $mages;
         }
         if($post['status'] != '1')
         {
            $validn = false;
            if(empty($model->vehicle_date) || is_null($model->vehicle_date))
            {
               $model->vehicle_date = '0000-00-00 00:00:00';
            }
         }else{
            $validn = true;
            if($model->vehicle_date == '0000-00-00 00:00:00')
            {
               $model->vehicle_date = '';
            }
         }
         if ($model->save($validn)) {
            Yii::$app->response->statusCode = 200;
            $return = [
               'success' => TRUE,
               'status' => 200,
               'message' => "Operation performed successfully",
               "unique_id" => $model->unique_id
            ];
            $this->keepLogActionWise(json_encode($return), false, true);
            return $return;
         } else {
            $return = [
               'success' => FALSE,
               'status' => 400,
               'message' => "Got error while saving",
               "ERROR" => $model->getErrors()
            ];
            $this->keepLogActionWise(json_encode($return), false, true);
            return $return;
         }
      } else {
         $return = [
            'success' => TRUE,
            'status' => FALSE,
            'message' => "Got error while loading model",
            "ERROR" => $model->getErrors()
         ];
         $this->keepLogActionWise(json_encode($return), false, true);
         return $return;
      }
   }


   function cleanJsonString($jsonStr){
      $len = strlen($jsonStr);
      if($len > 0){
         if( 
            ($jsonStr[0] == '"' || $jsonStr[0] == "'") 
            && 
            ($jsonStr[($len - 1)] == '"' || $jsonStr[($len - 1)] == "'") 
         ){
            $jsonStr = substr_replace($jsonStr,"",0,1);
            $len = strlen($jsonStr);
            $jsonStr = substr_replace($jsonStr,"",($len - 1),1);
         }
      }
      return $jsonStr; 
   }

//END OF API: Function to insert New Request ...

   protected function getModel($unique_id) {
      $model = NewRequest::find()->where(["unique_id" => $unique_id])->one();
      return $model ? $model : new NewRequest();
   }



//START OF API: Function to View/Get Beneficiary Record
   public function actionView() {
      Yii::$app->response->statusCode = 200;

      $return = [
         'success' => TRUE,
         'status' => 200,
         'message' => "Data fetched",
         "data" => $this->getNewRequestData(),
         "timestamp" => strtotime("now")
      ];
      return $return;
   }
//END OF API: Function to View/Get Beneficiary Record



//Get Beneficiary Data ...
   protected function getNewRequestData() {
      $user_id = $this->user; 
      $logginUser = $user_id->id;
      $select = ["*"];
      $newRequest = NewRequest::find()->select($select);
      if($this->headerTimestamp){
         $condition = [">","updated_at", intval($this->headerTimestamp)];
         $newRequest = $newRequest->where($condition);
      }
      $data = $newRequest->andWhere(['rpc_center_id'=>$user_id->rpc_id])->asArray()->all();
      $i = 0;
      if($data){
         foreach ($data as  $value) {
            if($value['vehicle_image'] !=""){
               $url =  "http://" . $_SERVER['SERVER_NAME'].Url::base()."/images/new-request/";
               $value['vehicle_image'] =  $url.$value['vehicle_image'];
            }else{
               $value['vehicle_image'] = "";
            }
            $data[$i]['vehicle_inspection_checklist'] = json_decode($value['vehicle_inspection_checklist']);
            $data[$i]['product_id'] = json_decode($value['product_id']);
            $data[$i]['vehicle_image'] = $value['vehicle_image'];
            $data[$i]['vehicle_date'] = $value['vehicle_date'];
            $i++;
         }
      }else{
         $data = [];
      }
      return $data;
   }
}
