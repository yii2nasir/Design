<?php

namespace app\modules\v1\controllers;

use Yii;
use app\models\CustomClasses\JWT;
use yii\base\ErrorException;
use \app\modules\v1\models\Users;

class ApiController extends \yii\web\Controller {

    public $enableCsrfValidation = false;
    public $user;
    public $headerTimestamp = false;
    public function beforeAction($action) {
        if ($action->id == "login") {
            return TRUE;
        }
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $header = Yii::$app->request->getHeaders();
        if (isset($header["token"]) > 0) {
            $tokenStatus = JWT::decode($header["token"], \Yii::$app->params["tokenSecret"]);
            if (isset($tokenStatus->http_status)) {
                header('Content-Type: application/json');
                header('WWW-Authenticate: Basic realm="Dhwaniris.com Authenticate"');
                header('HTTP/1.0 401 Unauthorized');
                http_response_code(401);
                echo json_encode(['success' => false, 'status' => 401, 'message' => $tokenStatus->msg]);
                exit;
            }
        } else {
            header('Content-Type: application/json');
            header('WWW-Authenticate: Token was required field');
            header('HTTP/1.0 401 Unauthorized');
            http_response_code(400);
            echo json_encode(['success' => false, 'status' => 400, 'message' => 'token is required']);
            exit;
        }

        if(isset($header['timestamp']) && !empty($header['timestamp'])){
            $this->headerTimestamp = $header['timestamp'];
        }
        $this->user = $tokenStatus;
        if (isset($header["version"]) && count($header["version"]) > 0) {
            $isChanged = $this->isAppVersionChanged($header["version"]);
            if ($isChanged) {
                $model = Users::find()->where(["id" => $this->user->id])->one();
                $model->scenario = Users::SCENARIO_VERSION;
                if ($model && $model->version != $header["version"]) {
                    $model->version = $header["version"];
                    $model->save();
                }
                $this->keepLogActionWise(json_encode($isChanged));
            }
        }
        return TRUE;
    }

    public function validateMethod($reqM, $method) {
        if (strtolower($reqM) != $method) {
            return [
                'success' => FALSE,
                'status' => 400,
                'message' => 'Method not allowd',
                "timestamp" => strtotime("now")
            ];
        } else {
            return FALSE;
        }
    }

    public function keepLogActionWise($string = "", $request = false, $response = false) {
        $logDir = '../web/logs/';
        $controller = \Yii::$app->controller->id;
        $action = \Yii::$app->controller->action->id;
        $controllerActionDir = $controller . "/" . $action;
        $uploads_dir = $logDir . $controllerActionDir . "/";
        if (!file_exists($uploads_dir)) {
            mkdir($uploads_dir, 0777, true);
        }
        if ($request && !empty($string)) {
            $dir = $uploads_dir . "request/" . date("d_m_Y") . "/";
            $file = $dir . $this->getUserId() . '.txt';
            if (!file_exists($dir)) {
                mkdir($dir, 0777, true);
            }
            file_put_contents($file, ' REQUESTBODY [' . date("Y:m:d H:m:s") . '] | ' . $string . "\n" . PHP_EOL, FILE_APPEND | LOCK_EX);
        }
        if ($response && !empty($string)) {
            $dir = $uploads_dir . "response/" . date("d_m_Y") . "/";
            $file = $dir . $this->getUserId() . '.txt';
            if (!file_exists($dir)) {
                mkdir($dir, 0777, true);
            }
            file_put_contents($file, ' RESPONSEBODY [' . date("Y:m:d H:m:s") . '] | ' . $string . "\n" . PHP_EOL, FILE_APPEND | LOCK_EX);
        }
        if (!empty($string)) {
            file_put_contents($logDir . 'log.txt', '[' . date("Y:m:d H:m:s") . '] | ' . $string . "\n" . PHP_EOL, FILE_APPEND | LOCK_EX);
        }
    }

    public function getUserId() {
        $request = \Yii::$app->request;
        $bodyParams = $request->getHeaders();
        if ($bodyParams['token'] != null) {
            $token = JWT::decode($bodyParams['token'], \Yii::$app->params["tokenSecret"]);
            return $token->id;
        }
        return FALSE;
    }

    public function findInToken($key) {
        $request = \Yii::$app->request;
        $bodyParams = $request->getHeaders();
        if ($bodyParams['token'] != null) {
            $token = JWT::decode($bodyParams['token'], \Yii::$app->params["tokenSecret"]);
            return $token->$key;
        }
        return FALSE;
    }

    public function uploaFile($model, $columnName) {
        $tmp_name = $_FILES["file"]["tmp_name"];
        $name = $_FILES["file"]["name"];
        $uploads_dir = \Yii::$app->params["imageBaseDir"];
        if (!file_exists($uploads_dir)) {
            mkdir($uploads_dir, 0777, true);
        }
        if (move_uploaded_file($tmp_name, $uploads_dir . $name)) {
            if ((!$model->isNewRecord ) && !is_null($model->$columnName) && !empty($model->$columnName) && $name != $model->$columnName && file_exists($uploads_dir . $model->$columnName)) {
                try {
                    unlink($uploads_dir . $model->$columnName);
                } catch (Exception $exc) {
                    echo $exc->getTraceAsString();
                }
            }// solve exception issues
            $model->$columnName = $name;
            return $model;
        } else {
            return FALSE;
        }
        return FALSE;
    }
    protected function findFileKey($files) {
        foreach ($files as $key => $names) {
            foreach ($names as $key => $name) {
                return $key;
            }
        }
    }

    protected function isKeyExist($key, $model) {
        foreach ($model as $name => $value) {
            if ($key == $name) {
                return TRUE;
            }
        }
        return FALSE;
    }
    public function getParams($param) {
        return \Yii::$app->params[$param];
    }
    public function isAppVersionChanged($param) {
        if($this->getParams("current_mobile_app_version") != $param){
            return [ $this->user->id => $this->user->id . " is on other(".$param.") version. current version is ".$this->getParams("current_mobile_app_version")];
        }
        return FALSE;
    }
    public function file($param) {
        try {

            // Undefined | Multiple Files | $_FILES Corruption Attack
            // If this request falls under any of them, treat it invalid.
            if (
                    !isset($_FILES['upfile']['error']) ||
                    is_array($_FILES['upfile']['error'])
            ) {
                throw new RuntimeException('Invalid parameters.');
            }

            // Check $_FILES['upfile']['error'] value.
            switch ($_FILES['upfile']['error']) {
                case UPLOAD_ERR_OK:
                    break;
                case UPLOAD_ERR_NO_FILE:
                    throw new RuntimeException('No file sent.');
                case UPLOAD_ERR_INI_SIZE:
                case UPLOAD_ERR_FORM_SIZE:
                    throw new RuntimeException('Exceeded filesize limit.');
                default:
                    throw new RuntimeException('Unknown errors.');
            }

            // You should also check filesize here. 
            if ($_FILES['upfile']['size'] > 1000000) {
                throw new RuntimeException('Exceeded filesize limit.');
            }

            // DO NOT TRUST $_FILES['upfile']['mime'] VALUE !!
            // Check MIME Type by yourself.
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            if (false === $ext = array_search(
                    $finfo->file($_FILES['upfile']['tmp_name']), array(
                'jpg' => 'image/jpeg',
                'png' => 'image/png',
                'gif' => 'image/gif',
                    ), true
                    )) {
                throw new RuntimeException('Invalid file format.');
            }

            // You should name it uniquely.
            // DO NOT USE $_FILES['upfile']['name'] WITHOUT ANY VALIDATION !!
            // On this example, obtain safe unique name from its binary data.
            if (!move_uploaded_file(
                            $_FILES['upfile']['tmp_name'], sprintf('./uploads/%s.%s', sha1_file($_FILES['upfile']['tmp_name']), $ext
                            )
                    )) {
                throw new RuntimeException('Failed to move uploaded file.');
            }

            echo 'File is uploaded successfully.';
        } catch (RuntimeException $e) {

            echo $e->getMessage();
        }
    }
    //Set null if any of key value not set to or passed empty value...
    public function setNullIfEmpty($body = []){
        foreach ($body as $key => $value) {
            if($value == ""){
                $body[$key] = NULL;
            }            
        }
        return $body;
    }

}