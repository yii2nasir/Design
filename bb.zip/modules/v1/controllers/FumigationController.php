<?php

namespace app\modules\v1\controllers;

use Yii;
use app\modules\v1\models\Config;
use app\modules\v1\models\Handlers;
use yii\web\Controller;
use app\models\Fumigation;
use app\models\FumigationMapper;
use app\models\IncomingQcCheck;
use app\models\FumigationType;
use yii\helpers\Url;

class FumigationController extends ApiController {

    public function actionCreate() {
        $post = Yii::$app->request->post();
        $this->keepLogActionWise(json_encode(["post" => $post, "file" => $_FILES]), TRUE, FALSE);
        Yii::$app->response->statusCode = 400;
        if (!isset($post["unique_id"]) || empty($post["unique_id"])) {
            $return = [
                'success' => FALSE,
                'status' => 400,
                'message' => "Unique Id is required"
            ];
            $this->keepLogActionWise(json_encode($return), false, true);
            return $return;
        } 

        $model = $this->getModel($post['unique_id']);
        $mages = $model->images;
        $fumigation["Fumigation"] = $post;
        $model->entry_type = "MOBILE";
        $model->updated_at = strtotime("now");
         
        if ($model->load($fumigation)) {
            $model->user_id = $this->user->id;
            $model->rpc_center_id = $this->user->rpc_id;
              if(isset($_FILES) && !empty($_FILES)){
                $model = \Yii::$app->fileupload->uploadApiFile($model,FALSE,TRUE);
              }else{
               $model->images =  $mages;
              }
              if($post['status'] != '1')
              {
                $validn = false; 
              }else{
                $validn = true;
              }
           
            if ($model->save($validn)) {
                $this->quantity_taken($post,$model->id);
                Yii::$app->response->statusCode = 200;
                $return = [
                    'success' => TRUE,
                    'status' => 200,
                    'message' => "Operation performed successfully",
                    "unique_id" => $model->unique_id
                ];
                $this->keepLogActionWise(json_encode($return), false, true);
                return $return;
            } else {
                $return = [
                    'success' => FALSE,
                    'status' => 400,
                    'message' => "Got error while saving",
                    "ERROR" => $model->getErrors()
                ];
                $this->keepLogActionWise(json_encode($return), false, true);
                return $return;
            }
        } else {
            $return = [
                'success' => TRUE,
                'status' => FALSE,
                'message' => "Got error while loading model",
                "ERROR" => $model->getErrors()
            ];
            $this->keepLogActionWise(json_encode($return), false, true);
            return $return;
        }
    }
    
function quantity_taken($post,$id){
        if(isset($post['quantity_taken']) && $post['quantity_taken'] !=""){
          
          foreach (FumigationMapper::find()->where("fumigation_id='".$id."'")->all() as $row)
           {
              $row->delete();
           }
             $resultQcM = FumigationMapper::find()->where(['fumigation_id'=>$id])->all();
             if(!$resultQcM){
                $quantityTaken = json_decode($this->cleanJsonString($post['quantity_taken']),true);
                    foreach ($quantityTaken as $value){
                      $quantityTaken = new FumigationMapper();
                      $quantityTaken->fumigation_id = $id;
                      $quantityTaken->product_id = $value['product_id'];
                      $quantityTaken->incoming_qc_uniq_id = $value['incoming_qc_uniq_id'];
                      $quantityTaken->batch_id = $value['batch_id'];
                      $quantityTaken->available_qty = $value['available_qty'];
                      $quantityTaken->quantity_value = $value['quantity_value'];
                      $quantityTaken->remaining_quantity = $value['remaining_quantity'];
                      $quantityTaken->fumigation_complete = $value['fumigation_complete'];
                      $quantityTaken->fumigation_unique_id = $value['fumigation_unique_id'];
                     if($quantityTaken->save()){
                          if($quantityTaken->remaining_quantity == 0){
                              $model = IncomingQcCheck::find()->where(['unique_id'=>$value['incoming_qc_uniq_id']])->one();
                               if($model){
                                  $model->fumigation_status = "Complete";
                                  $model->save();
                                }
                            }
                      }
                    }
             }
        }
}

  function cleanJsonString($jsonStr){
        $len = strlen($jsonStr);
        if($len > 0){
          if( 
            ($jsonStr[0] == '"' || $jsonStr[0] == "'") 
            && 
            ($jsonStr[($len - 1)] == '"' || $jsonStr[($len - 1)] == "'") 
          ){
            $jsonStr = substr_replace($jsonStr,"",0,1);
            $len = strlen($jsonStr);
            $jsonStr = substr_replace($jsonStr,"",($len - 1),1);
          }
        }
        return $jsonStr; 
   }


    //END OF API: Function to insert New Request ...

    protected function getModel($unique_id) {
        $model = Fumigation::find()->where(["unique_id" => $unique_id])->one();
        return $model ? $model : new Fumigation();
    }
    


    //START OF API: Function to View/Get Beneficiary Record
    public function actionView() {
        Yii::$app->response->statusCode = 200;
        $return = [
            'success' => TRUE,
            'status' => 200,
            'message' => "Data fetched",
            "data" => $this->getFumigation(),
            "timestamp" => strtotime("now")
        ];
        return $return;
    }
    //END OF API: Function to View/Get Beneficiary Record
    
  
    
    //Get Fumigation Data ...
    protected function getFumigation(){
      $user_id = $this->user; 
      $logginUser = $user_id->id;
      $query = new \yii\db\Query;
      $select=('`fumigation`.*,
                `fumigation_mapper`.`fumigation_id`,
                `fumigation_mapper`.`product_id`');
      $query->select($select)
            ->from('fumigation')
            ->innerjoin('fumigation_mapper','fumigation_mapper.fumigation_id=fumigation.id')   
            ->where('fumigation.rpc_center_id ='.$user_id->rpc_id);

        if($this->headerTimestamp){
            $condition = [">","updated_at", intval($this->headerTimestamp)];
            $query->andWhere($condition);
        }    
        $query->groupBy('fumigation.id');
        $data=$query->createCommand()->queryAll();

        $result = [];
         if($data){

           foreach ($data as  $value) {
             if($value['images'] !=""){
                  $url =  "http://" . $_SERVER['SERVER_NAME'].Url::base()."/images/fumigation/";
                  $value['images'] =  $url.$value['images'];
             }else{
               $value['images'] = "";
             }
              if($value['start_time']=="" || $value['start_time']=="NULL" ){$value['start_time']='';}
              if($value['end_time']=="" || $value['end_time']=="NULL" ){$value['end_time']='';}
              if($value['chemical_used']=="" || $value['chemical_used']=="NULL" ){$value['chemical_used']='';}
              if($value['qc_person_name']=="" || $value['qc_person_name']=="NULL" ){$value['qc_person_name']='';}
              if($value['fumigation_effective']=="" || $value['fumigation_effective']=="NULL" ){$value['fumigation_effective']='';}
              if($value['re_fumigate']=="" || $value['re_fumigate']=="NULL" ){$value['re_fumigate']='';}
              if($value['created_at']=="" || $value['created_at']=="NULL" ){$value['created_at']='';}
              if($value['overall_status']=="" || $value['overall_status']=="NULL" ){$value['overall_status']='';}
              if($value['updated_at']=="" || $value['updated_at']=="NULL" ){$value['updated_at']='';}
              if($value['latitude']=="" || $value['latitude']=="NULL" ){$value['latitude']='';}
              if($value['logtitude']=="" || $value['logtitude']=="NULL" ){$value['logtitude']='';}
              if($value['status']=="" || $value['status']=="NULL" ){$value['status']='';}
              if($value['fumigation_type']=="" || $value['fumigation_type']=="NULL" ){$value['fumigation_type']='';
            }
            $result[] = [
              'quantity_taken'=>$this->quantityTakenMapper($value['id']),
              'product_id'=>$value['product_id'],
              'unique_id'=>$value['unique_id'],
              'start_time'=>$value['start_time'],
              'end_time'=>$value['end_time'],
              'chemical_used'=>$value['chemical_used'],
              'qc_person_name'=>$value['qc_person_name'],
              'fumigation_effective'=>$value['fumigation_effective'],
              're_fumigate'=>$value['re_fumigate'],
              'created_at'=>$value['created_at'],
              'overall_status' =>$value['overall_status'],
              'images' =>$value['images'],
              'updated_at' =>$value['updated_at'],
              'latitude' =>$value['latitude'],
              'logtitude' =>$value['logtitude'],
              'status' =>$value['status'],
              'fumigation_type' =>$value['fumigation_type'],

               ];

           }
       }
        return $result;
     }

     function quantityTakenMapper($id){
        $fumigationQcM = FumigationMapper::find()->select(['id','fumigation_id','product_id','batch_id','available_qty','quantity_value','incoming_qc_uniq_id','remaining_quantity','fumigation_complete','fumigation_unique_id'])->where(['fumigation_id'=>$id])->all();
        if(!$fumigationQcM){
          $fumigationQcM = [];
        }
        return $fumigationQcM;
      }


/*fumigation type list */
    public function actionViewFumigationType() {
      Yii::$app->response->statusCode = 200;
      $return = [
          'success' => TRUE,
          'status' => 200,
          'message' => "Data fetched",
          "data" => $this->getFumigationtype(),
      ];
      return $return;
    } 
    
    //Get Fumigation Type Data ...
    protected function getFumigationtype()
    {
      $rpc_id = ApiController::findInToken('rpc_id');
      $rpc = '"'.$rpc_id.'"';
      $model = FumigationType::find()->select(['fumigation_type_id','fumigation_type_name','fumigation_days','product_ids'])
      ->where(['like','rpc_ids',$rpc])->all();
      if(COUNT($model) > 0)
      {
        foreach ($model as $key => $value) {
          if(!empty($value->product_ids))
          {
            $value->product_ids = json_decode($value->product_ids,true);
            $value->product_ids = implode(",", $value->product_ids);
            
          }
        }
      }
      return $model ? $model : [];
    }


}
