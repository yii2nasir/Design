<?php

namespace app\modules\v1\controllers;

use Yii;
use \app\models\Users;
use \app\models\LoginHistory;
use \app\models\CustomClasses\JWT;
use app\models\UserLocationMapper;
use app\models\Village;

class UsersController extends ApiController {
    public function actionLogin() {

        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $request = Yii::$app->request;
        $params = $request->post();
        $this->keepLogActionWise(json_encode(["post"=>$params,"file"=>$_FILES]), TRUE, FALSE);
        if ($request->getMethod() === "POST" || $request->getMethod() === "post") {
            $userdetail = Users::find()->where(['username' => $params['username']])->andWhere(['password' => $params['password']])->asArray()->one();
            if ($userdetail) {
               if($userdetail['level_id'] != 36){
                  Yii::$app->response->statusCode = 401;
                    $return =  ['success' => false, 'status' => 401, 'message' => 'User Unauthorized.'];
                    $this->keepLogActionWise(json_encode($return), FALSE, TRUE);
                    return $return;
                }
                unset($userdetail['username']);
                unset($userdetail['password']);
                unset($userdetail['confirm_password']);
                $lastLogin = LoginHistory::find()
                                ->select(["logged_in"])
                                ->where(["user_id" => $userdetail['id']])
                                ->orderBy("id DESC")
                                ->one();
                if ($lastLogin) {
                    $lastLogin = $lastLogin->logged_in;
                } else {
                    $lastLogin = strtotime("now");
                }
                
                $LoginHistoryModel = new LoginHistory();
                $LoginHistoryModel->user_id = $userdetail['id'];
                $LoginHistoryModel->logged_in = strtotime("now");
                $LoginHistoryModel->lat = isset($params["lat"]) && !empty($params["lat"]) ? $params["lat"] : "0.0";
                $LoginHistoryModel->lng = isset($params["lng"]) && !empty($params["lng"]) ? $params["lng"] : "0.0";
                $LoginHistoryModel->ip_address  = $_SERVER['REMOTE_ADDR'];
                $LoginHistoryModel->device_id = $_SERVER['HTTP_USER_AGENT'];
                if ($LoginHistoryModel->save()) {
                    $userdetail["login_id"] = $LoginHistoryModel->id;
                    Yii::$app->response->statusCode = 200;
                    $getInfoList = $this->getInfoList($userdetail["id"],$userdetail['level_id']);  
                    if($getInfoList){
                       $userdetail["rpc_name"] =  $getInfoList['rpc_name'];
                       $userdetail["rpc_id"] =  $getInfoList['id'];
                       $userdetail["city"] =  $getInfoList['district_name'];
                       $userdetail["state"] =  $getInfoList['state_name'];
                       $userdetail["code"] =  $getInfoList['code'];
                    }else{
                        Yii::$app->response->statusCode = 401;
                        $return =  ['success' => false, 'status' => 401, 'message' => 'User Unauthorized.'];
                        $this->keepLogActionWise(json_encode($return), FALSE, TRUE);
                        return $return; 
                    }

                    $return =  [
                        'success' => true,
                        'status' => 200,
                        'message' => 'Login successfull.',
                        'token' => JWT::encode($userdetail, \Yii::$app->params["tokenSecret"]),
                        "login_id" => $LoginHistoryModel->id,
                        "last_login" => $lastLogin,
                        "timestamp" => strtotime("now")
                    ];
                    $this->keepLogActionWise(json_encode($return), FALSE, TRUE);
                    return $return;
                } else {
                    Yii::$app->response->statusCode = 400;
                    $return =  ['success' => false, 'status' => 400, 'message' => 'Something went wrong.'];
                    $this->keepLogActionWise(json_encode($return), FALSE, TRUE);
                    return $return;
                }
            } else {
                Yii::$app->response->statusCode = 401;
                $return =  ['success' => false, 'status' => 401, 'message' => 'Authentication Failed'];
                $this->keepLogActionWise(json_encode($return), FALSE, TRUE);
                return $return;
            }
        } else {
            Yii::$app->response->statusCode = 400;
            $return =  ['success' => false, 'status' => 400, 'message' => 'Method not allowed'];
            $this->keepLogActionWise(json_encode($return), FALSE, TRUE);
            return $return;
        }
    }
    public function getInfoList($userId,$userLevel) {
        $condition = ["user_id"=>$userId,'level_id'=>$userLevel];
        return UserLocationMapper::find()
                     ->select(['rpc_centre.rpc_name','rpc_centre.id','district.name as district_name'
                     ,'state.name as state_name','rpc_centre.code'])
                     ->innerJoin("rpc_centre", "rpc_centre.id = user_location_mapper.location_id")
                     ->innerJoin("district", "district.id = rpc_centre.district_id")
                     ->innerJoin("state", "state.id = district.state_id")
                     ->where($condition)->asArray()
                     ->one();
       }


    
    public function actionLogout() {
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $request = Yii::$app->request;
        $LoginHistoryModel = LoginHistory::findOne($this->findInToken('login_id'));
        $LoginHistoryModel->logged_out = strtotime("now");
        if(!$LoginHistoryModel->save()){
            Yii::$app->response->statusCode = 400;
            $return =  ['success' => FALSE, 'status' => 400, 'message' => 'Error in logout',"ERR"=>['ERRCODE'=>"MODEL_ERROR","ERROR"=>$LoginHistoryModel->getErrors()]];
            $this->keepLogActionWise(json_encode($return), FALSE, TRUE);
            return $return;
        }
        Yii::$app->response->statusCode = 200;
        $return =  ['success' => TRUE, 'status' => 200, 'message' => 'Successfully logged out'];
        $this->keepLogActionWise(json_encode($return), FALSE, TRUE);
        return $return;
    }
}