<?php

namespace app\modules\v1\controllers;

use Yii;
use app\modules\v1\models\Config;
use app\modules\v1\models\Handlers;
use yii\web\Controller;
use app\models\Cleaning;
use app\models\CleaningMapper;
use app\models\CleaningQcCheck;
use app\models\FumigationMapper;
use app\models\Fumigation;
use yii\helpers\Url;

class CleaningController extends ApiController {
    //START OF API: Function to insert Beneficiary ...
  public function actionCreate() {
    $post = Yii::$app->request->post();
    $this->keepLogActionWise(json_encode(["post" => $post, "file" => $_FILES]), TRUE, FALSE);
    Yii::$app->response->statusCode = 400;
    if (!isset($post["unique_id"]) || empty($post["unique_id"])) {
      $return = [
        'success' => FALSE,
        'status' => 400,
        'message' => "Unique Id is required"
      ];
      $this->keepLogActionWise(json_encode($return), false, true);
      return $return;
    } 
    if(isset($post['product_id']) && $post['product_id'] !=""){
      $post['product_id'] = $this->cleanJsonString($post['product_id']);
    }

    if(isset($post['cleaning_checklist']) && $post['cleaning_checklist'] !=""){
      $post['cleaning_checklist'] = $this->cleanJsonString($post['cleaning_checklist']);
    }

    $model = $this->getModel($post['unique_id']);
    $mages = $model->image;
    $cleaning = [];
    $cleaning["Cleaning"] = $post;
    $model->entry_type = "MOBILE";
    $model->updated_at = strtotime("now");

    if ($model->load($cleaning)) {
      $model->user_id = $this->user->id;
      $model->rpc_center_id = $this->user->rpc_id;
      if(isset($_FILES) && !empty($_FILES)){
          $model = \Yii::$app->fileupload->uploadApiFile($model,FALSE,TRUE);
        }else{
         $model->image =  $mages;
       }
       if($post['status'] != '1')
         {
            $validn = false; 
            if(empty($model->cleaning_date) || is_null($model->cleaning_date))
            {
               $model->cleaning_date = '0000-00-00 00:00:00';
            }
         }else{
            $validn = true;
            if($model->cleaning_date == '0000-00-00 00:00:00')
            {
               $model->cleaning_date = '';
            }
         }

     if ($model->save()) {
      $this->cleaningProduct($post,$model->id);
      $this->cleaning_qc_check($post,$model->id);
      Yii::$app->response->statusCode = 200;
      $return = [
        'success' => TRUE,
        'status' => 200,
        'message' => "Operation performed successfully",
        "unique_id" => $model->unique_id
      ];
      $this->keepLogActionWise(json_encode($return), false, true);
      return $return;
    } else {
      $return = [
        'success' => FALSE,
        'status' => 400,
        'message' => "Got error while saving",
        "ERROR" => $model->getErrors()
      ];
      $this->keepLogActionWise(json_encode($return), false, true);
      return $return;
    }
  } else {
    $return = [
      'success' => TRUE,
      'status' => FALSE,
      'message' => "Got error while loading model",
      "ERROR" => $model->getErrors()
    ];
    $this->keepLogActionWise(json_encode($return), false, true);
    return $return;
  }
}

function cleaning_qc_check($post,$id){
      if(isset($post['cleaning_qc_check']) && $post['cleaning_qc_check'] !="")
      {

         foreach (CleaningQcCheck::find()->where("cleaning_id='".$id."'")->all() as $row)
         {
            $row->delete();
         }
         $resultQcM = CleaningQcCheck::find()->where(['cleaning_id'=>$id])->all();
         if(!$resultQcM){
            $resultQcCheck = json_decode($this->cleanJsonString($post['cleaning_qc_check']),true);
            foreach ($resultQcCheck as $value){
               $parameter_id = QcCheckPhyChemical::find()->where(['product_id'=>$post['product_id']])->andWhere(['type'=>'Cleaning'])->andWhere(['order_wise'=>$value['id']])->one()->id;
               $resultQcCheck = new CleaningQcCheck();
               $resultQcCheck->value = $value['value'];
               $resultQcCheck->qc_parameter_id = $parameter_id;
               $resultQcCheck->entry_type = "MOBILE";
               $resultQcCheck->updated_at = strtotime("now");
               $resultQcCheck->qc_check_id = $id;
               $resultQcCheck->unique_id = uniqid();
               $resultQcCheck->save();
            }
         }
      }
   }


function cleanJsonString($jsonStr){
  $len = strlen($jsonStr);
  if($len > 0){
    if( 
      ($jsonStr[0] == '"' || $jsonStr[0] == "'") 
      && 
      ($jsonStr[($len - 1)] == '"' || $jsonStr[($len - 1)] == "'") 
    ){
      $jsonStr = substr_replace($jsonStr,"",0,1);
      $len = strlen($jsonStr);
      $jsonStr = substr_replace($jsonStr,"",($len - 1),1);
    }
  }
  return $jsonStr; 
}

    //END OF API: Function to insert New Request ...

protected function getModel($unique_id) {
  $model = Cleaning::find()->where(["unique_id" => $unique_id])->one();
  return $model ? $model : new Cleaning();
}

function cleaningProduct($post,$id){
  if(isset($post['product_id']) && $post['product_id'] !=""){
    foreach (CleaningMapper::find()->where("cleaning_id='".$id."'")->all() as $row)
     {
        $row->delete();
     }
   $resultQcM = CleaningMapper::find()->where(['cleaning_id'=>$id])->all();
   if(!$resultQcM){
    $productMapper = json_decode($this->cleanJsonString($post['product_id']),true);
    foreach ($productMapper as $value){
      $productMapper = new CleaningMapper();
      $productMapper->cleaning_id = $id;
      $productMapper->product_id = $value['product_id'];
      $productMapper->incoming_uniq_id = $value['incoming_qc_uniq_id'];
      $productMapper->batch_id = $value['batch_id'];
      $productMapper->available_qty = (string)$value['available_qty'];
      $productMapper->quantity_value = (string)$value['quantity_value'];
      $productMapper->remaining_quantity = $value['remaining_quantity'];
       $productMapper->fumigation_uniq_id = $value['fumigation_uniq_id'];
       $productMapper->cleaning_uniq_id = $value['cleaning_uniq_id'];
      if(!$productMapper->save()){
         display_array($productMapper);
         exit;
        $fumigationId = Fumigation::find()->where(['unique_id'=>$value['fumigation_uniq_id']])->one()->id;

        if($fumigationId){
          $fumigationMapper = FumigationMapper::find()->where(['fumigation_id'=>$fumigationId])->one();
          if($fumigationMapper){
           $fumigationMapper['cleaning_status'] = "1"; 
           $fumigationMapper->save();
         }
       }
                            // END  
     }
   }
 }
}
}



    //START OF API: Function to View/Get Beneficiary Record
public function actionView() {
  Yii::$app->response->statusCode = 200;
  $return = [
    'success' => TRUE,
    'status' => 200,
    'message' => "Data fetched",
    "data" => $this->getCleaning(),
    "timestamp" => strtotime("now")
  ];
  return $return;
}
    //END OF API: Function to View/Get Beneficiary Record



    //Get Beneficiary Data ...
protected function getCleaning(){
  $user_id = $this->user; 
  $logginUser = $user_id->id;

        $query = new \yii\db\Query;         //add prduct_id
        $select=('`cleaning`.*,
          `cleaning_mapper`.`cleaning_id`,
          `cleaning_mapper`.`product_id`');
        $query->select($select)
        ->from('cleaning')
        ->innerjoin('cleaning_mapper','cleaning_mapper.cleaning_id=cleaning.id')   
        ->where('cleaning.rpc_center_id ='.$user_id->rpc_id)
        ->groupBy('cleaning.id');
        if($this->headerTimestamp){
          $condition = [">","updated_at", intval($this->headerTimestamp)];
          $query->andWhere($condition);
        }    
        $data=$query->createCommand()->queryAll();
        
        $result = [];
        $i = 0;
        if($data){
          foreach ($data as  $value) {

           if($value['image'] !=""){
              $url =  "http://" . $_SERVER['SERVER_NAME'].Url::base()."/images/cleaning/";
              $value['image'] =  $url.$value['image'];
            }else{
             $value['image'] = "";
           }
           $data[$i]['cleaning_checklist'] = json_decode($value['cleaning_checklist']);
           $data[$i]['product_id'] = $this->cleaningMapper($value['id']);
           $data[$i]['qCanswerList'] = $this->cleaningQcCheck($value['id']);
           $data[$i]['product'] = $value['product_id'];
           $data[$i]['cleaning_date'] = $value['cleaning_date'];
           $data[$i]['image'] = $value['image'];

           $i++;
         }
       }else{
        $data = [];
      }
      return $data;
    }

    function cleaningMapper($id){
      $fumigationQcM = CleaningMapper::find()->select(['id','cleaning_id','product_id','batch_id','incoming_uniq_id','available_qty','quantity_value','remaining_quantity','cleaning_uniq_id'])->where(['cleaning_id'=>$id])->all();
      if(!$fumigationQcM){
        $fumigationQcM = [];
      }
      return $fumigationQcM;
    }

    function cleaningQcCheck($id){
         // echo $id;
         // exit;
      // $rpc_id = ApiController::findInToken('rpc_id');
      // $rpc = '"'.$rpc_id.'"';
        $cleaningQcResultQcM = CleaningQcCheck::find()->select(['qc_parameter_id','value'])->where(['cleaning_id'=>$id])->all();
       // print_r($cleaningQcResultQcM);
       // exit;
        $result = [];
        if($cleaningQcResultQcM){
           foreach ($cleaningQcResultQcM as $value) {
             $result[] = [
                 'id'=>$this->findOrder($value['qc_parameter_id']),
                 'value'=>$value['value'],
                 ];
           }  
        } 
        return $result;
   }

   function findOrder($parm_id){
       $orderM = QcCheckPhyChemical::find()->select(['order_wise'])->where(['id'=>$parm_id])->andWhere(['type'=>'Cleaning'])->one();
       return $orderM ? $orderM->order_wise :""; 
   }


  }
