<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\FgCheckResultSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Fg Check Results';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="fg-check-result-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Fg Check Result', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'fg_qc_check_id',
            'qc_parameter_id',
            'value',
            'status',
            //'latitude',
            //'logtitude',
            //'entry_type',
            //'created_at',
            //'updated_at',
            //'unique_id',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
