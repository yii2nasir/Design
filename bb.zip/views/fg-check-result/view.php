<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\FgCheckResult */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Fg Check Results', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="fg-check-result-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'fg_qc_check_id',
            'qc_parameter_id',
            'value',
            'status',
            'latitude',
            'logtitude',
            'entry_type',
            'created_at',
            'updated_at',
            'unique_id',
        ],
    ]) ?>

</div>
