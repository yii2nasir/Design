<?php
use app\models\IncomingQcCheck;
use yii\widgets\ActiveForm;

?>
<style type="text/css">
  .fa-sign-in{
    font-size: 20px;
  }
</style>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <div class="x_panel">
        <div class="x_content">
         <div class="panel panel-default">
          <div class="panel-body"><h4 align="center">Incoming QC Check</h4></div>
        </div>  
        <h4>On Hold Request (<?= count($model) ?>)</h4>
        <div class="x_panel">
      
      <div class="x_content">
        <?php $form = ActiveForm::begin([
          'action' => ['hold-process'],
          'method' => 'post',
          ]); ?>
          <form action="" class="form-horizontal form-label-left">
            <?php
            if($model){
              foreach ($model as  $value) { ?>
              <div class="panel panel-default">
                <div class="panel-body">
                  <div class="row">
                   
                    <div class="col-md-7">
                      Product Name : <?= $value['product_name'] ?>
                    </div>

                    <div class="col-md-4">
                      Last updated : <?= date("d-m-Y h:i:s",$value['updated_at']); ?>
                    </div>

                    <div class="col-md-1"></div>
                    <div class="col-md-11">
                      Batch ID : <?= $value['batch_id'] ?>
                    </div>
                    <div class="col-md-11"></div>
                    <div class="col-md-1">
                      <a href="onholdproductprocess?rq_id=<?= $value['request_id'] ?>&p=<?= $value['product_id'] ?>&id=<?= $value['id'] ?>" class="fa fa-sign-in"></a>
                    </div>

                  </div>
                </div>
              </div>

              <?php }  }else{?>
              <div class="panel panel-default">
                <div class="panel-body">
                  Result not Found.
                </div>
              </div>
              <?php } ?>
              <?php ActiveForm::end(); ?>
            </div>
          </div>
        </div>
    </div>
  </div>
</div>
</div>
</div>

