<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\NewRequest */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'New Requests', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="new-request-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'onclick'=>'return (ask_confirm(\''.$model->id.'\',\''.Yii::$app->controller->id .'\')? true : false)'
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'unique_id',
            // //'supplier_id',
            [
                'attribute' => 'supplier_id',
                'value' => 'supplier.name'
            ],
            'vehicle_inspection_checklist',
            'product_id:ntext',
            //'date',
            [ 
                'attribute'=>'date',
                'value' => function($data){
                    return date("Y-m-d h:i:s", 
                           strtotime($data->date));
                }
            ],
            // 'status',
            'comments:ntext',
            'vehicle_image',
            'vehicle_status',
            // 'latitude',
            // 'logtitude',
            'entry_type',
            [ 
                'attribute'=>'created_at',
                'value' => function($data){
                    return date("Y-m-d h:i:s", 
                           strtotime($data->created_at));
                }
            ],
            [ 
                'attribute'=>'updated_at',
                'value' => function($data){
                    return date("Y-m-d h:i:s", 
                           strtotime($data->updated_at));
                }
            ],
            // 'created_at',
            // 'updated_at',
        ],
    ]) ?>

</div>
