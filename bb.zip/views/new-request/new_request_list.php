
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="x_panel">
				<div class="x_content">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="row">
								<div class="col-md-6">
									<a class="btn btn-sm" href="../new-request/create" style="background-color: #4ace35; width: 50%; color: white" align="center" type="button" aria-expanded="true">Create New Request
									</a>
								</div>
								<div class="col-md-6">
									<h4>New Request List</h4>
								</div>
							</div>
						</div>  
						<div class="x_panel">
							<div class="x_content">
								<?php foreach ($data as $value) {  ?>
								<div class="panel panel-default">
									<div class="panel-body">
										<div class="row">
											<div class="col-md-8">
												<b> Product List </b> :    <?= $value['product_id']; ?>
											</div>
											<div class="col-md-4">
												<b> Created At </b> :    <?= $value['created_at']; ?>
											</div></br>
											<div class="col-md-12">
												<b> Supplier Name </b>:   <?= $value['name']; ?>
											</div><br>
											<div class="col-md-12">
												<b> Status </b>:    <?= $value['vehicle_status']; ?>
											</div>
										</div>
									</div>
								</div>
								<?php } ?>		
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>