<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;
use yii\helpers\Url;
use app\models\Product;
use app\models\Supplier;

/* @var $this yii\web\View */
/* @var $searchModel app\models\NewRequestSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'New Requests';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="new-request-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php  // echo $this->render('_search', ['model' => $searchModel]); ?>

  <!-- date('z') + 1; -->

    <p>
        <?= Html::a('Create New Request', ['create'], ['class' => 'btn btn-success']) ?>
    </p>


    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= Html::submitButton('Search', ['class' => 'btn btn-primary','style'=>'display:none']) ?>


    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn','header'=>'Sr.No'],
            [
                'attribute' => 'supplier_id',
                'value' => function($data){
                     $product = Supplier::find()->where(['unique_id'=>$data->supplier_id])->one();
                     return $product ? $product->name:"";
                 }
            ],
            [
                'attribute' => 'product_id',
                'value' => function($data){
                  $product_name = "";
                  if($data->product_id !=""){
                     $productJson =  json_decode($data->product_id);
                     $i=0;
                     foreach ($productJson as $value) {
                      $productM = Product::find()->where(['id'=>$value])->one();
                      if($productM){
                            if($i == 0){
                              $product_name = $productM->name;
                            }else{
                             $product_name = $product_name ." , ".$productM->name;
                            }
                        $i++;
                       }
                     }
                  }
                  return $product_name;
                }
            ],
            
            'vehicle_status',

            [ 
                'attribute'=>'created_at',
                'value' => function($data){
                    return date("Y-m-d H:i:s", 
                           strtotime($data->created_at));
                }
            ],

            [
                'label' => 'Incoming',
                'format' => 'raw',
                'value' => function($data){
                     if($data->vehicle_status =="Accept"){
                         return  Html::a('Incoming Qc Check',Url::to(['new-request/product-wise-qc-check','req_id'=>$data->unique_id]), ['class' => 'btn btn-info']);
                     }else{
                        return "";
                     }
                }
            ],

            [
                   'class' => 'yii\grid\ActionColumn',
                    'contentOptions'=>['style'=>'width: 60px;text-align: center;'],
                    'header'=>'Action', 
                    'template' => '{view} {update} {delete}',
                    'buttons' => [
                        'view' => function ($url, $model) {
                            return Html::a('<span class="glyphicon glyphicon-eye-open"></span>', $url, [
                                        'title' => Yii::t('app', 'lead-view'),
                            ]);
                        },
                        'update' => function ($url, $model) {
                            return Html::a('<span class="glyphicon glyphicon-pencil"></span>', $url, [
                                        'title' => Yii::t('app', 'lead-update'),
                            ]);
                        },

                        'delete' => function ($url, $model) {
                            return Html::a('<span class="glyphicon glyphicon-trash" onclick="ask_confirm(\''.$model->id.'\',\''.Yii::$app->controller->id .'\')"></span>', $url, [
                                        'title' => Yii::t('app', 'Delete'),                        
                            ]);
                        },
                    ],
                    'urlCreator' => function ($action, $model, $key, $index) {
                         if ($action === 'view') {
                            $url ='../new-request/view?id='.$model->id;
                            return $url;
                        }
                        if ($action === 'update') {
                            $url ='../new-request/update?id='.$model->id;
                            return $url;
                        }
                        if ($action === 'delete') {
                            $url = "#";
                            return $url;
                        }
                    } 
            ],
            
        ],
    ]); ?>
    <?php ActiveForm::end() ?>
</div>
