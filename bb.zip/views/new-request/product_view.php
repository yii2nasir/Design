<?php
use app\models\IncomingQcCheck;


?>
<style type="text/css">
.x_panel{
    border-color: #DADADA;
   -moz-box-shadow:    inset 0 0 0.1px #000000;
   -webkit-box-shadow: inset 0 0 0.1px #000000;
   box-shadow:         inset 0 0 0.1px #000000;
}
</style>

<div class="container">
  <div class="row">
    <div class="col-md-12">
      <div class="x_panel">
        <div class="x_content">
        <?php foreach ($result as $value) { 
             $incomingQcCheck = IncomingQcCheck::find()->where(['request_id'=>$value['request_id'],'product_id'=>$value['product_id']])->one();
           ?>
                <div class="col-md-12">
                  <div class="panel panel-default">
                    <div class="panel-body">
                      <div class="row">
                        <div class="col-md-12">
                          <b>Product Name :</b> <?= $value['product_nane'] ?>
                        </div>
                        <div class="col-md-11">
                          <b>Product Code :</b> <?= $value['product_code'] ?>
                        </div>
                        <div class="col-md-1">
                          <?php if(!$incomingQcCheck){ ?>
                           <a href="../incoming-qc-check/create?rq_id=<?= $value['request_id'] ?>&p=<?= $value['product_id'] ?>" class="fa fa-sign-in"></a>
                          <?php }else{ ?>
                            <span class="fa fa-check"></span>
                           <?php } ?>
                        </div>
                        <div class="col-md-12">
                          <b>Supplier Name :</b> <?= $value['supplier'] ?>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
            
          <?php } ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>



