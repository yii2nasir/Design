<?php
use app\models\IncomingQcCheck;
?>
<style type="text/css">
  .fa-sign-in{
    font-size: 20px;
  }
</style>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h4 style="font-size: 32px;">Incoming QC Check</h4>
      <div class="x_panel">
        <!-- <div class="x_content"> -->
        <!--  <div class="panel panel-default">
          
        </div>  --> 
        <h4>In Process (<?= count($mainArray) ?>)</h4>
        <div class="panel panel-default">
          <div class="panel-body">  
            <?php
             if($mainArray){
               foreach ($mainArray as $value) { 
               $incomingQcCheck = IncomingQcCheck::find()->where(['request_id'=>$value['unique_id'],'product_id'=>$value['product_id']])->one();
               ?>
               <div class="col-md-12">
                <div class="panel panel-default">
                  <div class="panel-body">
                    <div class="row">
                      <div class="col-md-8">
                        <b>Product Name :</b> <?= $value['product_name'] ?>
                      </div>
                      <div class="col-md-4">
                        <b>Updated At :</b> <?= date("d-m-Y h:i:s",$value['updated_at']) ?>
                      </div>
                      <div class="col-md-11">
                        <b>Product Code :</b> <?= $value['product_code'] ?>
                      </div>

                      <div class="col-md-1">
                        <?php if(!$incomingQcCheck){ ?>
                        <a href="../incoming-qc-check/create?rq_id=<?= $value['unique_id'] ?>&p=<?= $value['product_id'] ?>" class="fa fa-sign-in"></a>
                        <?php }else{ ?>
                        <span class="fa fa-check"></span>
                        <?php } ?>
                      </div>
                      <div class="col-md-12">
                        <b>Supplier Name :</b> <?= $value['supplier_name'] ?>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <?php } 
                }
              ?>
          </div>
        </div>
     <!--  </div> -->
    </div>
  </div>
</div>
</div>
</div>

