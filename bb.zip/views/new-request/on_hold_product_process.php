<?php
use app\models\IncomingQcCheck;
use yii\widgets\ActiveForm;
use yii\helpers\Html;

?>
<style type="text/css">
  .fa-sign-in{
    font-size: 20px;
  }
  
    .buttons, button, .btn {
        margin-bottom: 5px;
        margin-right: 5px;
        width: 218px;
  }
</style>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <div class="x_panel">
        <div class="x_content">
         <div class="panel panel-default">
          <div class="panel-body"><h4 align="center">Incoming QC Check</h4></div>
        </div>  
        <h4>On Hold Request</h4>
        <div class="x_panel">
      
      <div class="x_content">

       
        <?php $form = ActiveForm::begin([
          // 'action' => ['on-hold-product-process'],
          'method' => 'post',
          ]); ?>
          <form action="" class="form-horizontal form-label-left">
            <?php
            if($value){ ?>
              <div class="panel panel-default">
                <div class="panel-body">
                  <div class="row">
                    
                    <div class="col-md-7">

                      Product Name : <?= $value['product_name']; ?>
                    </div>

                    <div class="col-md-4">
                      Last updated : <?= date("d-m-Y h:i:s",$value['updated_at']); ?>
                    </div>

                    <div class="col-md-1"></div>
                    <div class="col-md-11">
                      Product ID : <?= $value['productId'] ?>
                    </div>
                    <div class="col-md-1"></div>
                    <div class="col-md-11">
                      Supplier Name : <?= $value['supplier_name'] ?>
                    </div>
                    <div class="col-md-1"></div>
                    <div class="col-md-11">
                      Vihicle Inspection :  <?= $value['vehicle_status'] ?>
                    </div>
                    <div class="col-md-1"></div>
                    <div class="col-md-11">
                      Incomming QC Check : <?= $value['overall_status'] ?>
                    </div>
                    <div class="col-md-1"></div>
                    <div class="col-md-11">
                      Batch Id:  <?= $value['batch_id'] ?>
                    </div>
                    <div class="col-md-1"></div>
                    <div class="col-md-11">
                      QC: 
                    </div>
                    <div class="col-md-1"></div>
                    <div class="col-md-11">
                     Total Quantity: <?= $value['arrived_qty'] ?>
                    </div>
                   
                  </div>
                </div>
              </div>

              <div class="row">            

                <center><div class="" >
                <input type="submit" name="reject" class="btn btn-default btnNext"  id="Reject" value="Reject" >
                  <input type="submit" name="accept" class="btn btn-success btnNext"  id="Accept" value="Accept" ></
                </div></center>
                 
              </div> 
              <?php }else{?>
              <div class="panel panel-default">
                <div class="panel-body">
                  Result not Found.
                </div>
              </div>
              <?php } ?>
              <?php ActiveForm::end(); ?>
            </div>
          </div>
        </div>
    </div>
  </div>
</div>
</div>
</div>
