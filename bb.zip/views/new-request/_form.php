<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;
use yii\helpers\ArrayHelper;
use kartik\file\FileInput;


/* @var $this yii\web\View */
/* @var $model app\models\NewRequest */
/* @var $form yii\widgets\ActiveForm */
?>

<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<link rel="stylesheet" href="<?php echo Url::to("@web/mcss/select2.min.css"); ?>" />
<link rel="stylesheet" href="<?php echo Url::to("@web/mcss/select2-bootstrap.css") ?>" />
<script id='selectTwoJs' src="<?php echo Url::to("@web/mjs/select2.min.js"); ?>"></script>
<script type="text/javascript">
  $(document).ready(function () {
    $("select").select2({
      width: '100%',
      theme: "bootstrap",
      cache: true
    });
  });
</script>
<style type="text/css">
   .btn2{
    /*transition-property:transform .3s;*/
    border-style: none;
    margin-left: 40%;
    width:20%;
     
   }
   .btn2:hover{
          background:#383838;
          margin-left: 40% !important;
          min-width: 50px;
          max-width: 300px;
         /* transform: scale(1.3);*/
          box-shadow:0 0 1px rgba(0,0,0,0);
           
       }
       .btn2:link,.btn2:visited,.btn2:active{
          background:#383838;
          margin-left: 40% !important;
          min-width: 50px;
          max-width: 300px;
          border-style: none;
            
       }
      /* .btn3{
           transition-property:transform .3s;
           border-style: none;
           margin-left: 37%;
          }
       .btn3:hover{
          background:#383838;
          margin-left: 30%;
          min-width: 50px;
          max-width: 300px;
          transform: scale(1.3);
          margin-left: 37%; 
        }
       .btn3:link,.btn3:visited,.btn3:active{
          background:#383838;
          margin-left: 30%;
          min-width: 50px;
          max-width: 300px;
          border-style: none;
          margin-left: 37%;
        }*/
     /*  .btn2:visited{
          background:#383838;
          margin-left: 40%;
          min-width: 50px;
          max-width: 300px;
       }
       .btn2:active{
          background:#383838;
          margin-left: 40%;
          min-width: 50px;
          max-width: 300px;
       }*/
       .btn-primary{
        background:#383838;
        padding-top: 8px;
        font-size: 18px;
       }
       .btn_supplier:hover,.btn_supplier:link,.btn_supplier:visited,.btn_supplier:active{
        min-width: 50px;
        background: white;
       /* margin-bottom: 25px !important;*/
        margin-top: 20px !important;
        color:black !important;
        max-width: 200px;
        border-color: darkgray;
       }
      
       .alert-success{
        background-color: #689F35;
       }
       #product_list{
        width: 100% !important;
       }
      /* .btn1:link{
        min-width: 50px;
        background:#383838;
        max-width: 200px;
       }
       .btn1:visited{
        min-width: 50px;
        background:#383838;
        max-width: 200px;
       }
       .btn1:active{
        min-width: 50px;
        background:#383838;
        max-width: 200px;
       }*/
       .panel_newrequest{
          margin: -16px;
       }
       .panel_createnewrequest{
        margin: -22px;
       }
</style>
<div class="new-request-form">
  <?php $form = ActiveForm::begin([
    'options'=>['enctype'=>'multipart/form-data'],'id'=>'submitForm']);?>
    <ul class="nav nav-tabs" style="display: none;">
      <li class="active"><a href="#tab1" data-toggle="tab">Shipping</a></li>
      <li><a href="#tab2" data-toggle="tab">Quantities</a></li>
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab1">
       <div class="panel panel-default panel_newrequest">
        <div class="panel-body">
         <?php

         if(getUserLevelID() !=36){  
           echo $form->field($model, 'user_id')->dropDownList(
                ArrayHelper::map(\app\models\RpcCentre::find()->all(), 'id', 'rpc_name'),
                [
                  'prompt' => 'Select RPC',
                  'id' => 'user-id',
                  'class'=>'form-control'

                  ])->label('RPC');   
                  } ?>
        <span id="msg_user_id" style="color: red"></span><br>

        <?= $form->field($model, 'product_id')->dropDownList(ArrayHelper::map(\app\models\Product::find()->all(), 'id', 'name'),
          [
            'prompt' => 'Select Product',
            'id' => 'product_id',
            'class'=>'form-control test',
            'multiple'=>true
          ])->label('Product');   
          ?>
          <span id="msg_product" style="color: red"></span> <br>      
          <div class="row row3">
            <div class="col-md-9">
              <?= $form->field($model, 'supplier_id')->dropDownList(
                ArrayHelper::map(\app\models\Supplier::find()->all(), 'id', 'name'),
                [
                  'prompt' => 'Select supplier',
                  'id' => 'suplier-id',
                  'class'=>'form-control'

                  ])->label('Supplier');   ?>
                  <span id="msg_suplier" style="color: red"></span><br>
                </div> 

                <div class="col-md-2">
                  <label></label>
                  <a href="../supplier/create?type=new" class="btn btn-success btn_supplier">Add New Supplier</a>
                </div>
              </div>
               <div class="form-group">
               <!--  <a href="../all-proccess/index" class="btn btn-success btn3">Go Back</a> -->
                <a class="btn btn-primary btnNext btn2" id="first_page">CONTINUE</a>
              </div>
            </div>
          </div>
        </div>
 
    <div class="tab-pane" id="tab2">
      <div class="col-md-12 col-sm-12 col-xs-12">

          <div class="panel panel-default panel_createnewrequest"> 
                <div class="panel-body"> 
                    <div class="x_panel">
                      <div class="x_title">
                        <h2>Product List <small></small></h2>
                        <ul class="nav navbar-right panel_toolbox" style="margin-right: -5%;">
                          
                        <!--   <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                          </li>
                          <li><a class="close-link"><i class="fa fa-close"></i></a></li> -->
                          <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                        </ul>
                        <div class="clearfix"></div>
                      </div>
                      <div class="x_content">
                        <div id="product_list"></div>
                      </div>
                    </div>
                </div>

              <label style="padding:0;margin-left:1.2%;">Vehicle Inspection checklist</label>
              <div class="panel panel-default" style="width:97%;margin-left:1.4%;"> 
               <div class="panel-body">
                <div class="row" style="padding:0;margin:0;">
                  <div class="col-sm-5">
                    <div class="panel panel-default">
                      <div class="panel-body flat1"><input name="NewRequest[vehicle_inspection_checklist][]" id="pppp" value="Cleaning" type="checkbox"> Cleaning</div>
                    </div>
                  </div>
                  <div class="col-sm-5">
                    <div class="panel panel-default">
                      <div class="panel-body"><input name="NewRequest[vehicle_inspection_checklist][]" value="No chemical,liquor,fertilizer residue found" type="checkbox" class="flat1"> No chemical, liquor, fertilizer residue found</div>        
                    </div>
                  </div>
                </div>
                <div class="row" style="padding:0;margin:0;">
                  <div class="col-sm-5">
                    <div class="panel panel-default">
                      <div class="panel-body"><input name="NewRequest[vehicle_inspection_checklist][]" value="Odourless" type="checkbox" class="flat1"> Odourless</div>
                    </div>
                  </div>
                  <div class="col-sm-5">
                    <div class="panel panel-default">
                      <div class="panel-body"><input name="NewRequest[vehicle_inspection_checklist][]" value="Covered" type="checkbox" class="flat1"> Covered</div>        
                    </div>
                  </div>
                </div>

                <div class="row" style="padding:0;margin:0;">
                  <div class="col-sm-10">
                    <?= $form->field($model, 'comments')->textarea(['rows' => '3', 'placeholder' =>'Share your comments']) ->label("")  ?>
                  </div>
                </div>
                <?= $form->field($model, 'vehicle_status')->hiddenInput(['maxlength' => true])->label("") ?>

        <div class="row" style="padding:0;margin:0;">
          <div class="col-lg-4">
            <?= $form->field($model, 'vehicle_image')->fileInput(['maxlength' => true])->label("Image") ?>
          </div>
        </div>
     
      <!-- </div> -->
    </div>
    </div><br>
    
    <div class="row">
      <div class="col-lg-5" style="float: right;">
        <?= Html::submitButton('Reject', ['class' => 'btn btn-default btnNext','id'=>'Reject']) ?>
        <?= Html::submitButton('Partially Accept', ['class' => 'btn btn-primary btnNext','id'=>'partially_accept']) ?>
        <?= Html::submitButton('Accept', ['class' => 'btn btn-success btnNext','id'=>'Accept']) ?>
      </div>
   
      </div><br> 
      </div>
  <?php ActiveForm::end(); ?>
</div>
<script type="text/javascript">
 //  $("#first_page").click(function(){

 // });
// $(document).ready(function(){
//     $("#Reject").attr("disabled", "disabled");
//     $("#partially_accept").attr("disabled", "disabled");
//     $("#Accept").attr("disabled", "disabled");
// });

$("#Reject").on('click', function(event){
 $("#newrequest-vehicle_status").val("Reject");
 event.preventDefault();
 $("#submitForm").submit();
});

$("#partially_accept").on('click', function(event){
 $("#newrequest-vehicle_status").val("Onhold");
 event.preventDefault();
 $("#submitForm").submit();
});

$("#Accept").on('click', function(event){
 $("#newrequest-vehicle_status").val("Accept");
 event.preventDefault();
 $("#submitForm").submit();
 toastr.success('Successfully Request Created');
});


    // var counter;
    // counter = 0;
    // $(".flat1").click(function() {
    //   if(this.checked == true) {
    //         counter++;
    //         if(counter == 4){
    //             $("#Reject").prop("disabled", "");
    //             $("#partially_accept").prop("disabled", "");
    //             $("#Accept").prop("disabled", "");
    //         }
    //     } else {
    //         counter--;
    //         if(counter < 4){
    //             $("#Reject").prop("disabled", "disabled");
    //             $("#partially_accept").prop("disabled", "disabled");
    //             $("#Accept").prop("disabled", "disabled");
    //         }
    //     }
    // });

  </script>

  <script>
   $('.btnNext').click(function(){
     var suplier_id = $("#suplier-id").val();
     var product_id = $("#product_id").val();
     var user_id = $("#user-id").val();
     var flage = 0;
     if(product_id ==null){
       $("#msg_product").html("Product Name cannot be blank.");
       flage++;
     }else{
       $("#msg_product").html("");
     }

     if(user_id ==""){
       $("#msg_user_id").html("RPC Name cannot be blank.");
       flage++;
     }else{
       $("#msg_user_id").html("");
     }

     if(suplier_id ==""){
       $("#msg_suplier").html("Supplier Name cannot be blank.");
       flage++;
     }else{
       $("#msg_suplier").html("");
     }
     if(flage != 0){
       return false;
     }

     $.ajax({
      url: 'find-product',
      type: 'post',
      data: {'product_id':product_id,'suplier_id':suplier_id},
      success: function(data) {
        $('#product_list').html(data);
      },
      error: function(e) {
      }
    });

     $('.nav-tabs > .active').next('li').find('a').trigger('click');
   });

   $('.btnPrevious').click(function(){
    $('.nav-tabs > .active').prev('li').find('a').trigger('click');
  });

/*button enable/disable */
$('#Accept').prop('disabled', true);
    $('#partially_accept').prop('disabled', true);

    $( ".flat1" ).on( "click", function() {
      if($( ".flat1:checked" ).length ==3)
      {
        $('#Accept').prop('disabled', false);
      }
      else
      {
        $('#Accept').prop('disabled', true);
      }  
      if($( ".flat1:checked" ).length ==1 || $( ".flat1:checked" ).length ==2)
      {
        $('#partially_accept').prop('disabled', false);
      }
      else
      {
        $('#partially_accept').prop('disabled', true);
      }  
  });
    
</script>


