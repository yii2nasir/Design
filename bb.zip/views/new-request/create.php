<?php

use yii\helpers\Html;
use yii\helpers\Url;


/* @var $this yii\web\View */
/* @var $model app\models\NewRequest */
$this->title = 'Create New Request';
$this->params['breadcrumbs'][] = ['label' => 'New Requests', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="new-request-create">

    <h1 style="font-size: 32px !important;"><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
        'rpc_data'=>$rpc_data
    ]) ?>

</div>
