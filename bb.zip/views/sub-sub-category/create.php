<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\SubSubCategory */

$this->title = 'Create Sub Sub Category';
$this->params['breadcrumbs'][] = ['label' => 'Sub Sub Categories', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="sub-sub-category-create">

    <h1 style="font-size: 32px;"><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
