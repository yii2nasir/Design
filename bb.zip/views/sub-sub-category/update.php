<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\SubSubCategory */

$this->title = 'Update Sub Sub Category:' .$model->name;
$this->params['breadcrumbs'][] = ['label' => 'Sub Sub Categories', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->name, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="sub-sub-category-update">

    <h1 style="font-size: 32px;"><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
