<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;
use kartik\select2\Select2;
use app\models\SubSubCategory;
use app\models\SubCategory;
use app\models\Category;

/* @var $this yii\web\View */
/* @var $model app\models\SubSubCategory */
/* @var $form yii\widgets\ActiveForm */
?>
<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<?php
 if($model->isNewRecord == false){
     $query = new \yii\db\Query;
           $query->select('category.id')
                   ->from('category')
                   ->innerJoin('sub_category', 'sub_category.category_id= category.id')
                   ->where(['sub_category.id'=> $model->sub_cat_id]);
           $command = $query->createCommand();
           $data = $command->queryOne();
           $category_id = isset($data['id']) && $data['id'] !="" ? $data['id'] :"";
          
}else{
    $category_id = "";
}

?>
<style type="text/css">
  .btn.btn-success{
    background-color: cadetblue;
    border-style: none;
  }
</style>

<div class="sub-sub-category-form">

    <?php $form = ActiveForm::begin(); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_content">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <!-- Add category field in SubSubCategory form -->
                        <?= $form->field(new Category, 'id')->dropDownList(ArrayHelper::map(\app\models\Category::find()->all(),'id','category_name'),
                                              [
                                                  'prompt' => 'Select category ',
                                                  'id' => 'cat-id',
                                                  'onchange' => 'getSubCategory()',
                                              ])->label("Category") ?>

                      
                        <?= $form->field($model, 'sub_cat_id')->dropDownList(ArrayHelper::map(\
                        app\models\SubCategory::find()->select('id,sub_cat_name')->one(),'id','sub_cat_name'),
                                            [
                                                'prompt' => 'Select Subcategory',
                                                'id' => 'subcatID'
                                            ])->label("SubCategory") ?>

                        <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>
                    </div>
                </div>
                <div class="form-group">
                    <?= Html::submitButton('Update', ['class' => 'btn btn-success']) ?>
                </div>
            </div>
        </div>
    </div>

    <?php ActiveForm::end(); ?>

</div>

<!-- Here we write code for fetching data from one field to another like updateing .... -->

<script>

    $(document).ready(function(){

        var category_id = '<?= $category_id ?>';
        $("#cat-id").val(category_id);
        getSubCategory(category_id);
    });

    function getSubCategory(category_id=""){
        if(category_id){
            category_id = category_id;
        }else{
           category_id = document.getElementById("cat-id").value;  
        }
       
        $.ajax({
            url: '<?php echo Url::to(["site/lists"]); ?>',
            type: 'post',
            data: {
                type : 5,
                id : category_id
                },

                success: function (res) {

                    var subCategory = JSON.parse(res);
                    var areaOption = "<option value=''>Select Subcategory</option>";
                    for (var i = 0; i < subCategory.length; i++) {
                       areaOption += '<option value="' + subCategory[i]['id'] + '">' + subCategory[i]['sub_cat_name'] + '</option>'
                   }

                   $("#subcatID").html(areaOption);

                  <?php if($model->isNewRecord == false){ ?>
                         $("#subcatID").val('<?= $model->sub_cat_id ?>');
                   <?php } ?>

                //    if(document.getElementById("depDropDist") !== null){
                //    $("#depDropDist").val($("#depDropDist").val()).change();
                // }
            },
            error: function (res) {
            }
        }); 
        }

</script>
