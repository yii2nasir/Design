<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\Dristrict;
use app\models\State;
use yii\helpers\Url;
use kartik\select2\Select2;
use app\models\RpcCentre;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model app\models\RpcCentre */
/* @var $form yii\widgets\ActiveForm */
?>
<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<style type="text/css">
  .btn.btn-success{
    background-color: cadetblue;
    border-style: none;
  }
</style>
<?php
 if($model->isNewRecord == false){
     $query = new \yii\db\Query;
           $query->select('state.id')
                   ->from('state')
                   ->innerJoin('district', 'district.state_id = state.id')
                   ->where(['district.id'=> $model->district_id]);
           $command = $query->createCommand();
           $data = $command->queryOne();
           $state_id = isset($data['id']) && $data['id'] !="" ? $data['id'] :"";
          
}else{
    $state_id = "";
}
?>
<div class="rpc-centre-form">
    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_content">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <?= $form->field(new State, 'id')->dropDownList(ArrayHelper::map(\app\models\State::find()->all(),'id','name'),[
                                                            'prompt'=>'Select State',
                                                            'id'=> 'state-id',
                                                            'onchange' => 'getDistrict()',
                                                            ])->label('State') ?>

                    	<?= $form->field($model, 'district_id')->dropDownList(ArrayHelper::map(\app\models\District::find()->select('id,name')->one(),'id','name'),
                                                        [
                                                            'prompt' => 'Select District',
                                                            'id' => 'depDropDist'
                                                        ])->label("District"); ?>
                         
                        <?= $form->field($model, 'rpc_name')->textInput(['maxlength' => true]) ?>

                        <?= $form->field($model, 'code')->textInput(['maxlength' => true]) ?>

                    </div>
                </div> 
                <div class="form-group">
                    <?= Html::submitButton('Update', ['class' => 'btn btn-success']) ?>
                </div>
            </div>
        </div>           
    </div>

    <?php ActiveForm::end(); ?>
</div>
<script>

    $(document).ready(function(){

        var state_id = '<?= $state_id ?>';
        $("#state-id").val(state_id);
        getDistrict(state_id);
    });

    function getDistrict(state_id=""){
        if(state_id){
            state_id = state_id;
        }else{
           state_id = document.getElementById("state-id").value;  
        }
       
        $.ajax({
            url: '<?php echo Url::to(["site/lists"]); ?>',
            type: 'post',
            data: {
                type : 1,
                id : state_id
                },

                success: function (res) {

                    var district = JSON.parse(res);
                    var areaOption = "<option value=''>Select District</option>";
                    for (var i = 0; i < district.length; i++) {
                       areaOption += '<option value="' + district[i]['id'] + '">' + district[i]['name'] + '</option>'
                   }

                   $("#depDropDist").html(areaOption);

                  <?php if($model->isNewRecord == false){ ?>
                         $("#depDropDist").val('<?= $model->district_id ?>');
                   <?php } ?>

                //    if(document.getElementById("depDropDist") !== null){
                //    $("#depDropDist").val($("#depDropDist").val()).change();
                // }
            },
            error: function (res) {
            }
        }); 
        }

</script>
