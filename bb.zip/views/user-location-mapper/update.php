<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\UserLocationMapper */


$this->title = Yii::t('app', 'Update {modelClass}: ', [
    'modelClass' => 'User Location Mapper',
]) . $user_id;
//$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'User Location Mappers'), 'url' => ['index']];
//$this->params['breadcrumbs'][] = ['label' => $user_id, 'url' => ['view', 'id' => $user_id]];
//$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="user-location-mapper-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'searchModel' => $searchModel,
        'dataProvider' => $dataProvider,
        'user_id' => $user_id,
        'model' => $model,
    ]) ?>

</div>
