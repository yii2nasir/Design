<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;
use kartik\select2\Select2;
use app\models\RpcCentre;

/* @var $this yii\web\View */
/* @var $model app\models\UserLocationMapper */
/* @var $form yii\widgets\ActiveForm */
//print_R($model->user_id); 
//print_R($model->level_id);


?>

<style>
.bgCss{
    background-color: #e3f1f7;
    padding: 3%;
}
.fs-wrap.multiple.fs-default.fs-open{
        margin: -76px 0px 0px 0px ! important;
}
.kv-plugin-loading.loading-rpcCentre{
        margin: 0px 0px -24px 0px ! important;
}
.fs-wrap{
        width: 222px !important;
}
.select2-selection.select2-selection--multiple{
    position: relative;
    top: 3px !important;
}
 button.btn.btn-success,.btn.btn-success:focus{
    margin: 22px 0px 0px 40px;
    width:12%;
    background: cadetblue;
    border-style: none;
}
</style>



  <link rel="stylesheet" href="<?php echo Url::to("@web/mcss/select2.min.css"); ?>" />
    <link rel="stylesheet" href="<?php echo Url::to("@web/mcss/select2-bootstrap.css") ?>" />
    <script id='selectTwoJs' src="<?php echo Url::to("@web/mjs/select2.min.js"); ?>"></script>

    <script type="text/javascript">
            $(document).ready(function () {
                $("select").select2({
                    width: '100%',
                    theme: "bootstrap",
                    cache: true
                });
            });
    </script>

<div class="user-location-mapper-form">
    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_content">
                    <?= $form->field($model, 'user_id')->hiddenInput()->label(false) ?>
                    <?= $form->field($model, 'level_id')->hiddenInput()->label(false) ?> 
                </div>                               
                <div class ='col-md-12 bgCss'>
                    <div class="row">
                   <?php
                    if($model->level_id == 33){ ?>
                        <div class="col-md-6">
                            <?= $form->field($model, 'location_id')->dropDownList(
                            ArrayHelper::map(\app\models\State::find()->all(), 'id', 'name'),
                                [
                                    'prompt' => 'Select State',
                                    'id' => 'state-id',
                                     'multiple'=>true,
                                    'onchange' => 'getStateLists()',
                                ])->label('State');   ?>
                                <span id="msg_state" style="color: red"></span>
                        </div>
                        <?php }elseif ($model->level_id == 35) { ?>
                        <div class="col-md-4">
                            <?= $form->field(new app\models\State(), 'id')->dropDownList(
                            ArrayHelper::map(\app\models\State::find()->all(), 'id', 'name'),
                                [
                                    'prompt' => 'Select State',
                                    'id' => 'state-id',
                                    'onchange' => 'getStateLists()',
                                ])->label('State');   ?>

                                <span id="msg_state" style="color: red"></span>
                        </div>
                        <div class="col-md-4">                            
                            <?=  $form->field($model, 'location_id')->dropDownList(                                
                                ArrayHelper::map(\app\models\District::find()->select('id,name')->one(),
                                 'id', 'name'),
                                [
                                    'prompt' => 'Select District',
                                    'id' => 'depDropDistrict',
                                    'multiple'=>true,
                                    'onchange' => 'getRpcLists()',
                                ])->label('District');  ?>

                                <span id="msg_district" style="color: red"></span>
                                
                        </div>
                        <?php  } elseif ($model->level_id == 36) { ?>
                        <div class="col-md-3">
                            <?= $form->field(new app\models\State(), 'id')->dropDownList(
                            ArrayHelper::map(\app\models\State::find()->all(), 'id', 'name'),
                                [
                                    'prompt' => 'Select State',
                                    'id' => 'state-id',
                                    'onchange' => 'getStateLists()',
                                ])->label('State');   ?>

                                <span id="msg_state" style="color: red"></span>
                        </div>
                        <div class="col-md-3">                            
                            <?=  $form->field(new app\models\District(), 'id')->dropDownList(                                
                                ArrayHelper::map(\app\models\District::find()->select('id,name')->one(),
                                 'id', 'name'),
                                [
                                    'prompt' => 'Select District',
                                    'id' => 'depDropDistrict',
                                    'onchange' => 'getRpcLists()',
                                ])->label('District');  ?>

                                <span id="msg_district" style="color: red"></span>
                        </div>
                        <div class="col-md-3">
                              <?= $form->field($model, 'location_id')->dropDownList(
                                    ArrayHelper::map(\app\models\RpcCentre::find()->all(), 'id', 'rpc_name'),
                                        [
                                         'id' => 'rpcCentre',
                                        ])->label('RPC Centre');  
                              ?>
                        <span id="msg_rpc" style="color: red"></span>
                       </div>
                        <?php }elseif ($model->level_id == 37){ ?>
                        <div class="col-md-3">
                            <?= $form->field(new app\models\State(), 'id')->dropDownList(
                            ArrayHelper::map(\app\models\State::find()->all(), 'id', 'name'),
                                [
                                    'prompt' => 'Select State',
                                    'id' => 'state-id',
                                    'onchange' => 'getStateLists()',
                                ])->label('State');   ?>

                                <span id="msg_state" style="color: red"></span>
                        </div>
                        <div class="col-md-3">                            
                            <?=  $form->field(new app\models\District(), 'id')->dropDownList(                                
                                ArrayHelper::map(\app\models\District::find()->select('id,name')->one(),
                                 'id', 'name'),
                                [
                                    'prompt' => 'Select District',
                                    'id' => 'depDropDistrict',
                                    'onchange' => 'getRpcLists()',
                                ])->label('District');  ?>

                                <span id="msg_district" style="color: red"></span>
                        </div>
                        <div class="col-md-3">
                              <?= $form->field($model, 'location_id')->dropDownList(
                                    ArrayHelper::map(\app\models\RpcCentre::find()->all(), 'id', 'rpc_name'),
                                        [
                                         'multiple'=>true,   
                                         'id' => 'rpcCentre',
                                        ])->label('RPC Centre');  
                              ?>
                        <span id="msg_rpc" style="color: red"></span>
                       </div>
                      <?php } ?>

                        <div class="form-group" style="margin: 24px 0px 0px 0px; margin-top: 1px">
                            <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Assign') : 
                            Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn 
                            btn-success btncreate ' : 'btn btn-primary btncreate']) ?>
                        </div>
                    </div>
                </div>
                <?php ActiveForm::end(); ?>
                <div>
                    <?= $this->render('index',
                        [                            
                            'searchModel' => $searchModel,
                            'user_id' => $user_id,
                            'level_id' => $model->level_id,
                            'dataProvider' => $dataProvider,
                        ]); 
                        ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Head -->
<script>

       function getStateLists(){
        var state_id = document.getElementById("state-id").value;
        $.ajax({
            url: '<?php echo Url::to(["site/lists"]); ?>',
            type: 'post',
            data: {
                type : 1,
                id : state_id
            },
            success: function (res) {
                var districtData = JSON.parse(res);
                var areaOption = "<option value=''>Select District</option>";
                for (var i = 0; i < districtData.length; i++) {
                areaOption += '<option value="' + districtData[i]['id'] + '">' + districtData[i]['name'] + '</option>'
               }
               $("#depDropDistrict").html(areaOption);
        },
        error: function (res) {
        }
    }); 
}
    
function getRpcLists(){
    var district_id = document.getElementById("depDropDistrict").value;
    $.ajax({
        url: '<?php echo Url::to(["site/lists"]); ?>',
        type: 'post',
        data: {
            type : 2,
            id : district_id
        },
        success: function (res) {
            var rpcCentre = JSON.parse(res);
            // var areaOption = "<option value=''>Select RPC</option>";
            var areaOption = "";
            for (var i = 0; i < rpcCentre.length; i++) {
               areaOption += '<option value="' + rpcCentre[i]['id'] + '">' + rpcCentre[i]['rpc_name'] + '</option>'
           }
           $("#rpcCentre").html(areaOption);
    },
    error: function (res) {
    }
}); 
}


$(".btncreate").click(function(){
    var state_id = $("#state-id").val();
    var depDropDistrict = $("#depDropDistrict").val();
    var rpcCentre = $("#rpcCentre").val();

    var flage = 0;
  

     if(state_id ==""){
       $("#msg_state").html("State Name cannot be blank.");
       flage++;
     }else{
       $("#msg_state").html("");
     }
     if(depDropDistrict ==""){
       $("#msg_district").html("District Name cannot be blank.");
       flage++;
     }else{
       $("#msg_district").html("");
     }
     if(state_id ==""){
       $("#msg_rpc").html("RPC Center cannot be blank.");
       flage++;
     }else{
       $("#msg_rpc").html("");
     }

      if(flage != 0){
       return false;
     }
});
</script>

