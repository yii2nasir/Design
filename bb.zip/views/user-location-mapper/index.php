<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $searchModel app\models\search\UserLocationMapperSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'User Location Mappers');
// $this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-location-mapper-index">

    <h1><?php  Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= Html::submitButton('Search', ['class' => 'btn btn-primary','style'=>'display:none']) ?>
        <?php //Html::a(Yii::t('app', 'Create User Location Mapper'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>




    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        // 'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn','header' => 'S.No'],

            //'id',
           
            [
                'attribute' => 'level_id',
                'value' => function($data){
                    
                    if($data->level_id == 33){
                        return "State Coordinator";
                    }
                    if($data->level_id == 35){
                        return "District Coordinator";
                    }
                    if($data->level_id == 36){
                        return "RPC User";
                    }
                    if($data->level_id == 37){
                        return "RPC Coordinator";
                    }
                }
            ],
            [
                'attribute' => 'State',
                'value' => function($data){
                    if($data->level_id == 33){
                        return $data->getStateName($data->level_id,$data->location_id);
                    }else{
                        return $data->getStateName($data->level_id,$data->location_id);
                    }

                }
            ],
            [
                'attribute' => 'District',
                'visible'=> $level_id == 35 || $level_id == 36 || $level_id == 37 ? true : false,
                'value' => function($data){
                    if($data->level_id == 35 ||  $data->level_id == 37){
                        return $data->getDistrictName($data->level_id,$data->location_id);
                    }else{
                        return "";
                    }

                }
            ],
            


            [
                'attribute' => 'RPC Centre',
                'visible' => $level_id == 36 || $level_id == 37 ? true : false,
                'value' => function($data){
                    if($data->level_id == 1){
                        return "";
                    }else{
                        return $data->getRpcCenterName($data->level_id,$data->location_id);
                    }
                }
            ],

          [
                   'class' => 'yii\grid\ActionColumn',
                    'contentOptions'=>['style'=>'width: 60px;text-align: center;'],
                    'header'=>'Action', 
                    'template' => '{delete}',
                    'buttons' => [

                        'delete' => function ($url, $model) {
                            return Html::a('<span class="glyphicon glyphicon-trash" onclick="ask_confirm(\''.$model->id.'\',\''.Yii::$app->controller->id .'\')"></span>', $url, [
                                        'title' => Yii::t('app', 'Delete'),                        
                            ]);
                        },
                    ],
                    'urlCreator' => function ($action, $model, $key, $index) {

                        if ($action === 'delete') {
                            $url = "#";
                            return $url;
                        }
                    } 
            ],
        ],
    ]); ?>
    
    <?php ActiveForm::end(); ?>
</div>

