<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\UserLocationMapper */

$this->title = Yii::t('app', 'Assign Location');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'User Location Mappers'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-location-mapper-create">

    <h1 style="font-size: 30px;"><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [

        'searchModel' => $searchModel,
        'dataProvider' => $dataProvider,
        'user_id' => $user_id,
        'model' => $model,
    ]) ?>

</div>
