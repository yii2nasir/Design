<?php
/* @var $this \yii\web\View */
/* @var $content string */
    
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;
use yii\helpers\Url;
use yii\helpers\ArrayHelper;
AppAsset::register($this);

?>
<style type="text/css">
    .nav_menu{
        background: rgb(47,62,86,6) !important;
    }
    .top_nav .dropdown-menu{
        min-width:20% !important;
    }
    .nav .open>a, .nav .open>a:hover, .nav .open>a:focus {
        background-color: rgb(47,62,86,8) !important;
    }
    .nav>li>a{
         cursor: pointer !important;
    }
   /* ::-webkit-scrollbar{
        overflow: visible;
    }*/
  
   /* .right_col{
        min-height: 600px !important;
        overflow: auto !important;
    }*/
    .nav.side-menu> li.active {
    border-right: 5px solid #D0D0D0 !important; 
    }
    .new_request{
        overflow: hidden;
    }
    label{
        font-size: 17px;
    }
</style>
<?php
$user_level = NULL;
if (isset($_SESSION['login_info'])) {
    $user_level = $_SESSION['login_info']['level_id']; 
}

$pageM = Yii::$app->controller->id . "/" . Yii::$app->controller->action->id;

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['login_info'])) {
    if(strpos($_SERVER['REQUEST_URI'],"v1")){
        header('Content-Type: application/json');
        header('Message : Landed on wrong page');
        http_response_code(404);
        echo json_encode(['success' => false, 'status' => 404, 'message' => "Page not found"]);
        exit;
    }
    if (!isset($_POST['Users']) && $pageM != "users/login") {
        echo '<script>window.location="' . Url::to(['users/login']) . '";</script>';
        
        exit;
    }
}
?>

<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap core CSS -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="<?php echo Url::to("@web/Template/gentelella-master/production/css/bootstrap.min.css"); ?>" rel="stylesheet">

    <link href="<?php echo Url::to("@web/Template/gentelella-master/production/fonts/css/font-awesome.min.css"); ?>" rel="stylesheet">
    <link href="<?php echo Url::to("@web/Template/gentelella-master/production/css/animate.min.css"); ?>" rel="stylesheet">

    <!-- Custom styling plus plugins -->
    <link href="<?php echo Url::to("@web/Template/gentelella-master/production/css/custom.css"); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo Url::to("@web/Template/gentelella-master/production/css/maps/jquery-jvectormap-2.0.1.css"); ?>" />
    <link href="<?php echo Url::to("@web/Template/gentelella-master/production/css/icheck/flat/green.css"); ?>" rel="stylesheet" />
    <link href="<?php echo Url::to("@web/Template/gentelella-master/production/css/floatexamples.css"); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo Url::to("@web/css/pnotify.custom.min.css"); ?>" rel="stylesheet" type="text/css" />
     <link href="<?php echo Url::to("@web/mcss/formCss.css"); ?>" rel="stylesheet" type="text/css" />
    
    

    <!--<script src="Template/gentelella-master/production/css/bootstrap-latest/js/bootstrap.min.js"></script>-->
    <script src="<?php echo Url::to("@web/Template/gentelella-master/production/js/jquery.min.js"); ?>"></script>
    <script src="<?php echo Url::to("@web/Template/gentelella-master/production/js/nprogress.js"); ?>"></script>
    <script src="<?php echo Url::to("@web/Template/gentelella-master/production/js/input_mask/jquery.inputmask.js"); ?>"></script>

    <link href="<?php echo Url::to("@web/css/toastr.css"); ?>" rel="stylesheet"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
    <script src="<?php echo Url::to("@web/js/toastr.js"); ?>"></script>
    <script type="text/javascript" src="<?php echo Url::to("@web/js/pnotify.custom.min.js"); ?>"></script>


  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
 <script>
  $( function() {
    $(".datepicker" ).datepicker({
         dateFormat: 'yy-mm-dd'
     }

        );
     });
  </script>

<?php if (Yii::$app->session->hasFlash('success')){ ?>
       <script type="text/javascript">
           toastr.success('Successfully Save Member');
       </script>
  <?php } else if(Yii::$app->session->hasFlash('error')){ ?>
       <script type="text/javascript">
           toastr.success('Got While Error');
       </script>
   <?php } ?>

    <script type="text/javascript">


      // Delete Alert Box
        
    function ask_confirm(id,controller){
        $.ajax({
            type: "GET",
            url: '../site/get-alert?id='+id+'&controller='+controller,
            success: function(data) {
                $('#alert_container').html(data);
                $('#myModal').modal('show');
            }
         });
        }


    function uploadCsv(controller,action){
        $.ajax({
            type: "GET",
            url: '../site/upload-csv-modal?controller='+controller+"&action="+action,
            success: function(data) {
                $('#alert_container').html(data);
                $('#uploadCsv').modal('show');
            }
         });
     } 
    </script>


  
 <style type="text/css">
   .close_button{
      position: absolute;
      background: red;
      color: #fff;
      padding: 3px 5px;
      border-radius: 50%;
      top: -10px;
      right: -10px;
   }
   .ap_overlay{
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: #fff;
        opacity: 0.9;
        display: none; 
        z-index: 100;
    }

    .ap_container{
        position: absolute;
        top: 40%;
        left: 40%;
        text-align: center;
        display: none; 
        width: 20%;
        z-index: 100;
        height: 20%;
    }
    .ap_container img{
        width: 30%;
    }
    .no_action{ pointer-events: none;}
</style>

<style type="text/css">
            #sticky {
                width:100%;
                padding:16px;
                padding-bottom:16px;
                background:black;
                color:white;
                font-weight:bold;
                font-size:18px;
                text-align:center;
                position:fixed;    /*Here's what sticks it*/
                bottom:0;          /*to the bottom of the body*/
                left:0;            /*and to the left of the body.*/
                z-index:999999;
                /*EFFECTS*/
                background:rgba(0, 0, 0, .3) /*the a value of .5 makes it transparent*/
            }
</style>
</head>

<div id="alert_container"></div>
    
<?php



        $main_index = 0;
        $sub_index = 0;
    
        $mainMenuC = array();
        
        $mainMenuC['options']['class'] = 'navbar-nav navbar-right';
        
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        
        if(isset($_SESSION['login_info']))
        {
            
            
            /*
             * Users TAB
             */
            $submenuAvailable = false;
            $main_index++;
            $sub_index = -1;
            
            $page = 'users/create';
            
                $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'Users';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true;
            $page = 'users/index';
            
                $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'Edit Users';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true;
            $page = 'user-type/index';
           
            if($submenuAvailable == true)
            {
                $mainMenuC['items'][$main_index]['label'] = 'Manage Users';
                $mainMenuC['items'][$main_index]['icon'] = 'users';
            }
            else
            {
                unset($mainMenuC['items'][$main_index]);
                $main_index--;
            }
            
            
            
            
            
          
         
          //////// Master

            $submenuAvailable = false;
            $main_index++;
            $sub_index = -1;
            
            $page = 'state/index';
                $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'State';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true;

            $page = 'district/index';
                $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'District';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true;

            $page = 'rpc-centre/index';
                $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'RPC Center';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true; 

           $page = 'category/index';
                $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'Category';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true;         


           $page = 'sub-category/index';
                $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'Sub category';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true; 

                $page = 'sub-sub-category/index';
                $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'Sub-Sub category';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true;    
                
            $page = 'product/index';
                $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'Product';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true;           
            
            $page = 'supplier/index';
                $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'Supplier';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true;

            // $page = 'new-request/index';
            //     $sub_index++;
            //     $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'New Request';
            //     $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
            //     $submenuAvailable = true;    

            $page = 'qc-check-phy-chemical/index';
                $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'QC Checks';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true;  

            $page = 'qc-check-phy-chemical/processing-mapper';
                $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'Processing Mapper';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true;  

            $page = 'fumigation-type/index';
                $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'Fumigation Type';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true;

            if($submenuAvailable == true)
            {
                $mainMenuC['items'][$main_index]['label'] = 'Master';
                $mainMenuC['items'][$main_index]['icon'] = 'th';
            }
            else
            {
                unset($mainMenuC['items'][$main_index]);
                $main_index--;
            }


        
           /*
             * User Levles TAB
             */
            $submenuAvailable = false;
            $main_index++;
            $sub_index = -1;
            
            $page = 'report/incoming-bulk-inspection';
            
                $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'Incoming Bulk Inspection';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true;


               $page = 'report/final-goods-inspection';
            
                $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'Final Goods Inspection';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true;
                

                $page = 'report/fg-list-template';
            
                $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'FG QC Check Details';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true;       

                $page = 'report/rpc-report';
            
                $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'All Stages';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true;
    

            if($submenuAvailable == true)
            {
                $mainMenuC['items'][$main_index]['label'] = 'Report';
                $mainMenuC['items'][$main_index]['icon'] = 'at';
            }
            else
            {
                unset($mainMenuC['items'][$main_index]);
                $main_index--;
            }

        }
        else
        {
            /*
             * Users TAB
             */
            $submenuAvailable = false;
            $main_index++;
            $sub_index = -1;
            
            $page = 'users/login';
            $sub_index++;
                $mainMenuC['items'][$main_index]['items'][$sub_index]['label'] = 'Users';
                $mainMenuC['items'][$main_index]['items'][$sub_index]['url'][0] = $page;
                $submenuAvailable = true;
            
            if($submenuAvailable == true)
            {
                $mainMenuC['items'][$main_index]['label'] = 'Account';
                $mainMenuC['items'][$main_index]['icon'] = 'users';
            }
            else
            {
                unset($mainMenuC['items'][$main_index]);
                $main_index--;
            }
        }


?>

<body class="nav-md">

    <div class="container body">


        <div class="main_container">

            <div class="col-md-3 left_col" >
                <div class="left_col scroll-view" >

                    <div class="navbar nav_title" style="border: 0;">
                        
                        <a href="<?php echo Url::base(); ?>" class="site_title" id="logo_show"><img src="<?php echo Url::to("@web/images/bigbasket.png"); ?>"  width="100%" height="100%" style="margin-top: 0px;cursor: pointer;"> </a>
                        <a href="<?php echo Url::base(); ?>" class="site_title1" id="logo_hide" style="display: none;"><img src="<?php echo Url::to("@web/images/logo(1).png"); ?>" onclick="return false" width="100%" height="100%" style="margin-top: 0px;cursor: pointer;"> </a>
                    </div>
                    <div class="clearfix"></div>

                    <br />

                    <!-- sidebar menu -->
                    <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                     
                        <div class="menu_section">
                            <ul class="nav side-menu" id="sidemenu">
                            <li class="active"><a href="<?php echo Url::base(); ?>"><i class="fa fa-dashboard"></i>Dashboard</a></li>
                                <?php
                                if(isset($mainMenuC['items']))
                                {
                                    foreach ($mainMenuC['items'] as $key => $value) {
                                        echo '<li><a><i class="fa fa-'.$mainMenuC['items'][$key]['icon'].'"></i>'.$mainMenuC['items'][$key]['label'].'<span class="fa fa-chevron-left"></span></a>';
                                        echo '<ul class="nav child_menu" style="display: none">';

                                        for($si=0;$si<count($mainMenuC['items'][$key]['items']);$si++)
                                        {
                                            echo '<li><a href="'.Url::toRoute($mainMenuC['items'][$key]['items'][$si]['url'][0]).'">'.$mainMenuC['items'][$key]['items'][$si]['label'].'</a></li>';
                                        }
                                        echo '</ul>';
                                        echo '</li>';
                                    }
                                }
                                ?>
                                <li class="new_request"><a href="<?php echo Url::to(['all-proccess/index']) ?>"><i class="fa fa-plus-square-o"></i>New Request</a></li>
                            </ul>
                        </div>
                        

                    </div>
                </div>
            </div>

            <!-- top navigation -->
            <div class="top_nav">
             
                <div class="nav_menu">
                    <nav class="" role="navigation">
                        <div class="nav toggle " style=" float: left;margin-top: -15px;">
                            <a id="menu_toggle" onclick="myFunction()" style="float: left; color: #FFFFFF"><i class="fa fa-bars"></i> </a>
                        </div>
                        <!--<div style=" margin-top: 10px;float: left;font-size: 25px; color: #FFFFFF !important" >Big Basket RPC</div>-->

                        <ul class="nav navbar-nav navbar-right">
                            <li role="presentation" class="dropdown">
                              
                                <ul id="menu1" class="dropdown-menu list-unstyled msg_list animated fadeInDown" role="menu">
                                    <li>
                                        <a>
                                            <span>
                                        <span></span>
                                        <span class="time"></span>
                                            </span>
                                            <span class="message">
                                            </span>
                                        </a>
                                    </li>
                                   
                                    <li>
                                        <div class="text-center">
                                            <a href="<?php echo Url::to(['notifications/notifications']) ?>">
                                                <strong>See All Alerts</strong>
                                                <i class="fa fa-angle-right"></i>
                                            </a>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                            <li class="">
                                <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                    <!-- <img src="../images/img.jpg" alt=""> -->
                                    

<!-- 
                                <div style="float:right">
                                  <form align="right" name="form1" method="post" action="log_out.php">
                                       <label class="logoutLblPos">
                                          <input name="submit2" type="submit" id="submit2" value="log out">
                                       </label>
                                  </form>
                               </div> -->

                                    
                                    <?php
                                    
                                    if(isset($_SESSION['login_info']))
                                     {
                                       $level_id =  unserialize(serialize($_SESSION['login_info']['level_id']));
                                        $userLevelName = \app\models\UserLevels::find()->where(['id'=>$level_id])->one();
                                        $showUserNamee = unserialize(serialize($_SESSION['login_info']))->name
                                            .":".unserialize(serialize($_SESSION['login_info']))->username;
                                        if($userLevelName)
                                        {
                                           echo $showUserNamee = $userLevelName->level_name ;
                                       
                                        }
                                    }

                                    ?>
                                    
                                </a>
                                <ul class="dropdown-menu dropdown-usermenu animated fadeInDown pull-right">
                                    <!-- <li>
                                        <a href="javascript:;">Help</a>
                                    </li> -->
                                   <!--  <li>
                                        <a href="index.php?r=users/change-password">Change Password</a>
                                    </li> -->
                                    <li><a class="logout" href="<?php echo Url::to(['users/logout']) ?>"> Log Out</a>
                                    </li>
                                </ul>
                            </li>

                        </ul>
                    </nav>
                </div>

            </div>

           <div class="right_col" role="main">
                    <?= $content ?>
            </div>

        </div>

    </div>

    <div id="custom_notifications" class="custom-notifications dsp_none">
        <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
        </ul>
        <div class="clearfix"></div>
        <div id="notif-group" class="tabbed_notifications"></div>
    </div>

    <script src="<?php echo Url::to("@web/Template/gentelella-master/production/js/bootstrap.min.js"); ?>"></script>
    <!-- bootstrap progress js -->
    <script src="<?php echo Url::to("@web/Template/gentelella-master/production/js/progressbar/bootstrap-progressbar.min.js"); ?>"></script>
    <script src="<?php echo Url::to("@web/Template/gentelella-master/production/js/nicescroll/jquery.nicescroll.min.js"); ?>"></script>
    <!-- icheck -->
    <script src="<?php echo Url::to("@web/Template/gentelella-master/production/js/icheck/icheck.min.js"); ?>"></script>
    <!-- daterangepicker -->
    <script type="text/javascript" src="<?php echo Url::to("@web/Template/gentelella-master/production/js/moment.min.js"); ?>"></script>
    <script type="text/javascript" src="<?php echo Url::to("@web/Template/gentelella-master/production/js/datepicker/daterangepicker.js"); ?>"></script>

    <script src="<?php echo Url::to("@web/Template/gentelella-master/production/js/custom.js"); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>

  


  

    <script type="text/javascript">
        $(document).ready(function () {
            $('.make_it_select').val('').select2();
            $('.rpc_select').val('<?= Yii::$app->request->get('rpc_id')?>').select2();
            $('.product_select').val('<?= Yii::$app->request->get('product_id')?>').select2();
            $('.batch_select').val('<?= Yii::$app->request->get('batch_id')?>').select2();


            var cb = function (start, end, label) {
                console.log(start.toISOString(), end.toISOString(), label);
                $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
                //alert("Callback has fired: [" + start.format('MMMM D, YYYY') + " to " + end.format('MMMM D, YYYY') + ", label = " + label + "]");
            }

            var optionSet1 = {
                startDate: moment().subtract(29, 'days'),
                endDate: moment(),
                minDate: '01/01/2012',
                maxDate: '12/31/2015',
                dateLimit: {
                    days: 60
                },
                showDropdowns: true,
                showWeekNumbers: true,
                timePicker: false,
                timePickerIncrement: 1,
                timePicker12Hour: true,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                opens: 'left',
                buttonClasses: ['btn btn-default'],
                applyClass: 'btn-small btn-primary',
                cancelClass: 'btn-small',
                format: 'MM/DD/YYYY',
                separator: ' to ',
                locale: {
                    applyLabel: 'Submit',
                    cancelLabel: 'Clear',
                    fromLabel: 'From',
                    toLabel: 'To',
                    customRangeLabel: 'Custom',
                    daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                    monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                    firstDay: 1
                }
            };
            $('#reportrange span').html(moment().subtract(29, 'days').format('MMMM D, YYYY') + ' - ' + moment().format('MMMM D, YYYY'));
            $('#reportrange').daterangepicker(optionSet1, cb);
            $('#reportrange').on('show.daterangepicker', function () {
                console.log("show event fired");
            });
            $('#reportrange').on('hide.daterangepicker', function () {
                console.log("hide event fired");
            });
            $('#reportrange').on('apply.daterangepicker', function (ev, picker) {
                console.log("apply event fired, start/end dates are " + picker.startDate.format('MMMM D, YYYY') + " to " + picker.endDate.format('MMMM D, YYYY'));
            });
            $('#reportrange').on('cancel.daterangepicker', function (ev, picker) {
                console.log("cancel event fired");
            });
            $('#options1').click(function () {
                $('#reportrange').data('daterangepicker').setOptions(optionSet1, cb);
            });
            $('#options2').click(function () {
                $('#reportrange').data('daterangepicker').setOptions(optionSet2, cb);
            });
            $('#destroy').click(function () {
                $('#reportrange').data('daterangepicker').remove();
            });
        });
    </script>
    
    <script>
        $(document).ready(function () {
            $(":input").inputmask();
        });
    </script>
    <script type="text/javascript">
        function myFunction() {
          var logo_big = document.getElementById("logo_show");
          var logo_short = document.getElementById("logo_hide");
          if (logo_short.style.display === "none") {
            logo_short.style.display = "block";
            logo_big.style.display = "none";
          } else {
         logo_big.style.display = "block";
         logo_short.style.display = "none";
      }
    }
    </script>
    <script type="text/javascript">
        $('#sidemenu li a').click(function(){
           $(this).find('span').toggleClass('fa-chevron-left fa-chevron-down');
        });
        $("body").on('click','.img_popup',function(ev)
        {
            ev.preventDefault();
            var imgsrc = $(this).attr('href');
            if(imgsrc != '')
            {
                $("#modddal_img").attr('src',imgsrc);
                $("#modddal").modal('show');
            }
        });
    </script>
</body>

</html>