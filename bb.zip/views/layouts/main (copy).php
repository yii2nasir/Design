<?php
/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\widgets\Menu;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;
use \yii\helpers\Url;
use kartik\nav\NavX;
AppAsset::register($this);
?>
<?php
$user_level = NULL;
if (isset($_SESSION['login_info'])) {
    $user_level = $_SESSION['login_info']['level_id']; 
}

$pageM = Yii::$app->controller->id . "/" . Yii::$app->controller->action->id;

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['login_info'])) {
    if(strpos($_SERVER['REQUEST_URI'],"v1")){
        header('Content-Type: application/json');
        header('Message : Landed on wrong page');
        http_response_code(404);
        echo json_encode(['success' => false, 'status' => 404, 'message' => "Page not found"]);
        exit;
    }
    if (!isset($_POST['Users']) && $pageM != "users/login") {
        echo '<script>window.location="' . Url::to(['users/login']) . '";</script>';
        
        exit;
    }
}
?>


<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
    <head>
        <link rel="icon" href="<?php echo Url::to("@web/images/sk.png"); ?>"  sizes="16x16">
        <meta charset="<?= Yii::$app->charset ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?= Html::csrfMetaTags() ?>
        <title><?= Html::encode($this->title) ?></title>
<?php $this->head() ?>    
        <style type="text/css">
            #sticky {
                width:100%;
                padding:16px;
                padding-bottom:16px;
                background:black;
                color:white;
                font-weight:bold;
                font-size:18px;
                text-align:center;
                position:fixed;    /*Here's what sticks it*/
                bottom:0;          /*to the bottom of the body*/
                left:0;            /*and to the left of the body.*/
                z-index:999999;
                /*EFFECTS*/
                background:rgba(0, 0, 0, .3) /*the a value of .5 makes it transparent*/
            }
            .logoutBtn{
                color: #ecf0f1 !important;
            } 
            .logoutBtn:hover{
                text-decoration: none;

            } 


            .navbar-inverse  {
                 background-color: #43a047;
                 border-color: #43a047;
            }
            .navbar-inverse  .navbar-brand {
                color: #ecf0f1;
            }
            .navbar-inverse  .navbar-brand:hover,
            .navbar-inverse  .navbar-brand:focus {
                color: #ffffff;
            }
            .navbar-inverse  .navbar-text {
                color: #ecf0f1;
            }
            .navbar-inverse  .navbar-nav > li > a {
                color: #ecf0f1;
            }
            .navbar-inverse  .navbar-nav > li > a:hover,
            .navbar-inverse  .navbar-nav > li > a:focus {
                color: #ffffff;
            }
            /*.navbar-inverse  .navbar-nav  .dropdown > ul > li  > a,*/
            .navbar-inverse  .navbar-nav  .dropdown  > ul > li  > a:hover{
                color: #ffffff;
                background-color: #00008B;
            }
            .navbar-inverse  .navbar-nav > .active > a,
            .navbar-inverse  .navbar-nav > .active > a:hover,
            .navbar-inverse  .navbar-nav > .active > a:focus {
                color: #ffffff;
                background-color: #00008B;
            }
            .navbar-inverse  .navbar-nav > .open > a,
            .navbar-inverse  .navbar-nav > .open > a:hover,
            .navbar-inverse  .navbar-nav > .open > a:focus {
                color: #ffffff;
                background-color: #00008B;
            }
            .navbar-inverse  .navbar-toggle {
                border-color: #DEB887;
            }
            .navbar-inverse  .navbar-toggle:hover,
            .navbar-inverse  .navbar-toggle:focus {
                background-color: #00008B;
            }
            .navbar-inverse  .navbar-toggle .icon-bar {
                background-color: #ecf0f1;
            }
            .navbar-inverse  .navbar-collapse,
            .navbar-inverse  .navbar-form {
                border-color: #ecf0f1;
            }
            .navbar-inverse  .navbar-link {
                color: #ecf0f1;
            }
            .navbar-inverse  .navbar-link:hover {
                color: #ffffff;
            }

            @media (max-width: 767px) {
                .navbar-inverse  .navbar-nav .open .dropdown-menu > li > a {
                    color: #ecf0f1;
                }
                .navbar-inverse  .navbar-nav .open .dropdown-menu > li > a:hover,
                .navbar-inverse  .navbar-nav .open .dropdown-menu > li > a:focus {
                    color: #ffffff;
                }
                .navbar-inverse  .navbar-nav .open .dropdown-menu > .active > a,
                .navbar-inverse  .navbar-nav .open .dropdown-menu > .active > a:hover,
                .navbar-inverse  .navbar-nav .open .dropdown-menu > .active > a:focus {
                    /*color: #ffffff;*/
                    background-color: #00008B;
                }
            }

            .container { 
                width: 96%;
            }

   /*         .navbar-inverse {
    background-color: #43a047;
    border-color: #43a047;
}*/

        </style>
    </head>
    <body>
        <?php
            $admin = [
                        'options' => ['class' => 'navbar-nav navbar-right'],
                        'items' => [
                            ['label' => 'Home', 'url' => ['/site/index']],
                            [
                                'label' => 'Masters',
                                'items' => [
                                    ['label' => 'State', 'url' => ['/state/index/']],
                                    ['label' => 'District', 'url' => ['/district/index/']],
                                    ['label' => 'Rpc centre', 'url' => ['/rpc-centre/index/']],
                                    ['label' => 'Category', 'url' => ['/category/index/']],
                                    ['label' => 'Sub category', 'url' => ['/sub-category/index/']],
                                    ['label' => 'Product', 'url' => ['/product/index/']],
                                    ['label' => 'Supplier', 'url' => ['/supplier/index/']],

                                ],
                            ],
                            [
                                'label' => 'User',
                                'items' => [
                                    ['label' => 'Users', 'url' => ['/users/index/']],
                                    ['label' => 'User Level', 'url' => ['/user-levels/index/']],
                                ],
                            ],
                            (
                            '<li>'
                            . Html::beginForm(['/users/logout'], 'post', ['class' => 'navbar-form'])
                            . Html::hiddenInput("logBtn", "789")
                            . Html::submitButton(
                                    'Logout', ['class' => 'btn btn-link logoutBtn']
                            )
                            . Html::endForm()
                            . '</li>'
                            )
                        ],
                    ];
            $management = [
                        'options' => ['class' => 'navbar-nav navbar-right'],
                        'items' => [
                            ['label' => 'Home', 'url' => ['/site/index']],
                            ['label' => 'Dashboard', 'url' => ['/site/dashboard']],
                            ['label' => 'Beneficiary', 'url' => ['/beneficiary/index']],
                            
                            [
                                'label' => 'Activity Data Entry',
                                'items' => [
                                     [
                                        'label' => 'Farm Mechanization',
                                        'options' => ['class' => 'sidebar-menu treeview'],
                                        'items' => [
                                            ['label' => 'Laser Leveler', 'url' => ['/fmll/index']],
                                        ],
                                    ],
                                    ['label' => 'Crop Demonstration ', 'url' => ['/cdem/index']],
                                    ['label' => 'Soil Testing', 'url' => ['/soil-testing/index']],
                                    ['label' => 'Orchard Establishment', 'url' => ['/orchard-establishment/index']],
                                    ['label' => 'Micro Irrigation', 'url' => ['/micro-irrigation/index']],
                                    ['label' => 'Education', 'url' => ['/education/index']],
                                    ['label' => 'Dam Profiling', 'url' => ['/dam-profiling/index']],
                                    ['label' => 'Tracking Point', 'url' => ['/tracking-point/index']],
                                    ['label' => 'Tracking', 'url' => ['/tracking/index']],
                                    //['label' => 'Capacity Building ', 'url' => ['/cb/index']],
                                    ['label' => 'Training and Exposure Visit ', 'url' => ['/exposure/index']],
                                    
                                ],
                            ],
                            (
                            '<li>'
                            . Html::beginForm(['/users/logout'], 'post', ['class' => 'navbar-form'])
                            . Html::hiddenInput("logBtn", "789")
                            . Html::submitButton(
                                    'Logout', ['class' => 'btn btn-link logoutBtn']
                            )
                            . Html::endForm()
                            . '</li>'
                            )
                        ],
                    ];
            $data_entry = [
                        'options' => ['class' => 'navbar-nav navbar-right'],
                        'items' => [
                            ['label' => 'Home', 'url' => ['/site/index']],
                            ['label' => 'Dashboard', 'url' => ['/site/dashboard']],
                            ['label' => 'Beneficiary', 'url' => ['/beneficiary/index']],
                            [
                                'label' => 'Activity Data Entry',
                                'items' => [
                                     [
                                        'label' => 'Farm Mechanization',
                                        'options' => ['class' => 'sidebar-menu treeview'],
                                        'items' => [
                                            ['label' => 'Laser Leveler', 'url' => ['/fmll/index']],
                                        ],
                                    ],
                                    ['label' => 'Crop Demonstration ', 'url' => ['/cdem/index']],
                                    ['label' => 'Soil Testing', 'url' => ['/soil-testing/index']],
                                    ['label' => 'Orchard Establishment', 'url' => ['/orchard-establishment/index']],
                                    ['label' => 'Micro Irrigation', 'url' => ['/micro-irrigation/index']],
                                    ['label' => 'Education', 'url' => ['/education/index']],
                                    ['label' => 'Dam Profiling', 'url' => ['/dam-profiling/index']],
                                    ['label' => 'Tracking Point', 'url' => ['/tracking-point/index']],
                                    ['label' => 'Tracking', 'url' => ['/tracking/index']],
                                    //['label' => 'Capacity Building ', 'url' => ['/cb/index']],
                                    ['label' => 'Training and Exposure Visit ', 'url' => ['/exposure/index']],
                                    
                                ],
                            ],
                            (
                            '<li>'
                            . Html::beginForm(['/users/logout'], 'post', ['class' => 'navbar-form'])
                            . Html::hiddenInput("logBtn", "789")
                            . Html::submitButton(
                                    'Logout', ['class' => 'btn btn-link logoutBtn']
                            )
                            . Html::endForm()
                            . '</li>'
                            )
                        ],
                    ];
            $others = [
                        'options' => ['class' => 'navbar-nav navbar-right'],
                        'items' => [
                            (
                            '<li>'
                            . Html::beginForm(['/users/logout'], 'post', ['class' => 'navbar-form'])
                            . Html::hiddenInput("logBtn", "789")
                            . Html::submitButton(
                                    'Logout', ['class' => 'btn btn-link logoutBtn']
                            )
                            . Html::endForm()
                            . '</li>'
                            )
                        ],
                    ];
            
        ?>
        <?php $this->beginBody() ?>
         
            <div class="wrap">
                <div class="navbar-inverse ">
                    <?php
                    
                    NavBar::begin([
                        'brandLabel' => '<b>Bigbasket SRC</b>',
//                'brandUrl' => Yii::$app->homeUrl,
                        'brandUrl' => ['/site/index'],
                        'options' => [
                            'class' => 'navbar-inverse navbar-fixed-top',
                        ],
                    ]);
                    if($user_level !== NULL && $user_level == 1){
                       echo NavX::widget($admin); 
                    }
                    else if($user_level !== NULL && $user_level == 35){
                        echo NavX::widget($management);
                    }
                    else if($user_level !== NULL && $user_level == 33){
                        echo NavX::widget($data_entry);
                    }
                    else{
                        echo NavX::widget($others);
                    }
                    
                    NavBar::end();

//             . Html::submitButton(
//                                    'Logout (' . Yii::$app->user->identity->username . ')', ['class' => 'btn btn-link']
//                            )
                    ?>
                </div>
                
                    <div class="container">
                        <?=
                        Breadcrumbs::widget([
                            'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
                        ])
                        ?>
                        <?= $content ?>
                    </div>
                </div>
                <!--load common js-->
                <script src="<?php echo Url::to("@web/mjs/common_js.js"); ?>"></script>
                <!--load common CSS-->
                <link rel="stylesheet" href="<?php echo Url::to("@web/mcss/common_css.css"); ?>" />
                <script src="<?php echo Url::to("@web/mjs/jquery.maskedinput.min.js"); ?>"></script>
                        <?php
                        $getController = Yii::$app->controller->id;
                        $getControllerAction = Yii::$app->controller->action->id;
                        if (($getController != "family-details" && ($getControllerAction != "update" || $getControllerAction != "create")) && ($getController != "site" && ($getControllerAction != "graph-agriculture"))) {
                            ?>
                    <!-- select2 css js and bootstrap theme-->
                    <link rel="stylesheet" href="<?php echo Url::to("@web/mcss/select2.min.css"); ?>" />
                    <link rel="stylesheet" href="<?php echo Url::to("@web/mcss/select2-bootstrap.css") ?>" />
                    <script id='selectTwoJs' src="<?php echo Url::to("@web/mjs/select2.min.js"); ?>"></script>
                    <script type="text/javascript">
                        $(document).ready(function () {
                            $("select").select2({
                                width: '100%',
                                theme: "bootstrap",
                                cache: true
                            });
                        });
                    </script>
    <?php
}
?>

                <link rel="stylesheet" href="<?php echo Url::to("@web/mcss/jquery-ui.css"); ?>" />
                <script type="text/javascript" src="<?php echo Url::to("@web/mjs/jquery-ui.js"); ?>"></script>
                <script src="<?php echo Url::to("@web/mjs/jquery-ui-timepicker-addon.min.js"); ?>"></script>
                <script src="<?php echo Url::to("@web/mjs/jquery-ui-sliderAccess.js"); ?>"></script>
                <link rel="stylesheet" href="<?php echo Url::to("@web/mcss/jquery-ui-timepicker-addon.min.css"); ?>" />
<?php $this->endBody() ?>
                </body>
                </html>

                <?php $this->endPage() ?>
