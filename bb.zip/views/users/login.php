<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model app\models\Users */
/* @var $form yii\widgets\ActiveForm */
?>
<style type="text/css">
    #prevslide{
        display: none !important;
    }
     #nextslide{
        display: none !important;
    }
    @media(max-width: 800px) { 
    .modal-dialog {
        margin-left: 200px !important;
        width: 40% !important;
    }
    @media(max-width: 600px) { 
    .modal-dialog {
        margin-left: 120px !important;
        width: 40% !important;
    }
</style>
<html>
    <head>
        <link rel="icon" href="<?php echo Url::to("@web/images/title.png"); ?>" type="image/gif" sizes="16x16">
        <meta charset="<?= Yii::$app->charset ?>">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo Url::to("@web/mcss/supersized.css");?>" type="text/css" media="screen" />
        <link rel="stylesheet" href="<?php echo Url::to("@web/mcss/supersized.shutter.css");?>" type="text/css" media="screen" />

        <!--<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.1/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo Url::to("@web/mjs/jquery.easing.min.js");?>"></script>
        
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo Url::to("@web/mjs/supersized.3.2.7.min.js");?>"></script>
        <script type="text/javascript" src="<?php echo Url::to("@web/mjs/supersized.shutter.min.js");?>"></script>
        
        <?= Html::csrfMetaTags() ?>
        <title>Login</title>
        <style type="text/css">
                    
                    /* #####################################################################
                    #
                    #   Project       : Modal Login with jQuery Effects
                    #   Author        : Rodrigo Amarante (rodrigockamarante)
                    #   Version       : 1.0
                    #   Created       : 07/28/2015
                    #   Last Change   : 08/02/2015
                    #
                    ##################################################################### */

                     #login-modal .modal-dialog {
                         width: 350px;
                     }

                     #login-modal input[type=text], input[type=password] {
                             margin-top: 10px;
                     }

                     #div-login-msg,
                     #div-lost-msg,
                     #div-register-msg {
                         border: 1px solid #dadfe1;
                         height: 30px;
                         line-height: 28px;
                         transition: all ease-in-out 500ms;
                     }

                     #div-login-msg.success,
                     #div-lost-msg.success,
                     #div-register-msg.success {
                         border: 1px solid #68c3a3;
                         background-color: #c8f7c5;
                     }

                     #div-login-msg.error,
                     #div-lost-msg.error,
                     #div-register-msg.error {
                         border: 1px solid #eb575b;
                         background-color: #ffcad1;
                     }

                     #icon-login-msg,
                     #icon-lost-msg,
                     #icon-register-msg {
                         width: 30px;
                         float: left;
                         line-height: 28px;
                         text-align: center;
                         background-color: #dadfe1;
                         margin-right: 5px;
                         transition: all ease-in-out 500ms;
                     }

                     #icon-login-msg.success,
                     #icon-lost-msg.success,
                     #icon-register-msg.success {
                         background-color: #68c3a3 !important;
                     }

                     #icon-login-msg.error,
                     #icon-lost-msg.error,
                     #icon-register-msg.error {
                         background-color: #eb575b !important;
                     }

                     #img_logo {
                         max-height: 350px;
                         max-width: 200px;
                         border-radius: 10px;
                     }

                     /* #########################################
                        #    override the bootstrap configs     #
                        ######################################### */

                     .modal-backdrop.in {
                         filter: alpha(opacity=50);
                         opacity: .2;
                     }

                     .modal-content {
                         background-color: #ececec;
                         border: 1px solid #bdc3c7;
                         border-radius: 0px;
                         outline: 0;
                     }

                     .modal-header {
                         min-height: 16.43px;
                         padding: 15px 15px 15px 15px;
                         border-bottom: 0px;
                     }

                     .modal-body {
                         position: relative;
                         padding: 5px 15px 5px 15px;
                     }

                     .modal-footer {
                         padding: 15px 15px 15px 15px;
                         text-align: left;
                         border-top: 0px;
                     }

                     .checkbox {
                         margin-bottom: 0px;
                     }

                     .btn {
                         border-radius: 0px;
                     }

                     .btn:focus,
                     .btn:active:focus,
                     .btn.active:focus,
                     .btn.focus,
                     .btn:active.focus,
                     .btn.active.focus {
                         outline: none;
                     }

                     .btn-lg, .btn-group-lg>.btn {
                         border-radius: 0px;
                     }

                     .btn-link {
                         padding: 5px 10px 0px 0px;
                         color: #95a5a6;
                     }

                     .btn-link:hover, .btn-link:focus {
                         color: #2c3e50;
                         text-decoration: none;
                     }

                     .glyphicon {
                         top: 0px;
                     }

                     .form-control {
                       border-radius: 0px;
                     }

                    /*    a:hover { 
                         background-color: yellow;
                     }*/


/*                         .footer {
                                 position: absolute;
                                 bottom: 0;
                                 width: 100%;
                                  Set the fixed height of the footer here 
                                 height: 7vh;
                                 background-color: #f5f5f5;
                                 text-align: right;
                         }*/
                       /*  #login_button{
                              float: left;
                              background-color: rgb(137,196,19)  ;  Green 
                              border: 2px solid rgb(169,169,169);
                              margin-top:0.5%;
                              transition: transform .1s;
                              color: white;
                              font-weight: bold;
                              padding: 20px 32px;
                              padding-left: 50px;
                              padding-right: 50px;
                              padding-top: 10px;
                              padding-bottom: 10px;
                              padding: 10px;
                              text-align: center;
                              text-decoration: none;
                              display: inline-block;
                              font-size: 16px;
                              border-radius:7px;
                            
                                border-style: outset  ;  
                               border-left-style: outset  ; 
                              border-bottom-style: outset   ;
                              border-right-style: outset   ; 
                               border-color:white; 
                              
                         }*/
                         #login_button:hover{
                            -webkit-transform: scale(1.0);
                            transform: scale(1.2);
                         }
                         
                        ul#demo-block{ margin:0 15px 15px 15px; }
                        ul#demo-block li{ margin:0 0 10px 0; padding:10px; display:inline; float:left; clear:both; color:#aaa; background:url('../../images/bg-black.png'); font:11px Helvetica, Arial, sans-serif; }
                        ul#demo-block li a{ color:#eee; font-weight:bold; }
                        #lost_login_btn{ border-radius:15px;background-color: green; border: 2px solid rgb(169,169,169);}
                        .modal-content{
                            background-color:#e8f5e9;
                            border-radius: 10px;
                        }
                        .modal-dialog{
                               margin-top:12%;       
                               
                        } 
                        #login_username{
                            border-radius:15px;
                        } 
                        #login_password{
                            border-radius:15px;
                        }
                        .modal-content{
                            background-color: rgb(150,200,70);opacity: 0.90;filter: alpha(opacity=40);
                             height: 44% !important;
                        }
                         
        </style>
        <script type="text/javascript">
            
            jQuery(function($){
                
                $.supersized({
                
                    // Functionality
                    slide_interval          :   3000,       // Length between transitions
                    transition              :   3,          // 0-None, 1-Fade, 2-Slide Top, 3-Slide Right, 4-Slide Bottom, 5-Slide Left, 6-Carousel Right, 7-Carousel Left
                    transition_speed        :   700,        // Speed of transition
                                                               
                    // Components                           
                    slide_links             :   'blank',    // Individual links for each slide (Options: false, 'num', 'name', 'blank')
                    slides          :  [            // Slideshow Images
                                                                        // {image : '../../images/b_13.jpg', title : '© 2016, Dhwani Rural Information System, All rights reserved', thumb : '../../images/b_13.jpg', url : '../../images/b_13.jpg'},
                                                                        {image : '../../images/b_12.jpg', title : '© 2016, Dhwani Rural Information System, All rights reserved', onclick: 'return false' , thumb : '../../images/b_12.jpg', url : '../../images/b_12.jpg'},
                                                                        {image : '../../images/b.jpg', title : '© 2016, Dhwani Rural Information System, All rights reserved', thumb : '../../images/b.jpg', url : '../../images/b.jpg'},
                                                        
                                                                   ]
                    
                });
            });
            
        </script>
                
    </head>
    <body>
        <?php
        if (isset($_GET['error'])) {
            ?> 
            <script>
                alert("<?php echo $_GET['error']; ?>");
            </script>
            <?php
        }
        ?> 
            <!-- <div class="col-md-12 col-sm-12 col-xs-12" ><button  id="login_button"   data-toggle="modal" data-target="#login-modal">Login</button></div>     -->
      
        <!-- BEGIN # MODAL LOGIN -->
                <div class="modal fade"  id="login-modal" tabindex="-1" data-backdrop="static" data-keyboard="false" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: block;">
                    <div class="modal-dialog" style="width:38%; " >
                        <div class="modal-content" >
                            <div class="modal-header" align="center">
                                <img  id="img_logo" src="<?php echo Url::to("@web/images/logo.jpg"); ?>">
                               <!--   <button type="button" class="close" data-dismiss="modal" aria-label="Close"> 
                                    <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                                </button> -->
                            </div>

                            
                            <?php $form = ActiveForm::begin(); ?>              
                            <!-- Begin # DIV Form -->
                            <div id="div-forms" >

                                <!-- Begin # Login Form -->
                                <form id="login-form">
                                    <div class="modal-body" >
                                        <!-- <div id="div-login-msg"> -->
                                            <!-- <div id="icon-login-msg" class="glyphicon glyphicon-chevron-right"></div> -->
                                            <h4 id="text-login-msg" style="text-align:center;"><b><u>Login to continue</u></b></h4>
                                        <!-- </div> -->
                                        
                                       <!--Start: It will show error message if username and password will be wrong-->
                                        <?php
                                            if (isset($error)) {
                                                echo " <p class='fa fa-exclamation-triangle' style='color: #ed2553; padding-left:20px;margin-top:-7px;margin-bottom:-7px;'> {$error}</p>";}
                                                Html::submitButton('Log In >', [ 'style'=>"margin-top:-10px;",'id' => "lost_login_btn",  'type' => "button", 'class' => 'btn btn-primary btn-lg btn-block', 'name' => 'login-button'])
                                            
                                        ?>
                                       <!--End: It will show error message if username and password will be wrong-->
                                       
                                        <input id="login_username" class="form-control" type="text" name="Users[user_name]" placeholder="Enter Username" required />
                                            <input  id="login_password" class="form-control"  name="Users[password]" type="password" placeholder="Password" required/>
                                    </div>
                                    <div class="modal-footer">
                                        <div>
                                            <span>
                                                <?= Html::submitButton('Log In >', [ 'style'=>'','id' => "lost_login_btn",  'type' => "button", 'class' => 'btn btn-primary btn-lg btn-block', 'name' => 'login-button']) ?>
                                            </span>
                                        </div>
                                        <div>
                                            <!--<button id="login_lost_btn" type="button" class="btn btn-link">Forgot Passward?</button>-->
                                        </div>
                                    </div>
                                </form>
                                <!-- End # Login Form -->

                                <!-- Begin | Lost Password Form -->
                                <form id="lost-form" style="display:none;">
                                    <div class="modal-body">
                                        <div id="div-lost-msg">
                                            <div id="icon-lost-msg" class="glyphicon glyphicon-chevron-right"></div>
                                            <span id="text-lost-msg">Type your e-mail.</span>
                                        </div>
                                        <input id="lost_email" class="form-control" type="text" placeholder="E-Mail (type ERROR for error effect)" required>
                                    </div>
                                    <div class="modal-footer">
                                        <div>
                                            <button type="submit" class="btn btn-primary btn-lg btn-block">Send</button>
                                        </div>
                                        <div>
                                            <span>
                                                <?= Html::submitButton('Login', [ 'id' => "lost_login_btn", 'type' => "button",  'class' => 'btn btn-link', 'name' => 'login-button']) ?>
                                            </span>
                                        </div>
                                    </div>
                                </form>
                                <!-- End | Lost Password Form -->
                            </div>
                            <!-- End # DIV Form -->
                            <?php ActiveForm::end(); ?>
                        </div>
                    </div>
                </div>
                <!-- END # MODAL LOGIN --> 
                
                <!--End of styles-->

    <!--Thumbnail Navigation-->
                <div id="prevthumb"></div>
                <div id="nextthumb"></div>

                <!--Arrow Navigation-->
                <a id="prevslide" class="load-item"></a>
                <a id="nextslide" class="load-item"></a>

                <div id="thumb-tray" class="load-item">
                        <div id="thumb-back"></div>
                        <div id="thumb-forward"></div>
                </div>

                <!--Time Bar-->
                <div id="progress-back" class="load-item">
                        <div id="progress-bar"></div>
                </div>

                <!--Control Bar-->
                <div id="controls-wrapper" class="load-item">
                        <div id="controls">

<!--                                <a id="play-button"><img id="pauseplay" src="<?php echo Url::to("@web/images/icons/pause.png"); ?>"/></a>-->

                                <!--Slide counter-->
                                <div id="slidecounter">
                                        <span class="slidenumber"></span> / <span class="totalslides"></span>
                                </div>

                                <!--Slide captions displayed here-->
                                <div id="slidecaption"></div>

                                <!--Thumb Tray button-->
                                <a id="tray-button"><img id="tray-arrow" src="<?php echo Url::to("@web/images/icons/button-tray-up.png"); ?>"/></a>

                                <!--Navigation-->
                                <ul id="slide-list"></ul>

                        </div>
                </div>
            
    </body>
</html>
<script>
      $(document).ready(function(){
          $("#login-modal").modal('show')  
      })
</script>
