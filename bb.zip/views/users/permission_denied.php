<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\UsersSearch */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="jumbotron" style="background-color:#f1f8e9;" >
  <p class="display-3" style="color: #e53935;font-size: 50px;" >Permission Denied!</p>
  <p class="lead">You are not authorized user to access this page.Please login with valid user.</p>
</div>
