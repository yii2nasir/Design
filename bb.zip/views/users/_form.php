<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
/* @var $this yii\web\View */
/* @var $model app\models\User */
/* @var $form yii\widgets\ActiveForm */
?>
<style type="text/css">
    .btn-success,.btn-success:hover,.btn-success:focus{
        background-color: cadetblue;
        border-style: none;
    }
    select.form-control{
        font-size: 18px !important; 
    }
</style>
<div class="user-form">

    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_content">
                    <div class="col-md-12 col-sm-12 col-xs-12">

                        <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>
                        <span id="msg_name" style="position:relative;top:-5px;color: red;"></span> <br>

                        <?= $form->field($model, 'mobile')->textInput(['maxlength' => true]) ?>
                        <span id="msg_mobile" style="position:relative;top:-5px;color: red"></span> <br>

                        <?php if($model->isNewRecord){
                        echo $form->field($model, 'level_id')
                        ->dropDownList(ArrayHelper::map(\app\models\UserLevels::find()->where(["<>",'level_name',"Admin"])->all(),'id','level_name'),['prompt'=>'Select Level']);
                        }else { 
                        echo $form->field($model, 'level_id')
                        ->dropDownList(ArrayHelper::map(\app\models\UserLevels::find()->where(["<>",'level_name',"Admin"])->all(),'id','level_name'),['prompt'=>'Select Level',"disabled"=>"disabled"]);
                        } ?>
                        <span id="msg_level" style="position:relative;top:-5px;color: red"></span> <br>

                        <div class="form-group" align="center" >
                            <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Assign Location') : Yii::t('app', 'Update Location'), ['class' => $model->isNewRecord ? 'btn btn-success btnSuccess' : 'btn btn-primary btnSuccess',]) ?>
                        </div>
                    </div>    
                </div>
            </div>    
        </div>
        <style>
            button.btn.btn-success{
                margin: 0px; 
            }
        </style>
    </div>
    <?php ActiveForm::end(); ?>

</div>

<script>
$('.btnSuccess').click(function(){
         var name = $("#users-name").val();
         var mobile = $("#users-mobile").val();
         var level_id = $("#users-level_id").val();

         var flage = 0;
         if(name ==""){
           $("#msg_name").html("Name can not be blank.");
           flage++;
         }else{
           $("#msg_name").html("");
         }
         if(mobile ==""){
           $("#msg_mobile").html("Mobile number can not be blank.");
           flage++;
         }else{
           $("#msg_mobile").html("");
         }
         if(level_id ==""){
           $("#msg_level").html("Level can not be blank.");
           flage++;
         }else{
           $("#msg_level").html("");
         }
         if(flage != 0){
           return false;
         }
 });

</script>

