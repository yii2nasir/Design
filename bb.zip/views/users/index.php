<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use yii\widgets\ActiveForm;
use yii\helpers\Url;

// use app\models\Users;

/* @var $this yii\web\View */
/* @var $searchModel app\models\search\UserSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Users');
$this->params['breadcrumbs'][] = $this->title;
?>
<style type="text/css">
     .btn-success,.btn-success:hover,.btn-success:focus{
        background-color: cadetblue;
        border-style: none;
        padding-top: 7.5px;
    }
</style>
<div class="user-index">

    <h1 style="font-size: 30px;"><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p style="width: 12%; !important">
        <?= Html::a(Yii::t('app', 'Create User'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>


    <?= Html::submitButton('Search', ['class' => 'btn btn-primary','style'=>'display:none']) ?>

<?php Pjax::begin(); ?>    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'name',
            'mobile',
            'username',
            'password',
            [
                'attribute' => 'level_id',
                'filter' => ['33' => 'State Coordinator' , '35' => 'District Coordinator' ,'36'=>'RPC User','37' => 'RPC Coordinator'],
                'value' => function($data){
                    return $data->getUserOptions($data->level_id);
                }
            ],

            [
             'class' => 'yii\grid\ActionColumn',
             'header' => 'Location',
             'headerOptions' => [
               'style' => 'color:#3c8dbc'],
               'template' => '{location}',
               'buttons' => [
                 'location' => function ($url,$model) {
                  return '<input class="btn btn-primary" type="button" onclick="userLocationValue('.$model->id.','.$model->level_id.')" value="Location">';
                },
              ],
            ],

            // ['class' => 'yii\grid\ActionColumn'],
            [
                   'class' => 'yii\grid\ActionColumn',
                    'contentOptions'=>['style'=>'width: 80px;text-align: center;'],
                    'header'=>'Action', 
                    'template' => '{view} {update} {delete}',
                    'buttons' => [
                        'view' => function ($url, $model) {
                            return Html::a('<span class="glyphicon glyphicon-eye-open"></span>', $url, [
                                        'title' => Yii::t('app', 'lead-view'),
                            ]);
                        },
                        'update' => function ($url, $model) {
                            // display_array($model);
                            // exit;
                            if($model->level_id !=36){
                                return Html::a('<span class="glyphicon glyphicon-pencil"></span>', $url, [
                                            'title' => Yii::t('app', 'lead-update'),
                                ]);
                            }
                        },

                        'delete' => function ($url, $model) {
                            return Html::a('<span class="glyphicon glyphicon-trash" onclick="ask_confirm(\''.$model->id.'\',\''.Yii::$app->controller->id .'\')"></span>', $url, [
                                        'title' => Yii::t('app', 'Delete'),                        
                            ]);
                        },
                    ],
                    'urlCreator' => function ($action, $model, $key, $index) {
                         if ($action === 'view') {
                            $url ='../users/view?id='.$model->id;
                            return $url;
                        }
                        if ($action === 'update') {
                            $url ='../users/update?id='.$model->id;
                            return $url;
                        }
                        if ($action === 'delete') {
                            $url = "#";
                            return $url;
                        }
                    } 
            ],
        ],
    ]); ?>

<?php Pjax::end(); ?></div>
<?php ActiveForm::end(); ?>


<div id="myModal" class="modal fade" role="dialog">
      <div class="modal-dialog" style="width: 1000px;">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header" style="background-color:#2A3F54 ">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Location Status</h4>
          </div>
          <div class="modal-body" style="background-color: #F7F9F9">
          </div>
          <div class="modal-footer" style="background-color:#2A3F54 ">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>

      </div>
    </div>

  <script>
      function userLocationValue(user_id,level_id){
        $('#myModal').modal('show');
        $('.modal-body').html("");
        $.ajax({
          url: '<?php echo Url::to(["site/get-user-location-list"]); ?>',
          type: 'POST',
          data: {
            'user_id':user_id,
            'level_id': level_id
          },
          success: function(data) {
            $('.modal-body').html(data);
          },
          error: function(e) {
            //console.log(e.message);
          }
        });
      }
    </script>  