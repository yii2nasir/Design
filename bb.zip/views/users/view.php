<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\User */

$this->title = $model->name;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Users'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<style type="text/css">
    .btn-danger{
        background: #26B99A !important;
        border-style: none !important;
    }
    .modal-content{
        border-style: none !important;
    }
    .btn.btn-danger,.btn.btn-danger:active,.btn.btn-danger:focus{
        background-color: cadetblue !important;
        border-style: none;
        margin-top: -5px;
    }
    .modal-title{
        color: rgb(47,62,86) !important;
    }
</style>
<div class="user-view">

    <h1 style="font-size: 30px;"><?= Html::encode($this->title) ?></h1>

    <p>
        <?php
        if(getUserLevelID() !=36){
             Html::a(Yii::t('app', 'Update'), ['update', 'id' => $model->id], ['class' => 'btn btn-primary']); 
               }
        ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'onclick'=>'return (ask_confirm(\''.$model->id.'\',\''.Yii::$app->controller->id .'\')? true : false)'
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'name',
            'mobile',
            'username',
            //'password',
            //'level_id',
            [
                'attribute' => 'level_id',
                'value' => function($data){
                    return $data->getUserOptions($data->level_id);
                }
            ],
            [
                'attribute' => 'Location',
                'value' => function($data){
                    return $data->getLocations($data->level_id,$data->id);
                }
            ],
            // [
            //     'attribute' => 'sms_status',
            //     'filter'=>array("1"=>"Delivered","0"=>"Not Delivered"),
            //     'value' => function($data){
            //         return $data->sms_status == 1 ? 'Delivered' : 'Not Delivered';
            //     }
            // ], 
            //'sms_delivered_datetime',

            // [
            //     'attribute' => 'State',
            //     'value' => function($data){
            //         if($data->level_id == 1){
            //             return $data->getLocations($data->level_id,$data->id);
            //         }
            //         if($data->level_id == 2){
            //             return $data->getState($data->level_id,$data->id);
            //         }
            //         if($data->level_id == 3){
            //             return $data->getState($data->level_id,$data->id);
            //         }
            //         if($data->level_id == 4){
            //             return $data->getState($data->level_id,$data->id);
            //         }

            //     }
            // ],

            // [
            //     'attribute' => 'District',
            //     'value' => function($data){
            //         if($data->level_id == 2){
            //             return $data->getLocations($data->level_id,$data->id);
            //         }
            //         if($data->level_id == 3){
            //             return $data->getDistrict($data->level_id,$data->id);
            //         }
            //         if($data->level_id == 4){
            //             return $data->getDistrict($data->level_id,$data->id);
            //         }


            //     }
            // ],

            // [
            //     'attribute' => 'Block',
            //     'label'     => 'Block Name',
            //     'value' => function($data){
            //         if($data->level_id == 3){
            //             return $data->getLocations($data->level_id,$data->id);
            //         }
            //         if($data->level_id == 4){
            //             return $data->getBlock($data->level_id,$data->id);
            //         }
                   

            //     }
            // ],

            // [
            //     'attribute' => 'Village',

            //     'value' => function($data){
            //         if($data->level_id == 4){
            //             return $data->getLocations($data->level_id,$data->id);
            //         }
                    

                    
            //     }
            // ],
            // 'status',
            // 'authKey',
            // 'updated_at',
            // 'created_at',
        ],
    ]) ?>

</div>
