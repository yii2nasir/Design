<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\FgQcCheckProcessSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="fg-qc-check-process-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
        'options' => [
            'data-pjax' => 1
        ],
    ]); ?>

    <?= $form->field($model, 'id') ?>

    <?= $form->field($model, 'user_id') ?>

    <?= $form->field($model, 'unique_id') ?>

    <?= $form->field($model, 'product_id') ?>

    <?= $form->field($model, 'batch_id') ?>

    <?php // echo $form->field($model, 'batch_number') ?>

    <?php // echo $form->field($model, 'balance_quantity') ?>

    <?php // echo $form->field($model, 'sealing_quality') ?>

    <?php // echo $form->field($model, 'label_declaration') ?>

    <?php // echo $form->field($model, 'weight_check') ?>

    <?php // echo $form->field($model, 'moisture') ?>

    <?php // echo $form->field($model, 'odor') ?>

    <?php // echo $form->field($model, 'Infestation') ?>

    <?php // echo $form->field($model, 'count') ?>

    <?php // echo $form->field($model, 'forign_matter') ?>

    <?php // echo $form->field($model, 'broken_damage') ?>

    <?php // echo $form->field($model, 'qc_done_by') ?>

    <?php // echo $form->field($model, 'packed_size') ?>

    <?php // echo $form->field($model, 'pack_date') ?>

    <?php // echo $form->field($model, 'pack_quantity') ?>

    <?php // echo $form->field($model, 'photo') ?>

    <?php // echo $form->field($model, 'comment') ?>

    <?php // echo $form->field($model, 'created_at') ?>

    <?php // echo $form->field($model, 'updated_at') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
