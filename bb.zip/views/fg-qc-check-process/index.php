<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel app\models\FgQcCheckProcessSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Fg Qc Check Processes';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="fg-qc-check-process-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php Pjax::begin(); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Fg Qc Check Process', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'user_id',
            'unique_id',
            'product_id',
            'batch_id',
            //'batch_number',
            //'balance_quantity',
            //'sealing_quality',
            //'label_declaration',
            //'weight_check',
            //'moisture',
            //'odor',
            //'Infestation',
            //'count',
            //'forign_matter',
            //'broken_damage',
            //'qc_done_by',
            //'packed_size',
            //'pack_date',
            //'pack_quantity',
            //'photo',
            //'comment:ntext',
            //'created_at',
            //'updated_at',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    <?php Pjax::end(); ?>
</div>
