<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\FgQcCheckProcess */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Fg Qc Check Processes', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="fg-qc-check-process-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'user_id',
            'unique_id',
            'product_id',
            'batch_id',
            'batch_number',
            'balance_quantity',
            'sealing_quality',
            'label_declaration',
            'weight_check',
            'moisture',
            'odor',
            'Infestation',
            'count',
            'forign_matter',
            'broken_damage',
            'qc_done_by',
            'packed_size',
            'pack_date',
            'pack_quantity',
            'photo',
            'comment:ntext',
            'created_at',
            'updated_at',
        ],
    ]) ?>

</div>
