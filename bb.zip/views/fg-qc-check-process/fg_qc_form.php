<?php
use yii\widgets\ActiveForm;
use yii\helpers\Url;

?>
<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<style type="text/css">
.container{
	overflow-x: hidden;
	overflow-y: auto;
}
.text{
	height: 500px;
}
.btn-success{
	text-align: center;
	background: #DAA54B; 
	border-style:none;
	display:block;
	width: 20%;
    min-width: 20%;   
    /* max-width: 25%;  */
    }
	.btn_done{
		text-align: center;
		width:100%;
		display:block;
		margin-left:40%;
	}
       .btn-success:hover{
		text-align: center;
	    background: #DAA54B; 
		border-style:none;
		display:block;
		width: 20%;
		min-width: 20%;   
        /* max-width: 25%;  */
       }
       .btn-success:link{
		text-align: center;
	    background: #DAA54B; 
		border-style:none;
		display:block;
		width: 20%;
        min-width: 20%;   
        /* max-width: 25%;   */
       }
       .btn-success:visited{
		text-align: center;
	    background: #DAA54B; 
		border-style:none;
		display:block;
		width: 20%;
		min-width:20%;   
        /* max-width: 25%;  */
       }
       .btn-success:active{
		text-align: center;
	    background: #DAA54B; 
		border-style:none;
		display:block;	
		width: 20%;
        min-width: 20%;   
        /* max-width: 25%; 	 */
       }
	   .x_content{
		border-bottom:1px solid lightgray;
		/* overflow:auto; */
	   }

</style>

<div class="container">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_content">
				<br>
				<div class="row">
					<?php
					// print_r($data );
					//foreach ($data as  $value) { 
						?>
				 	<div>
						<h2>FG QC Check</h2>
						<div class="clearfix"></div>
 			 		</div>
					<div class="col-md-12">
						<div class="panel panel-default">
							<div class="panel-body">
								<div class="row">
									<div class="col-md-12">
										<b>Product Name :</b> <?//= //$value['product_name'] ?>test
									</div>
									<div class="col-md-12">
										<b>Batch ID :</b> <?//= //$value['batch_id'] ?>123
									</div>
									<div class="col-md-12">
										<b>Complete Load :</b> FG QC Check
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php //} ?>
				</div>
			<!-- </div>
		</div> -->
	</div>
	<div class="col-md-12 col-sm-12 col-xs-12">
	  <div>
				<h2>FG QC Check</h2>
				<div class="clearfix"></div>
	  </div>
		<!-- <div class="x_panel">
			<div class="x_content"> -->
				<br>
				<div class="row">
					<?php $form = ActiveForm::begin([
						'options' => ['enctype' => 'multipart/form-data'],
						'action' => [''],
						'method' => 'post',
						]); ?>
	
					<label>FG Batch Number </label><br>
					<input type="text" name="batch_number" value="277" class="form-control"><hr>
					
						
					<label>Balance Quantity</label> <br>
					<input type="text" name="balance_quantity" value="10" class="form-control"><hr>
					
					<label>Sealing Quality</label> <br>
					<input type="text" name="Sealing_quality" value="10" class="form-control"><hr>

					<label>Label Declaration</label> <br><?//= $value['batch_id']   ?>
					<input type="text" name="Sealing_quality" value="10" class="form-control"><hr>
					
					<label>Weight Check</label> <br>
					<input type="radio" name="weight" value="Yes">Yes
					<input type="radio" name="weight" value="No">No <hr>

					
					<label>Moisture % (Min-0 max-3)</label> <br>
					<input type="text" name="Moisture" value="1" class="form-control"><hr>
					
					<label> Odor</label> <br>
					<input type="radio" name="Odor" value="Yes">Characterstics Odor
					<input type="radio" name="Odor" value="No">Off Odor <hr>
					
					<label> Infestation</label> <br>
					<input type="radio" name="Infestation" value="Yes">Yes
					<input type="radio" name="Infestation" value="No">No <hr>
					
					<label> Count</label> <br>
					<input type="text" name="count" value="1"  class="form-control"><hr>
					
					<label> Forign Matter % (Min-0 Max 0.1)</label> <br>
					<input type="text" name="Forign_matter" value="1"  class="form-control"><hr>
					
					<label> Broken Damage % (Min-0 Max 0.1)</label> <br>
					<input type="text" name="broken_damage" value="0.1"  class="form-control"><hr>
					
					<label>QC Done By</label> <br>
					<input type="text" name="qc_done_by" value="anu"  class="form-control"> <hr>
					
					<label> Packed Size</label> <br>
					<input type="text" name="packed_size" value="10 kg"  class="form-control"><hr>
					
					<label> Pack Date</label> <br>
					<input type="text" name="pack_date" value="1-1-18"  class=" datepicker form-control"><hr>
					
					<label> Total Packed Quantity</label> <br>
					<input type="text" name="pack_quantity" value="10"  class="form-control"><hr>
					
					<label> Upload Photo</label> <br>
					<input type="file"><hr>
					
					<div class="col-md-12">
						<textarea style="display:block;" name="Fumigation[comments]" class="form-control" rows="3" placeholder="Share your comments.."></textarea>
					</div>
					 
					 <div class="col-md-3 btn_done"><br>
						<input type="submit" class="form-control btn btn-success"  value="Done" >
					 </div> 

					<?php ActiveForm::end(); ?>
				</div>
			</div>
		</div>
	</div>
</div>