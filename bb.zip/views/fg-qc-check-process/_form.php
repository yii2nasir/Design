<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;


/* @var $this yii\web\View */
/* @var $model app\models\FgQcCheckProcess */
/* @var $form yii\widgets\ActiveForm */
?>

<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<style type="text/css">
    button#Correctie_Action_Taken{
        margin-left: 3px ! important;
        width: 31% !important;
    }
    button#Reject{
        margin-left: -23% ! important;
        width: 23% !important;
    }
    button#Accept{
        margin-left: -1px ! important;
        width: 23% !important;
    }
     
    
</style> 
<div class="incoming-qc-check-form">
     <div class="panel panel-default">
      <div class="panel-body">
       <div class="row">
           <div class="col-md-12">
               <?= "<b>Product Name :</b> &nbsp;&nbsp;". $productM->name  ?>
           </div>
           <div class="col-md-12">
               <?= "<b>Product Code :   </b>&nbsp;&nbsp;". $productM->code  ?>
           </div>
       </div>    
   </div>
</div>
    <?php $form = ActiveForm::begin(['options'=>
    ['enctype'=>'multipart/form-data'],'id'=>'submitForm']); ?>

    <div class="row">
        <div class="col-md-12">
            <!-- <div class="col-md-6"> -->
                <div class="x_panel">
                    <div class="row">
                      <div class="panel_data">
                        <?php if(isset($_GET['rq_id']) && $_GET['rq_id'] !=""){
                           $model->incomming_qc_id =$_GET['rq_id'];
                        }
                        if(isset($_GET['p']) && $_GET['p'] !=""){
                            $model->product_id =$_GET['p'];
                        } 
                        $model->user_id = $userId;
                        ?>
                        
                        
                         
                        <?= $form->field($model, 'user_id')->hiddenInput()->label("") ?>

                       

                        <?= $form->field($model, 'product_id')->hiddenInput()->label("") ?>

                        <?php  $i=0; 
                        foreach ($qcCheckPhyChemy as  $value) {

                            if($value->category == 2){ ?>

                            <div>
                                <label class="category"><?= $value->name  ?> (Min- <?= $value->option_1  ?>  Max- <?= $value->option_2  ?>)</label>

                                <input type="text" style= "display: none" class="form-control" value= "<?=  $value['id'] ?>" name="FgQcCheckProcess[resultQcCheck][<?= $i ?>][id]"><br>
                                 <div class="col-md-5"><input type="number" class="form-control min-max" name="FgQcCheckProcess[resultQcCheck][<?= $i ?>][value]"> </div><br>
                                <br><hr>
                            </div>
                         
                            <?php } elseif ($value->category == 1) { ?>
                            <div>
                                <label><?= $value->name  ?></label>
                                <input type="text" style= "display: none" class="form-control" value= "<?=  $value['id'] ?>" name="FgQcCheckProcess[resultQcCheck][<?= $i ?>][id]"> <br>
                                <div class="col-md-5"><input type="text"  name="FgQcCheckProcess[resultQcCheck][<?= $i ?>][value]" class="form-control"></div><br>
                                <br><hr>
                            </div>
                            <?php } elseif ($value->category == 4) { ?>
                            <div class="col-md-12">
                                <label><?= $value->name  ?></label><br>
                                <input type="text" style= "display: none" class="form-control" value= "<?=  $value['id'] ?>" name="FgQcCheckProcess[resultQcCheck][<?= $i ?>][id]"> 
                                <?php if($value->option_1 !=""){ ?>
                                <input type="radio" class="coa_from_supplier" name="FgQcCheckProcess[resultQcCheck][<?= $i ?>][value]" value="<?= $value->option_1 ?>" checked> <?= $value->option_1 ?>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <?php } if($value->option_2 !=""){ ?>
                                <input type="radio" class="coa_from_supplier" name="FgQcCheckProcess[resultQcCheck][<?= $i ?>][value]" value="<?= $value->option_2 ?>">  <?= $value->option_2 ?>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <?php } if($value->option_3 !=""){ ?>
                                <input type="radio" name="FgQcCheckProcess[resultQcCheck][<?= $i ?>][value]" value="<?= $value->option_3 ?>">  <?= $value->option_3 ?> 
                                <?php } if($value->option_4 !=""){ ?>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="radio" name="FgQcCheckProcess[resultQcCheck][<?= $i ?>][value]" value="<?= $value->option_4 ?>">   <?= $value->option_4 ?> 
                                <?php } ?> <br><hr>
                            </div><br>
                            <?php }elseif ($value->category == 5) { ?>
                            <div>
                                <label class="category"><?= $value->name  ?></label>
                                <input type="text" style= "display: none" class="form-control" value= "<?=  $value['id'] ?>" name="FgQcCheckProcess[resultQcCheck][<?= $i ?>][id]"> <br>
                                <div class="col-md-5"><input type="text" name="FgQcCheckProcess[resultQcCheck][<?= $i ?>][value]" class="form-control"> </div><br>
                                <br><hr>
                            </div>
                             <?php } $i++;
                        } ?> 
                        <div class="row" style="padding:0;margin:0;">
                            <div class="col-sm-12">
                              <?= $form->field($model, 'comment')->textarea(['rows' => '3', 'placeholder' =>'Share your comments']) ->label("")  ?><br><br>
                            </div>
                        </div>

                        <div class="col-md-12">
                          <?= $form->field($model, 'overall_status')->hiddenInput(['maxlength' => true])->label("") ?>
                        </div>

                        <div class="col-md-12" style="margin-top:0px ">
                            <?= $form->field($model, 'photo')->fileInput(['maxlength' => true]) ->label("Image") ?>
                        </div>
                        <div class="col-md-8" style="float: right; margin-top:20px "> <br>
                            <?= Html::submitButton('Reject', ['class' => 'btn btn-default btnNext','id'=>'Reject']) ?>
                            <?= Html::submitButton('Correctie Action Taken', ['class' => 'btn btn-primary btnNext','id'=>'Correctie_Action_Taken']) ?>
                            <?= Html::submitButton('Accept', ['class' => 'btn btn-success btnNext','id'=>'Accept']) ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php ActiveForm::end(); ?>
</div>

<script type="text/javascript">
    $("#Reject").on('click', function(event){
         $("#fgqccheckprocess-overall_status").val("Reject");
         event.preventDefault();
         $("#submitForm").submit();
     });

    $("#Correctie_Action_Taken").on('click', function(event){
         $("#fgqccheckprocess-overall_status").val("Correctie_Action_Taken");
         event.preventDefault();
         $("#submitForm").submit();
    });
</script>
<?php /*<div class="container">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_content">
                <br>
                <div class="row">
                    <div>
                        <h2>FG QC Check</h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12">
                                       <?= "<b>Product Name :</b> &nbsp;&nbsp;". $productM->name  ?>
                                    </div>
                                    <div class="col-md-12">
                                        <!--<b>Batch ID :</b> -->
                                     <?= "<b>Product Code :   </b>&nbsp;&nbsp;". $productM->code  ?>

                                    </div>
                                    <div class="col-md-12">
                                        <b>Complete Load :</b> FG QC Check
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            
            </div>
           <?php /* <div class="fg-qc-check-process-form">

                <?php $form = ActiveForm::begin(); ?>

                <?= $form->field($model, 'user_id')->hiddenInput()->label("") ?>

                <?= $form->field($model, 'unique_id')->textInput(['maxlength' => true])->hiddenInput()->label("") ?>

                <?= $form->field($model, 'product_id')->hiddenInput()->label("") ?>

                <?= $form->field($model, 'batch_id')->textInput() ?>

                <?= $form->field($model, 'batch_number')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'balance_quantity')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'sealing_quality')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'label_declaration')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'weight_check')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'moisture')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'odor')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'Infestation')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'count')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'forign_matter')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'broken_damage')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'qc_done_by')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'packed_size')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'pack_date')->textInput() ?>

                <?= $form->field($model, 'pack_quantity')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'photo')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'comment')->textarea(['rows' => 6]) ?>

                <?= $form->field($model, 'created_at')->hiddenInput()->label("") ?>

                <?= $form->field($model, 'updated_at')->hiddenInput()->label("") ?>

                <div class="form-group">
                    <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
                </div>

                <?php ActiveForm::end(); ?>

            </div>
        </div>
    </div>
</div>

<?php /*
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div>
                <h2>FG QC Check</h2>
                <div class="clearfix"></div>
      </div>

                <br>
                <div class="row">
                    <?php $form = ActiveForm::begin(); ?>
    
                    <label>FG Batch Number </label><br>
                    <input type="text" name="batch_number" value="277" class="form-control"><hr>
                    
                        
                    <label>Balance Quantity</label> <br>
                    <input type="text" name="balance_quantity" value="10" class="form-control"><hr>
                    
                    <label>Sealing Quality</label> <br>
                    <input type="text" name="Sealing_quality" value="10" class="form-control"><hr>

                    <label>Label Declaration</label> <br><?//= $value['batch_id']   ?>
                    <input type="text" name="Sealing_quality" value="10" class="form-control"><hr>
                    
                    <label>Weight Check</label> <br>
                    <input type="radio" name="weight" value="Yes">Yes
                    <input type="radio" name="weight" value="No">No <hr>

                    
                    <label>Moisture % (Min-0 max-3)</label> <br>
                    <input type="text" name="Moisture" value="1" class="form-control"><hr>
                    
                    <label> Odor</label> <br>
                    <input type="radio" name="Odor" value="Yes">Characterstics Odor
                    <input type="radio" name="Odor" value="No">Off Odor <hr>
                    
                    <label> Infestation</label> <br>
                    <input type="radio" name="Infestation" value="Yes">Yes
                    <input type="radio" name="Infestation" value="No">No <hr>
                    
                    <label> Count</label> <br>
                    <input type="text" name="count" value="1"  class="form-control"><hr>
                    
                    <label> Forign Matter % (Min-0 Max 0.1)</label> <br>
                    <input type="text" name="Forign_matter" value="1"  class="form-control"><hr>
                    
                    <label> Broken Damage % (Min-0 Max 0.1)</label> <br>
                    <input type="text" name="broken_damage" value="0.1"  class="form-control"><hr>
                    
                    <label>QC Done By</label> <br>
                    <input type="text" name="qc_done_by" value="anu"  class="form-control"> <hr>
                    
                    <label> Packed Size</label> <br>
                    <input type="text" name="packed_size" value="10 kg"  class="form-control"><hr>
                    
                    <label> Pack Date</label> <br>
                    <input type="text" name="pack_date" value="1-1-18"  class=" datepicker form-control"><hr>
                    
                    <label> Total Packed Quantity</label> <br>
                    <input type="text" name="pack_quantity" value="10"  class="form-control"><hr>
                    
                    <label> Upload Photo</label> <br>
                    <input type="file"><hr>
                    
                    <div class="col-md-12">
                        <textarea style="display:block;" name="Fumigation[comments]" class="form-control" rows="3" placeholder="Share your comments.."></textarea>
                    </div>
                     
                     <!-- <div class="col-md-3 btn_done"><br>
                        <input type="submit" class="form-control btn btn-success"  value="Done" >
                     </div> --> 
                     <div class="form-group">
                         <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
                    </div>

                    <?php ActiveForm::end(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
*/?>