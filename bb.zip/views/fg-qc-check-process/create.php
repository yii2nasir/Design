<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\FgQcCheckProcess */

$this->title = 'Create Fg Qc Check Process';
$this->params['breadcrumbs'][] = ['label' => 'Fg Qc Check Processes', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="fg-qc-check-process-create">

    <h1><?= Html::encode($this->title) ?></h1>

   
<?= $this->render('_form', [
        'model' => $model,
        'qcCheckPhyChemy'=>$qcCheckPhyChemy,
        'userId'=>$userId,
        'productM'=>$productM
    ]) ?>

</div>
