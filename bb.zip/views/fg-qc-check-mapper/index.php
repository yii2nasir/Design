<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\FgQcCheckMapperSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Fg Qc Check Mappers';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="fg-qc-check-mapper-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Fg Qc Check Mapper', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'fg_qc_uniq_id',
            'packed_weight',
            'packed_quantity',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
