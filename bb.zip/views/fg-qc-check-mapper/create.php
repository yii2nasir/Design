<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\FgQcCheckMapper */

$this->title = 'Create Fg Qc Check Mapper';
$this->params['breadcrumbs'][] = ['label' => 'Fg Qc Check Mappers', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="fg-qc-check-mapper-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
