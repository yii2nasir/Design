<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;
/* @var $this yii\web\View */
/* @var $model app\models\SubCategory */
/* @var $form yii\widgets\ActiveForm */
?>
<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<style type="text/css">
    .btn.btn-success{
        background-color: cadetblue;
        border-style: none;
    }
</style>

<div class="sub-category-form">

    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_content">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                    	<?= $form->field($model, 'category_id')->dropDownList(ArrayHelper::map(\
                    		app\models\Category::find()->all(),'id','category_name'),['prompt' => 
                    		'Select '])->label("Category Name") ?>
                            
                    	<?= $form->field($model, 'sub_cat_name')->textInput(['maxlength' => true]) ?>
                    </div>                    
                </div>
                <div class="form-group">
                    	<?= Html::submitButton('Update', ['class' => 'btn btn-success']) ?>
                </div>
            </div>    
        </div>
    </div>    

    <?php ActiveForm::end(); ?>

</div>
