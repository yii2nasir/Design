<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\SubCategory */

$this->title = $model->sub_cat_name;
$this->params['breadcrumbs'][] = ['label' => 'Sub Categories', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<style type="text/css">
    .btn-danger{
        background: #26B99A !important;
        border-style: none !important;
        margin-top: -5px;
    }
    .modal-content{
        border-style: none !important;
    }
    .btn-primary,.btn-primary:active{
        background-color: cadetblue !important;
        border-style: none;
        margin-top: -5px;
    }
    .modal-title{
        color: rgb(47,62,86) !important;
    }
</style>
<div class="sub-category-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'onclick'=>'return (ask_confirm(\''.$model->id.'\',\''.Yii::$app->controller->id .'\')? true : false)'
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'sub_cat_name',
            //'category_id',
            [
                'attribute' => 'category_id',
                'value' => $model->category->category_name
            ],

            'created_at',
            'updated_at',
        ],
    ]) ?>

</div>
