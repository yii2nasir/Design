<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;


/* @var $this yii\web\View */
/* @var $searchModel app\models\SubCategorySearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Sub Categories';
$this->params['breadcrumbs'][] = $this->title;
?>
<style type="text/css">
    .action-column{
        width: 80px !important;
    }
     .btn.btn-success,.btn.btn-success:hover,.btn.btn-success:focus{
         background-color: cadetblue;
         border-style: none;
         padding-top: 7.5px;
    }
</style>
<div class="sub-category-index">

    <h1 style="font-size: 32px;"><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?php $action = Yii::$app->controller->id ?>
        <?= Html::a('Create Sub Category', ['create'], ['class' => 'btn btn-success']) ?>
        <?= Html::a(Yii::t('app', 'Download'), ['download'], ['class' => 'btn btn-success','method' => 'post']) ?>

        <input type="button" onclick="uploadCsv('<?= $action ?>','sub-category-upload')" class='btn btn-success' style='float:right' name="" value="Upload CSV">
    </p>
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>
    <?= Html::submitButton('Search', ['class' => 'btn btn-primary','style'=>'display:none']) ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn','header'=>'Sr.No'],

            //'id',
            'sub_cat_name',
            ['attribute'=>'category_id',
             'value'=>'category.category_name'
            ],
            [ 
                'attribute'=>'created_at',
                'value' => function($data){
                    return date("Y-m-d H:i:s",
                           strtotime($data->created_at));
                }
            ],       
            [ 
                'attribute'=>'updated_at',
                'value' => function($data){
                    return (!empty($data->updated_at)) ? 
                            date("Y-m-d H:i:s", 
                            
                            strtotime($data->updated_at)): null;
                }
            ],
            //'created_at',
            //'updated_at',

            [
                   'class' => 'yii\grid\ActionColumn',
                    'contentOptions'=>['style'=>'width: 60px;text-align: center;'],
                    'header'=>'Action', 
                    'template' => '{view} {update} {delete}',
                    'buttons' => [
                        'view' => function ($url, $model) {
                            return Html::a('<span class="glyphicon glyphicon-eye-open"></span>', $url, [
                                        'title' => Yii::t('app', 'lead-view'),
                            ]);
                        },
                        'update' => function ($url, $model) {
                            return Html::a('<span class="glyphicon glyphicon-pencil"></span>', $url, [
                                        'title' => Yii::t('app', 'lead-update'),
                            ]);
                        },

                        'delete' => function ($url, $model) {
                            return Html::a('<span class="glyphicon glyphicon-trash" onclick="ask_confirm(\''.$model->id.'\',\''.Yii::$app->controller->id .'\')"></span>', $url, [
                                        'title' => Yii::t('app', 'Delete'),                        
                            ]);
                        },
                    ],
                    'urlCreator' => function ($action, $model, $key, $index) {
                         if ($action === 'view') {
                            $url ='../sub-category/view?id='.$model->id;
                            return $url;
                        }
                        if ($action === 'update') {
                            $url ='../sub-category/update?id='.$model->id;
                            return $url;
                        }
                        if ($action === 'delete') {
                            $url = "#";
                            return $url;
                        }
                    } 
            ],
        ],
    ]); ?>
    <?php ActiveForm::end(); ?>
</div>
