<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;
/* @var $this yii\web\View */
/* @var $model app\models\Village */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="village-form">

    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
    	<div class="col-md-3">
            <?php
            echo $form->field(new app\models\State(), 'id')->dropDownList(
                ArrayHelper::map(\app\models\State::find()->all(), "id", "name"),
                [
            'prompt' => 'Select State',
            'id' => 'state_id',
            'onchange' => 'getAllDistrict()',
                ]
            )->label("State");
            ?>
       </div>
	    <div class="col-md-3">
            <?php
            echo $form->field(new app\models\District(), 'id')->dropDownList(
                ArrayHelper::map(\app\models\District::find()->all(), "id", "name"),
                [
            'prompt' => 'Select State',
            'id' => 'depDropDistrict',
            'onchange' => 'getAllBlock()',
                ]
            )->label("District");
            ?>
	    </div>

	    <div class="col-md-3">
        <?= $form->field($model, 'block_id')->dropDownList(ArrayHelper::map(\app\models\Block::find()->all(),'id','name'),['prompt'=>'Select Block','id' => 'depDropBlock']) ?>
	    </div>

	    <div class="col-md-3">
	    <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>
	    </div>
	</div>
    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
<script>
$(document).ready(function(){
 
})
function getAllDistrict(){
    var state_id = document.getElementById("state_id").value;
    
    $.ajax({
        url: '<?php echo Url::to(["site/lists"]); ?>',
        type: 'post',
        data: {
            type : 1,
            id : state_id
        },
        success: function (res) {
            var nandghar = JSON.parse(res);
            var areaOption = "<option value=''>Select District</option>";
             for (var i = 0; i < nandghar.length; i++) {
                 areaOption += '<option value="' + nandghar[i]['id'] + '">' + nandghar[i]['name'] + '</option>'
             }
            $("#depDropDistrict").html(areaOption);

            if(document.getElementById("depDropDistrict") !== null){
                $("#depDropDistrict").val($("#depDropDistrict").val()).change();
            }
        },
        error: function (res) {
        }
    }); 
}


    function getAllBlock(){
        var district_id = document.getElementById("depDropDistrict").value;
            
            $.ajax({
                url: '<?php echo Url::to(["site/lists"]); ?>',
                type: 'post',
                data: {
                    type : 2,
                    id : district_id
                },
                success: function (res) {
                var nandghar = JSON.parse(res);
                var areaOption = "<option value=''>Select Block</option>";
                 for (var i = 0; i < nandghar.length; i++) {
                     areaOption += '<option value="' + nandghar[i]['id'] + '">' + nandghar[i]['name'] + '</option>'
                 }
                $("#depDropBlock").html(areaOption);
                    if(document.getElementById("depDropBlock") !== null){
                        $("#depDropBlock").val($("#depDropBlock").val()).change();
                    
                    }
                },
                error: function (res) {
                }
            }); 
    }
</script>