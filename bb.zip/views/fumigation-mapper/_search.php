<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\FumigationMapperSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="fumigation-mapper-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id') ?>

    <?= $form->field($model, 'fumigation_id') ?>

    <?= $form->field($model, 'product_id') ?>

    <?= $form->field($model, 'batch_id') ?>

    <?= $form->field($model, 'available_qty') ?>

    <?php // echo $form->field($model, 'quantity_value') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
