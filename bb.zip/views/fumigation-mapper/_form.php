<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\FumigationMapper */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="fumigation-mapper-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'fumigation_id')->textInput() ?>

    <?= $form->field($model, 'product_id')->textInput() ?>

    <?= $form->field($model, 'batch_id')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'available_qty')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'quantity_value')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
