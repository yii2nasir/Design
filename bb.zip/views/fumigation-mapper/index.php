<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\FumigationMapperSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Fumigation Mappers';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="fumigation-mapper-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Fumigation Mapper', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'fumigation_id',
            'product_id',
            'batch_id',
            'available_qty',
            //'quantity_value',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
