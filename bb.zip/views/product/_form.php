<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use app\models\Category;
use app\models\SubCategory;
use app\models\SubSubCategory;
use yii\helpers\Url;
use kartik\select2\Select2;
use app\models\Product;
/* @var $this yii\web\View */
/* @var $model app\models\Product */
/* @var $form yii\widgets\ActiveForm */
?>
<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<?php
 if($model->isNewRecord == false){
     $query = new \yii\db\Query;
           $query->select(['category.id as cat_id',
                          'sub_category.id as sub_cat_id',
                          'sub_sub_category.id as sub_sub_cat_id' ])
                   ->from('category')
                   ->innerJoin('sub_category', 'sub_category.category_id = category.id')
                   ->innerJoin('sub_sub_category', 'sub_sub_category.sub_cat_id = sub_category.id')

                   ->where(['sub_sub_category.id'=> $model->sub_sub_cat_id]);
           $command = $query->createCommand();
           $data = $command->queryOne();
           $category_id = isset($data['cat_id']) && $data['cat_id'] !="" ? $data['cat_id'] :"";
           $sub_category_id = isset($data['sub_cat_id']) && $data['sub_cat_id'] !="" ? $data['sub_cat_id'] :"";
           $sub_sub_cat_id = isset($data['sub_sub_cat_id']) && $data['sub_sub_cat_id'] !="" ? $data['sub_sub_cat_id'] :"";
          
}else{
    $category_id = "";
    $sub_category_id = "";
    $sub_sub_cat_id ="";
}
?>
<style type="text/css">
  .btn.btn-success{
    background-color: cadetblue;
    border-style: none;
  }
</style>
<div class="product-form">

    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_content">
                    <div class="col-md-12 col-sm-12 col-xs-12"> 

                      <!-- Dropdown of category -->
                        <?= $form->field(new Category, 'id')->dropDownList(ArrayHelper::map(\app\models\Category::find()->all(),'id','category_name'),
                                              [
                                                  'prompt' => 'Select category ',
                                                  'id' => 'category-id',
                                                  'onchange' => 'getSubCategory()',
                                              ])->label("Category") ?>

                            <!-- Dropdown of Sub-Sub category -->

                      <?= $form->field(new SubCategory, 'id')->dropDownList(ArrayHelper::map(\app\models\SubCategory::find()->all(),'id','sub_cat_name'),
                                              [
                                                  'prompt' => 'Select Sub Category ',
                                                  'id' => 'subCat',
                                                  'onchange' => 'getSubSubCategory()',
                                              ])->label("Sub Category") ?>      

                            <!--Here we addsub-sub category ..  Dropdown of sub-sub-category  -->
                    	<?= $form->field($model, 'sub_sub_cat_id')->dropDownList(ArrayHelper::map(\app\models\SubSubCategory::find()->all(),'id','name'),
                                              [
                                                  'prompt' => 'Select SubSubCategory',
                                                  'id' => 'subSubCat'
                                                  ])->label(" Sub-Sub Category") ?>

                    	<?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>
                      <?= $form->field($model, 'code')->textInput(['maxlength' => true]) ?>

                    </div>
                </div>
                <div class="form-group">
                	<?= Html::submitButton('Update', ['class' => 'btn btn-success']) ?>
                </div>
            </div>
        </div>
    </div>    

    <?php ActiveForm::end(); ?>

</div>




<script>
     $(document).ready(function(){
        var category_id = '<?= $category_id ?>';
        $("#category-id").val(category_id);
         getSubCategory(category_id);
      });
    
    function getSubCategory(){
        var category_id  = document.getElementById("category-id").value;
        $.ajax({
            url: '<?php echo Url::to(["site/lists"]); ?>',
            type: 'post',
            data: {
                type : 3,
                id : category_id
                },
            success: function(res){
                var subCategory = JSON.parse(res);
                console.log("",res);
               var areaOption = "<option value=''>Select Sub Category</option>";
                    for (var i = 0; i < subCategory.length; i++) {
                       areaOption += '<option value="' + subCategory[i]['id'] + '">' + subCategory[i]['sub_cat_name'] + '</option>'
                   }

                   $("#subCat").html(areaOption);
                  <?php if($model->isNewRecord == false){ ?>
                         $("#subCat").val('<?= $sub_category_id ?>');
                   <?php } ?>
            },
            error: function (res) {
            }
        }); 
        }
</script>

<script>
   $(document).ready(function(){

        var sub_category_id = '<?= $sub_category_id ?>';
        // console.log("Subcategory",sub_category_id)
        $("#subCat").val(sub_category_id);
        getSubSubCategory(sub_category_id);
    });

   function getSubSubCategory(){
        var sub_category_id  = document.getElementById("subCat").value;
        console.log("Subcategory",sub_category_id);
        $.ajax({
            url: '<?php echo Url::to(["site/lists"]); ?>',
            type: 'post',
            data: {
                type : 4,
                id : sub_category_id
                },
            success: function(res){
                var subSubCategory = JSON.parse(res);
               var areaOption = "<option value=''>Select SubSubCategory</option>";
                    for (var i = 0; i < subSubCategory.length; i++) {
                       areaOption += '<option value="' + subSubCategory[i]['id'] + '">' + subSubCategory[i]['name'] + '</option>'
                   }

                   $("#subSubCat").html(areaOption);
                   
                  <?php if($model->isNewRecord == false){ ?>
                         $("#subSubCat").val('<?= $model->sub_sub_cat_id ?>');
                   <?php } ?>
            },
            error: function (res) {
            }
        }); 
        }

</script>
