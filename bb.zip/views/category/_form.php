<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;
/* @var $this yii\web\View */
/* @var $model app\models\Category */
/* @var $form yii\widgets\ActiveForm */
?>
<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<style>
    button.btn.btn-success.saveButton{
        float: right;
        margin: -51px -100px 6px 0px;
        background: cadetblue;
        border-style: none;
    }
</style>

<div class="category-form">

    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_content">
                    <div class="col-md-10 col-sm-12 col-xs-12">
                    	<?= $form->field($model, 'category_name')->textInput(['maxlength' => true]) ?>
                    
                        <div class="form-group">
                        	<?= Html::submitButton('Update', ['class' => 'btn btn-success saveButton']) ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php ActiveForm::end(); ?>
</div>

