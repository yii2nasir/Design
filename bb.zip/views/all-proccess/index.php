<?php
use yii\helpers\Html;

?>

<style type="text/css">
	.caret{
		/*margin-left: 15% !important;*/
		float: right;
		margin-top: 3% !important;
		border-width: 7px 7px 0 !important;	
	}
	.btn{
        font-size: 16px;
	}
	.form-control{
		font-size: 19px;
	}
</style>
<div class="col-md-4"></div>
<div class="col-md-4">
	<div class="x_content">
		<button data-toggle="dropdown"  class="btn dropdown-toggle btn-lg" style="background-color: #4ace35; width: 85%; color: white" align="center" type="button" aria-expanded="true">INITIATE NEW <span class="caret"></span>
		</button>
		<ul role="menu" style="width: 85%;" class="dropdown-menu">
			<li class="divider" style="margin-top: -0.5%;"></li>
			<li><a href="../new-request/new-request-list	">Request</a>
			</li>
			<li class="divider"></li>
			<li><a href="../new-request/index">Incoming QC Check</a>
			</li>
			<li class="divider"></li>
			<li><a href="../fumigation/fumigation-index">Fumingation Process</a>
			</li>
			<li class="divider"></li>
			<li><a href="../cleaning/index">Cleaning Process</a></li>
			<li class="divider"></li>
			<li><a href="../fg-qc-check/index">FG QC Check</a>
			<li class="divider" style="margin-bottom: -0.5%;"></li>
			</li>
		</ul>
	</div>
</div>
<div class="col-md-4" style="margin-top: 0.5%;">

	<select name="product" class="form-control" id="request_type" onchange="requesttype()">
			<option  value="In-Proccess_new-request">In-Process new-request</option>
			<option  value="In-Proccess_Incoming QC Check">In-Process Incoming QC Check</option>
			<option  value="On_Hold">On Hold</option>
		</select>	
</div>

 <div class="row">
	<div class="col-md-12">
		<div class="x_panel">
			<div class="x_content">

			</div>
		</div>
	</div>
</div>


<script type="text/javascript">
	function requesttype(){
		var request = $("#request_type").val();
		if(request == "In-Proccess_new-request"){
			window.location = "../new-request";	

		}else if(request == "In-Proccess_Incoming QC Check"){
			window.location = "../new-request";	

		}else if(request == "On_Hold"){
			window.location = "../new-request/onholdproduct";	
		}
		
	}
</script>
</div> 