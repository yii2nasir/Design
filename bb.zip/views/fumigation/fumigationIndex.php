<?php 
use yii\widgets\ActiveForm;
use app\models\Product;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\helpers\Url;
?>
<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<style type="text/css">
.container{
	overflow-x: hidden;
	overflow-y: auto;
}
.text{
	height: 500px;
}
.pagination{
	display: inline-block;
}
.checkbox{
	width: 17px !important;
	height: 16px !important;
}
.glyphicon.glyphicon-eye-open.open_popup{
	font-size: 20px;
}

</style>
<!-- Search -->
<div class="row">
	<div class="col-md-6">
	</div>	
	<div class="col-md-6">
		<?php $form = ActiveForm::begin([
			'action' => ['fumigation-index'],
			'method' => 'post',
			]); ?>

		<?php
		$productData = Product::find()->all();
		?>
		<label>Search Product</label>
		<select name="product" class="form-control" id="product_item" onchange="productWiseFumigation()">
			<!--<option value="">Select</option>-->
			<option value="">All Products</option>
			<?php foreach ($productData as $value) { ?>
			<option  value="<?= $value['id']  ?>"><?= $value['name']  ?></option>
			<?php }?>
		</select>
		
		<?php ActiveForm::end(); ?>			
	</div>
</div>
<!-- end -->

<!-- Index -->

<div class="container">
	<div class="col-md-12 col-sm-12 col-xs-12">
	 <div>
				<h2 style="font-size: 32px;margin-top: -6px;">Fumigation</h2>
				<div class="clearfix"></div>
	 </div>
		<div class="x_panel">
			
			<div class="x_content">

				<h4 style="margin-top: -5px;"><b>Select one or more products to do Fumigation</b></h4>
				<h5>Products which are qualified for Fumigation</h5>		
				<br>
				<?php $form = ActiveForm::begin([
					'action' => ['fumigation-option'],
					'method' => 'post',
					]); ?>
					<form action="" class="form-horizontal form-label-left">
						<?php
						if($model){
							foreach ($model as  $value) { ?>
							<div class="panel panel-default">
								<div class="panel-body">
									<div class="row">
										<div class="col-md-1">
											<input class="checkbox" type="checkbox" name="Fumigation[<?= $value['unique_id'] ?>][unique_id]" value="<?= $value['unique_id']  ?>">
										</div>
										<div class="col-md-6">
											Product Name : <?= $value['product_name'] ?>
										</div>

										<div class="col-md-4">
											Last updated : <?= date("d-m-Y h:i:s",$value['updated_at']); ?>
										</div>
                                        <div class="col-md-1">
											<a title="View Details" class="glyphicon glyphicon-eye-open open_popup" width="100px" onclick="viewData('<?= $value['unique_id'] ?>')"></a>
										</div>
									</div>
									<div class="row">
										<div class="col-md-1"></div>
										<div class="col-md-11">
											Batch ID : <?= $value['batch_id'] ?>
										</div>
										<!-- <div class="col-md-11"></div> -->
									</div>	
									
								</div>
							</div>

							<?php } ?>
							<input type="submit" name="" id="Proceed" value="Proceed" class="btn btn-success">

							<?php }else{?>
							<div class="panel panel-default">
								<div class="panel-body">
									Result not Found.
								</div>
							</div>
							<?php } ?>
							<?php ActiveForm::end(); ?>
						</div>
					</div>
				</div>
			</div>	
			<!-- End -->

			<!-- View Modules -->
			<div class="modal fade" id="view_data" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog" role="document">
					<form action="" method="POST" enctype="multipart/form-data">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
								<h3 class="modal-title" id="myModalLabel" style="color: green">View Data</h3>
							</div>
							<div class="modal-body">

							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
							</div>
						</div>
					</form>
				</div>
			</div>
			<!-- End View Modules -->

			<!-- Paggination -->
			<div class="row">
				<div class="col-md-12">
					<div class="col-md-6">
						<div style="margin-top: -0px;">
							<p>Showing <?php echo $skip+1; ?> to <?php echo $skip+5; ?> of <?php echo $count; ?> entries</p>
						</div>
					</div>
					<div class="col-md-6">
						<div style="margin-left: -23%;">
						  <?php
							$k=1;
							$a = 6;
							$currentPage = "";
							if(isset($count)){
								if(isset($_GET['page'])){
									$currentPage = $_GET['page'];   
									$a = $_GET['page']+1;
									$b = $_GET['page']-1;
									if($a > 2){ ?>
										<ul class="pagination">
											<?php if(isset($_GET['product_id'])){ ?>
											<li><a href='fumigation-index?product=<?= $_GET['product_id'] ?>&page=<?= $b ?>'>&laquo;</a></li>
											 <?php } else {?>
	                                          <li><a href='fumigation-index?page=<?= $b ?>'>&laquo;</a></li>
											 <?php } ?>
										</ul>
									<?php } 
								       }

									$g = ceil($count/5);
									for($i = 1; $i <= $g; $i++){

										if(isset($_GET['page'])){
											if($i == $_GET['page']){
												$back=  "brown"; 
												$color = "white";
											}else{
												$back=  ""; 
												$color = "";
											}
										}else{
											$back=  ""; 
											$color = "";
										}


										if($i < 6){
											?>
											<ul class="pagination">
												<?php if(isset($_GET['product_id'])){ ?>
												<li><a href='fumigation-index?product=<?= $_GET['product_id'] ?>&page=<?= $i; ?>' style="background-color:<?= $back ?>; color: <?= $color  ?>" class=""><?php echo $i; ?></a></li>
												 <?php }else{ ?>
                                                   <li><a href='fumigation-index?page=<?= $i; ?>' style="background-color:<?= $back ?>; color: <?= $color  ?>" class=""><?php echo $i; ?></a></li>
												 <?php } ?>
											</ul>
											<?php
										}
									}
									?>
									<ul class="pagination">
										<li><a href='fumigation-index?page=<?= $a ?>' >...</a></li>
									</ul> 
									<?php
									if($currentPage > 5){?>
									<ul class="pagination">
										<li><a href='fumigation-index?page=<?= $currentPage ?>' style="background-color: brown; color: white;"><?php echo $currentPage; ?></a></li>
									</ul> 
									<?php }?>
									<ul class="pagination">
										<li><a href='fumigation-index?page=<?= $g ?>'><?php echo $g; ?></a></li>
									</ul>
									<ul class="pagination">
										<li><a href='fumigation-index?page=<?= $a ?>' >&raquo;</a></li>
									</ul> 
									<?php 
								}?>
							</div>
						</div>
					</div>
				</div>
				<!-- end -->

				<script type="text/javascript">
					function viewData(unique_id){
						$("#view_data").modal('show');
						$.ajax({
							url: '../fumigation/view-data',
							type: 'GET',
							data: {'unique_id':unique_id},
							success: function(data) {
								var obj = JSON.parse(data);
								console.log(obj);
								var table = "";
								table +='<table class="table table-bordered">';
								table += '<tbody>';
								table += '<tr><td><b>Product Name</b></td><td>'+obj.product_name+'</td></tr>';
								table += '<tr><td><b>Product Code</b></td><td>'+obj.product_code+'</td></tr>';
								table += '<tr><td><b>Supplier Name</b></td><td>'+obj.supplier_name+'</td></tr>';
								table += '<tr><td><b>Supplier Code</b></td><td>'+obj.supplier_code+'</td></tr>';
								table += '<tr><td><b>Vehicle Inspection Checklist</b></td><td>'+obj.vehicle_inspection_checklist+'/4 Approved</td></tr>';
								table += '<tr><td><b>Total Quantity</b></td><td>'+obj.total_quantity+' Kgs</td></tr>';
								table += '</tbody>';
								table += '</table>';
								$('.modal-body').html(table);
							},
							error: function(e) {
								console.log(e);
							}
						});
					}
					<?php    
					if(isset($_GET['product_id']) && $_GET['product_id'] !=""){?>
						$("#product_item").val("<?= $_GET['product_id'] ?>");
						<?php } ?>
						function productWiseFumigation(){
							var product = $("#product_item").val();
							if(product == ""){
								window.location = "fumigation-index";	
							}else{
								window.location = "fumigation-index?product_id="+product+"";
							}
						}
					</script>

