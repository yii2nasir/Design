<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
// use kartik\date\DatePicker;
// use yii\jui\DatePicker;


/* @var $this yii\web\View */
/* @var $model app\models\Fumigation */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="fumigation-form">
      <?php $form = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="col-md-6">
                    <?= $form->field($model, 'quantity_taken')->textInput(['maxlength' => true]) ?>
                </div>
                <div class="col-md-6">
                    <?= $form->field($model, 'start_time')->textInput(['class'=>'form-control datepicker']) ?>                     
                </div>                  
                <div class="col-md-6">
                   <?= $form->field($model, 'end_time')->textInput(['class'=>'form-control datepicker']) ?> 
                </div>
                <br>
                <div class="col-md-6">                    
                    <?= $form->field($model, 'chemical_used')->textInput(['maxlength' => true]) ?>
                </div>
                <div class="col-md-6">
                    <?= $form->field($model, 'qc_person_name')->textInput(['maxlength' => true]) ?>
                </div>
                <div class="col-md-6">
                    <?= $form->field($model, 'fumigation_effective')->radioList([1 => 'yes', 0 => 'No'],['prompt' => '']) ?>

                    <?= $form->field($model, 're_fumigate')->radioList([ 'Yes' => 'Yes', 'No' => 'No', ], ['prompt' => '']) ?>
                </div>

                    <div class="form-group">
                        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
                    </div>
            </div>          
        </div>
    </div>
    <?php ActiveForm::end(); ?>

</div>
