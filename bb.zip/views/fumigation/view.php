<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Fumigation */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Fumigations', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="fumigation-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'onclick'=>'return (ask_confirm(\''.$model->id.'\',\''.Yii::$app->controller->id .'\')? true : false)'
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'user_id',
            'qc_check_id',
            'product_id',
            // 'batch_id',
            // 'unique_id',
            'quantity_taken',
            // 'start_time',
            // 'end_time',
            // 'chemical_used',
            // 'qc_person_name',
            'fumigation_effective',
            're_fumigate',
            // 'status',
            // 'mobile_created_at',
            'created_at',
            'updated_at',
            // 'images',
        ],
    ]) ?>

</div>
