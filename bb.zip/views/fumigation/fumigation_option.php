<?php
use yii\widgets\ActiveForm;
use app\models\FumigationMapper;
use yii\helpers\Url;

use app\models\Product;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;

?>
<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<style type="text/css">
.container{
	overflow-x: hidden;
	overflow-y: auto;
}
.text{
	height: 500px;
}
.btn-success{
	text-align: center;
	background: #DAA54B; 
	border-style:none;
	display:block;
	width: 20%;
    min-width: 20%;   
    /* max-width: 25%;  */
    }
	.btn_done{
		text-align: center;
		width:100%;
		display:block;
		margin-left:40%;
	}
       .btn-success:hover{
		text-align: center;
	    background: #DAA54B; 
		border-style:none;
		display:block;
		width: 20%;
		min-width: 20%;   
        /* max-width: 25%;  */
       }
       .btn-success:link{
		text-align: center;
	    background: #DAA54B; 
		border-style:none;
		display:block;
		width: 20%;
        min-width: 20%;   
        /* max-width: 25%;   */
       }
       .btn-success:visited{
		text-align: center;
	    background: #DAA54B; 
		border-style:none;
		display:block;
		width: 20%;
		min-width:20%;   
        /* max-width: 25%;  */
       }
       .btn-success:active{
		text-align: center;
	    background: #DAA54B; 
		border-style:none;
		display:block;	
		width: 20%;
        min-width: 20%;   
        /* max-width: 25%; 	 */
       }
	   .x_content{
		border-bottom:1px solid lightgray;
		/* overflow:auto; */
	   }

</style>

<div class="container">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_content">
				<br>
				<div class="row

					<div class="col-md-12">
						<div class="panel panel-default">
							<div class="panel-body">
								<div class="row">
									<?php $form = ActiveForm::begin([
									'action' => ['fumigation-proceed'],
									'method' => 'post',
									]);
									 ?>

										<form action="" class="form-horizontal form-label-left">
										<?php
											foreach ($model as  $value) {  ?>
											<div class="col-md-7">
											    <label>Do you want to proceed <?= $value['product_name']  ?> for Fumigation Process?</label><br>
												<input type="radio" name="Fumigation[<?= $value['unique_id'] ?>][unique_id]" value="<?= $value['unique_id']  ?>" id="f_accept"  "required"> Yes
												<input type="radio" name="Fumigation[<?= $value['unique_id'] ?>][unique_id]" value="No" id="f_reject" "required">  No
											</div><br>
											 <?php } ?>
										<div class="col-md-3 btn_done"><br>
											<input type="submit" name="submit" id="p" value="Proceed" class="  btn btn-success">
										 </div> 
										</form>
									<?php ActiveForm::end(); ?>
								</div>
							</div>
						</div>
					</div>
					
				</div>
			<!-- </div>
		</div> -->
	</div>
	
</div>
 