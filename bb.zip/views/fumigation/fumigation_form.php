<?php
use yii\widgets\ActiveForm;
use app\models\FumigationMapper;
use yii\helpers\Url;

?>
<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<style type="text/css">
.container{
	overflow-x: hidden;
	overflow-y: auto;
}
.text{
	height: 500px;
}
.btn-success{
	text-align: center;
	background: #DAA54B; 
	border-style:none;
	display:block;
	width: 20%;
    min-width: 20%;   
    max-width: 25%;  
    }
	.btn_done{
		text-align: center;
		width:100%;
		display:block;
		margin-left:40%;
	}
       .btn-success:hover{
		text-align: center;
	    background: #DAA54B; 
		border-style:none;
		display:block;
		width: 20%;
		min-width: 20%;   
       }
       .btn-success:link{
		text-align: center;
	    background: #DAA54B; 
		border-style:none;
		display:block;
		width: 20%;
        min-width: 20%;   
        /* max-width: 25%;   */
       }
       .btn-success:visited{
		text-align: center;
	    background: #DAA54B; 
		border-style:none;
		display:block;
		width: 20%;
		min-width:20%;   
        /* max-width: 25%;  */
       }
       .btn-success:active{
		text-align: center;
	    background: #DAA54B; 
		border-style:none;
		display:block;	
		width: 20%;
        min-width: 20%;   
        /* max-width: 25%; 	 */
       }
	   .x_content{
		border-bottom:1px solid lightgray;
		/* overflow:auto; */
	   }
       #type{
       	margin-left: 5px;
       }
</style>

<div class="container">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_content">
				<br>
				<div class="row">
					<?php
					// print_r($data );
					foreach ($data as  $value) { ?>
					<div class="col-md-12">
						<div class="panel panel-default" style="margin-top: -10px;">
							<div class="panel-body">
								<div class="row">
									<div class="col-md-12">
										<b>Product Name :</b> <?= $value['product_name'] ?>
									</div>
									<div class="col-md-12">
										<b>Batch ID :</b> <?= $value['batch_id'] ?>
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php } ?>
				</div>
			<!-- </div>
		</div> -->
	</div>
	<div class="col-md-12 col-sm-12 col-xs-12">
	  <div>
				<h2><b>Fumigation Process</b></h2>
				<div class="clearfix"></div>
	  </div>
		<!-- <div class="x_panel">
			<div class="x_content"> -->
				<br>
				<div class="row">
					<?php $form = ActiveForm::begin([
						'options' => ['enctype' => 'multipart/form-data'],
						'action' => ['fumigation-create'],
						'method' => 'post',
						]); ?>
					<?php
					$i=0;
					foreach ($data as  $value) {
                     $fumigation = FumigationMapper::find()->select(['quantity_value','available_qty'])->where(['product_id'=>$value['product_id']])->andWhere(['incoming_qc_uniq_id'=>$value['unique_id']])->orderBy(['(id)' => SORT_DESC])->one();
                    
                    

                    if($fumigation){
                          $value['accepted_qty'] = ($fumigation->available_qty)-($fumigation->quantity_value); 
                    }
					 ?>
					<div class="col-md-4">
						<label><?= $value['product_name']   ?></label></br>
						<label>Available: </label>&nbsp;&nbsp;<?= $value['accepted_qty']   ?>Kgs</br>
					</div>

					<div class="col-md-8">
						<label>Batch: </label> <?= $value['batch_id']   ?>
						<input type="hidden" name="Fumigation[user_id]" value="<?= $value['user_id']   ?>" class="form-control">

						<input type="hidden" name="Fumigation[quantity_taken][<?= $i ?>][product_id]" value="<?= $value['product_id']   ?>" class="form-control">

						<input type="hidden" name="Fumigation[quantity_taken][<?= $i ?>][incoming_qc_uniq_id]" value="<?= $value['unique_id']   ?>" class="form-control">

						<input type="hidden" name="Fumigation[quantity_taken][<?= $i ?>][batch_id]" value="<?= $value['batch_id']   ?>" class="form-control">

						<input type="hidden" name="Fumigation[quantity_taken][<?= $i ?>][accepted_qty]" value="<?= $value['accepted_qty']   ?>" class="form-control">
						<input type="number" name="Fumigation[quantity_taken][<?= $i ?>][quantity_value]" min="0" max="<?= $value['accepted_qty']   ?>" class="form-control">
					</div>
					<?php $i++; } ?>

					<div class="col-md-12">
						<hr>
					</div>
					<div class="col-md-7">
					    <label>Fumigation Type</label><br>
						<input type="radio" id="type" name="Fumigation[fumigation_type]" value="<?php echo $f_type[0]['fumigation_days'];?>"> Type1
						<input type="radio" id="type" name="Fumigation[fumigation_type]" value="<?php echo $f_type[1]['fumigation_days'];?>"> Type2
						<input type="radio" id="type" name="Fumigation[fumigation_type]" value="<?php echo $f_type[2]['fumigation_days'];?>"> Type3
					</div>
					<div class="col-md-12">
						<hr>
					</div>
					<div class="col-md-6">
						<?= $form->field($model, 'start_time')->textInput(['class'=>'datepicker form-control']) ?>
					</div>
					<div class="col-md-6">
						<?= $form->field($model, 'end_time')->textInput(['class'=>'datepicker form-control']) ?>
					</div>
					<div class="col-md-12">
						<hr>
					</div>
					<div class="col-md-7">
						<?= $form->field($model, 'chemical_used') ?>
					</div>
					<div class="col-md-12">
						<hr>
					</div>
					<div class="col-md-7">
						<?= $form->field($model, 'qc_person_name') ?>
					</div>
					<div class="col-md-12">
						<hr>
					</div>
					
					<div class="col-md-7">
					    <label>Fumigation Effective?</label><br>
						<input type="radio" name="Fumigation[fumigation_effective]" value="Yes"> Yes
						<input type="radio" name="Fumigation[fumigation_effective]" value="No">  No
					</div>

					<div class="col-md-12">
						<hr>
					</div>
					<div class="col-md-7">
					    <label>Do you want to Re-Fumigate?</label><br>
						<input type="radio" name="Fumigation[re_fumigate]" value="Yes"> Yes
						<input type="radio" name="Fumigation[re_fumigate]" value="No">  No
					</div>
					<div class="col-md-12">
						<hr>
					</div>
					<div class="row" style="padding:0;margin:0;">
                      <div class="col-lg-4">
					      <?= $form->field($model, 'images')->FileInput() ?> 
					  </div>
					</div> <br>
					<div class="col-md-12">
						<textarea style="display:block;" name="Fumigation[comments]" class="form-control" rows="3" placeholder="Share your comments"></textarea><br>
					</div>
					 
					 <div class="col-md-3 btn_done"><br>
						<input type="submit" class="form-control btn btn-success"  value="Done" >
					 </div> 
					<?php ActiveForm::end(); ?>
				</div>
			</div>
		</div>
	</div>
</div>