<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $searchModel app\models\FumigationSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Fumigations';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="fumigation-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php Pjax::begin(); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Fumigation', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>
    <?= Html::submitButton('Search', ['class' => 'btn btn-primary','style'=>'display:none']) ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn', 'header' => 'Sr.No'],

            //'id',
            //'product_id',
            [
                'attribute'=>'product_id',
                "value"=>"product.name"
            ],
            'batch_id',
            // 'user_id',
            // 'qc_check_id',
            
            //  [
            //     'attribute'=>'product_id',
            //     "value"=>"state.name"
            // ],
            
            //'unique_id',
            //'quantity_taken',
            //'start_time',
            //'end_time',
            //'chemical_used',
            //'qc_person_name',
            //'fumigation_effective',
            //'re_fumigate',
            //'status',
            //'mobile_created_at',
            //'created_at',
            // [ 
            //     'attribute'=>'created_at',
            //     'value' => function($data){
            //         return date("Y-m-d H:i:s", 
            //                strtotime($data->created_at));
            //     }
            // ],       
            // [ 
            //     'attribute'=>'updated_at',
            //     'value' => function($data){
            //         return (!empty($data->updated_at)) ? 
            //                 date("Y-m-d H:i:s",
            //                 strtotime($data->updated_at)) : null;
            //     }
            // ],
            //'updated_at',
            //'images',

             [
                   'class' => 'yii\grid\ActionColumn',
                    'contentOptions'=>['style'=>'width: 60px;text-align: center;'],
                    'header'=>'Action', 
                    'template' => '{view} {update} {delete}',
                    'buttons' => [
                        'view' => function ($url, $model) {
                            return Html::a('<span class="glyphicon glyphicon-eye-open"></span>', $url, [
                                        'title' => Yii::t('app', 'lead-view'),
                            ]);
                        },
                        'update' => function ($url, $model) {
                            return Html::a('<span class="glyphicon glyphicon-pencil"></span>', $url, [
                                        'title' => Yii::t('app', 'lead-update'),
                            ]);
                        },

                        'delete' => function ($url, $model) {
                            return Html::a('<span class="glyphicon glyphicon-trash" onclick="ask_confirm(\''.$model->id.'\',\''.Yii::$app->controller->id .'\')"></span>', $url, [
                                        'title' => Yii::t('app', 'Delete'),                        
                            ]);
                        },
                    ],
                    'urlCreator' => function ($action, $model, $key, $index) {
                         if ($action === 'view') {
                            $url ='../fumigation/view?id='.$model->id;
                            return $url;
                        }
                        if ($action === 'update') {
                            $url ='../fumigation/update?id='.$model->id;
                            return $url;
                        }
                        if ($action === 'delete') {
                            $url = "#";
                            return $url;
                        }
                    } 
            ],
        ],
    ]); ?>
    <?php ActiveForm::end(); ?>
    <?php Pjax::end(); ?>
</div>
