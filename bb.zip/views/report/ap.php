<?php
use app\models\Product;
use app\models\Supplier;
use app\models\Users;
use app\models\ProductSearch;
use yii\helpers\Url;

?>
<form class="form" id="container-fluid" style="max-width: none; width: 1005px;">     
   <div id="content">
      <div class="panel panel-default">
         <div class="panel-body">
            <h2 align="center"><u><b>Final Goods Analysis Report</b></u></h2><br>
            <div class="row" style="overflow-x: scroll;">
               <table class="table table-bordered">
                  <thead>
                     <tr>
                        <th colspan="7"></th>
                        <th colspan="8">Vehicle Status</th>
                        <th colspan="<?php echo (COUNT($qc_cols['Incoming']) + 7);?>">Incoming QC Check</th>
                        <th colspan="10"> Fumigation</th>
                        <th colspan="11"> Cleaning</th>
                        <th colspan="<?php echo (COUNT($qc_cols['FG QC Check']) + 5);?>"> FG QC Check</th>
                     </tr>
                  </thead>
                  <tbody>
                     <tr>
                        <th>S.No</th>
                        <th>RPC Name</th>
                        <th>Product Name</th>
                        <th>Supplier Name</th>
                        <th>Raw Material Batch Number</th>
                        <th>FG Batch Number</th>
                        <th>Incoming Date</th>
                        <th>Cleanliness</th>
                        <th>No Chemical, Liquor, Fertilizer Residue Found</th>
                        <th>Odourless</th>
                        <th>Covered</th>
                        <th>Status</th>
                        <th>Image</th>
                        <th>Updated By</th>
                        <th>QC Check Date</th>
                        <?php 
                        foreach ($qc_cols['Incoming'] as $key => $value) {
                           echo '<th>'.ucwords($value).'</th>';
                        }
                        ?>
                        <th>Image</th>
                        <th>Total Qty Received(Kgs)</th>
                        <th>Accepted Qty(Kgs)</th>
                        <th>Fumigation Needed</th>
                        <th>Cleaning Needed</th>
                        <th>Updated By</th>

                        <th>Fumigant Type</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Qty Taken For Fumigation(Kgs)</th>
                        <th>Agency Name</th>
                        <th>Image</th>
                        <th>Updated By</th>
                        <th>Fumigation Effective</th>
                        <th>Refumigation Required</th>
                        <th>Updated By</th>

                        <th>Date</th>
                        <th>Qty Taken for Cleaning(Kgs)</th>
                        <th>Destoner</th>
                        <th>Vibro - Shifter</th>
                        <th>Vibro - Shifter with Magnet </th>
                        <th>Manual Cleaning</th>
                        <th>Blower</th>
                        <th>Table Grading</th>
                        <th>Automated - Mechanial Sieving, Mechanical Blower</th>
                        <th>Manual Filling / FFS Filling Check</th>
                        <th>Image</th>
                        <th>Updated By</th>
                        <?php 
                        foreach ($qc_cols['FG QC Check'] as $key => $value) {
                           echo '<th>'.ucwords($value).'</th>';
                        }
                        ?>
                        <th>Package Size(Kgs)</th>
                        <th>No.of Packs</th>
                        <th>Total Packed Size(Kgs)</th>
                        <th>Status</th>
                        <th>Updated By</th> 
                     </tr>
                     <?php
                     $i = 1;
                     foreach ($data as $key => $value) 
                     {
                        foreach ($value as $row) 
                        {
                           $row['nr_vehicle_inspection_checklist'] = json_decode($row['nr_vehicle_inspection_checklist'],true);
                           $row['c_cleaning_checklist'] = json_decode($row['c_cleaning_checklist'],true);
                           foreach ($row['c_cleaning_checklist'] as $index => $carr) {
                              $cleaning_chk[$carr['id']] = $carr['value'];
                           }


                           ?>
                           <tr>
                              <td><?= $i?></td>
                              <td><?= $row['rpc_rpc_name'] ?></td>  <!-- RPC NAME -->
                              <td>
                                 <?php $Prod = Product::find()->where(['id'=>$row['iqc_product_id']])->one();?>
                                 <?= $Prod->name?>
                              </td>   <!-- PRODUCT NAME -->
                              <td>
                                 <?php $Supp = Supplier::find()->where(['unique_id'=>$row['rpc_supplier_id']])->one();?>
                                 <?= $Supp->name?>
                              </td>   <!-- SUPPLIER NAME -->
                              <td><?= $row['iqc_batch_id'] ?></td>
                              <td><?= $qc_cols_products[$row['iqc_product_id']]['fg_batch'] ?></td>
                              <td><?= date("Y-m-d",strtotime($row['nr_vehicle_date'])) ?></td>
                              <td>
                                 <?= (in_array("Cleaning", $row['nr_vehicle_inspection_checklist'])) ? "Yes" : 'No'?>
                              </td> <!-- Cleanliness -->
                              <td>
                                 <?= (in_array("No chemical, liquor, fertilizer residue found", $row['nr_vehicle_inspection_checklist'])) ? "Yes" : 'No';?>
                              </td> <!-- No Chemical, Liquor, Fertilizer Residue Found -->
                              <td>
                                 <?= (in_array("Odourless", $row['nr_vehicle_inspection_checklist'])) ? "Yes" : 'No'?>
                              </td> <!-- Odourless -->
                              <td>
                                 <?= (in_array("Covered", $row['nr_vehicle_inspection_checklist'])) ? "Yes" : 'No'?>
                              </td> <!-- Covered -->
                              <td><?= ucwords($row['nr_vehicle_status']) ?></td>   <!-- VEHICLE STATUS -->
                              <td><?= '<a href="'."http://" . $_SERVER['SERVER_NAME'].Url::base()."/images/new-request/".$row['nr_vehicle_image'].'" >View Image</a>' ?></td>
                              <td>
                                 <?php $Users = Users::find()->where(['id'=>$row['nr_user_id']])->one();?>
                                 <?= $Users->name?>
                              </td>   <!-- UPDATED BY -->

                              <!-- INCOMING QC CHECK STARTS -->
                              <td><?= $row['iqc_incoming_date'] ?></td>
                              <?php 
                              foreach ($qc_cols['Incoming'] as $qc_column) {
                                 if(isset($qc_cols_products[$row['iqc_product_id']]['Incoming'][$qc_column]))
                                 {
                                    echo '<td>'.ucwords($qc_cols_products[$row['iqc_product_id']]['Incoming'][$qc_column]).'</td>';
                                 }else{
                                    echo '<td></td>';

                                 }
                              }
                              ?>
                              <td><?= '<a href="'."http://" . $_SERVER['SERVER_NAME'].Url::base()."/images/new-request/".$row['iqc_product_image'].'" >View Image</a>' ?></td>
                              <td><?= $row['iqc_arrived_qty'] ?></td>
                              <td><?= $row['iqc_accepted_qty'] ?></td>
                              <td><?= ($row['iqc_product_is_fumigation']) ? "Yes" : "No" ?></td>
                              <td><?= ($row['iqc_product_is_cleaning']) ? "Yes" : "No" ?></td>
                              <td>
                                 <?php $Users = Users::find()->where(['id'=>$row['iqc_user_id']])->one();?>
                                 <?= $Users->name?>
                              </td>

                              <!-- INCOMING QC CHECK ENDS -->

                              <!-- FUMIGATION CHECK STARTS -->
                              <td><?= $row['f_fumigation_type'] ?></td>
                              <td><?= $row['f_start_time'] ?></td>
                              <td><?= $row['f_end_time'] ?></td>
                              <td><?= $row['fm_quantity_value'] ?></td>                              
                              <td><?= $row['f_rpc_center_id'] ?></td>
                              <td><?= ucwords($row['f_chemical_used']) ?></td>
                              <td><?= '<a href="'."http://" . $_SERVER['SERVER_NAME'].Url::base()."/images/new-request/".$row['f_images'].'" >View Image</a>' ?></td>
                              <td><?= ($row['f_fumigation_effective']) ? "Yes" : "No" ?></td>
                              <td><?= ($row['f_re_fumigate']) ? "Yes" : "No" ?></td>
                              <td>
                                 <?php $Users = Users::find()->where(['id'=>$row['f_user_id']])->one();?>
                                 <?= $Users->name?>
                              </td>

                              <!-- FUMIGATION CHECK ENDS -->
                              <td><?= $row['c_cleaning_date'] ?></td>
                              <td><?= $row['c_quantity_value'] ?></td>
                              <td><?= (array_key_exists('Destoner', $cleaning_chk)) ? $cleaning_chk['Destoner'] : 'N/A' ?></td>
                              <td><?= (array_key_exists('Vibro - Shifter', $cleaning_chk)) ? $cleaning_chk['Vibro - Shifter'] : 'N/A' ?></td>
                              <td><?= (array_key_exists('Vibro - Shifter with Magnet', $cleaning_chk)) ? $cleaning_chk['Vibro - Shifter with Magnet'] : 'N/A' ?></td>
                              <td><?= (array_key_exists('Manual Cleaning', $cleaning_chk)) ? $cleaning_chk['Manual Cleaning'] : 'N/A' ?></td>
                              <td><?= (array_key_exists('Blower', $cleaning_chk)) ? $cleaning_chk['Blower'] : 'N/A' ?></td>
                              <td><?= (array_key_exists('Table Grading', $cleaning_chk)) ? $cleaning_chk['Table Grading'] : 'N/A' ?></td>
                              <td><?= (array_key_exists('Automated - Mechanial Sieving, Mechanical Blower', $cleaning_chk)) ? $cleaning_chk['Automated - Mechanial Sieving, Mechanical Blower'] : 'N/A' ?></td>
                              <td><?= (array_key_exists('Manual Filling / FFS Filling Check', $cleaning_chk)) ? $cleaning_chk['Manual Filling / FFS Filling Check'] : 'N/A' ?></td>
                              <td><?= '<a href="'."http://" . $_SERVER['SERVER_NAME'].Url::base()."/images/new-request/".$row['c_image'].'" >View Image</a>' ?></td>
                              <td>
                                 <?php $Users = Users::find()->where(['id'=>$row['c_cleaning_user']])->one();?>
                                 <?= $Users->name?>
                              </td>
                              <!-- FGQC STARTS -->
                              
                              <?php 
                              foreach ($qc_cols['FG QC Check'] as $qc_column) 
                              {
                                 
                                 if(isset($qc_cols_products[$row['iqc_product_id']]['FG QC Check'][$qc_column]))
                                 {
                                    echo '<td>'.ucwords($qc_cols_products[$row['iqc_product_id']]['FG QC Check'][$qc_column]).'</td>';
                                 }else{
                                    echo '<td></td>';

                                 }
                              }
                              ?>
                              </td>
                              <td><?= $row['fgcm_packed_weight'] ?></td>
                              <td><?= $row['fgcm_packed_quantity'] ?></td>
                              <td><?= ($row['fgcm_packed_weight']*$row['fgcm_packed_quantity']) ?></td>
                              <td><?= $row['fgc_overall_status'] ?></td>
                              <td>
                                 <?php $Users = Users::find()->where(['id'=>$row['fgc_fguser']])->one();?>
                                 <?= $Users->name?>
                              </td>

                           </tr>
                           <?php  
                           $i++;
                        }  /*INNER FOREACH ENDS*/
                     }
                     ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div> 
   </div>
</form>