<?php
use yii\helpers\Url;
use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use app\models\RpcCentre;
use kartik\select2\Select2;
?>
<style type="text/css">
	.select2-container .select2-selection--single, .select2-container--default .select2-selection--single .select2-selection__rendered, .select2-container--default .select2-selection--single .select2-selection__arrow {
    height: 40px;
}

.select2-container--default .select2-selection--single .select2-selection__rendered {
    line-height: 40px;
}
</style>

<div class="panel panel-default" style="margin-top: 50px; font-size: 14px !important;" >
	<div class="panel-heading" align="center"><b>FG QC Check Details</b></div>
	<div class="panel-body">
		<div class="col-md-3">
			<label>FG Batch</label>
			<?php 
			$mappedArr = ArrayHelper::map($data,'id','value');
			?>
			<select id="fg_batch" class="js-example-basic-single make_it_select form-control" name="state">
				<?php 
				foreach ($mappedArr as $key => $value) {
					echo '<option value="'.$key.'">'.$value.'</option>';	
				}
				?>
			</select>
			<?php /*Html::dropDownList('fg_batch','',ArrayHelper::map($data,'id','value'),['prompt'=>'Select FG Batch','class'=>'form-control select2','id'=>'fg_batch'])*/ ?>
		</div>
		<div class="col-md-3" style="margin-top: 3%">
			<input type="button" name="" id="search" value="Search" class="btn btn-xs btn-success" onclick="final_goods_inspection()">
		</div>
	</div>
</div>
<div id="list_inspection"></div>

<script type="text/javascript">
	function final_goods_inspection(){
        let fg_batch = $("#fg_batch").val();

		$.ajax({
			url: '<?php echo Url::to(["report/all-list-fg"]); ?>',
			type: 'post',
			data: {
				'fg_batch': fg_batch
			},
			success: function (res) {
				// console.log(res);

                // $("#csv_download").css('display','block');
				$("#list_inspection").html(res);
			},
			error: function (res) {
			}
		}); 
	}
</script>