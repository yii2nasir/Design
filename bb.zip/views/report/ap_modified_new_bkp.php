<?php
use app\models\Product;
use app\models\Supplier;
use app\models\Users;
use app\models\ProductSearch;
use yii\helpers\Url;
use yii\helpers\ArrayHelper;
use app\models\RpcCentre;

?>
<style type="text/css">
.select2-container .select2-selection--single, .select2-container--default .select2-selection--single .select2-selection__rendered, .select2-container--default .select2-selection--single .select2-selection__arrow {
 height: 40px;
}

.select2-container--default .select2-selection--single .select2-selection__rendered {
 line-height: 40px;
}
.datepicker{
   border:1px solid #aaa;
}
</style>    
<div id="content">
   <form class="form" method="GET" action="<?= $_SERVER['PHP_SELF']?>" id="container-fluid" > 
      <div class="panel panel-default" style="margin-top: 70px; font-size: 14px !important;" >
         <div class="panel-heading" align="center"><b>Filters</b></div>
         <div class="panel-body">
            <table class="table table-bordered">
               <tr>
                  <td width="50%"><label>RPC Name</label></td>
                  <td>
                     <?php $mappedArr = ArrayHelper::map(RpcCentre::find()->all(),'id','rpc_name'); ?>
                     <select placeholder="Select RPC" id="rpc_batch" class="js-example-basic-single rpc_select form-control" name="rpc_id">
                        <?php 
                        foreach ($mappedArr as $key => $value) {
                           echo '<option value="'.$key.'" >'.$value.'</option>';  
                        }
                        ?>
                     </select></td>
                  </tr>
                  <tr>
                     <td><label>Product Name</label></td>
                     <td>
                        <?php $mappedArr = ArrayHelper::map(Product::find()->all(),'id','name'); ?>
                        <select class="js-example-basic-single product_select form-control" name="product_id">
                           <?php
                           foreach ($mappedArr as $key => $value) {
                              echo '<option value="'.$key.'" >'.$value.'</option>';  
                           }
                           ?>
                        </select>
                     </td>
                  </tr>
                  <tr>
                     <td><label>FG Batch</label></td>
                     <td>
                        <select class="js-example-basic-single batch_select form-control" name="batch_id">
                           <?php
                           foreach ($fgbatch as $key => $value) {
                              echo '<option value="'.$value['pid'].'" >'.$value['value'].'</option>';  
                           }
                           ?>
                        </select>
                     </td>
                  </tr>
                  <tr>
                     <td><label>From</label></td>
                     <td><input type="text" class="form-control datepicker" value="<?= Yii::$app->request->get('from_date',date("Y-m-d")) ?>" name="from_date" id="from_date"></td>
                  </tr>
                  <tr>
                     <td><label>To</label></td>
                     <td><input type="text" class="form-control datepicker" value="<?= Yii::$app->request->get('to_date',date("Y-m-d")) ?>" name="to_date" id="to_date"></td>
                  </tr>
                  <tr>
                     <td colspan="2"><input type="submit" name="filter_report" value="Filter" class="btn btn-primary"></td>
                  </tr>
               </table>
            </div>
         </div>

      </form>
      <div class="panel panel-default">
         <div class="panel-body">
            <h2 align="center"><u><b>All Stages Report</b></u>
            <?php 
            //if(COUNT($allrecords) > 0) echo '  (<i onclick="exceller()" style="cursor:pointer;" class="fa fa-download"></i>)';
            if(isset($_GET['csv']) && $_GET['csv'] == '1')
            {
               $path = Yii::$app->request->absoluteUrl;
            }else{
               $path = Yii::$app->request->absoluteUrl."&csv=1";
            }
            if(COUNT($allrecords) > 0) echo '  (<a target="_blank" href="'.$path.'" ><i style="cursor:pointer;" class="fa fa-download"></i></a>)';?></h2><br>

            <div class="row" style="overflow-x: scroll;">
               <table id="toExcel" class="table table-bordered">
                  <thead>
                     <tr>
                        <th>S.No</th>
                        <th>RPC Name</th>
                        <th>Product Name</th>
                        <th>Supplier Name</th>
                        <th>Raw Material Batch Number</th>
                        <th>FG Batch Number</th>
                        <th>Process</th>
                        <th>Parameter</th>
                        <th>Actual</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php
                     $i = 1;
                     if(COUNT($allrecords) > 0)
                     {
                        foreach ($allrecords as $reqid => $data) 
                        {
                           foreach ($data as $product_id => $value) 
                           {
                              foreach ($value['vehicle'] as $parameter => $actual) 
                              {
                                 ?>
                                 <tr>
                                    <td><?= $i?></td>
                                    <td><?= $value['details']['rpc_name'] ?></td>  <!-- RPC NAME -->
                                    <td>
                                       <?php $Prod = Product::find()->where(['id'=>$product_id])->one();?>
                                       <?= $Prod->name?>
                                    </td>   <!-- PRODUCT NAME -->
                                    <td>
                                       <?php $Supp = Supplier::find()->where(['unique_id'=>$value['details']['supplier_name']])->one();?>
                                       <?= $Supp->name?>
                                    </td>   <!-- SUPPLIER NAME -->
                                    <td><?= $value['details']['raw_material_batch_number'] ?></td>
                                    <td><?= $value['fg_batch'] ?></td>
                                    <td><?= "Vehicle Status" ?></td>
                                    <td><?= ucwords(str_replace("_", " ", $parameter)) ?></td>
                                    <td><?= $actual ?></td>
                                 </tr>
                                 <?php  
                                 $i++;
                              }  /*vehicle FOREACH ENDS*/

                              foreach ($value['Incoming'] as $parameter => $actual) 
                              {
                                 ?>
                                 <tr>
                                    <td><?= $i?></td>
                                    <td><?= $value['details']['rpc_name'] ?></td>  <!-- RPC NAME -->
                                    <td>
                                       <?php $Prod = Product::find()->where(['id'=>$product_id])->one();?>
                                       <?= $Prod->name?>
                                    </td>   <!-- PRODUCT NAME -->
                                    <td>
                                       <?php $Supp = Supplier::find()->where(['unique_id'=>$value['details']['supplier_name']])->one();?>
                                       <?= $Supp->name?>
                                    </td>   <!-- SUPPLIER NAME -->
                                    <td><?= $value['details']['raw_material_batch_number'] ?></td>
                                    <td><?= $value['fg_batch'] ?></td>
                                    <td><?= "Incoming QC Check" ?></td>
                                    <td><?= ucwords(str_replace("_", " ", $parameter)) ?></td>
                                    <td><?= $actual ?></td>
                                 </tr>
                                 <?php  
                                 $i++;
                              }  /*Incoming FOREACH ENDS*/

                              foreach ($value['fumigation'] as $fid => $sub_fumigation) 
                              {
                                 if(COUNT($sub_fumigation) > 0)
                                 {
                                    foreach ($sub_fumigation as $parameter => $actual) 
                                    {
                                       ?>
                                       <tr>
                                          <td><?= $i?></td>
                                          <td><?= $value['details']['rpc_name'] ?></td>  <!-- RPC NAME -->
                                          <td>
                                             <?php $Prod = Product::find()->where(['id'=>$product_id])->one();?>
                                             <?= $Prod->name?>
                                          </td>   <!-- PRODUCT NAME -->
                                          <td>
                                             <?php $Supp = Supplier::find()->where(['unique_id'=>$value['details']['supplier_name']])->one();?>
                                             <?= $Supp->name?>
                                          </td>   <!-- SUPPLIER NAME -->
                                          <td><?= $value['details']['raw_material_batch_number'] ?></td>
                                          <td><?= $value['fg_batch'] ?></td>
                                          <td><?= "Fumigation" ?></td>
                                          <td><?= ucwords(str_replace("_", " ", $parameter)) ?></td>
                                          <td><?= $actual ?></td>
                                       </tr>
                                       <?php 
                                       $i++;
                                    }
                                 }  // if fumigation was done
                              }  /*fumigation FOREACH ENDS*/

                              foreach ($value['cleaning'] as $cid => $sub_cleaning) 
                              {
                                 if(COUNT($sub_cleaning) > 0)
                                 {
                                    foreach ($sub_cleaning as $parameter => $actual) 
                                    {
                                       ?>
                                       <tr>
                                          <td><?= $i?></td>
                                          <td><?= $value['details']['rpc_name'] ?></td>  <!-- RPC NAME -->
                                          <td>
                                             <?php $Prod = Product::find()->where(['id'=>$product_id])->one();?>
                                             <?= $Prod->name?>
                                          </td>   <!-- PRODUCT NAME -->
                                          <td>
                                             <?php $Supp = Supplier::find()->where(['unique_id'=>$value['details']['supplier_name']])->one();?>
                                             <?= $Supp->name?>
                                          </td>   <!-- SUPPLIER NAME -->
                                          <td><?= $value['details']['raw_material_batch_number'] ?></td>
                                          <td><?= $value['fg_batch'] ?></td>
                                          <td><?= "Cleaning Process" ?></td>
                                          <td><?= ucwords(str_replace("_", " ", $parameter)) ?></td>
                                          <td><?= $actual ?></td>
                                       </tr>
                                       <?php  
                                       $i++;
                                    }
                                 }  // if cleaning was done
                              }  /*cleaning FOREACH ENDS*/

                              foreach ($value['FG QC Check'] as $fgid => $fg_array) 
                              {
                                 foreach ($fg_array as $fg_parameter => $fg_actual) 
                                 {
                                    ?>
                                    <tr>
                                       <td><?= $i?></td>
                                       <td><?= $value['details']['rpc_name'] ?></td>  <!-- RPC NAME -->
                                       <td>
                                          <?php $Prod = Product::find()->where(['id'=>$product_id])->one();?>
                                          <?= $Prod->name?>
                                       </td>   <!-- PRODUCT NAME -->
                                       <td>
                                          <?php $Supp = Supplier::find()->where(['unique_id'=>$value['details']['supplier_name']])->one();?>
                                          <?= $Supp->name?>
                                       </td>   <!-- SUPPLIER NAME -->
                                       <td><?= $value['details']['raw_material_batch_number'] ?></td>
                                       <td><?= $fg_array['FG Batch Number *'] ?></td>
                                       <td><?= "FG QC Check" ?></td>
                                       <td><?= ucwords(str_replace("_", " ", $fg_parameter)) ?></td>
                                       <td><?= $fg_actual ?></td>
                                    </tr>
                                    <?php  
                                    $i++;
                                 }  /*FG QC Check FOREACH ENDS*/

                                 if((isset($value['fgqc_entries'][$fgid])) && (COUNT($value['fgqc_entries'][$fgid]) > 0))
                                 {
                                    foreach ($value['fgqc_entries'][$fgid] as $fgm_id => $fgm_ar) 
                                    {
                                       foreach ($fgm_ar as $fgm_parameter => $fgm_actual) 
                                       {
                                          ?>
                                          <tr>
                                             <td><?= $i?></td>
                                             <td><?= $value['details']['rpc_name'] ?></td>  <!-- RPC NAME -->
                                             <td>
                                                <?php $Prod = Product::find()->where(['id'=>$product_id])->one();?>
                                                <?= $Prod->name?>
                                             </td>   <!-- PRODUCT NAME -->
                                             <td>
                                                <?php $Supp = Supplier::find()->where(['unique_id'=>$value['details']['supplier_name']])->one();?>
                                                <?= $Supp->name?>
                                             </td>   <!-- SUPPLIER NAME -->
                                             <td><?= $value['details']['raw_material_batch_number'] ?></td>
                                             <td><?= $fg_array['FG Batch Number *'] ?></td>
                                             <td><?= "FG QC Check" ?></td>
                                             <td><?= ucwords(str_replace("_", " ", $fgm_parameter)) ?></td>
                                             <td><?= $fgm_actual ?></td>
                                          </tr>
                                          <?php  
                                          $i++;
                                       }
                                    }  /*FG QC Check FOREACH ENDS*/
                                 }
                              }  /*FG QC Check FOREACH ENDS*/
                           }
                        }
                     }else{
                        echo '<tr>
                        <td colspan="9" style="text-align:center">No Record Found</td>
                        </tr>';
                     }

                     ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div> 
   </div>
   <script type="text/javascript">
      function exceller() {
         var uri = 'data:application/vnd.ms-excel;base64,',
         template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
         base64 = function(s) {
            return window.btoa(unescape(encodeURIComponent(s)))
         },
         format = function(s, c) {
            return s.replace(/{(\w+)}/g, function(m, p) {
               return c[p];
            })
         }
         var toExcel = document.getElementById("toExcel").innerHTML;
         var ctx = {
            worksheet: name || '',
            table: toExcel
         };
         var link = document.createElement("a");
         link.download = "export.xls";
         link.href = uri + base64(format(template, ctx))
         link.click();
      }


   </script>

