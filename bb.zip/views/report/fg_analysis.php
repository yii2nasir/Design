
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.3/jspdf.min.js"></script> -->
<!-- <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>   -->
  <!-- <script type="text/javascript" src="//cdn.rawgit.com/niklasvh/html2canvas/0.5.0-alpha2/dist/html2canvas.min.js"> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.5/jspdf.min.js"></script> 


<input type="button" id="create_pdf" value="Generate PDF" class="btn btn-success"> 


<form class="form" id="container-fluid" style="max-width: none; width: 1005px;">     
<div id="content">
   <div class="panel panel-default">
     <div class="panel-body">
      <h2 align="center"><u><b>Final Goods Analysis Report</b></u></h2><br>
        <div class="row">
          <div class="col-md-6">
            <p><b>Vendor Name :</b> <?= isset($data[0]['rpc_name']) ? $data[0]['rpc_name']:""  ?></p> 
            <p><b>Location :</b> <?= isset($data[0]['district_name']) ? $data[0]['district_name']:""  ?> </p> 
          </div>
          <div class="col-md-6">
           <p></p> 
           <p><b>Date: </b> <?= date('d-m-Y')  ?></p>
         </div>
       </div></br></br>

       <div class="row">
        <div class="col-md-6">
          <table class="table table-bordered">
            <tbody>
              <tr>
                <th>Article Name</th>
                <td><?= isset($data[0]['product_name']) ? $data[0]['product_name']:""  ?></td>
              </tr>
              <tr>
                <th>Supplier Name</th>
                <td><?= isset($data[0]['supplier_name']) ? $data[0]['supplier_name']:""  ?></td>
              </tr>
              <tr>
                <th>Batch/Lot No.</th>
                <td><?= isset($data[0]['batch_id']) ? $data[0]['batch_id']:""  ?></td>
              </tr>
              <tr>
                <th>Date of Receipt</th>
                <td><?= isset($data[0]['created_date']) ? $data[0]['created_date']:""  ?></td>
              </tr>
              <tr>
                <th>Packed Date</th>
                <td><?= isset($data[0]['created_date']) ? $data[0]['created_date']:""  ?></td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="col-md-6">
          <table class="table table-bordered">
            <tbody>
              <tr>
                <th>Pack Sizes</th>
                <td>Quantity</td>
              </tr>
              <?php
              $totalQuantity = "";
              if($packSizeAll){
               foreach ($packSizeAll as $singleData){
              ?>
                <tr>
                  <th><?= $singleData['packed_weight']  ?></th>
                  <td><?= $singleData['packed_quantity']  ?></td>
                </tr>
              <?php
                  $totalQuantity = $totalQuantity + ($singleData['packed_weight'] * $singleData['packed_quantity']);
                }
               }
              ?>
            </tbody>
          </table>
        </div>
      </div>
      <h4 style="color: #FF0000">Below standard &amp; results are picked up from the analysis report of cleaned material</h4>
        <div class="row">
            <div class="col-md-12">
              <table class="table table-bordered">
              <tbody>
                <tr>
                  <th>Sl. No.</th>
                  <th>Parameters</th>
                  <th>Min</th>
                  <th>Max</th>
                  <th>Actual Result</th>
                </tr>
                
               <?php 
               $srNo = 1;
              if(isset($data[0]['bulk'])){
                
                foreach ($data[0]['bulk'] as  $value) { ?>
                <tr>
                  <th><?= $srNo ?></th>
                  <th><?= $value['name'] ?></th>
                  <td><?= $value['option_1'] ?></td>
                  <td><?= $value['option_2'] ?></td>
                  <td><?= $value['value'] ?></td>
                </tr>
                <?php $srNo++; }  }?>
              </tbody>
            </table>
            </div>
        </div> <br>
        <h4 style="color: black"><u>All the processes as per standard protocols are followed:</u> Yes</h4><br>
      <div class="row" style="display: block;">
          <div class="col-md-12">
            <table class="table table-bordered">
            <tbody>
              <tr>
                <th>Total Quantity(In Kgs)</th>
                <td><?= $totalQuantity  ?></td>
              </tr>
              <tr>
                <th>Checked By</th>
                <td><?= isset($data[0]['user_name']) ? $data[0]['user_name']:""  ?></td>
              </tr>
            </tbody>
          </table>
          </div>
        </div>
     </div>
    </div> 
</div>
</form>

<script>  


 $('#create_pdf').on('click', function () {  
       makePDF();
 });


function makePDF() {
        var quotes = document.getElementById('container-fluid');

        html2canvas(quotes, {
            onrendered: function(canvas) {

            //! MAKE YOUR PDF
            var pdf = new jsPDF('p', 'pt', 'a4');

            for (var i = 0; i <= quotes.clientHeight/980; i++) {
                //! This is all just html2canvas stuff
                var srcImg  = canvas;
                var sX      = 0;
                var sY      = 980*i; // start 980 pixels down for every new page
                var sWidth  = 950;
                var sHeight = 980;
                var dX      = 0;
                var dY      = 0;
                var dWidth  = 900;
                var dHeight = 980;

                window.onePageCanvas = document.createElement("canvas");
                onePageCanvas.setAttribute('width', 980);
                onePageCanvas.setAttribute('height', 980);
                var ctx = onePageCanvas.getContext('2d');

                /// images
                ctx.drawImage(srcImg,sX,sY,sWidth,sHeight,dX,dY,dWidth,dHeight);

                // document.body.appendChild(canvas);
                var canvasDataURL = onePageCanvas.toDataURL("image/png", 1.0);

                var width         = onePageCanvas.width;
                var height        = onePageCanvas.clientHeight;

                //! If we're on anything other than the first page,
                // add another page
                if (i > 0) {
                    pdf.addPage(612, 791); //8.5" x 11" in pts (in*72)
                }
                //! now we declare that we're working on that page
                pdf.setPage(i+1);
                //! now we add content to that page!
                pdf.addImage(canvasDataURL, 'PNG', 20, 40, (width*.62), (height*.62));

            }

            //! after the for loop is finished running, we save the pdf.
            pdf.save('Final Goods Analysis Report.pdf');
        }
      });
    }
</script>  