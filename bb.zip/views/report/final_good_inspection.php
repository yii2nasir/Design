<?php
use yii\helpers\Url;
use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use app\models\RpcCentre;

?>

<style type="text/css">

div.ex3 {
	/*background-color: #D3D3D3;*/
	width: 100%;
	overflow-x: auto;
}
body{
	font-size: 10px !important;
}
</style>
<div class="panel panel-default" style="margin-top: 50px; font-size: 14px !important;" >
	<div class="panel-heading" align="center"><b>Report</b></div>
	<div class="panel-body">
		<div class="col-md-3">
			<label>RPC Name</label>
			<?= Html::dropDownList('rpc_centre','',ArrayHelper::map(RpcCentre::find()->all(),'id','rpc_name'),['prompt'=>'Select RPC','class'=>'form-control','id'=>'rpc_centre'])    ?>
		</div>
		<div class="col-md-3">
			<label>From Date</label>
			<input type="text" class="form-control datepicker" name="" id="from_date">
		</div>
		<div class="col-md-3">
			<label>To Date</label>
			<input type="text" class="form-control datepicker" name="" id="to_date">
		</div>
		<div class="col-md-3" style="margin-top: 3%">

			<input type="button" name="" id="search" value="Search" class="btn btn-success" onclick="final_goods_inspection()">
		</div>
	</div>
</div>
<input type="button" onclick="exceller()" id="csv_download" class="btn btn-success" value="CSV Download" style="display: none;">
<div class="ex3">
	<div id="final_goods_inspection">
	</div>
</div>
<script type="text/javascript">
	function final_goods_inspection(){
        let rpc_centre = $("#rpc_centre").val();
		let from_date = $("#from_date").val();
		let to_date = $("#to_date").val();

		$.ajax({
			url: '<?php echo Url::to(["report/final-goods-inspection-data"]); ?>',
			type: 'post',
			data: {
				'rpc_centre': rpc_centre,
				'from_date': from_date,
				'to_date' : to_date
			},
			success: function (res) {
                $("#csv_download").css('display','block');
				$("#final_goods_inspection").html(res);
			},
			error: function (res) {
			}
		}); 
	}
</script>

<script>
  function exceller() {
    var uri = 'data:application/vnd.ms-excel;base64,',
      template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
      base64 = function(s) {
        return window.btoa(unescape(encodeURIComponent(s)))
      },
      format = function(s, c) {
        return s.replace(/{(\w+)}/g, function(m, p) {
          return c[p];
        })
      }
    var toExcel = document.getElementById("toExcel").innerHTML;
    var ctx = {
      worksheet: name || '',
      table: toExcel
    };
    var link = document.createElement("a");
    link.download = "Final Goods Inspection.xls";
    link.href = uri + base64(format(template, ctx))
    link.click();
  }
</script>







