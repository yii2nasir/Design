<?php
use yii\helpers\Url;
use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use app\models\RpcCentre;

?>

<style type="text/css">

div.ex3 {
	/*background-color: #D3D3D3;*/
	width: 100%;
	overflow-x: auto;
}
body{
	font-size: 10px !important;
}
</style>
<div class="panel panel-default" style="margin-top: 50px; font-size: 14px !important;" >
	<div class="panel-heading" align="center"><b>Report</b></div>
	<div class="panel-body">
		<div class="col-md-3">
			<label>RPC Name</label>
			<?= Html::dropDownList('rpc_centre','',ArrayHelper::map(RpcCentre::find()->all(),'id','rpc_name'),['prompt'=>'Select RPC','class'=>'form-control','id'=>'rpc_centre'])    ?>
		</div>
		<div class="col-md-3">
			<label>From Date</label>
			<input type="text" class="form-control datepicker" name="" id="from_date">
		</div>
		<div class="col-md-3">
			<label>To Date</label>
			<input type="text" class="form-control datepicker" name="" id="to_date">
		</div>
		<div class="col-md-3" style="margin-top: 3%">

			<input type="button" name="" id="search" value="Search" class="btn btn-success" onclick="incomming_bulk_inspection()">
		</div>
	</div>
</div>

<button onclick="exceller()" class="btn btn-xs btn-success">CSV Download</button>
<div class="ex3">
	<div id="incomming_bulk_inspection">
	</div>
</div>
<div id="modddal" class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">

			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
				</button>
				<h4 class="modal-title" id="myModalLabel">Image</h4>
			</div>
			<div class="modal-body">
				<img id="modddal_img" style="width: 100%;height: auto;" src=""/>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>

		</div>
	</div>
</div>
<script type="text/javascript">
	function incomming_bulk_inspection(){
		let rpc_centre = $("#rpc_centre").val();
		let from_date = $("#from_date").val();
		let to_date = $("#to_date").val();

		$.ajax({
			url: '<?php echo Url::to(["report/incoming-bulk-data"]); ?>',
			type: 'post',
			data: {
				'rpc_centre' : rpc_centre,
				'from_date': from_date,
				'to_date' : to_date
			},
			success: function (res) {
				$("#incomming_bulk_inspection").html(res);
			},
			error: function (res) {
			}
		}); 
	}

	function exceller() {
		var uri = 'data:application/vnd.ms-excel;base64,',
		template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
		base64 = function(s) {
			return window.btoa(unescape(encodeURIComponent(s)))
		},
		format = function(s, c) {
			return s.replace(/{(\w+)}/g, function(m, p) {
				return c[p];
			})
		}
		var toExcel = document.getElementById("toExcel").innerHTML;
		var ctx = {
			worksheet: name || '',
			table: toExcel
		};
		var link = document.createElement("a");
		link.download = "export.xls";
		link.href = uri + base64(format(template, ctx))
		link.click();
	}


</script>





