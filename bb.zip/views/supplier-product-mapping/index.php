<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;


/* @var $this yii\web\View */
/* @var $searchModel app\models\SupplierProductMappingSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Supplier Product Mappings';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="supplier-product-mapping-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Supplier Product Mapping', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>
    <?= Html::submitButton('Search', ['class' => 'btn btn-primary','style'=>'display:none']) ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            //'product_id',
            [
                'attribute' => 'product_id',
                'value' =>'product.name'
            ],
            //'supplier_id',
             [
                'attribute' => 'supplier_id',
                'value' =>'supplier.name'
            ],
            [ 
                'attribute'=>'created_at',
                'value' => function($data){
                    return date("Y-m-d H:i:s", 
                           strtotime($data->created_at));
                }
            ],       
            [ 
                'attribute'=>'updated_at',
                'value' => function($data){
                    return (!empty($data->updated_at)) ? 
                            date("Y-m-d H:i:s",
                            strtotime($data->updated_at)) : null;
                }
            ],
            //'created_at',
            //'updated_at',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    <?php ActiveForm::end(); ?>
</div>
