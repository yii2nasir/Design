<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;
/* @var $this yii\web\View */
/* @var $model app\models\Block */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="block-form">

    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-md-4">
            <?php
            echo $form->field(new app\models\State(), 'id')->dropDownList(
                ArrayHelper::map(\app\models\State::find()->all(), "id", "name"),
                [
            'prompt' => 'Select State',
            'id' => 'state_id',
            'onchange' => 'getAllDistrict()',
                ]
            )->label("State");
            ?>
        </div>
    	<div class="col-md-4">
         <?= $form->field($model, 'district_id')->dropDownList(ArrayHelper::map(\app\models\District::find()->all(),'id','name'),['prompt' => 'Select District','id' => 'depDropDistrict']) ?>
        </div>
        <div class="col-md-4">
         <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>
        </div>
    </div>
    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
<script>

function getAllDistrict(){
    var state_id = document.getElementById("state_id").value;
    
    $.ajax({
        url: '<?php echo Url::to(["site/lists"]); ?>',
        type: 'post',
        data: {
            type : 1,
            id : state_id
        },
        success: function (res) {
            var nandghar = JSON.parse(res);
            var areaOption = "<option value=''>Select District</option>";
             for (var i = 0; i < nandghar.length; i++) {
                 areaOption += '<option value="' + nandghar[i]['id'] + '">' + nandghar[i]['name'] + '</option>'
             }
            $("#depDropDistrict").html(areaOption);

            if(document.getElementById("depDropDistrict") !== null){
                $("#depDropDistrict").val($("#depDropDistrict").val()).change();
            }
        },
        error: function (res) {
        }
    }); 
}
</script>