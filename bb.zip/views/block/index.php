<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\BlockSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Blocks';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="block-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Block', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            // 'id',
            // 'district_id',
            [
                'attribute'=>'district_id',
                "value"=>"district.name"
            ],
            'name',
            [ 
                'attribute'=>'created_at',
                'value' => function($data){
                    return date("d/m/Y H:i:s",  strtotime($data->created_at));
                }
            ],       
            [ 
                'attribute'=>'updated_at',
                'value' => function($data){
                    return (!empty($data->updated_at)) ? date("d/m/Y H:i:s",  strtotime($data->updated_at)) : null;
                }
            ],

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
