<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;
/* @var $this yii\web\View */
/* @var $model app\models\Supplier */
/* @var $form yii\widgets\ActiveForm */
?>
<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
  <style type="text/css">
	 .fs-label-wrap, .fs-dropdown {
	    user-select: none;
	    width: 462px;
	    /*height: 35px;*/
	}
  .btn.btn-success{
    background-color: cadetblue;
    border-style: none;
  }
	.select2-container--bootstrap .select2-selection--multiple {
	    min-height: 34px;
	    display: none !important;
	}
  </style>
  <link href="<?php echo Url::to("@web/js/fSelect.css"); ?>" rel="stylesheet">
  <script src="<?php echo Url::to("@web/js/fSelect.js"); ?>"></script>

  <div class="supplier-form">
  <?php $form = ActiveForm::begin(); ?>

    <div class="row">
      <div class="col-md-12">
        <div class="x_panel">
          <div class="x_content">
            <div class="col-md-12 col-sm-12 col-xs-12">

            <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>
             <?= $form->field($model, 'code')->textInput(['maxlength' => true]) ?>

            </div>
            <div class="col-md-6 form-group">
              <?php
                // $householdM = Household::find()->select(['hh_code','hh_head_name'])->asArray()->all();
              ?>          
            </div>
          </div>
          <div class="form-group">
            <?= Html::submitButton('Update', ['class' => 'btn btn-success']) ?>
          </div>
        </div>
      </div>
    </div>
  
  <?php ActiveForm::end(); ?>

</div>


<!-- script>
  (function($) {
    $(function() {
      $('.test').fSelect();
      });
    })(jQuery);
</script> -->
<script>
    // $('#supplier-code').val('SUP000N');
    $('#supplier-code').attr('readonly', true);
</script> 
