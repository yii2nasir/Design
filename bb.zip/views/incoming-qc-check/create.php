<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\IncomingQcCheck */

$this->title = 'Create Incoming Qc Check';
$this->params['breadcrumbs'][] = ['label' => 'Incoming Qc Checks', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="incoming-qc-check-create">

    <h1 style="font-size: 32px;"><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
        'qcCheckPhyChemy'=>$qcCheckPhyChemy,
        'userId'=>$userId,
        'productM'=>$productM
    ]) ?>

</div>
