<?php
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use app\models\Product;
use app\models\Supplier;
use app\models\IncomingQcCheck;

?>
<style type="text/css">
  #Accept{
    margin-left: 45%;
  }
</style>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h4>Incoming QC</h4>
      <div class="x_panel">
          <div class="x_content">
            <h4>Update Product Information</h4>
          <?php
          if($status == "o"){
            $model->overall_status = "Onhold";
          }else{
            $model->overall_status = "Accept";
          }
          


          $productCode = Product::find()->where(['id'=>$model->product_id])->one()->code;
          $SupplierCode = Supplier::find()->where(['id'=>$supplierId])->one()->code;
          
          // $incomingQcCheck = IncomingQcCheck::find()
          //                     ->where(['user_id'=>$model->user_id,'product_id'=>$model->product_id])
          //                     ->andWhere(['created_at'=>date('Y-m-d')])
          //                     ->andWhere(['batch_id'=>''])
          //                     ->all();
          //  display_array($incomingQcCheck);
          //  exit;            



          $batch_id = $SupplierCode.$productCode.(date('z') + 1).yearCode(date("Y"))."1";
          $model->batch_id = $batch_id;
          ?>
            <?php $form = ActiveForm::begin([
                'action'=>'qc-check-update',
                 'id'=>"css_margin"

             ]); ?>
               <?php 
                  $model->overall_status = "Accept";
               ?>
             <?= $form->field($model, 'request_id')->hiddenInput()->label("") ?>
              <?= $form->field($model, 'product_id')->hiddenInput()->label("") ?>
              <?= $form->field($model, 'overall_status')->hiddenInput(['maxlength' => true])->label("") ?>
              <?= $form->field($model, 'batch_id')->textInput(['readonly'=>true]) ?>
              <?= $form->field($model, 'arrived_qty')->textInput() ?>
              <span id="msg_arrived_qty" style="color: red"></span>
              <?= $form->field($model, 'accepted_qty')->textInput() ?>
              <span id="msg_accepted_qty" style="color: red"></span><br>
              <?= Html::submitButton('Save', ['class' => 'btn btn-success btnNext','id'=>'Accept']) ?>
           <?php ActiveForm::end(); ?>
        </div>
      </div>
    </div>
  </div>
</div>


<script type="text/javascript">


 $('.btnNext').click(function(){
  var arrived_qty =  $("#incomingqccheck-arrived_qty").val();
  var accepted_qty =  $("#incomingqccheck-accepted_qty").val();

  var flage =0;
  if(arrived_qty ==""){
     $("#msg_arrived_qty").html("Arrived quantity cannot be blank.");  
     flage++;
   }else{
    $("#msg_arrived_qty").html(""); 
  }
  if(accepted_qty ==""){
   $("#msg_accepted_qty").html("Accepted quantity cannot be blank.");  
   flage++;
  }else{
    $("#msg_accepted_qty").html(""); 
  }
   
  // if(accepted_qty > arrived_qty) {
  //    $("#msg_accepted_qty").html("Accepted quantity must be lessthan or equal to arrived quantity."); 
  //    flage++; 
  // }else{
  //    $("#msg_accepted_qty").html(""); 
  // }

  if(flage != 0){
    return false;
  }
 });



</script>
 
