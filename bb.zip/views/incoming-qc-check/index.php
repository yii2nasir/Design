<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\IncomingQcCheckSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Incoming Qc Checks';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="incoming-qc-check-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Incoming Qc Check', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'unique_id',
            'user_id',
            'request_id',
            'product_id',
            //'batch_id',
            //'arrived_qty',
            //'accepted_qty',
            //'overall_status',
            //'comments:ntext',
            //'status',
            //'latitude',
            //'logtitude',
            //'mobile_created_at',
            //'entry_type',
            //'created_at',
            //'updated_at',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
