<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model app\models\IncomingQcCheck */
/* @var $form yii\widgets\ActiveForm */
?>
<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<style type="text/css">
    button#partially_accept{
        margin-left: -2px ! important;
        width: 23% !important;
    }
    button#Reject{
        margin-left: -23% ! important;
        width: 23% !important;
    }
    button#Accept{
        margin-left: -2px ! important;
        width: 23% !important;
    }
     button#Onhold{
        margin-left: 4px ! important;
        width: 23% !important;
    }
    .form-group.field-incomingqccheck-product_image{
        margin: -107px 3px 0px 4px ! important;
    }
    .panel_data{
        padding-top: 0px !important;
        
    }
    .field-incomingqccheck-user_id{
        display: none;
    }
    .form-group{
        margin-bottom: -20px !important;
    }
    .fa-sign-in{
        font-size: 40px !important;
    }
    .category{
        text-indent: 10px;
        margin-top: 10px;
            }
</style> 



<div class="incoming-qc-check-form">
     <div class="panel panel-default">
      <div class="panel-body">
       <div class="row">
           <div class="col-md-12">
               <?= "<b>Product Name :</b> &nbsp;&nbsp;". $productM->name  ?>
           </div>
           <div class="col-md-12">
               <?= "<b>Product Code :   </b>&nbsp;&nbsp;". $productM->code  ?>
           </div>
       </div>    
   </div>
</div>
    <?php $form = ActiveForm::begin(['options'=>
    ['enctype'=>'multipart/form-data'],'id'=>'submitForm']); ?>

    <div class="row">
        <div class="col-md-12">
            <!-- <div class="col-md-6"> -->
                <div class="x_panel">
                    <div class="row">
                      <div class="panel_data">
                        <?php if(isset($_GET['rq_id']) && $_GET['rq_id'] !=""){
                            $model->request_id =$_GET['rq_id'];
                        }
                        if(isset($_GET['p']) && $_GET['p'] !=""){
                            $model->product_id =$_GET['p'];
                        } 
                        $model->user_id = $userId;
                        ?>
                        
                        
                         
                        <?= $form->field($model, 'user_id')->hiddenInput()->label("") ?>

                        <?= $form->field($model, 'request_id')->hiddenInput()->label("") ?>

                        <?= $form->field($model, 'product_id')->hiddenInput()->label("") ?>

                        <?php  $i=0; foreach ($qcCheckPhyChemy as  $value) {
                           // echo "<pre>";print_r($value);

                            if($value->category == 2){ ?>

                            <div>
                                <label class="category"><?= $value->name  ?> (Min- <?= $value->option_1  ?>  Max- <?= $value->option_2  ?>)</label>

                                <input type="text" style= "display: none" class="form-control" value= "<?=  $value['id'] ?>" name="IncomingQcCheck[resultQcCheck][<?= $i ?>][id]"><br>
                            <div class="col-md-5"><input type="number" class="form-control min-max" name="IncomingQcCheck[resultQcCheck][<?= $i ?>][value]"> </div><br>
                                <br><hr>
                                </div>
                         
                    <?php } elseif ($value->category == 1) { ?>
                <div>
                    <label><?= $value->name  ?></label>
                    <input type="text" style= "display: none" class="form-control" value= "<?=  $value['id'] ?>" name="IncomingQcCheck[resultQcCheck][<?= $i ?>][id]"> <br>
                    <div class="col-md-5"><input type="text"  name="IncomingQcCheck[resultQcCheck][<?= $i ?>][value]" class="form-control"></div><br>
                    <br><hr>
                </div>
                <?php } elseif ($value->category == 4) { ?>
                <div class="col-md-12">
                    <label><?= $value->name  ?></label><br>
                    <input type="text" style= "display: none" class="form-control" value= "<?=  $value['id'] ?>" name="IncomingQcCheck[resultQcCheck][<?= $i ?>][id]"> 
                    <?php if($value->option_1 !=""){ ?>
                    <input type="radio" class="coa_from_supplier" name="IncomingQcCheck[resultQcCheck][<?= $i ?>][value]" value="<?= $value->option_1 ?>" checked> <?= $value->option_1 ?>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <?php } if($value->option_2 !=""){ ?>
                    <input type="radio" class="coa_from_supplier" name="IncomingQcCheck[resultQcCheck][<?= $i ?>][value]" value="<?= $value->option_2 ?>">  <?= $value->option_2 ?>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <?php } if($value->option_3 !=""){ ?>
                    <input type="radio" name="IncomingQcCheck[resultQcCheck][<?= $i ?>][value]" value="<?= $value->option_3 ?>">  <?= $value->option_3 ?> 
                    <?php } if($value->option_4 !=""){ ?>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="radio" name="IncomingQcCheck[resultQcCheck][<?= $i ?>][value]" value="<?= $value->option_4 ?>">   <?= $value->option_4 ?> 
                    <?php } ?> <br><hr>
                </div><br>
                <?php }elseif ($value->category == 5) { ?>
                <div>
                    <label class="category"><?= $value->name  ?></label>
                    <input type="text" style= "display: none" class="form-control" value= "<?=  $value['id'] ?>" name="IncomingQcCheck[resultQcCheck][<?= $i ?>][id]"> <br>
                    <div class="col-md-5"><input type="text" name="IncomingQcCheck[resultQcCheck][<?= $i ?>][value]" class="form-control"> </div><br>
                    <br><hr>
                </div>
                <?php }elseif ($value->category == 6) { ?>
                <div>
                    <label><?= $value->name  ?></label>
                    <input type="text" style= "display: none" class="form-control" value= "<?=  $value['id'] ?>" name="IncomingQcCheck[resultQcCheck][<?= $i ?>][id]"> <br>
                    <div class="col-md-5"><input type="date"  name="IncomingQcCheck[resultQcCheck][<?= $i ?>][value]" class=" datepicker form-control"></div><br>
                    <br><hr>
                </div>

                <?php }elseif ($value->category == 7) { ?>
                <div>
                    <label><?= $value->name  ?></label>
                    <input type="text" style= "display: none" class="form-control" value= "<?=  $value['id'] ?>" name="IncomingQcCheck[resultQcCheck][<?= $i ?>][id]"> <br>
                    <div class="col-md-5"><input type="number"  name="IncomingQcCheck[resultQcCheck][<?= $i ?>][value]" class="form-control"></div><br>
                    <br><hr>
                </div>
                 <?php } $i++; } ?> 
                 
                 <div class="row" style="padding:0;margin:0;">
                    <div class="col-sm-12">
                       <?= $form->field($model, 'comments')->textarea(['rows' => '3', 'placeholder' =>'Share your comments']) ->label("")  ?><br><br>
                    </div>
                 </div>

                <div class="col-md-12">
                 <?= $form->field($model, 'overall_status')->hiddenInput(['maxlength' => true])->label("") ?>
             </div>

             <div class="col-md-12" style="margin-top:90px ">
                <?= $form->field($model, 'product_image')->fileInput(['maxlength' => true]) ->label("Image") ?>
           </div>

            <div class="col-md-8" style="float: right; margin-top:-50px "> <br>
                <?= Html::submitButton('Reject', ['class' => 'btn btn-default btnNext','id'=>'Reject']) ?>
                <?= Html::submitButton('Onhold', ['class' => 'btn btn-default btnNext','id'=>'Onhold']) ?>
                <?= Html::submitButton('Partially Accept', ['class' => 'btn btn-primary btnNext','id'=>'partially_accept']) ?>
                <?= Html::submitButton('Accept', ['class' => 'btn btn-success btnNext','id'=>'Accept']) ?>
            </div>
          </div>
        </div><br>
    </div>
</div>
</div>

<?php ActiveForm::end(); ?>

</div>

<script type="text/javascript">
    $("#Reject").on('click', function(event){
     $("#incomingqccheck-overall_status").val("Reject");
     event.preventDefault();
     $("#submitForm").submit();
 });

    $("#partially_accept").on('click', function(event){
     $("#incomingqccheck-overall_status").val("Partially");
     event.preventDefault();
     $("#submitForm").submit();
 });
    $("#Onhold").on('click', function(event){
     $("#incomingqccheck-overall_status").val("Onhold");
     event.preventDefault();
     $("#submitForm").submit();
 });
   //  $("#Accept").on('click', function(event){
   //     $("#incomingqccheck-overall_status").val("Accept");
   //     event.preventDefault();
   //     $("#submitForm").submit();
   // });

  // $(".coa_from_supplier").click(function(){


  //   // alert("sa");
  //   // var id = $('#parent li a').attr('id');
  //   // alert(id);
  // });

         //  function isNumber(evt) {  

         //        evt = (evt) ? evt : window.event;
         //        var charCode = (evt.which) ? evt.which : evt.keyCode;
         //        if (charCode == 46) {
         //            return true;
         //        }
         //        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
         //            return false;
         //        }
         //        return true;
         // }

     </script>