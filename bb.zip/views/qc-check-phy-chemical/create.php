<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\QcCheckPhyChemical */

$this->title = 'Create QC & Cleaning Checks';
$this->params['breadcrumbs'][] = ['label' => 'QC Check Phy Chemicals', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="qc-check-phy-chemical-create">

    <h1 style="font-size: 32px;"><?= Html::encode($this->title) ?></h1>

    <?= $this->render('ap_form', [
        // 'model' => $model,
    ]) ?>

</div>
