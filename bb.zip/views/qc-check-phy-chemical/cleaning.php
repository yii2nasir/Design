<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;
use app\models\SubSubCategory;
use app\models\Product;

use yii\helpers\ArrayHelper;


/* @var $this yii\web\View */
/* @var $model app\models\QcCheckPhyChemical */
/* @var $form yii\widgets\ActiveForm */
?>
<link href="<?php echo Url::to("@web/css/pnotify.custom.min.css"); ?>" rel="stylesheet" type="text/css" />
<style type="text/css">
   .ap_overlay{
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: #fff;
        opacity: 0.9;
        display: none; 
        z-index: 100;
    }

    .ap_container{
        position: absolute;
        top: 40%;
        left: 40%;
        text-align: center;
        display: none; 
        width: 20%;
        z-index: 100;
        height: 20%;
    }
    .ap_container img{
        width: 30%;
    }
</style>
<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<div class="qc-check-phy-chemical-form">
   <form id="qform" method="post" action="<?php echo Url::to(["qc-check-phy-chemical/cleanm-update"]);?>">
      <div class="row">
         <div class="col-md-12"> 
            <div class="x_panel">
               <div class="x_content">
                  <div class="row">
                     <div class="col-sm-6">
                        <label>Select Sub Sub Category <font size='2' style="color:red"> *</font></label>
                        <?= Html::dropDownList('sub_sub_category_id', null,ArrayHelper::map(\app\models\SubSubCategory::find()->all(), 'id', 'name'),['prompt' => 'Select Sub Sub Category',
                           'id' => 'sub_sub_category_id',
                           'class'=>'form-control',
                           'onchange' => 'getProductLists()'
                        ]) ?>

                     </div>
                     <div class="col-sm-6">
                        <label>Select Product <font size='2' style="color:red"> *</font></label>
                        <?= Html::dropDownList('product_id', null,ArrayHelper::map(\app\models\Product::find()->all(), 'id', 'name'),['prompt' => 'Select Product',
                           'id' => 'product_id',
                           'class'=>'form-control',
                        ]) ?>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
              <div id="append_here" class="col-sm-12" style="overflow-x: scroll;">
              </div>
            </div>
            <br>
            <input type="button" class="btn btn-xs btn-primary update" value="Update">
         </div>
      </div>
   </form>
   <div class="ap_overlay"></div>
   <div class="ap_container"><img src="<?php echo Url::to('@web/images/loader.gif');?>"/></div>
</div>
<script type="text/javascript" src="<?php echo Url::to("@web/js/pnotify.custom.min.js"); ?>"></script>
<script type="text/javascript">

   $(".update").on("click",function()
   {
      var sub_id = $('#sub_sub_id').val();
      var product_id = $('#product_id').val();
      if(sub_id == '' || product_id == '')
      {
         alert("Please select category & product.");
         return false;
      }
      var formdata = $('#qform').serializeArray();
       ap_overlay('show');
       $.ajax({
          url: $('#qform').attr('action'),
          type: 'post',
          data: formdata,
          success: function (res) {
             ap_overlay('hide');
             data = jQuery.parseJSON( res );
             new PNotify({
                 type: data.type,
                 title: data.type,
                 text: data.msg,
                 sticker: false
             });
          },
          error: function (res) {
          }
       });
   });

   function ap_overlay(mode)
    {
        if(mode == 'show')
        {
            $(".ap_overlay, .ap_container").fadeIn();
        }else{
            $(".ap_overlay, .ap_container").fadeOut();
        }
    }

   $('body').on("change","#product_id",function()
   {
      var val = $(this).val();
      if(val != '')
      {
        ap_overlay('show');
        $.ajax({
          url: '<?php echo Url::to(["qc-check-phy-chemical/fetch-clean-mapper"]); ?>',
          type: 'post',
          data: {product_id : val},
          success: function (res) {
            ap_overlay('hide');
            data = jQuery.parseJSON( res );
            if(data.type == 'success')
            {
              $("#append_here").html(data.data);
              $(".update").removeAttr("disabled");
            }else{

              $(".update").prop("disabled","disabled");
              $("#append_here").html("");
              new PNotify({
                type: data.type,
                title: data.type,
                text: data.msg,
                sticker: false
              });
            }
          },
          error: function (res) {
          }
        });
      }
   });

   function getProductLists()
   {
      var sub_sub_category_id = document.getElementById("sub_sub_category_id").value;
      ap_overlay('show');
      $.ajax({
         url: '<?php echo Url::to(["site/product-list"]); ?>',
         type: 'post',
         data: {
            type : 1,
            id : sub_sub_category_id
         },
         success: function (res) {
            var productData = JSON.parse(res);
            var areaOption = "<option value=''>Select Product</option>";
            for (var i = 0; i < productData.length; i++) {
               areaOption += '<option value="' + productData[i]['id'] + '">' + productData[i]['name'] + '</option>'
            }
            $("#product_id").html(areaOption);
            ap_overlay('hide');
         },
         error: function (res) {
            ap_overlay('hide');
         }
      }); 
   }   
   $("body").on("click",".select_all", function()
   {
      var rpc_id = $(this).attr("id");
      if($(this).is(':checked'))
      {
        $(".select_all_"+rpc_id).each(function()
        {
          $(this).prop('checked', true);
        });
      }else{
        $(".select_all_"+rpc_id).each(function()
        {
          $(this).removeAttr('checked');
        });
      }
   });

</script>