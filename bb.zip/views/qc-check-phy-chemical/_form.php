<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;
use app\models\SubSubCategory;
use app\models\Product;

use yii\helpers\ArrayHelper;


/* @var $this yii\web\View */
/* @var $model app\models\QcCheckPhyChemical */
/* @var $form yii\widgets\ActiveForm */
?>
<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<style type="text/css">
.border-between > [class*='col-']:before {
 background: #e3e3e3;
 bottom: 0;
 content: " ";
 left: 0;
 position: absolute;
 width: 2px;
 top: 0;
 color: red;
}
.fs-wrap1 {
  display: inline-block;
  cursor: pointer;
  line-height: 1;
  width: 515px;
}
.border-between > [class*='col-']:first-child:before {
 display: none;
}
.btn.btn-success{
  margin-left: 3px !important;
  background: cadetblue;
  border-style: none;
}
.btn.btn-success{
  margin-left: 3px !important;
  background: cadetblue;
  border-style: none;
}
</style>

<div class="qc-check-phy-chemical-form">
  <?php $form = ActiveForm::begin(); ?>
  <div class="row">
    <div class="col-md-12">
      <div class="x_panel">
        <div class="x_content">
          <div class="row border-between">
            <div class="col-md-6">
              <?= $form->field($model, 'type')->Dropdownlist(['Incoming'=>"Incoming",'FG QC Check'=>'FG QC Check'],['prompt'=>'Select']) ?>

              <?= $form->field($model, 'nature')->Dropdownlist(['Physical' =>'Physical','Chemical'=>'Chemical'],['prompt'=>'Select']) ?>

              <?= $form->field($model, 'sub_sub_category_id')->dropDownList(
                ArrayHelper::map(\app\models\SubSubCategory::find()->all(), 'id', 'name'),['prompt' => 'Select',
                'id' => 'sub_sub_category_id',
                'class'=>'form-control',
                'onchange' => 'getProductLists()'
                ])->label('Sub-Sub Category');   ?>

              <?= $form->field($model, 'product_id')->dropDownList(
                ArrayHelper::map(\app\models\Product::find()->select('id,name')->one(),
                 'id', 'name'),
                ['prompt' => 'Select',
                'id' => 'product_id',
                'class'=>'form-control'
                ])->label('Product');   ?>

                <?= $form->field($model, 'category')->Dropdownlist(['1'=>"min-max numeric",'2'=>'min-max percentage','3'=>'dropdown','4'=>'radio button','5'=>'textbox','6'=>'date','7'=>'number'],['prompt'=>'Select','onchange'=>'optionSelected()']) ?>          

                <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>
              </div>
              <div class="col-md-6">
                <div id="remove_data" style="display: none;">
                  <?= $form->field($model, 'option_1')->textInput(['maxlength' => true]) ?>
                  <?= $form->field($model, 'option_2')->textInput(['maxlength' => true]) ?>
                </div>
                
                  <div id="remove_data1" style="display: none;">

                   <?= $form->field($model, 'option_3')->textInput(['maxlength' => true]) ?>

                   <?= $form->field($model, 'option_4')->textInput(['maxlength' => true]) ?>
                 </div>
                 <div id="remove_data2" style="display: none;">
                  <div class="form-group field-qccheckphychemical-expected_answer">
                   <label class="control-label" for="qccheckphychemical-expected_answer">Expected Answer</label>
                   <select id="qccheckphychemical-expected_answer" class="form-control" name="QcCheckPhyChemical[expected_answer]">
                    <option value="">Select</option>
                    <option value="" id ="ans_option_1">option 1</option>
                    <option value="" id ="ans_option_2">option 2</option>
                    <option value="" id ="ans_option_3">option 3</option>
                    <option value="" id ="ans_option_4">option 4</option>
                  </select>
                  <div class="help-block"></div>
                </div>
              </div>
              <?= $form->field($model, 'mandatory')->Dropdownlist(['1'=>"Yes",'0'=>'No'],['prompt'=>'Select','class'=>'form-control']) ?>
              <div id="remove_data3" style="display: none;">
               <?= $form->field($model, 'is_editable')->Dropdownlist(['1'=>"Yes",'0'=>'No'],['prompt'=>'Select']) ?>
             </div>
           </div> 
         </div>
       </div>
       <div class="form-group">
        <?= Html::submitButton('Update', ['class' => 'btn btn-success']) ?>
      </div>
    </div>
  </div>
</div>        
<?php ActiveForm::end(); ?>
</div>
<script type="text/javascript">
  $(document).ready(function(){
    optionSelected();
    getProductLists();
  })
  function optionSelected(){
    if($("#qccheckphychemical-category").val() == "5" || $("#qccheckphychemical-category").val() == "6" || $("#qccheckphychemical-category").val() == "7"){
      $("#remove_data1").css("display", "none");
      $("#remove_data").css("display", "none");
      $("#remove_data2").css("display", "none");
    }else if($("#qccheckphychemical-category").val() == "3" || $("#qccheckphychemical-category").val() == "4" ){
      $("#remove_data1").css("display", "block");
      $("#remove_data").css("display", "block");
      $("#remove_data2").css("display", "block");
    }else{
     $("#remove_data1").css("display", "none");
     $("#remove_data2").css("display", "none");
     $("#remove_data").css("display", "block");
   }
 }
 function getProductLists(){
  var sub_sub_category_id = document.getElementById("sub_sub_category_id").value;
  $.ajax({
    url: '<?php echo Url::to(["site/product-list"]); ?>',
    type: 'post',
    data: {
      type : 1,
      id : sub_sub_category_id
    },
    success: function (res) {
      var productData = JSON.parse(res);
      var areaOption = "<option value=''>Select Product</option>";
      for (var i = 0; i < productData.length; i++) {
        areaOption += '<option value="' + productData[i]['id'] + '">' + productData[i]['name'] + '</option>'
      }
      $("#product_id").html(areaOption);
      <?php if($model->isNewrecord == false){ ?>
        $("#product_id").val('<?= $model->product_id ?>')
        <?php }  ?>
      },
      error: function (res) {}
    }); 
}   

/*fill expected answer value start*/
$("#qccheckphychemical-option_1").focusout(function(){
  var option_1= $("#qccheckphychemical-option_1").val();
  var answer_1= $("#ans_option_1").val(option_1);
}) 
$("#qccheckphychemical-option_2").focusout(function(){
  var option_2= $("#qccheckphychemical-option_2").val();
  var answer_2= $("#ans_option_2").val(option_2);
}) 
$("#qccheckphychemical-option_3").focusout(function(){
  var option_3= $("#qccheckphychemical-option_3").val();
  var answer_3= $("#ans_option_3").val(option_3);
}) 
$("#qccheckphychemical-option_4").focusout(function(){
  var option_4= $("#qccheckphychemical-option_4").val();
  var answer_4= $("#ans_option_4").val(option_4);
}) 


var option_1= $("#qccheckphychemical-option_1").val();
var answer_1= $("#ans_option_1").val(option_1);

var option_2= $("#qccheckphychemical-option_2").val();
var answer_2= $("#ans_option_2").val(option_2);

var option_3= $("#qccheckphychemical-option_3").val();
var answer_3= $("#ans_option_3").val(option_3);

var option_4= $("#qccheckphychemical-option_4").val();
var answer_4= $("#ans_option_4").val(option_4);

/*fill expected answer value end*/


/*display/hide is_editable field start*/

$("#qccheckphychemical-type").change(function(){
  if($("#qccheckphychemical-type").val() == "FG QC Check" ){
    $("#qccheckphychemical-category").change(function(){
      if($("#qccheckphychemical-category").val() == "1" || $("#qccheckphychemical-category").val() == "2" || $("#qccheckphychemical-category").val() == "5"){

        $("#remove_data3").css("display", "block");
      } 
      else{
        $("#remove_data3").css("display", "none");
      }
    })
  }   
})

</script>