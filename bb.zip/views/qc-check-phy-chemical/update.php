<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\QcCheckPhyChemical */
$this->title = 'Update QC Check : ' . $prod_data['pname'];
$this->params['breadcrumbs'][] = ['label' => 'Qc Check Phy Chemicals', 'url' => ['index']];
// $this->params['breadcrumbs'][] = ['label' => $prod_data['pname'], 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="qc-check-phy-chemical-update">

    <h1 style="font-size: 32px;"><?= Html::encode($this->title) ?></h1>

    <?= $this->render('ap_form', [
    	'prod_data' => $prod_data,
    	'type' => $type,
        'all_entries' => $all_entries,
        // 'model' => $model,
    ]) ?>

</div>
