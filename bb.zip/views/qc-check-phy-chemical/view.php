<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\QcCheckPhyChemical */

$this->title = $model->name;
$this->params['breadcrumbs'][] = ['label' => 'Qc Check Phy Chemicals', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<style type="text/css">
    .btn-danger{
        background: #26B99A !important;
        border-style: none !important;
        margin-top: -5px;
    }
    .modal-content{
        border-style: none !important;
    }
    .btn-primary,.btn-primary:active{
        background-color: cadetblue !important;
        border-style: none;
        margin-top: -5px;
    }
    .modal-title{
        color: rgb(47,62,86) !important;
    }
</style>
<div class="qc-check-phy-chemical-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'onclick'=>'return (ask_confirm(\''.$model->id.'\',\''.Yii::$app->controller->id .'\')? true : false)'
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'type',
            'nature',
            'category',
            [
                'attribute'=>'category',
                'value'=>$model->getCategory($model->category)
            ],
            'name',
            // 'option_1',
            // 'option_2',
            // 'status',
            // 'entry_type',
            // 'created_at',
            // 'updated_at',
            [ 
                'attribute'=>'created_at',
                'value' => function($data){
                    return date("Y-m-d H:i:s", 
                           strtotime($data->created_at));
                }
            ],       
            [ 
                'attribute'=>'updated_at',
                'value' => function($data){
                    return (!empty($data->updated_at)) ? 
                            date("Y-m-d H:i:s",
                            strtotime($data->updated_at)) : null;
                }
            ],
        ],
    ]) ?>

</div>
