<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;
use app\models\SubSubCategory;
use app\models\Product;

use yii\helpers\ArrayHelper;


/* @var $this yii\web\View */
/* @var $model app\models\QcCheckPhyChemical */
/* @var $form yii\widgets\ActiveForm */
?>
<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<div class="qc-check-phy-chemical-form">
   <form id="qform" method="post" action="<?php echo ($this->context->action->id == 'create') ? Url::to(["qc-check-phy-chemical/submit-qform"]) : Url::to(["qc-check-phy-chemical/update-qform"]); ?>">
      <div class="row">
         <div class="col-md-12"> 
            <div class="x_panel">
               <div class="x_content">
                  <div class="row <?php echo ($this->context->action->id == 'create') ? '' : 'no_action'; ?>">
                     <div class="col-sm-4">
                        <label>Select Sub Sub Category <font size='2' style="color:red"> *</font></label>
                        <?php $sub_cat = (isset($prod_data['sub_sub_id'])) ? $prod_data['sub_sub_id'] : NULL; ?>
                        <?= Html::dropDownList('sub_sub_category_id', $sub_cat,ArrayHelper::map(\app\models\SubSubCategory::find()->all(), 'id', 'name'),['prompt' => 'Select Sub Sub Category',
                           'id' => 'sub_sub_category_id',
                           'class'=>'form-control',
                           'onchange' => 'getProductLists()'
                        ]) ?>

                     </div>
                     <div class="col-sm-4">
                        <label>Select Product <font size='2' style="color:red"> *</font></label>
                        <?php
                        $product_id = (isset($prod_data['product_id'])) ? $prod_data['product_id'] : NULL; 
                        ?>
                        <?= Html::dropDownList('product_id', $product_id,ArrayHelper::map(\app\models\Product::find()->all(), 'id', 'name'),['prompt' => 'Select Product',
                           'id' => 'product_id',
                           'class'=>'form-control',
                        ]) ?>
                     </div>
                     <div class="col-sm-4">
                        <label>Select Type <font size='2' style="color:red"> *</font></label>
                        <?php
                        $product_type = (isset($type)) ? ucwords($type) : NULL; 
                        ?>
                        <?= Html::dropDownList('type', $product_type,['Incoming'=>"Incoming",'FG QC Check'=>'FG QC Check','Processing'=>'Processing'],['prompt' => 'Select Type',
                           'id' => 'type',
                           'class'=>'form-control',
                        ]) ?>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row append_here">
               <div class="col-sm-12">
                  <input type="button" class="btn btn-xs btn-primary add_more pull-right" value="Add">
               </div>
            </div>

            <?php
            if(isset($all_entries))
            {
               foreach ($all_entries as $key => $value) 
               {
                  ?>
                  <div id="<?php echo 'div_'.$value->id;?>" class="x_panel sub_entries" style="margin-top:10px;">
                     <div class="x_content">
                        <div class="row">
                           <table class="table table-bordered">
                              <tr>
                                 <td width="10%" >Nature</td>
                                 <td width="15%" >Question Type</td>
                                 <td width="15%" >Name</td>
                                 <td width="10%" >Option 1</td>
                                 <td width="10%" >Option 2</td>
                                 <td width="10%" >Option 3</td>
                                 <td width="10%" >Option 4</td>
                                 <td width="10%" >Expected Answers</td>
                                 <td width="10%" >Mendatory</td>
                              </tr>
                              <tr>
                                 <td>
                                    <?= Html::dropDownList('Q['.$value->id.'][nature]', $value->nature,['Physical' => 'Physical','Chemical' => 'Chemical'],['prompt' => 'Select',
                                       'id' => 'type',
                                       'class'=>'form-control',
                                    ]) ?>
                                 </td>
                                 <td>
                                  <?php
                                  if($_GET['type'] == 'Processing' || $_GET['type'] == 'processing')
                                  {
                                    $options_ar = ['4'=>'radio button'];
                                  }else{
                                    $options_ar = ['1'=>"min-max numeric",'2'=>'min-max percentage','3'=>'dropdown','4'=>'radio button','5'=>'textbox','6'=>'date','7'=>'number'];
                                  }
                                  ?>
                                    <?= Html::dropDownList('Q['.$value->id.'][category]', $value->category,$options_ar,
                                    ['prompt' => 'Select',
                                       'data-id' => $value->id,
                                       'id' => "qtype_".$value->id,
                                       'class'=>'form-control qtype',
                                    ]) ?>
                                 </td>
                                  <td>
                                    <?= Html::textInput('Q['.$value->id.'][name]', $value->name,[ 'class' => 'form-control']); ?>
                                 </td>
                                 <td>
                                    <?= Html::textInput('Q['.$value->id.'][option_1]', $value->option_1,[ 'data-id' => $value->id, 'data-option' => 'ans_option_1', 'class' => 'option_changed form-control one_'.$value->id.'']); ?>
                                 </td>
                                 <td>
                                    <?= Html::textInput('Q['.$value->id.'][option_2]', $value->option_2,[ 'data-id' => $value->id, 'data-option' => 'ans_option_2', 'class' => 'option_changed form-control two_'.$value->id.'']); ?>
                                 </td>
                                 <td>
                                    <?= Html::textInput('Q['.$value->id.'][option_3]', $value->option_3,[ 'data-id' => $value->id, 'data-option' => 'ans_option_3', 'class' => 'option_changed form-control three_'.$value->id.'']); ?>
                                 </td>
                                 <td>
                                    <?= Html::textInput('Q['.$value->id.'][option_4]', $value->option_4,[ 'data-id' => $value->id, 'data-option' => 'ans_option_4', 'class' => 'option_changed form-control four_'.$value->id.'']); ?>
                                 </td>
                                 <td>
                                    <select id="expected_answer_<?php echo $value->id;?>" class="form-control" name="<?php echo 'Q['.$value->id.'][expected_answer]';?>">
                                       <option value="">Select</option>
                                       <option value="<?php echo $value->option_1; ?>" <?php if($value->option_1 == $value->expected_answer) echo "selected";?> id ="ans_option_1">option 1</option>
                                       <option value="<?php echo $value->option_2; ?>" <?php if($value->option_2 == $value->expected_answer) echo "selected";?> id ="ans_option_2">option 2</option>
                                       <option value="<?php echo $value->option_3; ?>" <?php if($value->option_3 == $value->expected_answer) echo "selected";?> id ="ans_option_3">option 3</option>
                                       <option value="<?php echo $value->option_4; ?>" <?php if($value->option_4 == $value->expected_answer) echo "selected";?> id ="ans_option_4">option 4</option>
                                    </select>
                                 </td>
                                 <td>
                                    <?= Html::dropDownList('Q['.$value->id.'][mandatory]', $value->mandatory,['1'=>"Yes",'0'=>'No'],
                                    ['prompt' => 'Select',
                                       'id' => 'mandatory',
                                       'class'=>'form-control',
                                    ]) ?>
                                 </td>
                              </tr>
                           </table>
                           
                        </div>
                     </div>
                     <span data-id="<?php echo $value->id;?>" class="close_button"><i class="fa fa-close"></i></span>
                     <input type="hidden" name="Q[<?php echo $value->id;?>][delete]" id="Q_<?php echo $value->id;?>"/>

                  </div>
                  <?php
               }
            }

            ?>         
         <input type="button" class="btn btn-xs btn-success submit" value="Save"/>
         <a href="<?php echo Url::to(["qc-check-phy-chemical/index"]);?>" class="btn btn-dark">Back</a>
         <br>
         <br>
         </div>
      </div>
   </form>
   <div class="ap_overlay"></div>
   <div class="ap_container"><img src="<?php echo Url::to('@web/images/loader.gif');?>"/></div>
</div>
<script type="text/javascript">

   $(".submit").on("click",function()
   {
      var sub_id = $('#sub_sub_id').val();
      var product_id = $('#product_id').val();
      var type = $('#type').val();
      if(sub_id == '' || product_id == '' || type == '')
      {
         alert("Fields marked with (*) are requred");
         return false;
      }
      if($(".sub_entries").length)
      {
         var formdata = $('#qform').serializeArray();
         ap_overlay('show');
         $.ajax({
            url: $('#qform').attr('action'),
            type: 'post',
            data: formdata,
            success: function (res) {
               ap_overlay('hide');
               data = jQuery.parseJSON( res );
               new PNotify({
                   type: data.type,
                   title: data.type,
                   text: data.msg,
                   sticker: false
               });
            },
            error: function (res) {
            }
         });
      }else{
         alert("Please add some questions");
         return false;
      }
   });

   function ap_overlay(mode)
    {
        if(mode == 'show')
        {
            $(".ap_overlay, .ap_container").fadeIn();
        }else{
            $(".ap_overlay, .ap_container").fadeOut();
        }
    }
   $(".add_more").on("click",function()
   {
      var type = $('#type').val();
      if(type != '')
      {
        ap_overlay('show');
          $.ajax({
           url: '<?php echo Url::to(["qc-check-phy-chemical/add-more"]); ?>',
           type: 'post',
           data: {type : type},
           success: function (res) {
            ap_overlay('hide');
            $(".append_here").after(res);
          },
          error: function (res) {
          }
        }); 
      }else{
        alert("Fields marked with (*) are requred");return false;
      }
   });

   $('body').on("click",".close_button",function()
   {
      if(confirm("Are you sure you want to delete this question?"))
      {
         ap_overlay('show');
         var row_id = $(this).attr('data-id');
         $("#Q_"+row_id).val('1');
         $("#div_"+row_id).fadeOut();
         ap_overlay('hide');
      }
   });

   $('body').on("click",".qtype",function()
   {
      var row_id = $(this).attr("data-id");
      var option_selected = $(this).val();
      if((option_selected == '1') || (option_selected == '2'))
      {
         $(".one_"+row_id+", .two_"+row_id).attr('type',"number");
         $(".one_"+row_id+", .two_"+row_id).attr('min',"0");
         $(".one_"+row_id+", .two_"+row_id).fadeIn();
         $(".three_"+row_id+", .four_"+row_id).val('');
         $(".three_"+row_id+", .four_"+row_id).fadeOut();
      }else if((option_selected == '5') || (option_selected == '6') || (option_selected == '7')){
         $(".three_"+row_id+", .four_"+row_id+", .two_"+row_id+", .one_"+row_id).val('');
         $(".three_"+row_id+", .four_"+row_id+", .two_"+row_id+", .one_"+row_id).fadeOut();
      }else{
        $(".one_"+row_id+", .two_"+row_id).attr('type',"text");
        $(".one_"+row_id+", .two_"+row_id).removeAttr("min");
        $(".three_"+row_id+", .four_"+row_id+", .two_"+row_id+", .one_"+row_id).fadeIn();
      }
   });

   $('body').on("change",".option_changed",function()
   {
      var row_id = $(this).attr("data-id");
      var option_id = $(this).attr("data-option");
      var value = $(this).val();
      $("#expected_answer_"+row_id+ " #"+option_id).val(value);

      var qtype = $("#qtype_"+row_id).val();
      var qone = parseInt($(".one_"+row_id).val());
      var qtwo = parseInt($(".two_"+row_id).val());
      if((qone != '') && (qtwo != ''))
      {
        if((qtype == 1) || (qtype == 2))
        {
          if(qone >= qtwo)
          {
            alert("Option 1 can not be greater than option 2");
            $(".submit").prop("disabled",'disabled');
            $(".one_"+row_id+ ", .two_"+row_id).css("border-color","red");
            return false;
          }
        }
      }
      $(".one_"+row_id+ ", .two_"+row_id).css("border-color","#ededed");
      $(".submit").removeAttr("disabled");
   });

   function getProductLists()
   {
      var sub_sub_category_id = document.getElementById("sub_sub_category_id").value;
      ap_overlay('show');
      $.ajax({
         url: '<?php echo Url::to(["site/product-list"]); ?>',
         type: 'post',
         data: {
            type : 1,
            id : sub_sub_category_id
         },
         success: function (res) {
            var productData = JSON.parse(res);
            var areaOption = "<option value=''>Select Product</option>";
            for (var i = 0; i < productData.length; i++) {
               areaOption += '<option value="' + productData[i]['id'] + '">' + productData[i]['name'] + '</option>'
            }
            $("#product_id").html(areaOption);
            ap_overlay('hide');
         },
         error: function (res) {
            ap_overlay('hide');
         }
      }); 
   }   


</script>