<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;
/* @var $this yii\web\View */
/* @var $model app\models\State */
/* @var $form yii\widgets\ActiveForm */
?>
<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<style type="text/css">
 
</style>

<div class="state-form">
  <?php $form = ActiveForm::begin(); ?>

  <div class="row">
    <div class="col-md-12">
        <div class="x_panel">
            <div class="x_content">
                <div class="col-md-10 col-sm-12 col-xs-12">
    			    <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>
                    
                    <div class="form-group">
    			        <?= Html::submitButton('Update', ['class' => 'btn btn-success rightButton', 'id' =>'btnNext']) ?>
                        <span id="msg_product" style="color: red"></span> <br>
    			    </div>
                </div>
            </div>
        </div>
    </div>
</div>
 <?php ActiveForm::end(); ?>

</div>

<script>
   $('#btnNext').click(function(){
     var state_name = $("#state-name").val();     
     var flage = 0;

     if(state_name ==null){
       $("#msg_state").html("State name can not be blank.");
       flage++;
     }else{
       $("#msg_product").html("");
     }
     
     if(flage != 0){
       return false;
     }
