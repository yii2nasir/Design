<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;
/* @var $this yii\web\View */
/* @var $model app\models\Cleaning */
/* @var $form yii\widgets\ActiveForm */
?>
<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<div class="cleaning-form">

  <style type="text/css">
    .container{
      overflow-x: hidden;
      overflow-y: auto;
    }
    .text{
      height: 500px;
    }
  /*button#partially_accept{
        margin-left: -2px ! important;
        width: 30% !important;
    }
    button#Reject{
        margin-left: -25% ! important;
        width: 30% !important;
    }
    button#Accept{
        margin-left: -2px ! important;
        width: 30% !important;
    }*/
    .btn-success{
        text-align: center;
        background: #DAA54B; 
        border-style:none;
        display:block;
        width: 20%;
        min-width: 20%;   
        max-width: 25%;  
    }
    .btn_done{
        text-align: center;
        width:100%;
        display:block;
        margin-left:40%;
    }
   .btn-success:hover{
        text-align: center;
        background: #DAA54B; 
        border-style:none;
        display:block;
        width: 20%;
        min-width: 20%;   
    }
    .btn-success:link{
        text-align: center;
        background: #DAA54B; 
        border-style:none;
        display:block;
        width: 20%;
        min-width: 20%;   
        /* max-width: 25%;   */
    }
    .btn-success:visited{
        text-align: center;
        background: #DAA54B; 
        border-style:none;
        display:block;
        width: 20%;
        min-width:20%;   
        /* max-width: 25%;  */
    }
   .btn-success:active{
        text-align: center;
        background: #DAA54B; 
        border-style:none;
        display:block;  
        width: 20%;
        min-width: 20%;   
        /* max-width: 25%;   */
    }
</style>

<div class="container">
  <div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
      <div class="x_content">
        <br>
        <div class="row">
          <?php
          foreach ($data as  $value) { ?>
          <div class="col-md-12">
            <div class="panel panel-default" style="margin-top: -15px;">
              <div class="panel-body" style="margin-top: 5px;">
                <div class="row">
                  <div class="col-md-12">
                    <b>Product Name :</b> <?= $value['product_name'] ?>
                  </div>
                  <div class="col-md-12">
                    <b>Batch ID :</b> <?= $value['batch_id'] ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
      <div class="x_content">
        <h2><b>Cleaning Process</b></h2>
        <div class="row">
          <?php $form = ActiveForm::begin([
            'options' => ['enctype' => 'multipart/form-data'],
            'action' => ['create'],
            'method' => 'post',
            ]); ?>
          <?php
          $i=0;
          foreach ($data as  $value) { ?>
          <div class="col-md-8">
            <input type="hidden" name="Cleaning[user_id]" value="<?= $value['user_id']   ?>" class="form-control">
            <input type="hidden" name="Cleaning[cleaning_mapper][<?= $i ?>][fmid]" value="<?= $value['id']  ?>">

            <input type="hidden" name="Cleaning[cleaning_mapper][<?= $i ?>][product_id]" value="<?= $value['product_id']   ?>" class="form-control">

            <input type="hidden" name="Cleaning[cleaning_mapper][<?= $i ?>][incoming_qc_uniq_id]" value="<?= $value['incoming_qc_uniq_id']   ?>" class="form-control">

            <input type="hidden" name="Cleaning[cleaning_mapper][<?= $i ?>][batch_id]" value="<?= $value['batch_id']   ?>" class="form-control">
          </div>
          <?php $i++; }
          $array = ['Destoner'=>'Destoner','Vibro-sifter'=>'Vibro-sifter','Blower'=>'Blower','Vibro-sifter with magnet'=>'Vibro-sifter with magnet','Manual Cleaning'=>'Manual Cleaning','Table Grading'=>'Table Grading','Magnet'=>'Magnet','Lable Check'=>'Lable Check','Weight Check'=>'Weight Check','Automated-Mechanical sieving,mechanical blower'=>'Automated-Mechanical sieving,mechanical blower','Manual filling/FFS filling check'=>'Manual filling/FFS filling check','Automated-Mechanical sieving,mechanical blower-Optional'=>'Automated-Mechanical sieving,mechanical blower-Optional','Sealing quality check'=>'Sealing quality check','Metal detector check'=>'Metal detector check','Master pack declaration check'=>'Master pack declaration check'];
          $i = 0;
          foreach($array as $checkList){ ?>
          <div class="col-md-6">
            <div class="panel panel-default">
              <div class="panel-body">
               <input type="hidden" value="<?= $checkList ?>" name="Cleaning[cleaning_checklist][<?= $i ?>][value]">
               <div class="row"><div class="col-md-6"><?= $checkList  ?></div><div class="col-md-6"> <input type="radio" value="Yes" name="Cleaning[cleaning_checklist][<?= $i ?>][status]"> &nbsp;Yes&nbsp;&nbsp;<input type="radio" value="No" name="Cleaning[cleaning_checklist][<?= $i ?>][status]"> &nbsp; No &nbsp;&nbsp; <input type="radio" value="NA" name="Cleaning[cleaning_checklist][<?= $i ?>][status]">&nbsp; NA </div></div>
             </div>
           </div>
         </div>
         <div class="cleaningfix"></div>
         <?php $i++; } ?>
         <div class="col-md-12">
           <?= $form->field($model, 'image')->fileInput() ?>
       <br>  </div>
         <div class="col-md-12">
          
          <textarea name="Cleaning[comments]" class="form-control" rows="3" placeholder="Share your comments"></textarea><br><br>
        </div>
        <?php /* <div class="col-md-8" style="float: right; ">
                <?= Html::submitButton('Reject', ['class' => 'btn btn-default btnNext','id'=>'Reject']) ?>
                <?= Html::submitButton('Partially Accept', ['class' => 'btn btn-primary btnNext','id'=>'partially_accept']) ?>
                <?= Html::submitButton('Accept', ['class' => 'btn btn-success btnNext','id'=>'Accept']) ?> 
            </div>*/?>
        <div class="col-md-3 btn_done"><br>
            <input type="submit" class="form-control btn btn-success"  value="Done" >
        </div> 
        <!-- <div class="col-md-3">
          <input type="submit" id="Proceed" class="form-control btn btn-success" rows="4" value="Accept" >
        </div> -->
        <?php ActiveForm::end(); ?>
      </div>
    </div>
  </div>
</div>
</div>
</div>
