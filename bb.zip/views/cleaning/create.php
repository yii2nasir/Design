<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Cleaning */

$this->title = 'Create Cleaning';
$this->params['breadcrumbs'][] = ['label' => 'Cleanings', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="cleaning-create">

    <h1 style="font-size:32px";><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
        'data'=>$data
    ]) ?>

</div>
