<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;
use app\models\RpcCentre;


/* @var $this yii\web\View */
/* @var $model app\models\FgQcCheck */
/* @var $form yii\widgets\ActiveForm */
?>

<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<style type="text/css">
    button#Correctie_Action_Taken{
        margin-left: 3px ! important;
        width: 31% !important;
    }
    button#Reject{
        margin-left: -23% ! important;
        width: 23% !important;
    }
    button#Accept{
        margin-left: -1px ! important;
        width: 23% !important;
    }
     
    
</style> 
<div class="incoming-qc-check-form">
     <div class="panel panel-default">
      <div class="panel-body">
       <div class="row">
           <div class="col-md-12">
               <?= "<b>Product Name :</b> &nbsp;&nbsp;". $productM->name  ?>
           </div>
           <div class="col-md-12">
               <?= "<b>Batch ID :   </b>&nbsp;&nbsp;". $batch_id ?>
           </div>
           <div class="col-md-12">
               <?= "<b>Complete Load :   </b> FG QC Check"  ?>
           </div>
       </div>    
   </div>
</div>
    <?php $form = ActiveForm::begin(['options'=>
    ['enctype'=>'multipart/form-data'],'id'=>'submitForm']); ?>

    <div class="row">
        <div class="col-md-12">
            <!-- <div class="col-md-6"> -->
                <div class="x_panel">
                    <div class="row">
                      <div class="panel_data">
                        <?php
                            $rpc_code = RpcCentre::find()->where(['id'=>getUserRpcCenterId()])->one()->code;
                            $batch_id = $rpc_code.(date('z') + 1).yearCode(date("Y"));
                         if(isset($_GET['rq_id']) && $_GET['rq_id'] !=""){
                          // $model->incomming_qc_id =$_GET['rq_id'];
                        }
                        if(isset($_GET['p']) && $_GET['p'] !=""){
                            $model->product_id =$_GET['p'];
                        } 
                        $model->user_id = $userId;
                        ?>
                       
                        <input type="hidden" value='<?php echo $batch_id; ?>' name="batchId" id="batch_id">
                         
                        <?= $form->field($model, 'user_id')->hiddenInput()->label("") ?>

                       

                        <?= $form->field($model, 'product_id')->hiddenInput()->label("") ?>

                        <?php  $i=0; 
                        foreach ($qcCheckPhyChemy as  $value) {

                            if($value->category == 2){ ?>

                            <div>
                                <label class="category"><?= $value->name  ?> (Min- <?= $value->option_1  ?>  Max- <?= $value->option_2  ?>)</label>

                                <input type="text" style= "display: none" class="form-control" value= "<?=  $value['id'] ?>" name="FgQcCheck[resultQcCheck][<?= $i ?>][id]"><br>
                                 <div class="col-md-5"><input type="number" class="form-control min-max" name="FgQcCheck[resultQcCheck][<?= $i ?>][value]"> </div><br>
                                <br><hr>
                            </div>
                         
                            <?php } elseif ($value->category == 1) { ?>
                            <div>
                                <label><?= $value->name  ?></label>
                                <input type="text" style= "display: none" class="form-control" value= "<?=  $value['id'] ?>" name="FgQcCheck[resultQcCheck][<?= $i ?>][id]"> <br>
                                <div class="col-md-5"><input type="text"  name="FgQcCheck[resultQcCheck][<?= $i ?>][value]" class="form-control"></div><br>
                                <br><hr>
                            </div>
                            <?php } elseif ($value->category == 4) { ?>
                            <div class="col-md-12">
                                <label><?= $value->name  ?></label><br>
                                <input type="text" style= "display: none" class="form-control" value= "<?=  $value['id'] ?>" name="FgQcCheck[resultQcCheck][<?= $i ?>][id]"> 
                                <?php if($value->option_1 !=""){ ?>
                                <input type="radio" class="coa_from_supplier" name="FgQcCheck[resultQcCheck][<?= $i ?>][value]" value="<?= $value->option_1 ?>" checked> <?= $value->option_1 ?>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <?php } if($value->option_2 !=""){ ?>
                                <input type="radio" class="coa_from_supplier" name="FgQcCheck[resultQcCheck][<?= $i ?>][value]" value="<?= $value->option_2 ?>">  <?= $value->option_2 ?>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <?php } if($value->option_3 !=""){ ?>
                                <input type="radio" name="FgQcCheck[resultQcCheck][<?= $i ?>][value]" value="<?= $value->option_3 ?>">  <?= $value->option_3 ?> 
                                <?php } if($value->option_4 !=""){ ?>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="radio" name="FgQcCheck[resultQcCheck][<?= $i ?>][value]" value="<?= $value->option_4 ?>">   <?= $value->option_4 ?> 
                                <?php } ?> <br><hr>
                            </div><br>
                            <?php }elseif ($value->category == 5) { ?>
                            <div>
                                <label class="category"><?= $value->name  ?></label>
                                <input type="text" style= "display: none" class="form-control" value= "<?=  $value['id'] ?>" name="FgQcCheck[resultQcCheck][<?= $i ?>][id]"> <br>
                                <div class="col-md-5"><input type="text" name="FgQcCheck[resultQcCheck][<?= $i ?>][value]" class="form-control"> </div><br>
                                <br><hr> </div>
                            <?php }elseif ($value->category == 6) { ?>
                            <div>
                                <label><?= $value->name  ?></label>
                                <input type="text" style= "display: none" class="form-control" value= "<?=  $value['id'] ?>" name="IncomingQcCheck[resultQcCheck][<?= $i ?>][id]"> <br>
                                <div class="col-md-5"><input type="date"  name="IncomingQcCheck[resultQcCheck][<?= $i ?>][value]" class=" datepicker form-control"></div><br>
                                <br><hr>
                            </div>

                            <?php }elseif ($value->category == 7) { ?>
                            <div>
                                <label><?= $value->name  ?></label>
                                <input type="text" style= "display: none" class="form-control" value= "<?=  $value['id'] ?>" name="IncomingQcCheck[resultQcCheck][<?= $i ?>][id]"> <br>
                                <div class="col-md-5"><input type="number"  name="IncomingQcCheck[resultQcCheck][<?= $i ?>][value]" class="form-control"></div><br>
                                <br><hr>
                            </div>
                             <?php } $i++; } ?> 
                        <div class="row" style="padding:0;margin:0;">
                            <div class="col-sm-12">
                              <?= $form->field($model, 'comment')->textarea(['rows' => '3', 'placeholder' =>'Share your comments']) ->label("")  ?><br><br>
                            </div>
                        </div>

                        <div class="col-md-12">
                          <?= $form->field($model, 'overall_status')->hiddenInput(['maxlength' => true])->label("") ?>
                        </div>

                        <div class="col-md-12" style="margin-top:0px ">
                            <?= $form->field($model, 'photo')->fileInput(['maxlength' => true]) ->label("Image") ?>
                        </div>
                        <div class="col-md-8" style="float: right; margin-top:20px "> <br>
                            <?= Html::submitButton('Reject', ['class' => 'btn btn-default btnNext','id'=>'Reject']) ?>

                            <?= Html::submitButton('Take Correctie Action', ['class' => 'btn btn-primary btnNext','id'=>'Correctie_action']) ?>

                            <?= Html::submitButton('Accept', ['class' => 'btn btn-success btnNext','id'=>'Accept']) ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php ActiveForm::end(); ?>
</div>

<script type="text/javascript">
    $("#Reject").on('click', function(event){
         $("#fgqccheck-overall_status").val("Reject");
         event.preventDefault();
         $("#submitForm").submit();
     });

    $("#Correctie_action").on('click', function(event){
         $("#fgqccheck-overall_status").val("Onhold");
         event.preventDefault();
         $("#submitForm").submit();
    });
    $("#Accept").on('click', function(event){
         $("#fgqccheck-overall_status").val("Accept");
         event.preventDefault();
         $("#submitForm").submit();
    });

    $('#submitForm').find('input[name="FgQcCheck[resultQcCheck][0][value]"]').val($('#batch_id').val());
    $('#submitForm').find('input[name="FgQcCheck[resultQcCheck][0][value]"]').attr('readonly', true);
</script>

<?php /*
<div class="fg-qc-check-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'unique_id')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'qc_check_uniq_id')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'cleaning_uniq_id')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'batch_Id')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'overall_status')->dropDownList([ 'Accept' => 'Accept', 'Onhold' => 'Onhold', 'Reject' => 'Reject', ], ['prompt' => '']) ?>

    <?= $form->field($model, 'status')->dropDownList([ '0', '1', ], ['prompt' => '']) ?>

    <?= $form->field($model, 'latitude')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'logtitude')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'entry_type')->dropDownList([ 'MOBILE' => 'MOBILE', 'WEB' => 'WEB', ], ['prompt' => '']) ?>

    <?= $form->field($model, 'created_at')->textInput() ?>

    <?= $form->field($model, 'updated_at')->textInput() ?>

    <?= $form->field($model, 'mobile_created_at')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
*/?>