<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\FgQcCheck */

$this->title = 'FG QC Check';
$this->params['breadcrumbs'][] = ['label' => 'Fg Qc Checks', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="fg-qc-check-create">

    <h1><?= Html::encode($this->title) ?></h1>

   <?= $this->render('_form', [
        'model' => $model,
        'qcCheckPhyChemy'=>$qcCheckPhyChemy,
        'userId'=>$userId,
        'productM'=>$productM,
        'batch_id'=>$batch_id
    ]) ?>

</div>
