<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;
use app\models\Product;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;
/* @var $this yii\web\View */
/* @var $searchModel app\models\FgQcCheckSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'FG QC Check';
$this->params['breadcrumbs'][] = $this->title;
?>
<?php /*<div class="fg-qc-check-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Fg Qc Check', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'unique_id',
            'qc_check_uniq_id',
            'cleaning_uniq_id',
            'batch_Id',
            //'overall_status',
            //'status',
            //'latitude',
            //'logtitude',
            //'entry_type',
            //'created_at',
            //'updated_at',
            //'mobile_created_at',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
*/?>


<link rel="stylesheet" href="<?php echo Url::to("@web/css/custom.css"); ?>" />
<style type="text/css">
    .container{
        overflow-x: hidden;
        overflow-y: auto;
    }
    .text{
        height: 500px;
    }
    .checkbox{
        width: 17px !important;
        height: 16px !important;
    }
    .glyphicon.glyphicon-eye-open.open_popup{
        font-size: 20px;
    }
</style>    
<div class="fg-qc-check-index">
    <!-- Index -->
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
               <div>
                    <h3 style="font-size: 32px;margin-top:-6px !important;">FG QC Check</h3>
                    <div class="clearfix"></div>
                </div>
                <div class="x_panel">
                    <h4>In Process (<?= count($data) ?>)</h4>
                    <div class="x_content">
                        <?php $form = ActiveForm::begin([
                            'action' => ['index'],
                            'method' => 'post',
                            ]); ?>
                            <form action="" class="form-horizontal form-label-left">
                                <?php
                                if($data){
                                    foreach ($data as  $value) {  ?>
                                    <div class="panel panel-default">
                                        <div class="panel-body">
                                            <div class="row">
                                               
                                                <div class="col-md-6">
                                                    Product Name : <?= $value['product_name'] ?>
                                                </div>

                                                <div class="col-md-4">

                                                    Last updated : <?php
                                                     if($value['updated_at'] !=""){
                                                        echo date("d-m-Y",$value['updated_at']);
                                                      }else{
                                                        echo "";
                                                      }
                                                      ?>
                                                </div>
                                               
                                            </div>
                                            <div class="row">
                                                <div class="col-md-11">
                                                    Batch ID : <?= $value['batch_id'] ?>
                                                </div>
                                            </div> 
                                           <div class="row">
                                                <div class="col-md-11">
                                                    Complete Load : Cleaning Process
                                                </div>
                                                 <div class="col-md-1">
                                                  
                                                    <a href="../fg-qc-check/create?rq_id=<?= $value['incoming_uniq_id'] ?>&p=<?= $value['product_id'] ?>&c_Uid=<?= $value['unique_id'] ?>&c_id=<?= $value['id'] ?>" class="fa fa-sign-in"></a>
                                                </div>
                                            </div> 
                                        </div>
                                    </div>

                                <?php } ?>
                              <!--  <input type="submit" name="" id="Proceed" value="Proceed" class="btn btn-success">-->

                                <?php }else{?>
                                <div class="panel panel-default">
                                    <div class="panel-body">
                                        Result not Found.
                                    </div>
                                </div>
                                <?php } ?>
                                <?php ActiveForm::end(); ?>
                                </form>

                    </div>
                </div>
            </div>
        </div>  <!-- End -->
    </div>
</div>

