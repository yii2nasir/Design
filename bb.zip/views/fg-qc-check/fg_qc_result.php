<?php
use app\models\IncomingQcCheck;


?>
<style type="text/css">
.x_panel{
    border-color: #DADADA;
   -moz-box-shadow:    inset 0 0 0.1px #000000;
   -webkit-box-shadow: inset 0 0 0.1px #000000;
   box-shadow:         inset 0 0 0.1px #000000;
}
</style>

<div class="container">
  <div class="row">
    <div class="col-md-12">
      <div class="x_panel">
        <div class="x_content">
        
                <div class="col-md-12">
                  <div class="panel panel-default">
                    <div class="panel-body">
                      <div class="row">
                        <div class="col-md-12">
                          <b>FG QC Process Done. </b>
                        </div>
                        
                        <div class="col-md-12">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>



