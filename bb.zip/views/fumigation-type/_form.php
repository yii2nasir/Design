<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;
use app\models\SubSubCategory;
use app\models\Product;
/* @var $this yii\web\View */
/* @var $model app\models\FumigationType */
/* @var $form yii\widgets\ActiveForm */

$rpcs = ArrayHelper::map(\app\models\RpcCentre::find()->all(),'id','rpc_name');
$p_Ar = [];
// echo '<pre>';print_r($rpcs);exit;
?>
<style type="text/css">
	#fumigationtype-rpc_ids, #product_id{display: block !important;}
</style>
<div class="fumigation-type-form">

    <?php $form = ActiveForm::begin(); ?>
    
    <?= $form->field($model, 'fumigation_days')->textInput() ?>

    <?= $form->field($model, 'fumigation_type_name')->textInput() ?>

    <?= $form->field($model, 'sub_sub_category_id')->dropDownList(
    ArrayHelper::map(\app\models\SubSubCategory::find()->all(), 'id', 'name'),['prompt' => 'Select',
    'id' => 'sub_sub_category_id',
    'class'=>'form-control',
    'onchange' => 'getProductLists()'
    ])->label('Sub-Sub Category');   ?>

    <?php 
    if(!$model->isNewRecord)
    {
        $model->product_ids = json_decode($model->product_ids,true);
        $p_Ar = ArrayHelper::map(\app\models\Product::find()->where(['sub_sub_cat_id' => $model->sub_sub_category_id])->all(),'id','name');
    }
    if($_POST)
    {
        $p_Ar = ArrayHelper::map(\app\models\Product::find()->where(['sub_sub_cat_id' => $_POST['FumigationType']['sub_sub_category_id']])->all(),'id','name');
        $model->product_ids = $_POST['FumigationType']['product_ids'];
        $model->rpc_ids = $_POST['FumigationType']['rpc_ids'];
    }
    echo $form->field($model, 'product_ids')->widget(Select2::classname(), [
        'data' => $p_Ar,
        'options' => ['placeholder' => 'Select Products ...', 'id' => 'product_id','required' => true],
        'pluginOptions' => [
            'allowClear' => true,
            'multiple' => true
        ],
    ]); 

    if(!$model->isNewRecord)
    {
        $model->rpc_ids = json_decode($model->rpc_ids,true);
    }

    echo $form->field($model, 'rpc_ids')->widget(Select2::classname(), [
	    'data' => $rpcs,
	    'options' => ['placeholder' => 'Select RPC ...', 'required' => true],
	    'pluginOptions' => [
	        'allowClear' => true,
	        'multiple' => true
	    ],
	]); 

	?>

    <?php /*<?= $form->field($model, 'created_at')->textInput() ?>

    <?= $form->field($model, 'updated_at')->textInput() ?>*/?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>

<script type="text/javascript">
    function getProductLists()
   {
      var sub_sub_category_id = document.getElementById("sub_sub_category_id").value;
      // ap_overlay('show');
      $.ajax({
         url: '<?php echo Url::to(["site/product-list"]); ?>',
         type: 'post',
         data: {
            type : 1,
            id : sub_sub_category_id
         },
         success: function (res) {
            var productData = JSON.parse(res);
            var areaOption = '';
            // var areaOption = "<option value=''>Select Product</option>";
            for (var i = 0; i < productData.length; i++) {
               areaOption += '<option value="' + productData[i]['id'] + '">' + productData[i]['name'] + '</option>'
            }
            $("#product_id").html(areaOption);
            // ap_overlay('hide');
         },
         error: function (res) {
            // ap_overlay('hide');
         }
      }); 
   } 
</script>