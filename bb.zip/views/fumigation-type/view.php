<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\FumigationType */

$this->title = $model->fumigation_type_id;
$this->params['breadcrumbs'][] = ['label' => 'Fumigation Types', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="fumigation-type-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->fumigation_type_id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->fumigation_type_id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'fumigation_type_id',
            'fumigation_type_name',
            'fumigation_days',
            [
                'attribute' => 'sub_sub_category_id',
                'format' => 'raw',
                'value' => function($data)
                {
                    $cat = \app\models\SubSubCategory::find()->where(['id' => $data->sub_sub_category_id])->one();
                    if($cat != null || !empty($cat))
                    {
                        return $cat->name;
                    }else{
                        return "";
                    }
                }
            ],
            [
                'attribute' => 'product_ids',
                'format' => 'raw',
                'value' => function($data)
                {
                    $html = '';
                    if(!empty($data->product_ids))
                    {
                        $ids = json_decode($data->product_ids,true);
                        if(!empty($ids) && COUNT($ids) > 0)
                        {
                            $html .= '<ul>';
                            foreach ($ids as $key => $value) 
                            {
                                $prod = \app\models\Product::find()->where(['id' => $value])->one();
                                $html .= '<li>'.$prod->name.'</li>';
                            }
                            $html .= '</ul>';
                        }
                    }
                    return $html;
                }
            ],
            [
                'attribute' => 'rpc_ids',
                'format' => 'raw',
                'value' => function($data)
                {
                    $html = '';
                    if(!empty($data->rpc_ids))
                    {
                        $ids = json_decode($data->rpc_ids,true);
                        if(!empty($ids) && COUNT($ids) > 0)
                        {
                            $html .= '<ul>';
                            foreach ($ids as $key => $value) 
                            {
                                $rpc = \app\models\RpcCentre::find()->where(['id' => $value])->one();
                                $html .= '<li>'.$rpc->rpc_name.'</li>';
                            }
                            $html .= '</ul>';
                        }
                    }
                    return $html;
                }
            ],
        ],
    ]) ?>

    <?php
    
    ?>

</div>
