<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use yii\helpers\Url;
/* @var $this yii\web\View */
/* @var $searchModel app\models\FumigationTypeSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Fumigation Types';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="fumigation-type-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php Pjax::begin(); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Fumigation Type', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'fumigation_type_id',
            'fumigation_type_name',
            'fumigation_days',
            [
                'attribute' => 'product_ids',
                'format' => 'raw',
                'value' => function($data)
                {
                    if($data->product_ids != '')
                    {
                        return "<a href='javascript:void(0)' class='fetch_prods' data-type='Product' data-id='".$data->fumigation_type_id."' >view</a>";
                    }else{
                        return "";
                    }   
                }
            ],
            [
                'attribute' => 'rpc_ids',
                'format' => 'raw',
                'value' => function($data)
                {
                    if($data->rpc_ids != '')
                    {
                        return "<a href='javascript:void(0)' class='fetch_prods' data-type='RPC' data-id='".$data->fumigation_type_id."' >view</a>";
                    }else{
                        return "";
                    }
                    
                }
            ],
            /*[
                'attribute' => 'product_ids',
                'format' => 'raw',
                'value' => function($data)
                {
                    $html = '';
                    if(!empty($data->product_ids))
                    {
                        $ids = json_decode($data->product_ids,true);
                        if(!empty($ids) && COUNT($ids) > 0)
                        {
                            $html .= '<ul>';
                            foreach ($ids as $key => $value) 
                            {
                                $prod = \app\models\Product::find()->where(['id' => $value])->one();
                                $html .= '<li>'.$prod->name.'</li>';
                            }
                            $html .= '</ul>';
                        }
                    }
                    return $html;
                }
            ],
            [
                'attribute' => 'rpc_ids',
                'format' => 'raw',
                'value' => function($data)
                {
                    $html = '';
                    if(!empty($data->rpc_ids))
                    {
                        $ids = json_decode($data->rpc_ids,true);
                        if(!empty($ids) && COUNT($ids) > 0)
                        {
                            $html .= '<ul>';
                            foreach ($ids as $key => $value) 
                            {
                                $rpc = \app\models\RpcCentre::find()->where(['id' => $value])->one();
                                $html .= '<li>'.$rpc->rpc_name.'</li>';
                            }
                            $html .= '</ul>';
                        }
                    }
                    return $html;
                }
            ],*/

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    <?php Pjax::end(); ?>
    <div class="ap_overlay"></div>
   <div class="ap_container"><img src="<?php echo Url::to('@web/images/loader.gif');?>"/></div>
</div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="border: none">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">

            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $("body").on("click", ".fetch_prods",function()
    {
        var id = $(this).attr("data-id");
        var type = $(this).attr("data-type");
        $.ajax({
            url: '<?php echo Url::to(["fumigation-type/fetch-products"]); ?>',
            type: 'post',
            data: {id : id, type : type},
            success: function (res) 
            {
                data = jQuery.parseJSON( res );
                if(data.type == 'success')
                {
                    $("#myModal .modal-body").html(data.data);
                    $("#myModal").modal("show");
                }else{
                    new PNotify({
                        type: data.type,
                        title: data.type,
                        text: data.msg,
                        sticker: false
                    });
                }
                
            },
            error: function (res) {
            }
        }); 
    });
    function ap_overlay(mode)
    {
        if(mode == 'show')
        {
            $(".ap_overlay, .ap_container").fadeIn();
        }else{
            $(".ap_overlay, .ap_container").fadeOut();
        }
    }
</script>