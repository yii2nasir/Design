<?php

use yii\helpers\Url;

?>

<style>
    .panel {
        padding: 0px !important;
        border: none;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        /*box-shadow: 10px 10px 5px grey*/ 
    }
</style> 

<style type="text/css">
    .tabs-left {
        border-bottom: none;
        padding-top: 2px;
        border-right: 1px solid #ddd;
    }
    .tabs-left>li{
        float: none;
        margin-bottom: 2px;
        margin-right: -1px;
    }
    .tabs-left>li.active>a,
    .tabs-left>li.active>a:hover,
    .tabs-left>li.active>a:focus {
        border-bottom-color: #ddd;
        border-right-color: transparent;
    }
    .tabs-left>li>a {
        border-radius: 4px 0 0 4px;
        margin-right: 0;
        display:block;
    }
    .tab-pane .highcharts-container{
        margin: 0 auto;
    }
</style>

<div class="site-index">
    <div class="body-content">
        <div class="panel panel-default" style="margin-bottom: 15px;">
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-1"><a href="" class="btn btn-warning btn-sm" onclick="window.history.go(-1);">Back</a></div>
                    <div class="col-lg-10">
                        <h3 class="text-center" style="margin-top: 0px;margin-bottom: 0px;"><b>Agriculture</b></h3>
                    </div>
                    <div class="col-lg-1"></div>
                </div>
            </div>			
        </div>

        <div class="panel panel-default" style="margin-bottom: 15px;">

            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12">
                        <!-- Tab panes -->
                            <div id="get_agriculture_distribution_tab">
                                <div class="row">
                                    <div class="col-md-3" id="villageDropDownDiv">
                                        <?php
                                        $query = new \yii\db\Query;
                                        $query->select([ 'village.id', 'village.village'])->from('household_profile')->innerJoin('village', 'household_profile.village = village.id')->groupBy('household_profile.village');
                                        $command = $query->createCommand();
                                        $Output = $command->queryAll();
                                        ?>
                                        <?=
                                        \yii\helpers\Html::dropDownList("HouseholdProfile[village]", "", yii\helpers\ArrayHelper::map($Output, 'id', 'village'), ['prompt' => 'ALL', 'id' => 'householdprofile-village','class' => 'form-control']);
                                        ?> 
                                    </div>
                                   
                                    <div class="col-md-3">
                                        <?php
                                        $financialYearC = date('Y');
                                        $financialYear = intval($financialYearC);
                                        echo \yii\helpers\Html::dropDownList("financial_year", $financialYear, yii\helpers\ArrayHelper::map(\app\models\FinancialYear::find()->all(), 'financial_year', 'financial_year'), [ 'id' => 'financial_year', 'class' => 'form-control'])
                                        ?> 
                                    </div>
                                    <div class="col-md-3">
                                        <input type="button" value="Search" id="btn_agri_practice_distribution_report" class="btn btn-primary"/>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-10">
                                        <div class="bsGraphColborderRight bsPaddingTop15px" id="get_agriculture_distribution_report"></div>            
                                    </div>
                                    <div class="col-md-2" id="other">
                                        <table class="table table-condensed table-bordered table-striped" style="font-size: 11px;margin-top: 15px;">
                                            <tr>
                                                <td style="font-size: 13px;text-align: center;"><b>Others</b></td>
                                            </tr>
                                            <tr>
                                                <td>Bee keeping</td>
                                            </tr>
                                            <tr>
                                                <td>Spices</td>
                                            </tr>
                                            <tr>
                                                <td>Sugarcane</td>
                                            </tr>
                                            <tr>
                                                <td>Medicinal and Aromatic</td>
                                            </tr>
                                            <tr>
                                                <td>Floriculture</td>
                                            </tr>
                                            <tr>
                                                <td>Plantation</td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            
                        </div>
                    </div>
                </div>
            </div>			
        </div>

    </div>        
</div>   


<script type="text/javascript">
    function Projectwise(){
        localStorage.setItem('functionIdStat','Projectwise'); 
        //alert($("#financial_year").val());
        $.ajax({
            url: '<?php echo Url::to(["site/agriculture-practice-distribution-report-project"]); ?>',
            type: 'post',
            data: {
                householdId: "",
                village: "",
                financialYear: $("#financial_year").val(),
                _csrf: '<?php echo Yii::$app->request->getCsrfToken() ?>'
            },
            beforeSend: function () {
                ajaxIndicatorStart("Please wait...", '<?php echo Url::to("@web/images/loading.gif") ?>');
            },
            complete: function () {
                ajaxIndicatorStop();
            },
            success: function (jsonResponse) {
                var response = JSON.parse(jsonResponse);
                $('#get_agriculture_distribution_report').html(response.data.practiceDetails);
            },
            error: function () {
                alert("Something went gone in Data Agriculture Practice Distribution graph.");
            }
        });
    }
    function Villagewise() {
        localStorage.setItem('functionIdStat','Villagewise'); 
       // alert($("#financial_year").val());
        $.ajax({
            url: '<?php echo Url::to(["site/agriculture-practice-distribution-report-village"]); ?>',
            type: 'post',
            data: {
                householdId: "",
                village: "",
                financialYear: $("#financial_year").val(),
                _csrf: '<?php echo Yii::$app->request->getCsrfToken() ?>'
            },
            beforeSend: function () {
                ajaxIndicatorStart("Please wait...", '<?php echo Url::to("@web/images/loading.gif") ?>');
            },
            complete: function () {
                ajaxIndicatorStop();
            },
            success: function (jsonResponse) {
                var response = JSON.parse(jsonResponse);
                $('#get_agriculture_distribution_report').html(response.data.practiceDetails);
            },
            error: function () {
                alert("Something went gone in Data Agriculture Practice Distribution graph.");
            }
        });
    }
    function Householdwise() {
        localStorage.setItem('functionIdStat','Householdwise');
        $('#villageDropDownDiv').show();
        $.ajax({
            url: '<?php echo Url::to(["site/agriculture-practice-distribution-report-household"]); ?>',
            type: 'post',
            data: {
                householdId: "",
                village: $("#householdprofile-village").val(),
                financialYear: $("#financial_year").val(),
                _csrf: '<?php echo Yii::$app->request->getCsrfToken() ?>'
            },
            beforeSend: function () {
                ajaxIndicatorStart("Please wait...", '<?php echo Url::to("@web/images/loading.gif") ?>');
            },
            complete: function () {
                ajaxIndicatorStop();
            },
            success: function (jsonResponse) {
                console.log(jsonResponse);
                $('#get_agriculture_distribution_report').html(jsonResponse);
                return false;
            },
            error: function () {
                alert("Something went gone in Data Agriculture Practice Distribution graph.");
            }
        });
    }
</script>

<script type="text/javascript">
    
    $("document").ready(function () {
        $('#other').show();
        $('#villageDropDownDiv').hide();
        Projectwise();
        $("#btn_agri_practice_distribution_report").click(function () {
            var functionIdStat = localStorage.getItem('functionIdStat');
            //alert(localStorage.getItem('functionIdStat'));
            if(functionIdStat === "Projectwise"){
                Projectwise();
            }
            if(functionIdStat === "Villagewise"){
                Villagewise();
            }
            if(functionIdStat === "Householdwise"){
                Householdwise();
            }      
            return false;
        });

    });
</script>
