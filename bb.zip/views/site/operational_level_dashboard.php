<?php

use \yii\helpers\Url;

?>

<style type="text/css">
    .bsBtnGraph{
        font-weight: bold;
        font-size: 20px;
        text-shadow: 0px 2px 2px #2B1A1C;
    }
    .parent{
        display: inline-block;
        vertical-align: top;
        margin-right: 20px;
    }
    .child{
        height: 150px;width: 200px;
        display:table-cell;
        vertical-align:bottom;
    }

    .blc{
        height: 150px;width: 180px;  
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat !important;
        display: inline-block;
    }
    .blcAhref{
        font-weight: bold;
        font-size: 20px;
        text-shadow: 0px 2px 2px #2B1A1C;
        color: white;
        display: inline-block;
        position: relative;
        margin-top: 155px;
        /*bottom: 0 !important;*/
        width: 100%;
        text-align: center;
        transition: background-color 1s;
        /*        background-color: deeppink;
             background-image: linear-gradient( white,  rgba(255, 0, 0, 0.4));*/
        /* Fallback for web browsers that doesn't support RGBa */
        background: rgb(0, 0, 0);
        /* RGBa with 0.6 opacity */
        background: rgba(0, 0, 0, 0.4)
    }
    /*    #mainC:hover  .blcAhref{
            color: white;
            text-decoration: none;
            background: rgb(0, 0, 0);
            background: rgba(0, 0, 0, 0.6)
        }*/
    .likn{
        display: inline-block;  
        transition: background-color 1s;
        /*border: 1px solid #EFF0F1;*/
        background-color: #f8f9f9;
         border-radius: 80%;
    }
    .likn:hover{
        /*background: rgb(0, 0, 0);*/
        background: rgba(0, 0, 0, 0.15);
    }
    
    .collapsible-header{
        background-color: #f1f8e9;
        padding:10px;
        margin-bottom: 2px;
        border-bottom-left-radius: 5px;
        border-bottom-right-radius: 5px;
        border-top-left-radius: 5px;
        border-top-right-radius: 5px;
        
        
    }
    .list_style{
        list-style: none;
        
    }

    
</style>
<body>
    
<div class="site-index">
    <div class="body-content">
        <div class="row" >
            <ul class="collapsible popout" data-collapsible="accordion">
        <li class="list_style " >
            <div class="collapsible-header active" style="padding-bottom: 20px;">Agriculture<a style="float:right;" onclick="window.history.go(-1);"  class="btn btn-warning btn-sm">Back</a></div>
            <div class="collapsible-body active">
                
               <table id="ag_table" class="table table-sm table-hover table-condensed table-responsive table-bordered">
                      <thead>
                        <tr>
                          <th>Activity</th>
                          <th>Activity Code</th>
                          <th>Parameter to track</th>
                        </tr>
                      </thead>
                      <tbody>
                        
                        <tr>
                          <td>Farm Mechanization</td>
                          <td>MECH</td>
                          <td>Reduced cost of cultivation, Area covered</td>
                        </tr>
                        
                        <tr>
                          <td>Crop Demonstration</td>
                          <td>CDM</td>
                          <td>Increased productivity</td>
                        </tr>
                      </tbody>
                </table>
            
            </div>
        </li>
        <li class="list_style">
            <div class="collapsible-header">Capacity Building</div>
            <div class="collapsible-body">
                <table  class="table table-sm table-hover table-condensed table-responsive table-bordered">
                 <thead>
                        <tr>
                          <th>Activity</th>
                          <th>Activity Code</th>
                          <th>Parameter to track</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Farmer training and exposure visit</td>
                          <td>CB</td>
                          <td>Number of Training / exposure visit organized, count of people attended training / exposure visit.</td>
                        </tr>
                      </tbody>
                </table>
            </div>
        </li>
    </ul>
            <div class="col-md-12">


                <div class="row" >
                    <div  class=" col-md-4 text-center" >
                        <a href="<?php echo Url::to(["/site/agriculture"]) ?>" class="likn">
                            <div class="blc" style="background: url(<?php echo Url::to("@web/images/icons/sprout.png"); ?>);">
                                <div class="blcAhref">Agriculture</div>
                            </div>
                        </a>
                    </div>   
                    
                    <div  class=" col-md-4 text-center" >
                        <a href="<?php echo Url::to(["/site/education"]) ?>" class="likn">
                            <div class="blc" style="background: url(<?php echo Url::to("@web/images/icons/education.png"); ?>);">
                                <div class="blcAhref">Education</div>
                            </div>
                        </a>
                    </div> 
                    
                    <div class="col-md-4 text-center" >
                        <a href="<?php echo Url::to(["/site/capacity-building"]) ?>" class="likn">
                            <div class="blc" style="background: url(<?php echo Url::to("@web/images/icons/cb.png"); ?>);">
                                <div class="blcAhref">Capacity Building</div>
                            </div>
                        </a>
                    </div> 

                </div>
            </div>
            <div class="col-md-2"></div>
        </div>


    </div>
</div>
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.8/js/materialize.min.js"></script>
</body>
</html>


