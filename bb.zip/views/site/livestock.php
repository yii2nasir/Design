<?php

use yii\helpers\Url;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

?>

<style>
    .panel {
        padding: 0px !important;
        border: none;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        /*box-shadow: 10px 10px 5px grey*/ 
    }

    #reportBreadcrumb li a{
        cursor: pointer;
    }
    .bsDisplayInlineBlock{
        display: inline-block;
    }
</style> 
<script src="<?php echo Url::to("@web/mjs/sehgal_dashboard_graph.js?v=".  rand(1, 1000)); ?>"></script>
<script src="<?php echo Url::to("@web/mjs/jquery.tabletoCSV.js?v=".  rand(1, 1000)); ?>"></script>
<script src="<?php echo Url::to("@web/graph-lib/highcharts.js"); ?>"></script>
<script src="<?php echo Url::to("@web/graph-lib/drilldown.js"); ?>"></script>
<script src="<?php echo Url::to("@web/graph-lib/exporting.js"); ?>"></script>
<script src="<?php echo Url::to("@web/graph-lib/data-graph.js"); ?>"></script>
<style type="text/css">
    .tabs-left {
        border-bottom: none;
        padding-top: 2px;
        border-right: 1px solid #ddd;
    }
    .tabs-left>li{
        float: none;
        margin-bottom: 2px;
        margin-right: -1px;
    }
    .tabs-left>li.active>a,
    .tabs-left>li.active>a:hover,
    .tabs-left>li.active>a:focus {
        border-bottom-color: #ddd;
        border-right-color: transparent;
    }
    .tabs-left>li>a {
        border-radius: 4px 0 0 4px;
        margin-right: 0;
        display:block;
    }
    .tab-pane .highcharts-container{
        margin: 0 auto;
    }
</style>


<div class="site-index">
    <div class="body-content">
        <div class="panel panel-default" style="margin-bottom: 15px;">
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-1"><a  class="btn btn-warning btn-sm" onclick="window.history.go(-1);">Back</a></div>
                    <div class="col-lg-10">
                        <h3 class="text-center" style="margin-top: 0px;margin-bottom: 0px;"><b>Livestock</b></h3>
                    </div>
                    <div class="col-lg-1"></div>
                </div>
            </div>			
        </div>

        <div class="panel panel-default" style="margin-bottom: 15px;">
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12">
                        <!-- START OF: Main Tab START Graph/Report -->
                        <ul class="nav nav-tabs nav-justified">
                            <li class="active"><a data-toggle="tab" href="#agriculture_graphs"><b>Graphs</b></a></li>
                            <li><a data-toggle="tab" href="#agriculture_reports"><b>Reports</b></a></li>
                        </ul>
                        <!-- ENDs OF: Main Tab START Graph/Report -->
                        
                        <!--START OF: GRAPH/REPORT DIV SECTION--> 
                        <div class="tab-content">
                            <div id="agriculture_graphs" class="tab-pane fade in active bsPaddingTop15px">
                                <!-- START OF: Agriculture Graphs Content -->
                                <div class="row">
                                    <!-- START OF: Name list of graph menu Section-->
                                        <div class="col-md-3">
                                            <ul class="nav nav-tabs tabs-left">
                                                <li class="active"><a href="#animal_nutrient_management_tab" data-toggle="tab" onclick="ajaxGetDataAnimalNutrientManagement();"><span class="glyphicon glyphicon-info-sign" onclick="showHelp('')"></span>7.1 Animal Nutrient Management</a></li>
                                                <li><a href="#animal_health_camp" data-toggle="tab" onclick="ajaxGetDataAnimalHealthCamp();"><span class="glyphicon glyphicon-info-sign" onclick="showHelp('')"></span>8.1 Animal Health Camp</a></li>
                                                <li><a href="#data_goatry_promotion_tab" data-toggle="tab" onclick="ajaxGetDataGoatryPromotion();"><span class="glyphicon glyphicon-info-sign" onclick="showHelp('')"></span>9.1 Goatry Promotion</a></li>
                                            </ul>
                                        </div>
                                    <!-- END OF: Name list of graph menu Section-->

                                    <!-- START OF: Graph Highchart Section-->
                                    
                                        <div class="col-md-9">
                                           <!-- Tab panes -->
                                            <div class="tab-content">
                                                
                                                <div class="tab-pane fade in active" id="animal_nutrient_management_tab">
                                                    <div class="row">
                                                        <div class="col-md-3">
                                                           <?php 
                                                            $Month=[ 
                                                                    "01"=>'January',"02"=>'February',"03"=>'March',
                                                                    "04"=>'April',"05"=>'May',"06"=>'June',"07"=>'July',
                                                                    "08"=>'August',"09"=>'September',"10"=>'October',
                                                                    "11"=>'November',"12"=>'December'
                                                                   ];
                                                            echo \yii\helpers\Html::dropDownList("month","", $Month, [ 'id' => 'month', 'class' => 'form-control','prompt'=>'Select Month'])
                                                           ?>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <?php
                                                            $Years=[
                                                                        "2016"=>2016,"2017"=>2017
                                                                   ];
                                                                    
                                                            echo \yii\helpers\Html::dropDownList("year","", $Years, [ 'id' => 'year', 'class' => 'form-control','prompt'=>'Select Year'])
                                                           ?>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <input type="button" onclick="ajaxGetDataAnimalNutrientManagement()" value="Search"  class="btn btn-primary"/>
                                                        </div>
                                                        
                                                        <div class="col-md-3">
                                                        </div>
                                                    </div>
                                                   
                                                    <div class="row" >
                                                        <div class="col-md-12" >
                                                            <div  class="bsGraphColborderRight bsPaddingTop15px" id="data_animal_nutrient_management"></div>            
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <!-- Animal Health Camp-->
                                                <div class="tab-pane fade" id="animal_health_camp">
                                                    <div class="row">
                                                        <div class="col-md-3">
                                                           <?php 
                                                            $Month=[ 
                                                                    "01"=>'January',"02"=>'February',"03"=>'March',
                                                                    "04"=>'April',"05"=>'May',"06"=>'June',"07"=>'July',
                                                                    "08"=>'August',"09"=>'September',"10"=>'October',
                                                                    "11"=>'November',"12"=>'December'
                                                                   ];
                                                            echo \yii\helpers\Html::dropDownList("month","", $Month, [ 'id' => 'monthanimalHealth', 'class' => 'form-control','prompt'=>'Select Month'])
                                                           ?>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <?php
                                                            $Years=[
                                                                        "2016"=>2016,"2017"=>2017
                                                                   ];
                                                            echo \yii\helpers\Html::dropDownList("year","", $Years, [ 'id' => 'yearanimalHealth', 'class' => 'form-control','prompt'=>'Select Year'])
                                                           ?>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <input type="button" onclick="ajaxGetDataAnimalHealthCamp()" value="Search"  class="btn btn-primary"/>
                                                        </div>
                                                        
                                                        <div class="col-md-3">
                                                        </div>
                                                    </div>
                                                   
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div  class="bsGraphColborderRight bsPaddingTop15px" id="btn_animal_health_camp"></div>            
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="tab-pane fade" id="data_goatry_promotion_tab">
                                                    <div class="row">
                                                        <div class="col-md-3">
                                                           <?php 
                                                            $Month=[ 
                                                                    "01"=>'January',"02"=>'February',"03"=>'March',
                                                                    "04"=>'April',"05"=>'May',"06"=>'June',"07"=>'July',
                                                                    "08"=>'August',"09"=>'September',"10"=>'October',
                                                                    "11"=>'November',"12"=>'December'
                                                                   ];
                                                            echo \yii\helpers\Html::dropDownList("month","", $Month, [ 'id' => 'monthGoatryPromotion', 'class' => 'form-control','prompt'=>'Select Month'])
                                                           ?>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <?php
                                                            $Years=[
                                                                        "2016"=>2016,"2017"=>2017
                                                                   ];
                                                                    
                                                            echo \yii\helpers\Html::dropDownList("year","", $Years, [ 'id' => 'yearGoatryPromotion', 'class' => 'form-control','prompt'=>'Select Year'])
                                                           ?>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <input type="button" onclick="ajaxGetDataGoatryPromotion()" value="Search"  class="btn btn-primary"/>
                                                        </div>
                                                        
                                                        <div class="col-md-3">
                                                        </div>
                                                    </div>
                                                   
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div  class="bsGraphColborderRight bsPaddingTop15px" id="data_goatry_promotion"></div>            
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                
                                            </div>
                                           
                                        </div>
                                     <!-- END OF: Graph Highchart Section DIV-->    
                                </div>
                                <!-- END OF: Agriculture Graphs Content DIV-->
                            </div>
                            
                           <!--START OF: Capacity Building reports content-->
                                <div id="agriculture_reports" class="tab-pane fade bsPaddingTop15px">
                                    <div id="animal_health_camp_container">
                                        <div class="row">
                                            <!-- START OF: Name list of Report menu Section-->
                                                <div class="col-md-3">
                                                    <ul class="nav nav-tabs tabs-left">
                                                        <li class="active"><a href="#report_animal_health_camp" data-toggle="tab" onclick="ajaxAnimalHealthCampReport();">Animal Health Camp</a></li>
                                                    </ul>
                                                </div>
                                            <!-- END OF: Name list of Report menu Section-->
                                            <!-- START OF : Report table for Capacity Building -->
                                            <div class="col-md-9">
                                                <div class="row">
                                                    <div class="col-lg-12 col-md-12 col-sm-12" >
                                                    <button id="export" data-export="export" class="btn btn-success">Download CSV</button>
                                                    <table id="get_animal_health_camp_report" class="table table-bordered table-responsive">
                                                    </table>
                                                    </div> 
                                                </div>
                                            </div>
                                            <!-- END OF : Report table for Capacity Building -->
                                            
                                            
                                        </div>
<!--                                        <div class="row">
                                            <div class="col-md-10">
                                                <button class="btn btn-success" id="dd" onclick='$("#get_agriculture_distribution_report table").tableToCSV();'>
                                                    Download CSV
                                                </button>
                                                <div class="bsGraphColborderRight bsPaddingTop15px" id="get_agriculture_distribution_report"></div>            
                                            </div>
                                        </div>-->
                                    </div>
                                </div>
                                <!--END OF: Agriculture_reports content-->
                        </div>
                        <!--END OF: GRAPH/REPORT DIV SECTION-->
                    </div>
                </div>
            </div>			
        </div>
    </div>     
</div>


<script type="text/javascript">
    $("document").ready(function (){
        ajaxAnimalHealthCampReport();//Report table will load on page load
        $("#get_animal_health_camp_report").click(function () {
            ajaxAnimalHealthCampReport();
            return false;
        });
    });
</script>

<script>
//Start OF: Ajax Function for REPORT
    //Start OF REPORT FUNCTION FOR:  Animal Health Camp
    function ajaxAnimalHealthCampReport(){
//        alert("WOOOOOOOOOOOO");
        $.ajax({
            url: '<?php echo Url::to(["site/animal-health-camp-report"]); ?>',
            type: 'get',
            data: {
                
            },
            beforeSend: function () {
               // ajaxIndicatorStart("Please wait...", '<?php //echo Url::to("@web/images/loading.gif") ?>');
            },
            complete: function () {
               // ajaxIndicatorStop();
            },
            success: function (data) {
                console.log("Capacity Building Report Data",data);
                $('#get_animal_health_camp_report').html(createAnimalHealthCampTable(data));
//              
            },
            error: function () {
                //alert("Something went wrong in Animal Health Camp Report.");
            }
        });
    }
    
    function createAnimalHealthCampTable(data)
    {
      // console.log("Crop Diversification Datatable values",data) 
      //  alert("Hello Table");
       var table = "<thead>";
       table += "<th>Camp ID</th>";
       table += "<th>Camp Date</th>";
       table += "<th>Farmer Attended Count</th>";
       table += "<th>Cow</th>";
       table += "<th>Buffalo</th>";
       table += "<th>Others</th>";
       table += "<th>Total</th>";
       table += "</thead>";
       table += "<tbody>";
       var totalFarmerAttendedSum = 0;
       var totalCowSum = 0;
       var totalBuffaloSum = 0;
       var totalOthersSum = 0;
       var totalSum = 0;
       for(var i = 0; i < data.length; i++){
           totalFarmerAttendedSum = totalFarmerAttendedSum + data[i].beneficiary;
           totalCowSum=totalCowSum + data[i].cow;
           totalBuffaloSum=totalBuffaloSum + data[i].buffalo;
           totalOthersSum=totalOthersSum + data[i].others;
           totalSum=totalSum + data[i].total;

           table += "<tr>";
           table += "<td>"+data[i].SlNo+"</td>";
           table += "<td>"+data[i].date+"</td>";
           table += "<td>"+data[i].beneficiary+"</td>";
           table += "<td>"+data[i].cow+"</td>";
           table += "<td>"+data[i].buffalo+"</td>";
           table += "<td>"+data[i].others+"</td>";
           table += "<td>"+data[i].total+"</td>";
           table += "</tr>";
       }
       table += "<tr><td></td><td><b>Total</b></td>";
       table += "<td><b>"+totalFarmerAttendedSum+"</b></td>";
       table += "<td><b>"+totalCowSum+"</b></td>";
       table += "<td><b>"+totalBuffaloSum+"</b></td>";
       table += "<td><b>"+totalOthersSum+"</b></td>";
       table += "<td><b>"+totalSum+"</b></td>";
       table += "</tr>";
       table += "</tbody>";
       return table;

          
    }
    
    //End OF REPORT FUNCTION FOR: Animal Health Camp
    
 //END OF: Ajax Function for REPORT
</script>


<script type="text/javascript">
    $("document").ready(function (){
        ajaxGetDataAnimalNutrientManagement();//initialize while first time on page load
        $("#btn_animal_nutrient_management").click(function () {
            ajaxGetDataAnimalNutrientManagement();
            return false;
        });
    });
</script>

<script type="text/javascript">
   //  1. START OF AJAX FUNCTION CALL:   Animal Nutrient Management 
    function ajaxGetDataAnimalNutrientManagement(){
        var year = document.getElementById("year").value;
        var month = document.getElementById("month").value;
        //alert("I'm working...");
        $.ajax({
            url: '<?php echo Url::to(["site/animal-nutrient-management"]); ?>',
            type: 'post',
            data: {
                year:year,
                month : month,
                _csrf: '<?=Yii::$app->request->getCsrfToken()?>'
                
            },
            beforeSend: function () {
                //ajaxIndicatorStart("Please wait...", '<?php //echo Url::to("@web/images/loading.gif") ?>');
            },
            complete: function () {
               // ajaxIndicatorStop();
            },
            success: function (data) {
                  console.log("Animal Nutrient Management Data",data);
                  animalNutrientManagementLineChart(data.month,data.cowData,data.buffaloData,data.totalCattle,data.tillDateArray);
//                lineChart();
            },
            error: function (jsonResponse) {
                console.log(jsonResponse);
                //alert("Something went wrong in Animal Nutrient Management.");
            }
        });
    }
   //  1. END OF AJAX FUNCTION CALL:   Animal Nutrient Management 
    
   //  2. START OF AJAX FUNCTION CALL:   Animal Health Camp
    function ajaxGetDataAnimalHealthCamp(){
        var year = document.getElementById("yearanimalHealth").value;
        var month = document.getElementById("monthanimalHealth").value;
        //alert("I'm working...");
        $.ajax({
            url: '<?php echo Url::to(["site/animal-health-camp"]); ?>',
            type: 'post',
            data: {
                year:year,
                month : month,
                _csrf: '<?=Yii::$app->request->getCsrfToken()?>'
                
            },
            beforeSend: function () {
                //ajaxIndicatorStart("Please wait...", '<?php //echo Url::to("@web/images/loading.gif") ?>');
            },
            complete: function () {
               // ajaxIndicatorStop();
            },
            success: function (data) {
                  console.log("Animal Health Camp Data",data);
                  animalAnimalHealthCamp(data);
//                lineChart();
            },
            error: function (jsonResponse) {
                console.log(jsonResponse);
                //alert("Something went wrong in Animal Health Camp.");
            }
        });
    }
    //  2. END OF AJAX FUNCTION CALL:   Animal Health Camp
    
    
    //  3. START OF AJAX FUNCTION CALL:   Goatry Promotion
    function ajaxGetDataGoatryPromotion()
    {
//        alert("I'm working");
        var year = document.getElementById("yearGoatryPromotion").value;
        var month = document.getElementById("monthGoatryPromotion").value;
        //alert("I'm working...");
        $.ajax({
            url: '<?php echo Url::to(["site/goatry-promotion"]); ?>',
            type: 'post',
            data: {
                year:year,
                month : month,
                _csrf: '<?=Yii::$app->request->getCsrfToken()?>'
                
            },
            beforeSend: function () {
                //ajaxIndicatorStart("Please wait...", '<?php //echo Url::to("@web/images/loading.gif") ?>');
            },
            complete: function () {
               // ajaxIndicatorStop();
            },
            success: function (data) {
                  console.log("Goatry Data",data);
                  goatryPromotionLineChart(data.month,data.monBenefCount,data.ptdBenefCount);
//                lineChart();
            },
            error: function (jsonResponse) {
                console.log(jsonResponse);
                //alert("Something went wrong in Goatry Promotion.");
            }
        });
    }
    // 3. END OF AJAX FUNCTION CALL:   Goatry Promotion
    
  
</script>

<!-- Code for CSV Download -->
<script>
  $("#export").click(function(){
  $("#get_animal_health_camp_report").tableToCSV();
});
</script>
