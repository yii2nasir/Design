<?php

use yii\helpers\Url;
?>

<style>
    .panel {
        padding: 0px !important;
        border: none;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        /*box-shadow: 10px 10px 5px grey*/ 
    }

    #reportBreadcrumb li a{
        cursor: pointer;
    }
    .bsDisplayInlineBlock{
        display: inline-block;
    }
</style> 
<script src="<?php echo Url::to("@web/mjs/jquery.tabletoCSV.js?v=".  rand(1, 1000)); ?>"></script>
<script src="<?php echo Url::to("@web/graph-lib/highcharts.js"); ?>"></script>
<script src="<?php echo Url::to("@web/graph-lib/drilldown.js"); ?>"></script>
<script src="<?php echo Url::to("@web/graph-lib/exporting.js"); ?>"></script>
<script src="<?php echo Url::to("@web/graph-lib/data-graph.js"); ?>"></script>
<style type="text/css">
    .tabs-left {
        border-bottom: none;
        padding-top: 2px;
        border-right: 1px solid #ddd;
    }
    .tabs-left>li{
        float: none;
        margin-bottom: 2px;
        margin-right: -1px;
    }
    .tabs-left>li.active>a,
    .tabs-left>li.active>a:hover,
    .tabs-left>li.active>a:focus {
        border-bottom-color: #ddd;
        border-right-color: transparent;
    }
    .tabs-left>li>a {
        border-radius: 4px 0 0 4px;
        margin-right: 0;
        display:block;
    }
    .tab-pane .highcharts-container{
        margin: 0 auto;
    }
</style>
<!--<script src="<?php echo Url::to("@web/mjs/dashboard_graph_js.js?v=".  rand(1, 1000)); ?>"></script>-->
<script src="<?php echo Url::to("@web/mjs/dashboard_graph.js?v=".  rand(1, 1000)); ?>"></script>
<div class="site-index">
    <div class="body-content">
        <div class="panel panel-default" style="margin-bottom: 15px;">
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-1"><a href="" class="btn btn-warning btn-sm" onclick="window.history.go(-1);">Back</a></div>
                    <div class="col-lg-10">
                        <h3 class="text-center" style="margin-top: 0px;margin-bottom: 0px;"><b>Capacity Building</b></h3>
                    </div>
                    <div class="col-lg-1"></div>
                </div>
            </div>			
        </div>

        <div class="panel panel-default" style="margin-bottom: 15px;">

            <div class="panel-body">
                <div class="row">

                    <div class="col-md-12">
                        <!--main tab START graph/report-->
                        <ul class="nav nav-tabs nav-justified">
                            <li class="active"><a data-toggle="tab" href="#agriculture_graphs"><b>Graphs</b></a></li>
                            <li><a data-toggle="tab" href="#agriculture_reports"><b>Reports</b></a></li>
                        </ul>

                        <div class="tab-content">
                            <div id="agriculture_graphs" class="tab-pane fade in active bsPaddingTop15px">
                                <!--agriculture_graphs content-->

                                <div class="row">

                                    <div class="col-md-3">
                                        <!-- Nav tabs -->
                                        <ul class="nav nav-tabs tabs-left">
                                            <li><a href="#graph1" data-toggle="tab" onclick="ajaxGetDatamld();"><span class="glyphicon glyphicon-info-sign" onclick="showHelp('')"></span> 10.1 Capacity Building</a></li>
                                            
                                            
                                        </ul>
                                    </div>
                                     <div class="col-md-9">
                                        <!-- Tab panes -->
                                        <div class="tab-content">
                                            
                                            <div class="tab-pane fade in active" id="graph1">

                                                <div class="row">
                                                    <div class="col-md-3">
                                                      <select name="HouseholdProfile[id]" id="householdprofile-id" class="form-control"><option value="">Select Village</option></select> 
                                                    </div>
                                                    
                                                    <div class="col-md-3">
                                                        <select name="HouseholdProfile[id]" id="householdprofile-id" class="form-control"><option value="">Select Farmer</option></select>
                                                    </div>
                                                    
                                                    <div class="col-md-3">
                                                        <input type="button" value="Search" id="btn_land_utilization" class="btn btn-primary"/>
                                                    </div>
                                                    
                                                    <div class="col-md-3">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="bsGraphColborderRight bsPaddingTop15px" id="land_utilization"></div>            
                                                    </div>
                                                </div>


                                            </div>

                                            <div class="tab-pane fade" id="agri_inputs_distribution">

                                            </div>
                                            
                                        <div class="tab-pane fade" id="graph2">
                                            <div class="row">
                                                <div class="col-md-4">
                                                        <select name="HouseholdProfile[id]" id="householdprofile-id" class="form-control"><option value="">Select Village</option></select> 
                                                </div>

                                                <div class="col-md-4">

                                                        <select name="HouseholdProfile[id]" id="householdprofile-id" class="form-control" onchange="changehouseData()"><option value="">Select Farmer</option></select>
                                                </div>

                                                <div class="col-md-4">
                                                    <input type="button" value="Search" id="btn_kitchen_garden_across_year_project_level" class="btn btn-primary"/>
                                                </div>

                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="bsGraphColborderRight bsPaddingTop15px" id="kitchen_garden_across_year_project_level"></div>
                                                </div>
                                            </div>
                                         </div>

                                        <div class="tab-pane fade" id="get_agriculture_distribution_tab">
                                            <div class="row">
                                                <div class="col-md-12">
                                                <div class="bsDisplayInlineBlock">
                                                    <select>
                                                        <option value=""> --Select Year--</option>>
                                                    </select>
                                                </div>


                                                  <!---------------- suresh Start-------------->
                                                   <div class="bsDisplayInlineBlock">

                                                   </div>
                                                 <!---------------- suresh end-------------->
                                                <div class="bsDisplayInlineBlock">
                                                     <select name="HouseholdProfile[id]" id="householdprofile-id" class="form-control"><option value="">Select village</option></select>
                                                </div>
                                                <div class="bsDisplayInlineBlock">
                                                    <select name="HouseholdProfile[id]" id="householdprofile-id" class="form-control"><option value="">Select farmer</option></select>

                                                </div>

                                                <div class="bsDisplayInlineBlock">
                                                    <input type="button" value="Search" id="btn_agri_practice_distribution" class="btn btn-primary"/>
                                                </div>
                                            </div>
                                        </div>
                                            
                                        <div class="row">
                                            <div class="col-md-10">
                                                <div class="bsGraphColborderRight bsPaddingTop15px" id="get_agriculture_distribution"></div>            
                                            </div>
                                            <div class="col-md-2">
                                                <table class="table table-condensed table-bordered table-striped" style="font-size: 11px;margin-top: 15px;">
                                                    <tr>
                                                        <td style="font-size: 13px;text-align: center;"><b>Others</b></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Bee keeping</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Spices</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Sugarcane</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Medicinal and Aromatic</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Floriculture</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Plantation</td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    </div>

                                         <div class="tab-pane fade" id="get_agriculture_distribution_graph">
                                            <div class="row">
                                                <div class="col-md-12">
                                                <div class="bsDisplayInlineBlock">

                                                </div>


                                                <div class="bsDisplayInlineBlock">
                                                    <select name="HouseholdProfile[id]" id="householdprofile-id" class="form-control"><option value="">Select village</option></select>
                                                </div>
                                                <div class="bsDisplayInlineBlock">
                                                    <select name="HouseholdProfile[id]" id="householdprofile-id" class="form-control"><option value="">Select farmer</option></select>

                                                </div>

                                                <div class="bsDisplayInlineBlock">
                                                    <input type="button" value="Search" id="btn_agri_practice_distribution_graph" class="btn btn-primary"/>
                                                </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="bsGraphColborderRight bsPaddingTop15px" id="pnjab_2020_agriinput"></div>
                                                </div>
                                            </div>
                                     </div>
                                            <div class="tab-pane fade" id="kitchen_garden_tab">
                                                <div class="bsGraphColborderRight" id="kitchen_garden"></div>
                                            </div>
                                            <div class="tab-pane fade" id="profitability_analysis_tab">
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        
                                                    </div>
                                                    <div class="col-md-3">
                                                        <input type="button" value="Search" id="btn_crop_production_profitability" class="btn btn-primary"/>
                                                    </div>
                                                    <div class="col-md-3">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="bsGraphColborderRight bsPaddingTop15px" id="profitability_analysis" ></div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                            </div>
                        </div>
                            <div id="agriculture_reports" class="tab-pane fade bsPaddingTop15px">
                                
                                <div id="agriculture_report_container">
                                    <div class="row">
                                        <div class="col-md-3" id="villageDropDownDiv">
                                           
                                        </div>

                                        <div class="col-md-3">
                                             
                                        </div>
                                        <div class="col-md-3">
                                            <input type="button" value="Search" id="btn_agri_practice_distribution_report" class="btn btn-primary"/>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-10">
                                            <button class="btn btn-success" id="dd" onclick='
//                                                alert($("#export_table table").html());
                                                $("#get_agriculture_distribution_report table").tableToCSV();'>
                                                Download CSV
                                            </button>
                                            <div class="bsGraphColborderRight bsPaddingTop15px" id="get_agriculture_distribution_report"></div>            
                                        </div>
                                        <div class="col-md-2" id="other">
                                            <table class="table table-condensed table-bordered table-striped" style="font-size: 11px;margin-top: 15px;">
                                                <tr>
                                                    <td style="font-size: 13px;text-align: center;"><b>Others</b></td>
                                                </tr>
                                                <tr>
                                                    <td>Bee keeping</td>
                                                </tr>
                                                <tr>
                                                    <td>Spices</td>
                                                </tr>
                                                <tr>
                                                    <td>Sugarcane</td>
                                                </tr>
                                                <tr>
                                                    <td>Medicinal and Aromatic</td>
                                                </tr>
                                                <tr>
                                                    <td>Floriculture</td>
                                                </tr>
                                                <tr>
                                                    <td>Plantation</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                    </div>
                </div>
            </div>
        </div>
                                    
            <script>
                function ajaxGetDatamld(){
                    var containerDivId = "graph1";
                    getDatamldGraph(containerDivId);
                }
                
                function ajaxGetDataTest(){
                    var secContainerDivId = "graph2";
                    getDataTestGraph(secContainerDivId);
                }
            </script>
                                           
                                            
                                

                                            
