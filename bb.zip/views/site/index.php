<?php
use yii\helpers\Url;
use app\models\RpcCentre;
use app\models\Users;
use app\models\IncomingQcCheck;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <style type="text/css">
    #header1{
        text-shadow: 2px 2px 5px #008000 ;
        color: #689F35;
        font-family: serif;
    }
    .jumbotron{
      margin-top: 10px;
    }
   .icon1 {
      color: white !important;
    }
   .icon{
      margin-top: 25px;    
   }
   .fa-bank,.fa-tasks{
     font-size: 50px !important; 
        }
    .material-icons{
      font-size: 62px !important; 
    }
      body{
        overflow: hidden !important;
    }
</style>
</head>
<body>

    <div class="jumbotron">
          <h1 id="header1">Big Basket RPC</h1> 
    </div> 

</body>
</html>

<div class="panel panel-default">
   <!--  <div class="panel-heading">Total Count</div> -->
      <div class="panel-body">
          <div class="row top_tiles">
            <div class="animated flipInY col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="tile-stats" style="background: cadetblue">
                    <div class="icon icon1"><i class="material-icons">people</i>
                    </div>
                    <div class="count icon1"><?= Users::find()->count(); ?></div>

                    <h3 class="icon1">Total User</h3>
                </div>
            </div>
            <div class="animated flipInY col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="tile-stats" style="background: darkgray">
                    <div class="icon icon1"><i class="fa fa-bank"></i>
                    </div>
                   <div class="count icon1"><?= RpcCentre::find()->count(); ?></div>

                    <h3 class="icon1">Total RPC Center</h3>
                </div>
            </div>
            <div class="animated flipInY col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="tile-stats" style="background: darkseagreen">
                    <div class="icon icon1"><i class="fa fa-tasks"></i>
                    </div>
                     <div class="count icon1"><?= IncomingQcCheck::find()->count(); ?></div>

                    <h3 class="icon1">Incoming QC Check</h3>
                </div>
            </div>
        </div>
      </div>
</div> 
