<?php

use yii\helpers\Url;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

?>

<style>
    .panel {
        padding: 0px !important;
        border: none;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        /*box-shadow: 10px 10px 5px grey*/ 
    }

    #reportBreadcrumb li a{
        cursor: pointer;
    }
    .bsDisplayInlineBlock{
        display: inline-block;
    }
</style> 

<script src="<?php echo Url::to("@web/mjs/sehgal_dashboard_graph.js?v=".  rand(1, 1000)); ?>"></script>
<script src="<?php echo Url::to("@web/mjs/jquery.tabletoCSV.js?v=".  rand(1, 1000)); ?>"></script>
<script src="<?php echo Url::to("@web/graph-lib/highcharts.js"); ?>"></script>
<script src="<?php echo Url::to("@web/graph-lib/drilldown.js"); ?>"></script>
<script src="<?php echo Url::to("@web/graph-lib/exporting.js"); ?>"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="<?php echo Url::to("@web/graph-lib/data-graph.js"); ?>"></script>
<style type="text/css">
    .tabs-left {
        border-bottom: none;
        padding-top: 2px;
        border-right: 1px solid #ddd;
    }
    .tabs-left>li{
        float: none;
        margin-bottom: 2px;
        margin-right: -1px;
    }
    .tabs-left>li.active>a,
    .tabs-left>li.active>a:hover,
    .tabs-left>li.active>a:focus {
        border-bottom-color: #ddd;
        border-right-color: transparent;
    }
    .tabs-left>li>a {
        border-radius: 4px 0 0 4px;
        margin-right: 0;
        display:block;
    }
    .tab-pane .highcharts-container{
        margin: 0 auto;
    }
</style>

<div class="site-index">
    <div class="body-content">
        <div class="panel panel-default" style="margin-bottom: 15px;">
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-1"><a  class="btn btn-warning btn-sm" onclick="window.history.go(-1);">Back</a></div>
                    <div class="col-lg-10">
                        <h3 class="text-center" style="margin-top: 0px;margin-bottom: 0px;"><b>Education</b></h3>
                    </div>
                    <div class="col-lg-1"></div>
                </div>
            </div>			
        </div>

        <div class="panel panel-default" style="margin-bottom: 15px;">
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12">
                        <!-- START OF: Main Tab START Graph/Report -->
                        <ul class="nav nav-tabs nav-justified">
                            <li class="active"><a data-toggle="tab" href="#education_graphs"><b>Graphs</b></a></li>
                            <li><a data-toggle="tab" href="#education_reports"><b>Reports</b></a></li>
                        </ul>
                        <!-- ENDs OF: Main Tab START Graph/Report -->
                        
                        <!--START OF: GRAPH/REPORT DIV SECTION--> 
                        <div class="tab-content">
                            <div id="education_graphs" class="tab-pane fade in active bsPaddingTop15px">
                                <!-- START OF: Agriculture Graphs Content -->
                                <div class="row">
                                    <!-- START OF: Name list of graph menu Section-->
                                        <div class="col-md-3">
                                            <ul class="nav nav-tabs tabs-left">
                                               <li><a href="tab_education" data-toggle="tab" onclick="ajaxGetDataEducation();"><span class="glyphicon glyphicon-info-sign" onclick="showHelp('')"></span> 1.1 Education</a></li>
                                                
                                            </ul>
                                        </div>
                                    <!-- END OF: Name list of graph menu Section-->

                                    <!-- START OF: Graph Highchart Section-->
                                    
                                        <div class="col-md-9">
                                           <!-- Tab panes -->
                                            <div class="tab-content">
                                                <div class="tab-pane fade in active" id="animal_nutrient_management_tab">
                                                    <div class="row">
<!--                                                         <div class="col-md-3">
                                                           <?php 
//                                                            $Month=[ 
//                                                                    "01"=>'January',"02"=>'February',"03"=>'March',
//                                                                    "04"=>'April',"05"=>'May',"06"=>'June',"07"=>'July',
//                                                                    "08"=>'August',"09"=>'September',"10"=>'October',
//                                                                    "11"=>'November',"12"=>'December'
//                                                                   ];
//                                                            echo \yii\helpers\Html::dropDownList("month","", $Month, [ 'id' => 'cbMonth', 'class' => 'form-control','prompt' => 'Select Month'])
                                                           ?>
                                                        </div>-->
                                                        <div class="col-md-3">
                                                            <?php
                                                            $Years=[
                                                                        "2016"=>2016,"2017"=>2017
                                                                   ];
                                                                
                                                            echo \yii\helpers\Html::dropDownList("year","", $Years, [ 'id' => 'educationYear', 'class' => 'form-control' ,'prompt' => 'Select Year'])
                                                           ?>
                                                        </div>
                                                        <div class="col-md-3">
                                                             <?php 
                                                                $query = new \yii\db\Query;
                                                                $query = $query->select(['village.id as village_id','village.village'])
                                                                        ->from('education')
                                                                        ->innerJoin("village","village.id = education.village_id");
                                                                $command = $query->createCommand();
                                                                $Output = $command->queryAll();
//                                                                display_array($Output);exit;
                                                                $expArray = [];
                                                                $selected = 0;
                                                                foreach ($Output as $key=>$value){
                                                                    if($key === 0){
                                                                        $selected = $value['village_id'];
                                                                    }                                                                
                                                                    $expArray[$value['village_id']] = $value['village'];
                                                                }
                                                                echo \yii\helpers\Html::dropDownList("village_id","",$expArray, [ 'id' => 'villageList', 'class' => 'form-control', 'prompt' => 'Select Village'])
                                                           ?>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <input type="button" onclick="ajaxGetDataEducation()" value="Search"  class="btn btn-primary"/>
                                                        </div>
                                                        
                                                        
                                                    </div>
                                                   
                                                    <div class="row" >
                                                        <div class="col-md-12">
                                                            <div  class="bsGraphColborderRight bsPaddingTop15px" id="data_education"></div>            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                     <!-- END OF: Graph Highchart Section DIV-->    
                                </div>
                                <!-- END OF: Agriculture Graphs Content DIV-->
                            </div>
                             <!--START OF: Capacity Building reports content-->
                                <div id="education_reports" class="tab-pane fade bsPaddingTop15px">
                                    <div id="education_report_container">
                                        <div class="row">
                                            <!-- START OF: Name list of Report menu Section-->
                                                <div class="col-md-3">
                                                    <ul class="nav nav-tabs tabs-left">
                                                        <li class="active"><a href="#report_education" data-toggle="tab" onclick="ajaxEducationReport();">Education</a></li>
                                                    </ul>
                                                </div>
                                            <!-- END OF: Name list of Report menu Section-->
                                            <!-- START OF : Report table for Capacity Building -->
                                            <div class="col-md-9">
                                                <div class="row">
                                                    <div class="col-lg-12 col-md-12 col-sm-12" >
                                                    <button id="education" data-export="export" class="btn btn-success">Download CSV</button>
                                                    <br>
                                                    <table id="get_education_report" class="table table-bordered table-responsive">
                                                    </table>
                                                    </div> 
                                                </div>
                                            </div>
                                            <!-- END OF : Report table for Capacity Building -->
                                            
                                            
                                        </div>
<!--                                        <div class="row">
                                            <div class="col-md-10">
                                                <button class="btn btn-success" id="dd" onclick='$("#get_agriculture_distribution_report table").tableToCSV();'>
                                                    Download CSV
                                                </button>
                                                <div class="bsGraphColborderRight bsPaddingTop15px" id="get_agriculture_distribution_report"></div>            
                                            </div>
                                        </div>-->
                                    </div>
                                </div>
                                <!--END OF: Agriculture_reports content-->
                        </div>
                        <!--END OF: GRAPH/REPORT DIV SECTION-->
                    </div>
                </div>
            </div>			
        </div>
    </div>     
</div>

<script type="text/javascript">
    $("document").ready(function (){
        ajaxGetDataEducation();//initialize while first time on page load
        $("#btn_animal_nutrient_management").click(function () {
            ajaxGetDataEducation();
            return false;
        });
    });
</script>
<script type="text/javascript">
    
    //START OF AJAX FUNCTION CALL:   Capacity Building 
    function ajaxGetDataEducation(){
        var year = document.getElementById("educationYear").value;
        var village = document.getElementById("villageList").value;
        console.log("Village List", village);
        console.log("Village year", year);
        $.ajax({
            url: '<?php echo Url::to(["site/education-data"]); ?>',
            type: 'post',
            data: {
//                month:month,
                year:year,
                village:village,
                _csrf: '<?=Yii::$app->request->getCsrfToken()?>'
                
            },
            beforeSend: function () {
                ajaxIndicatorStart("Please wait...", '<?php echo Url::to("@web/images/loading.gif") ?>');
            },
            complete: function () {
                ajaxIndicatorStop();
            },
            success: function (data) {
                  console.log("Education  Data",data);
                  educationLineChart(data);
//                lineChart();
            },
            error: function (jsonResponse) {
                console.log(jsonResponse);
            }
        });
    }
   // END OF AJAX FUNCTION CALL:  Capacity Building 
 
</script>

<script type="text/javascript">

    $("document").ready(function () {
        ajaxEducationReport();
    });
</script> 

<script type="text/javascript">
    //Start: Capacity Building Report ... 
    function ajaxEducationReport() {
        $.ajax({
            url: '<?php echo Url::to(["site/education-report"]); ?>',
            type: 'get',
            data: {
            },
            success: function (data) {
                $('#get_education_report').html(createTable(data));
            },
            error: function (jsonResponse) {
                console.log("Eroor:",jsonResponse);
            }
        });
    }
    
    function createTable(data)
    {
       var table = "<thead>";
       table += "<th>SL No.</th>";
       table += "<th>Month</th>";
       table += "<th>Year</th>";
       table += "<th>Village</th>";
       table += "<th>Name</th>";
       table += "<th>Boys Count</th>";
       table += "<th>Girls Count</th>";
       table += "<th>Total</th>";
       table += "</thead>";
       table += "<tbody>";
       var totalTopicCount = 0;
       var totalBenfSum = 0;
       var totalExposureTopicCount = 0;
       for(var i = 0; i < data.length; i++){
           totalTopicCount++;
           totalBenfSum = totalBenfSum + data[i].beneficiary;
           totalExposureTopicCount = totalExposureTopicCount + data[i].exposureTopicCount;
           table += "<tr>";
           table += "<td>"+data[i].SlNo+"</td>";
           table += "<td>"+data[i].monthName+"</td>";
           table += "<td>"+data[i].yearName+"</td>";
           table += "<td>"+data[i].village_id+"</td>";
           table += "<td>"+data[i].name+"</td>";
           table += "<td>"+data[i].boys_count+"</td>";
           table += "<td>"+data[i].girls_count+"</td>";
           table += "<td>"+data[i].total+"</td>";
           table += "</tr>";
       }
//       table += "<tr><td style='border-right: 1px solid white;'>Total</td><td style='border-right: 1px solid white;'></td><td><b></b></td>";
//       table += "<td><b>"+totalTopicCount+"</b></td>";
//       table += "<td><b>"+totalExposureTopicCount+"</b></td>";
//       table += "<td><b>"+totalBenfSum+"</b></td>";
//       table += "</tr>";
       table += "</tbody>";
       return table;
    }
    //End: Capacity Building Report ... 
    
</script>
 <!-- Code for CSV Download -->
 <script>
    $("#education").click(function(){
        var name = "Education";
        $("#get_education_report").tableToCSV(name);
    });
 </script>