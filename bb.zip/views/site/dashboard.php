<?php
use \yii\helpers\Url;
?>
<style type="text/css">
    .bsBtnGraph{
        font-weight: bold;
        font-size: 20px;
        text-shadow: 0px 2px 2px #2B1A1C;
    }
    .parent{
        display: inline-block;
        vertical-align: top;
        margin-right: 20px;
    }
    .child{
        height: 150px;width: 200px;
        display:table-cell;
        vertical-align:bottom;
    }

    .blc{
        
        height: 200px;width: 200px;  
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat !important;
        display: inline-block;
    }
    .blcAhref{
        font-weight: bold;
        font-size: 20px;
        text-shadow: 0px 2px 2px #2B1A1C;
        color: white;
        display: inline-block;
        position: relative;
        margin-top: 155px;
        /*bottom: 0 !important;*/
        width: 100%;
        text-align: center;
        transition: background-color 1s;
        /*        background-color: deeppink;
             background-image: linear-gradient( white,  rgba(255, 0, 0, 0.4));*/
        /* Fallback for web browsers that doesn't support RGBa */
        background: rgb(0, 0, 0);
        /* RGBa with 0.6 opacity */
        background: rgba(0, 0, 0, 0.4)
    }
    /*    #mainC:hover  .blcAhref{
            color: white;
            text-decoration: none;
            background: rgb(0, 0, 0);
            background: rgba(0, 0, 0, 0.6)
        }*/
    .likn{
        display: inline-block;  
        transition: background-color 1s;
        /*border: 1px solid #EFF0F1;*/
        background-color: #f8f9f9;
         border-radius: 80%;
    }
    .likn:hover{
        /*background: rgb(0, 0, 0);*/
        background: rgba(0, 0, 0, 0.15);
    }
    
     #map{
        height: 560px;
        width: 100%;
       }
    /* #container:hover #cube { background-color: yellow; }*/
    
    a:hover {
        color: green;
    }
    .modal-body {
    max-height: calc(100vh - 210px);
    overflow-y: auto;
     
}
</style>

<?php
    $query = new \yii\db\Query;
    $query->select([
                'village.village as villageName',
                'block.block as blockName',
                'village.village_type as villageType',
                'village.latitude as latitude',
                'village.longitude as longitude'
                ])
            ->from('village')
            ->innerJoin('block', 'block.id=village.block_id')
            ->where(['village.village_type' => 'Intervention']);
    $command = $query->createCommand();
    $respIntervention = $command->queryAll();
//    display_array($respIntervention);exit;
    
?>

<?php
    $query = new \yii\db\Query;
    $query->select([
                'village.village as villageName',
                'block.block as blockName',
                'village.village_type as villageType',
                'village.latitude as latitude',
                'village.longitude as longitude'
                ])
            ->from('village')
            ->innerJoin('block', 'block.id=village.block_id')
            ->where(['village.village_type'=> 'Non intervention']);
    $command = $query->createCommand();
    $respNonIntervention = $command->queryAll();
//    display_array($respNonIntervention);exit;
?>

<?php
    $query = new \yii\db\Query;
    $query->select([
                'village.village',
                'block.block as blockName'
                ])
            ->from('village')
            ->innerJoin('block', 'block.id=village.block_id')
            ->where(["village.village_type"=>'intervention']);
    $command = $query->createCommand();
    $interventionVillResponse = $command->queryAll();
?>

<?php
    $query = new \yii\db\Query;
    $query->select([
                'village.village',
                'block.block as blockName'
                ])
            ->from('village')
            ->innerJoin('block', 'block.id=village.block_id')
            ->where(["village_type"=>'non intervention']);
    $command = $query->createCommand();
    $nonInterventionVillResponse = $command->queryAll();
?>

<?php
    $query = new \yii\db\Query;
    $query->select([
                'block'
                ])
            ->from('block');
    $command = $query->createCommand();
    $blockList = $command->queryAll();
?>
<?php
    $query = new \yii\db\Query;
    $query->select([
                'district'
                ])
            ->from('district');
    $command = $query->createCommand();
    $districtList = $command->queryAll();
?>
<!--nnv-->
<?php
    $query = new \yii\db\Query;
    $query->select([
                    'CONCAT(beneficiary.beneficiary_name,"-",village.village_type) as beneficiaryList'
                ])
            ->from('beneficiary')
            ->innerJoin('village', 'beneficiary.village_id=village.id');
    $command = $query->createCommand();
    $beneficiayWithIntervention = $command->queryAll();
?>

<div class="container-fluid">
    <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6">
                <!--  graph container-->
                <div id="map"></div> 
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6">
                <!--  graph container-->
                <table id="get_program_coverage_report" class="table table-bordered table-responsive" style="margin-bottom:100px;">
                </table>
                    <div class="col-lg-6 col-md-6 col-sm-6" style="padding-left:50px; ">
                        <a href="<?php echo Url::to(["/site/operation-level-dash"]) ?>" class="likn">
                            <div  class="blc" style="background: url(<?php echo Url::to("@web/images/icons/old.png"); ?>); ">
                                <div class="blcAhref">Operation Level Dashboard</div>
                            </div>
                        </a>
                    </div>            
                    <div class="col-lg-6 col-md-6 col-sm-6" style="padding-left:50px">
                        <a href="<?php echo Url::to(["/site/management-level-dash"]) ?>" class="likn">
                            <div class="blc" style="background: url(<?php echo Url::to("@web/images/icons/mld2.png"); ?>);">
                                <div class="blcAhref">Management Level Dashboard</div>
                            </div>
                        </a>
                    </div> 
                </div>
            </div>
            
        </div>

    
<!--Start Of: Modal for Intervention Village List-->
<div class="modal fade" id="intervention">
  <div class="modal-dialog" >
    <div class="modal-content">
      <div class="modal-header" style='background-color:#81c784; color:white'>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" >Intervention Village List</h4>
      </div>
      <div class="modal-body" >
        <table id="ag_table" class="table table-sm table-hover table-condensed table-responsive table-bordered">
                      
                    <thead>
                        <th>Serial No</th>
                        <th>Village Name</th>
                        <th>Block Name</th>
                    </thead> 
                    <tbody>
                        <tr>
                            <?php   
                                $count = 0;
                                foreach ($interventionVillResponse as $key => $value) { 
                                    $count ++;
                            ?>
                                        
                                        <tr>
                                        <td><?= $count ?></td>
                                        <td><?php print_r($value['village']);?></td>    
                                        <td><?php print_r($value['blockName']);?></td>
                                        </tr>
                            <?php } ?>
                        </tr>
                    </tbody>
                </table>
      </div>
      <div class="modal-footer" style='background-color:#81c784; color:white'>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!--End Of: Modal for Intervention Village List-->

<!--Start Of: Modal for Non Intervention Village List-->
<div class="modal fade" id="nonIntervention">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style='background-color:#81c784; color:white'>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" >Non Intervention Village List</h4>
      </div>
      <div class="modal-body" style="overflow:auto;">
        <table id="ag_table" class="table table-sm table-hover table-condensed table-responsive table-bordered">
                    
                    <thead>
                        <th>Serial No</th>
                        <th>Village Name</th>
                        <th>Block Name</th>
                    </thead>
                    <tbody>
                        <tr>
                            <?php 
                                    $count = 0;
                                    foreach ($nonInterventionVillResponse as $key => $value) { $count++; ?>
                                        <tr>
                                        <td><?= $count;?></td>
                                        <td><?php print_r($value['village']);?></td>  
                                        <td><?php print_r($value['blockName']);?></td>
                                        </tr>
                            <?php } ?>
                        </tr>
                      </tbody>
                </table>
      </div>
      <div class="modal-footer" style='background-color:#81c784; color:white'>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!--End Of: Modal for Non Intervention Village List-->

<!--Start Of: Modal for Beneficiary with intervention-->
<div class="modal fade" id="BenefWithIntervention">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style='background-color:#81c784; color:white'>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" >Beneficiary With Intervention</h4>
      </div>
      <div class="modal-body" style="overflow:auto;">
        <table id="ag_table" class="table table-sm table-hover table-condensed table-responsive table-bordered">
                    <thead>
                         <th>Serial No</th>
                        <th>Beneficiary With Intervention </th>
                    </thead>  
                    <tbody>
                        <tr>
                            <?php 
                                    $count = 0;
                                    foreach ($beneficiayWithIntervention as $key => $value) {  $count++;?>
                                        <tr>
                                        <td><?= $count;?></td>    
                                        <td><?php print_r($value['beneficiaryList']);?></td>
                                        </tr>
                            <?php } ?>
                        </tr>
                      </tbody>
                </table>
      </div>
      <div class="modal-footer" style='background-color:#81c784; color:white'>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!--End Of: Modal for Beneficiary with intervention -->





<!--Start Of: Modal for Block List-->
<div class="modal fade" id="block">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style='background-color:#81c784; color:white'>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" >Block List</h4>
      </div>
      <div class="modal-body" style="overflow:auto;">
        <table id="ag_table" class="table table-sm table-hover table-condensed table-responsive table-bordered">
                    <thead>
                        <th>Block Name</th>
                    </thead>  
                    <tbody>
                        <tr>
                            <?php 
                                    foreach ($blockList as $key => $value) { ?>
                                        <tr>
                                        <td><?php print_r($value['block']);?></td>
                                        </tr>
                            <?php } ?>
                        </tr>
                      </tbody>
                </table>
      </div>
      <div class="modal-footer" style='background-color:#81c784; color:white'>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!--End Of: Modal for Block List-->

<!--Start Of: Modal for District List-->
<div class="modal fade" id="district">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style='background-color:#81c784; color:white'>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" >District List</h4>
      </div>
      <div class="modal-body" style="overflow:auto;">
        <table id="ag_table" class="table table-sm table-hover table-condensed table-responsive table-bordered">
                    <thead>
                        <th>District Name</th>
                    </thead>  
                    <tbody>
                        <tr>
                            <?php 
                                    foreach ($districtList as $key => $value) { ?>
                                        <tr>
                                        <td><?php print_r($value['district']);?></td>
                                        </tr>
                            <?php } ?>
                        </tr>
                      </tbody>
                </table>
      </div>
      <div class="modal-footer" style='background-color:#81c784; color:white'>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!--End Of: Modal for District List-->
<script>
         function initMap() {
         
          var myLatLng = {lat: <?php echo ($respIntervention[0]['latitude'] != "") ? $respIntervention[0]['latitude'] : "0"; ?>, lng: <?php echo ($respIntervention[0]['longitude'] != "") ? $respIntervention[0]['longitude'] : "0"; ?>};
          var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 8,
            center :myLatLng
          });

        <?php for ($i = 0; $i < count($respIntervention); $i++) { ?>
               
                 var myLatLng<?php echo $i ?> = {lat: <?php echo ($respIntervention[$i]['latitude'] != "") ? $respIntervention[$i]['latitude'] : "0"; ?>, lng: <?php echo ($respIntervention[$i]['longitude'] != "") ? $respIntervention[$i]['longitude'] : "0"; ?>};
                 var marker<?php echo $i ?> = new google.maps.Marker({
                  icon: 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
                  position: myLatLng<?php echo $i ?>,
                  map: map,
//                  icon: icon,
                  title: 'Village Name:  <?php echo $respIntervention[$i]['villageName'] ?> <br><br> Block Name: <?php echo $respIntervention[$i]['blockName'] ?>'
                  
                });

                var contentString<?php echo $i ?> ='<table class="table table-bordered">'+ 

                       '<thead >'+
                       '<h4>'+ '<span style="color:#1b5e20;">Village Name:</span> <?php echo $respIntervention[$i]['villageName'] ?> <br><br>Village Type:</span> <?php echo $respIntervention[$i]['villageType'] ?> <br><br><span style="color:#1b5e20;"> Block Name:</span> <?php echo $respIntervention[$i]['blockName'] ?>'+'<h4>'+'<tr>'+

                       '</tr>'+
                       '</thead>'+'</table>';


                 var infowindow<?php echo $i ?> = new google.maps.InfoWindow({
                  content: contentString<?php echo $i ?>
                });

                marker<?php echo $i ?>.addListener('mouseover', function() {
                    infowindow<?php echo $i ?>.open(map, this);
                });
                marker<?php echo $i ?>.addListener('mouseout', function() {
                    infowindow<?php echo $i ?>.close();
                });
        <?php } ?>
        
         <?php for ($i = 0; $i < count($respNonIntervention); $i++) { ?>
               
                 var NmyLatLng<?php echo $i ?> = {lat: <?php echo ($respNonIntervention[$i]['latitude'] != "") ? $respNonIntervention[$i]['latitude'] : "0"; ?>, lng: <?php echo ($respNonIntervention[$i]['longitude'] != "") ? $respNonIntervention[$i]['longitude'] : "0"; ?>};
                 var Nmarker<?php echo $i ?> = new google.maps.Marker({
                  icon: 'http://maps.google.com/mapfiles/ms/icons/red-dot.png',
                  position: NmyLatLng<?php echo $i ?>,
                  map: map,
//                  icon: icon,
                  title: 'Village Name:  <?php echo $respNonIntervention[$i]['villageName'] ?> <br><br> Block Name: <?php echo $respNonIntervention[$i]['blockName'] ?>'
                  
                });

                var NcontentString<?php echo $i ?> ='<table class="table table-bordered">'+ 

                       '<thead >'+
                       '<h4>'+ '<span style="color:#1b5e20;">Village Name:</span> <?php echo $respNonIntervention[$i]['villageName'] ?> <br><br>Village Type:</span> <?php echo $respNonIntervention[$i]['villageType'] ?> <br><br><span style="color:#1b5e20;"> Block Name:</span> <?php echo $respNonIntervention[$i]['blockName'] ?>'+'<h4>'+'<tr>'+

                       '</tr>'+
                       '</thead>'+'</table>';


                 var Ninfowindow<?php echo $i ?> = new google.maps.InfoWindow({
                  content: NcontentString<?php echo $i ?>
                });

                Nmarker<?php echo $i ?>.addListener('mouseover', function() {
                    Ninfowindow<?php echo $i ?>.open(map, this);
                });
                Nmarker<?php echo $i ?>.addListener('mouseout', function() {
                    Ninfowindow<?php echo $i ?>.close();
                });
        <?php } ?>
        
        

  }
</script>



<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDJvysCzncAjSo4qPqG0M02NqB8ZXl2VM4&callback=initMap"></script>
<script type="text/javascript">
    $("document").ready(function (){
        ajaxProgramCoverageReport();//Report table will load on page load
        $("#get_program_coverage_report").click(function (){
            ajaxProgramCoverageReport();
            return false;
        });
    });
</script>
<script>
//Start OF: Ajax Function for REPORT
    //Start OF REPORT FUNCTION FOR:  Program Coverage 
    function ajaxProgramCoverageReport(){
        $.ajax({
            url: '<?php echo Url::to(["site/program-coverage-report"]); ?>',
            type: 'get',
            data: {
            },
            beforeSend: function () {
//                ajaxIndicatorStart("Please wait...", '<?php // echo Url::to("@web/images/loading.gif") ?>');
            },
            complete: function () {
               // ajaxIndicatorStop();
            },
            success: function (data) {
                var interven=data.intervention;
                var nonInterven=data.nonIntervention;
                var block=data.block;
                var district=data.districtName;
                var benefWithIntervention=data.benefWithIntervention;
                console.log(interven,nonInterven,block,district,benefWithIntervention);
                //console.log("Program Coverage report",data);
                $('#get_program_coverage_report').html(createManagementLevelTable(interven,nonInterven,block,district,benefWithIntervention));
            },
            error: function () {
                alert("Something went wrong in Program Coverage  Report.");
            }
        });
    }
    
    function createManagementLevelTable(a,b,c,d,e)
    {
       //var modal="<button type='button' class='btn btn-primary btn-lg' data-toggle='modal' data-target='#myModal'> Launch demo modal</button>"; 
        
       var table = "<thead style='background-color:#87cefa; color:white'>";
       table += "<th>Description</th>";
       table += "<th>Count</th>";
       table += "</thead>";
       table += "<tbody>";

       table += "<tr>";
       table +='<div class="container">';
       table += '<td><a onclick="interventionVillageList()" style="cursor:pointer;">Project Intervention Villages</td>';
       table += "<td>"+a.intervention+"</td>";
       table += "</tr>";
//        
//       table += "<tr>";
//       table +='<div class="container">';
//       table += '<td><a onclick="interventionBeneficiaryList()" style="cursor:pointer;">Beneficiary With Intervention </td>';
//       table += "<td>"+e.benefWithIntervention+"</td>";
//       table += "</tr>";
       
//       Modal Testin Code
       //var modal="<div class='modal fade' id='myModal' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'> </div>";

       table += "<tr>";
       table += "<td><a onclick='nonInterventionVillageList()' style='cursor:pointer;'>Project Non Intervention Villages</a></td>";
       table += "<td>"+b.nonIntervention+"</td>";
       table += "</tr>";
        
       table += "<tr>";
       table += "<td><a onclick='blockList()' style='cursor:pointer;'>Blocks List</a></td>";
       table += "<td>"+c.block+"</td>";
       table += "</tr>";
       
       table += "<tr>";
       table += "<td><a onclick='districtList()' style='cursor:pointer;'>District</a></td>";
       table += "<td>"+d.district+"</td>";
       table += "</tr>";
       
       table += "<tr>";
       table += "<td>State</td>";
       table += "<td>Rajasthan</td>";
       table += "</tr>";
       
       table += "</tbody>";
       return table;         
    }
    
    //End OF REPORT FUNCTION FOR: Program Coverage
    
 //END OF: Ajax Function for REPORT
    
</script>

<script type="text/javascript">
    function interventionVillageList(){
        $("#intervention").modal("show");
    }
    
    function nonInterventionVillageList(){
         $("#nonIntervention").modal("show");
    }
    function interventionBeneficiaryList(){
        $("#BenefWithIntervention").modal("show");
    }
    function blockList(){
         $("#block").modal("show");
    }
        function districtList(){
         $("#district").modal("show");
    }
</script>