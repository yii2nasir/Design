<?php

use yii\helpers\Url;

?>
<style>
    .panel {
        padding: 0px !important;
        border: none;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        /*box-shadow: 10px 10px 5px grey*/ 
    }

    #reportBreadcrumb li a{
        cursor: pointer;
    }
    .bsDisplayInlineBlock{
        display: inline-block;
    }
</style> 
<script src="<?php echo Url::to("@web/mjs/sehgal_dashboard_graph.js?v=".  rand(1, 1000)); ?>"></script>
<script src="<?php echo Url::to("@web/mjs/jquery.tabletoCSV.js?v=".  rand(1, 1000)); ?>"></script>
<script src="<?php echo Url::to("@web/graph-lib/highcharts.js"); ?>"></script>
<script src="<?php echo Url::to("@web/graph-lib/drilldown.js"); ?>"></script>
<script src="<?php echo Url::to("@web/graph-lib/exporting.js"); ?>"></script>
<script src="<?php echo Url::to("@web/graph-lib/data-graph.js"); ?>"></script>
<style type="text/css">
    .tabs-left {
        border-bottom: none;
        padding-top: 2px;
        border-right: 1px solid #ddd;
    }
    .tabs-left>li{
        float: none;
        margin-bottom: 2px;
        margin-right: -1px;
    }
    .tabs-left>li.active>a,
    .tabs-left>li.active>a:hover,
    .tabs-left>li.active>a:focus {
        border-bottom-color: #ddd;
        border-right-color: transparent;
    }
    .tabs-left>li>a {
        border-radius: 4px 0 0 4px;
        margin-right: 0;
        display:block;
    }
    .tab-pane .highcharts-container{
        margin: 0 auto;
    }
</style>

<div class="site-index">
    <div class="body-content">
        <div class="panel panel-default" style="margin-bottom: 15px;">
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-1"><a  onclick="window.history.go(-1);" class="btn btn-warning btn-sm" >Back</a></div>
                    <div class="col-lg-10">
                        <h3 class="text-center" style="margin-top: 0px;margin-bottom: 0px;"><b>Targets</b></h3>
                    </div>
                    <div class="col-lg-1"></div>
                </div>
            </div>			
        </div>

        <div class="panel panel-default" style="margin-bottom: 15px;">
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12">
                        <!-- START OF: Main Tab START Graph/Report -->
                        <ul class="nav nav-tabs nav-justified">
                            <li class="active"><a data-toggle="tab" href="#management_level_graph"><b>Graphs</b></a></li>
                            <li><a data-toggle="tab" href="#management_level_reports"><b>Reports</b></a></li>
                        </ul>
                        <!-- ENDs OF: Main Tab START Graph/Report -->
                        
                        <!--START OF: GRAPH/REPORT DIV SECTION--> 
                        <div class="tab-content">
                            <div id="management_level_graph" class="tab-pane fade in active bsPaddingTop15px">
                                <!-- START OF: Management Level Dashboard Graphs Content -->
                                <div class="row">
                                    <!-- START OF: Name list of graph menu Section-->
                                        <div class="col-md-3">
                                            <ul class="nav nav-tabs tabs-left">
                                                <li><a href="#tab_target_activity_wise" data-toggle="tab" onclick="ajaxGetDataTargetActivityWise();"><span class="glyphicon glyphicon-info-sign" onclick="showHelp('')"></span> Target vs Achievement (Activity wise)</a></li>
                                                <li><a href="#tab_target_beneficiary_wise" data-toggle="tab" onclick="ajaxGetDataTargetBeneficiaryWise();"><span class="glyphicon glyphicon-info-sign" onclick="showHelp('')"></span> Target vs Achievement (Beneficiary wise)</a></li>
                                                <li><a href="#tab_overall_program_gender_distribution" data-toggle="tab" onclick="ajaxGetDataOverallProgramGenderDistribution();"><span class="glyphicon glyphicon-info-sign" onclick="showHelp('')"></span> Program wise gender distribution</a></li>
                                                <li><a href="#tab_program_wise_gender_distribution" data-toggle="tab" onclick="ajaxGetDataProgramWiseGenderDistribution();"><span class="glyphicon glyphicon-info-sign" onclick="showHelp('')"></span> Overall program gender distribution</a></li>
                                            </ul>
                                        </div>
                                    <!-- END OF: Name list of graph menu Section-->

                                    <!-- START OF: Graph Highchart Section-->
                                        <div class="col-md-9">
                                            <!-- Tab panes -->
                                            <div class="tab-content">
                                                
                                                <!-- START OF: Data Target Activity Wise -->
                                                <div class="tab-pane fade in active" id="tab_target_activity_wise">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="bsGraphColborderRight bsPaddingTop15px" id="target_activity_wise"></div>            
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- END OF: Target Activity Wise -->
                                                
                                                
                                                <!-- START OF: Data Solar Irrigation Area -->
                                                <div class="tab-pane fade" id="tab_target_beneficiary_wise">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="bsGraphColborderRight bsPaddingTop15px" id="target_beneficiary_wise"></div>            
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- END OF: Data Solar Irrigation Area -->
                                                
                                                <!-- START OF: overall_program_gender_distribution -->
                                                <div class="tab-pane fade" id="tab_overall_program_gender_distribution">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="bsGraphColborderRight bsPaddingTop15px" id="overall_program_gender_distribution"></div>            
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- END OF: overall_program_gender_distribution -->
                                                
                                                <!-- START OF: program_wise_gender_distribution -->
                                                <div class="tab-pane fade" id="tab_program_wise_gender_distribution">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="bsGraphColborderRight bsPaddingTop15px" id="program_gender_distribution"></div>            
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- END OF: program_wise_gender_distribution -->
                                                
                                            </div>
                                        </div>
                                     <!-- END OF: Graph Highchart Section DIV-->    
                                </div>
                                <!-- END OF: Management Level Dashboard Graphs Content DIV-->
                            </div>
                            
                            <!--START OF: Management Level Dashboard reports content-->
                                <div id="management_level_reports" class="tab-pane fade bsPaddingTop15px">
                                    <div id="management_level_container">
                                        <div class="row">
                                                <div class="col-md-3">
                                                    <ul class="nav nav-tabs tabs-left">
                                                        <li class="active"><a href="#report_geographical_gender_distribution" data-toggle="tab" onclick="ajaxGetDataGeographicalgenderdistribution();">Geographical gender distribution</a></li>
                                                    </ul>
                                                </div>
                                            <div class="col-md-9">
                                                <div class="row">
                                                   <div class="collapsible-body" style="background: #FFFFFF">
                                                    <div class="row">
                                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                            <div class="form-group" style="margin: 10px 0px;">
                                                                <div class="row">
                                                                    <div class="col-md-3 col-lg-3 col-sm-4 col-xs-4" id="submitDashboard">
                                                                        <!--<input type="button" value="Search" onclick="finalDashboard()" id="btn_fnf"  class="btn btn-primary"/>-->
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="clearfix"></div>
                                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                                <div id="dashboard" style="padding: 3px;"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--END OF: Agriculture_reports content-->
                            </div>
                        <!--END OF: GRAPH/REPORT DIV SECTION-->
                    </div>
                </div>

            </div>			
        </div>

    </div>     
</div>

<script type="text/javascript">
    $("document").ready(function (){
        ajaxGetDataGeographicalgenderdistribution();//Report table will load on page load
        $("#report_geographical_gender_distribution").click(function () {
            ajaxGetDataGeographicalgenderdistribution();
            return false;
        });
    });
</script>
<script>
    function ajaxGetDataGeographicalgenderdistribution()
    {   
    $.ajax({
        url:'<?php echo Url::to(["site/geographical-gender-distribution-project-level"]); ?>',
        type: 'GET',
        beforeSend: function () {
//                        ajaxIndicatorStart("Please wait...", '<?php echo Url::to("@web/images/loading.gif") ?>');
        },
        complete: function () {
//                        ajaxIndicatorStop();
        },
        success: function (jsonResponse) {
              var maleCount= jsonResponse.male;
              var femaleCount= jsonResponse.female;
              console.log("amcd",maleCount);
              var othersCount= jsonResponse.others;
              var total = maleCount + femaleCount + othersCount;
              //console.log("Data",tableData);
              var tableString = "";
              tableString+='<nav class="breadcrumb" style="cursor:pointer"> <a class="breadcrumb-item" style="color:gray"><span style="cursor:pointer">Project</span>/</a></nav>';                                                                                 
              tableString+='<table class="table table-bordered">';
              tableString+='<tr><th></th><th>Male</th><th>Female</th><th>Data Not Filled</th><th>Male + Female</th></tr>';
              tableString+='<tr>';
              tableString+='<td onclick="getDistrictTableData()"><a><span style="cursor:pointer">Project<span></a></td>'; 
              
              tableString+='<td>';
              tableString+=maleCount;
              tableString+='</td>';
              
              tableString+='<td>';
              tableString+=femaleCount;
              tableString+='</td>';
              
              tableString+='<td>';
              tableString+=othersCount;
              tableString+='</td>';
              
              tableString+='<td>';
              tableString+=total;
              tableString+='</td>';
              
              tableString+='</tr>';
              tableString+='</table>';
              document.getElementById("dashboard").innerHTML = tableString;
        },
        error: function (error) {
                console.log(" Error:",error);
            }
    });
    } 
    
 function getDistrictTableData()
    {   
    $.ajax({
        url:'<?php echo Url::to(["site/geographical-gender-distribution-district-level"]); ?>',
        type: 'GET',
        beforeSend: function () {
//                        ajaxIndicatorStart("Please wait...", '<?php echo Url::to("@web/images/loading.gif") ?>');
        },
        complete: function () {
//                        ajaxIndicatorStop();
        },
        success: function (jsonResponse) {
             var districtTableData= jsonResponse.data;
             var maleTotalCount = 0;
              var femaleTotalCount = 0;
              var maleFemaleTotalCount =0;
              var othersTotalCount= 0;
              //console.log("Data",tableData);
              var tableString = "";
              tableString+='<nav class="breadcrumb" style="cursor:pointer"> <a class="breadcrumb-item" onclick="ajaxGetDataGeographicalgenderdistribution()">Project/ </a> <a class="breadcrumb-item" style="cursor:pointer" onclick="getDistrictTableData()" style="color:gray"><span style="cursor:pointer">District</span>/</a> </nav>';  
              tableString+='<table class="table table-bordered">';
              tableString+='<tr><th></th><th>Male</th><th>Female</th><th>Data Not Filled</th><th>Male + Female</th></tr>';
             
             for(i=0;i<districtTableData.length;i++){
                tableDataList = districtTableData[i];
                
                 district_id=tableDataList['district_id'];
                district=tableDataList['district'];
                male = tableDataList['male'];
                female = tableDataList['female'];
                others = tableDataList['others'];
                total = tableDataList['total']; 
                maleTotalCount += male;
                femaleTotalCount += female;
                othersTotalCount += others;
                maleFemaleTotalCount += total;
             
              tableString+='<tr>';

              tableString+='<td>';
              tableString+='<a style="cursor:pointer" onclick="getBlockTableData('+district_id+')">'+district+'</a>';
//              tableString+='<a style="cursor:pointer">'+district+'</a>';
              tableString+='</td>';

              tableString+='<td>';
              tableString+=male;
              tableString+='</td>';
              
              tableString+='<td>';
              tableString+=female;
              tableString+='</td>';
              
              tableString+='<td>';
              tableString+=others;
              tableString+='</td>';
              
              tableString+='<td>';
              tableString+=total;
              tableString+='</td>';
              
              tableString+='</tr>';
          }
                tableString+='</tr>';
              
              tableString+='<tr style="background-color:#dcedc8; font-weight: bold;">';
                tableString+='<td>Total</td>';
                tableString+='<td>'+maleTotalCount+'</td>';
                tableString+='<td>'+femaleTotalCount+'</td>';
                tableString+='<td>'+othersTotalCount+'</td>';
                tableString+='<td>'+maleFemaleTotalCount+'</td>';
              tableString+='</tr>';
              
              tableString+='</table>';
              document.getElementById("dashboard").innerHTML = tableString;
        },
        error: function (error) {
                console.log(" Error:",error);
            }
    });
    } 
    
    function getBlockTableData(district_id)
    {   
      console.log("District_id",district_id);
      $.ajax({
        url:'<?php echo Url::to(["site/geographical-gender-distribution-block-level"]); ?>'+"?district_id="+district_id,
        type: 'GET',
        beforeSend: function () {
//                        ajaxIndicatorStart("Please wait...", '<?php echo Url::to("@web/images/loading.gif") ?>');
        },
        complete: function () {
//                        ajaxIndicatorStop();
        },
        success: function (jsonResponse) {
              var blockTableData= jsonResponse.data;
              console.log("anup",blockTableData)
              var maleTotalCount = 0;
              var femaleTotalCount = 0;
              var maleFemaleTotalCount =0;
              var othersTotalCount= 0;
              var tableString = "";
//              console.log("prince",blockTableData.lenght);
              tableString+='<nav class="breadcrumb" style="cursor:pointer"> <a class="breadcrumb-item" style="cursor:pointer" onclick="ajaxGetDataGeographicalgenderdistribution()">Project/</a> <a class="breadcrumb-item" style="cursor:pointer" onclick="getDistrictTableData()">District/</a> <a class="breadcrumb-item" style="cursor:pointer" style="color:gray"><span style="cursor:pointer">Block</span></a> </nav>';
              tableString+='<table class="table table-bordered">';
              tableString+='<tr><th></th><th>Male</th><th>Female</th><th>Data Not Filled</th><th>Male + Female</th></tr>';
              
              for(i=0;i<blockTableData.length;i++){
                tableDataList = blockTableData[i];
                block_id=tableDataList['block_id'];
                block=tableDataList['block'];
                male = tableDataList['male'];
                female = tableDataList['female'];
                others = tableDataList['others'];
                total = tableDataList['total']; 
                maleTotalCount += male;
                femaleTotalCount += female;
                othersTotalCount += others;
                maleFemaleTotalCount += total;
                
              
                tableString+='<tr>';
                
                tableString+='<td>';
                tableString+='<a style="cursor:pointer" onclick="getVillageTableData('+block_id+')">'+block+'</a>';
                tableString+='</td>';

                tableString+='<td>';
                tableString+=male;
                tableString+='</td>';

                tableString+='<td>';
                tableString+=female;
                tableString+='</td>';
                
                tableString+='<td>';
                tableString+=others;
                tableString+='</td>';
                
                tableString+='<td>';
                tableString+=total;
                tableString+='</td>';
                
                tableString+='</tr>';
                

              } 
              tableString+='</tr>';
              
              tableString+='<tr style="background-color:#dcedc8; font-weight: bold;">';
                tableString+='<td>Total</td>';
                tableString+='<td>'+maleTotalCount+'</td>';
                tableString+='<td>'+femaleTotalCount+'</td>';
                tableString+='<td>'+othersTotalCount+'</td>';
                tableString+='<td>'+maleFemaleTotalCount+'</td>';
              tableString+='</tr>';
              
              tableString+='</table>';
              document.getElementById("dashboard").innerHTML = tableString;
        },
        error: function (error) {
                console.log(" utilities controllerUtilities fpoTableData",error);
            }
    });
 } 
 
 function getVillageTableData(block_id)
    {   
      console.log("block_id",block_id);
      $.ajax({
        url:'<?php echo Url::to(["site/geographical-gender-distribution-village-level"]); ?>'+"?block_id="+block_id,
        type: 'GET',
        beforeSend: function () {
//                        ajaxIndicatorStart("Please wait...", '<?php echo Url::to("@web/images/loading.gif") ?>');
        },
        complete: function () {
//                        ajaxIndicatorStop();
        },
        success: function (jsonResponse) {
              var blockTableData= jsonResponse.data;
              var maleTotalCount = 0;
              var femaleTotalCount = 0;
              var maleFemaleTotalCount =0;
              var othersTotalCount= 0;
              var tableString = "";
//              console.log("prince",blockTableData.lenght);
              tableString+='<nav class="breadcrumb" style="cursor:pointer"> <a class="breadcrumb-item" style="cursor:pointer" onclick="ajaxGetDataGeographicalgenderdistribution()">Project/</a> <a class="breadcrumb-item" style="cursor:pointer" onclick="getDistrictTableData()">District/</a> <a class="breadcrumb-item" style="cursor:pointer" onclick="getBlockTableData()" style="color:gray"><span style="cursor:pointer">Block</span></a> </nav>';
              tableString+='<table class="table table-bordered">';
              tableString+='<tr><th></th><th>Male</th><th>Female</th><th>Data Not Filled</th><th>Male + Female</th></tr>';
              
              
              for(i=0;i<blockTableData.length;i++){
                tableDataList = blockTableData[i];
                village_id=tableDataList['village_id'];
                village=tableDataList['village'];
                male = tableDataList['male'];
                female = tableDataList['female']; 
                others = tableDataList['others'];
                total = tableDataList['total'];
                maleTotalCount += male;
                femaleTotalCount += female;
                othersTotalCount += others;
                maleFemaleTotalCount += total;
              
                tableString+='<tr>';
                
                tableString+='<td>';
                tableString+=village;
                tableString+='</td>';

                tableString+='<td>';
                tableString+=male;
                tableString+='</td>';

                tableString+='<td>';
                tableString+=female;
                tableString+='</td>';
                
                tableString+='<td>';
                tableString+=others;
                tableString+='</td>';
                
                tableString+='<td>';
                tableString+=total;
                tableString+='</td>';
                
                tableString+='</tr>';
                

              } 
              tableString+='</tr>';
              tableString+='<tr style="background-color:#dcedc8; font-weight: bold;">';
                tableString+='<td>Total</td>';
                tableString+='<td>'+maleTotalCount+'</td>';
                tableString+='<td>'+femaleTotalCount+'</td>';
                tableString+='<td>'+othersTotalCount+'</td>';
                tableString+='<td>'+maleFemaleTotalCount+'</td>';
              tableString+='</tr>';
              tableString+='</table>';
              document.getElementById("dashboard").innerHTML = tableString;
        },
        error: function (error) {
                console.log(" utilities controllerUtilities fpoTableData",error);
            }
    });
 } 
    
    

</script>
<script type="text/javascript">
    $("document").ready(function (){
        ajaxGetDataTargetActivityWise();//Report table will load on page load
        $("#get_target_activity_wise").click(function () {
            ajaxGetDataTargetActivityWise();
            return false;
        });
    });
</script>
<script type="text/javascript">
    
    // START OF AJAX FUNCTION CALL:   Data Target Activity Wise
    function ajaxGetDataTargetActivityWise()
    {
        $.ajax({
            url: '<?php echo Url::to(["site/target-activity-wise-data"]); ?>',
            type: 'post',
            data: {
               // activityName : activity_Name,
                //_csrf: '<?=Yii::$app->request->getCsrfToken()?>'
            },
            beforeSend: function () {
                //ajaxIndicatorStart("Please wait...", '<?php //echo Url::to("@web/images/loading.gif") ?>');
            },
            complete: function () {
               // ajaxIndicatorStop();
            },
            success: function (data) {
                console.log("Target Activity Wise  Data",data);
                var achieved = data.achieved;
                var tmArr = [
                        achieved.at,
                        achieved.c_dem, 
                        achieved.stacking,
                        achieved.mulching,
                        achieved.exposure
                    ]
                    
                targetActivityWiseLineChart(data.activity_name,data.target_value,tmArr);
                console.log(tmArr);
            },
            error: function (jsonResponse) {
                console.log(jsonResponse);
            }
        });
    }
    // END OF AJAX FUNCTION CALL:   Data Target Activity Wise
    
    // START OF AJAX FUNCTION CALL:   Data Target Beneficiary Wise
    function ajaxGetDataTargetBeneficiaryWise()
    {
        $.ajax({
            url: '<?php echo Url::to(["site/target-beneficiary-wise-data"]); ?>',
            type: 'post',
            data: {
                //_csrf: '<?=Yii::$app->request->getCsrfToken()?>'
            },
            beforeSend: function () {
                //ajaxIndicatorStart("Please wait...", '<?php //echo Url::to("@web/images/loading.gif") ?>');
            },
            complete: function () {
               // ajaxIndicatorStop();
            },
            success: function (data) {
                console.log("Target Beneficiary Wise  Data",data);
                var achieved = data.achieved;
                var tmArr = [
                        achieved.at,
                        achieved.c_dem, 
                        achieved.stacking,
                        achieved.mulching,
                        achieved.exposure
                    ]
                targetBeneficiaryWiseLineChart(data.activity_name,data.target_value,tmArr)
            },
            error: function (jsonResponse) {
                console.log(jsonResponse);
            }
        });
    }
    //  END OF AJAX FUNCTION CALL:   Data Target Beneficiary Wise
    
    //  START OF AJAX FUNCTION CALL:   Overall program gender distribution
    function ajaxGetDataOverallProgramGenderDistribution()
    {
        $.ajax({
            url: '<?php echo Url::to(["site/overall-program-gender-distribution"]); ?>',
            type: 'get',
            data: {
//                _csrf: '<?=Yii::$app->request->getCsrfToken()?>'
            },
            beforeSend: function () {
                //ajaxIndicatorStart("Please wait...", '<?php //echo Url::to("@web/images/loading.gif") ?>');
            },
            complete: function () {
               // ajaxIndicatorStop();
            },
            success: function (data) {
                console.log("Overall program gender distribution",data);
                var male = data.male;
                console.log("Count of Male",male);
                var tmArr = [
                        male.at,  male.c_dem, 
                        male.stacking,  male.mulching,
                        male.cb  
                    ]
                    
                var female = data.female;
                console.log("Count of Female",female);
                var tmArr2 = [
                        female.at,   female.c_dem, 
                        female.stacking,  female.mulching,
                        female.cb
                    ]    
                dataOverallProgramGenderDistribution(data.activity_name,tmArr,tmArr2)
            },        
            error: function (jsonResponse) {
                console.log(jsonResponse);
            }
        });
    }
    //  END OF AJAX FUNCTION CALL:   Overall program gender distribution
    
     //  START OF AJAX FUNCTION CALL:   Program Wise Gender Distribution
    function ajaxGetDataProgramWiseGenderDistribution()
    {
       $.ajax({
            url: '<?php echo Url::to(["site/program-wise-gender-distribution"]); ?>',
            type: 'get',
            data: {

//                _csrf: '<?=Yii::$app->request->getCsrfToken()?>'
            },
            beforeSend: function () {
                //ajaxIndicatorStart("Please wait...", '<?php //echo Url::to("@web/images/loading.gif") ?>');
            },
            complete: function () {
               // ajaxIndicatorStop();
            },
            success: function (data) {
                 console.log("Count of Male",data.male);
                 console.log("Count of Female",data.female);
                 dataProgramWiseGenderDistribution(data.male,data.female);
            },
            error: function (jsonResponse) {
                console.log(jsonResponse);
            }
        });
    }
    //  END OF AJAX FUNCTION CALL:   Program Wise Gender Distribution
</script>





