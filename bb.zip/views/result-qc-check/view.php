<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\ResultQcCheck */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Result Qc Checks', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="result-qc-check-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'unique_id',
            'qc_check_id',
            'qc_parameter_id',
            'value',
            'status',
            'latitude',
            'logtitude',
            'entry_type',
            'created_at',
            'updated_at',
        ],
    ]) ?>

</div>
