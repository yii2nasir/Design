


$(function(){
    
    $('#modalButton').click(function(){
//        alert("sdffdsf");
        $('#modal').model('show').find('#modalContent').load($(this).attr('value'));
    });
});
