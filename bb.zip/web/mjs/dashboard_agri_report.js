/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function Projectwise() {
        $('#financialYearHP').show();
        $("#financialYearHProject").attr("disabled", false);
        $('#selectVillageHide').hide();
        var financial_year = $("#financialYearHProject").val();
        $.get("<?php echo Url::to(["site-report/nutrition-project"]); ?>", {financial_year: financial_year}, function (data, status) {
            $('#report').html(data);

        });
    }
    function Villagewise() {
        $("#financialYearHProject").attr("disabled", true);
        var financial_year = $("#financialYearHProject").val();
        $.get("<?php echo Url::to(["site-report/nutrition-village"]); ?>", {financial_year: financial_year}, function (data, status) {
            $('#report').html(data);
            $('#project').DataTable();
        });
    }
