function graphAgriLandOwnership(year, owned, leasedIn, leasedOut) {
    $('#land_ownership').highcharts({
        chart: {
            type: 'column'
        },
        title: {
            text: '<span style="font-weight:bold;">Land ownership across years</span>'
        },
        xAxis: {
            categories: year,
            crosshair: true,
            title: {
                text: 'Financial year'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Land Ownership across years (in acres)'
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                    '<td style="padding:0"><b>{point.y:.1f} acres</b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
        },
        plotOptions: {
            column: {
                pointPadding: 0.1,
                borderWidth: 0
            }
        },
        series: [{
                name: 'Owned',
                data: owned
            }, {
                name: 'Land Leased In',
                data: leasedIn
            }, {
                name: 'Land Leased Out',
                data: leasedOut
            }],
        credits: {
            enabled: false
        }
    });
}

function graphAgriLandUtilization(year, conventional, organic, punjab) {
    $('#land_utilization').highcharts({
        chart: {
            type: 'column'
        },
        title: {
            text: '<span style="font-weight:bold;">Punjab – 2020 land distribution</span>'
        },
        xAxis: {
            categories: year,
            crosshair: true,
            title: {
                text: 'Financial year'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Land Utilization across years (in acres)'
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                    '<td style="padding:0"><b>{point.y:.1f} acres</b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
        },
        plotOptions: {
            column: {
                pointPadding: 0.1,
                borderWidth: 0
            }
        },
        series: [{
                color: "#0D3C55",  
                name: 'conventional',
                data: conventional

            }, {
                color: "#117899",
                name: 'Organic-Other',
                data: organic

            }, {
                color: "#5CA793",
                name: 'Punjab-2020',
                data: punjab

            }],
        credits: {
            enabled: false
        }
    });
}

function graphCropProductionProfitability(conventional, organic, punjab) {
    $('#profitability_analysis').highcharts({
        chart: {
            type: 'column'
        },
        title: {
            text: '<span style="font-weight:bold;">Profitability analysis</span>'
        },
        xAxis: {
            categories: [
                'Agri Input Cost per acre',
                'Agri Revenue per acre',
                'Profitability per acre'
            ],
            crosshair: true,
        },
        yAxis: {
            title: {
                text: 'Cost (in rupees)'
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                    '<td style="padding:0"><b>{point.y:.1f} rupees</b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
        },
        plotOptions: {
            column: {
                pointPadding: 0.1,
                borderWidth: 0
            }
        },
        series: [{
                name: 'Conventional',
                data: conventional

            }, {
                name: 'Organic-Other',
                data: organic

            }, {
                name: 'Punjab-2020',
                data: punjab

            }],
        credits: {
            enabled: false
        }
    });
}

function graphAgriculturePracticeDistribution(practiceDetails, drilldownArray) {
    $('#get_agriculture_distribution').highcharts({
        colors: ['#0D3C55', '#5CA793', '#A2B86C',
        '#EBC844', '#EF8B2C', '#D94E1F','#6CA4C8','#BFAB52','#AA291A','#318E88','#29D2A5','#DB9047','#819356'],
        chart: {
            type: 'pie'
        },
        title: {
            text: '<span style="font-weight:bold;">Punjab-2020 crop distribution</span>'
        },
        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    format: '{point.name} {point.percentage:.1f}%'
                }
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> acres<br/>'
        },
        series: [{
                name: 'Agriculture Practice',
                colorByPoint: true,
                data: practiceDetails
            }],
        drilldown: {
            series: drilldownArray
        },
        credits: {
            enabled: false
        }
    });
}
function graphAgriculturePracticeDistributionGraph(agriPractice, other,drilldown) {
    
    console.log('---**--**--');
    console.log(drilldown);
    
    $('#pnjab_2020_agriinput').highcharts({
        colors: ['#0D3C55', '#5CA793', '#A2B86C',
        '#EBC844', '#EF8B2C', '#D94E1F','#6CA4C8','#BFAB52','#AA291A','#318E88','#29D2A5','#DB9047','#819356'],
        chart: {
            type: 'pie'
        },
        title: {
            text: '<span style="font-weight:bold;">Punjab-2020 crop distribution</span>'
        },
        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    format: '{point.name} {point.percentage:.1f}%'
                }
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> acres<br/>'
        },
        series: [{
                name: 'Agriculture Practice',
                colorByPoint: true,
                data: agriPractice.data,
            }],
        drilldown: {
            series: drilldown.graph.series,
        },
        credits: {
            enabled: false
        }
    });
}

function graphAgriInputConventionalDistribution(label, machinaryDrilldown) {
    $('#agri_input_conventional_distribution').highcharts({
         colors: ['#0D3C55', '#117899', '#5CA793', '#A2B86C',
        '#EBC844', '#EF8B2C', '#D94E1F','#6CA4C8','#BFAB52','#AA291A','#318E88','#29D2A5','#DB9047','#819356'],
        chart: {
            type: 'pie'
        },
        title: {
            text: '<span style="font-weight:bold;">Comparative Graph-1</span>'
        },
        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    format: '{point.name} {point.percentage:.1f}%'
                }
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> rupees<br/>'
        },
        series: [{
                name: 'Agri Inputs',
                colorByPoint: true,
                data: label
            }],
        drilldown: {
            series: [{
                    name: 'Machinery',
                    id: 'Machinery',
                    data: machinaryDrilldown
                }]
        },
        credits: {
            enabled: false
        }
    });
}

function graphAgriInputPunjab2020Distribution(label, machinaryDrilldown) {
    $('#agri_input_punjab2020_distribution').highcharts({
        colors: ['#0D3C55', '#117899', '#5CA793', '#A2B86C',
        '#EBC844', '#EF8B2C', '#D94E1F','#6CA4C8','#BFAB52','#AA291A','#318E88','#29D2A5','#DB9047','#819356'],
        chart: {
            type: 'pie'
        },
        title: {
            text: '<span style="font-weight:bold;">Comparative Graph-2</span>'
        },
        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    format: '{point.name} {point.percentage:.1f}%'
                }
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> rupees<br/>'
        },
        series: [{
                name: 'Agri Inputs',
                colorByPoint: true,
                data: label
            }],
        drilldown: {
            series: [{
                    name: 'Machinery',
                    id: 'Machinery',
                    data: machinaryDrilldown
                }]
        },
        credits: {
            enabled: false
        }
    });
}


function graphCattleDistributionAtProjectLevel(CattleTypeArray, drilldownArray) {

    $('#cattle_distribution_at_project_level').highcharts({
        colors: ['#5CA793', '#A2B86C',
        '#EBC844', '#EF8B2C', '#D94E1F','#6CA4C8','#BFAB52','#AA291A','#318E88','#29D2A5','#DB9047','#819356'],
        chart: {
            type: 'pie'
        },
        title: {
            text: '<span style="font-weight:bold;">Cattle distribution</span>'
        },
        /*subtitle: {
         text: 'Click the slices to view versions. Source: netmarketshare.com.'
         },*/
        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    format: '{point.name} {point.percentage:.0f}%'
                }
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.0f}</b><br/>'
        },
        series: [{
                name: 'Cattle distribution',
                colorByPoint: true,
                data: CattleTypeArray,
            }],
        drilldown: {
            drillUpButton: {
                relativeTo: 'spacingBox',
                position: {
                    y: 0,
                    x: 0
                },
                /*
                 theme: {
                 fill: 'white',
                 'stroke-width': 1,
                 stroke: 'silver',
                 r: 0,
                 states: {
                 hover: {
                 fill: '#bada55'
                 },
                 select: {
                 stroke: '#039',
                 fill: '#bada55'
                 }
                 }
                 }
                 */
            },
            series: drilldownArray
        },
        credits: {
            enabled: false
        }
    });
}



    
    
   function graphDairyExpensePerHousehold(Response) {
//   console.log("Response",Response);
    $('#dairy_expense_per_household').highcharts({
        colors: ['#5CA793', '#A2B86C',
        '#EBC844', '#EF8B2C', '#D94E1F','#6CA4C8','#BFAB52','#AA291A','#318E88','#29D2A5','#DB9047','#819356'],
        title: {
            text: 'Punjab-2020 average cattle expenditure',
            x: -20 //center
        },
//        subtitle: {
//            text: 'Source: WorldClimate.com',
//            x: -20
//        },
        xAxis: {
            categories: Response.years
        },
        yAxis: {
            title: {
                text: 'Amount (rupees)'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: ' rupees'
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle',
            borderWidth: 0
        },
        credits: {
            enabled: false
        },
        series: Response.expenses
    });
}

  



function graphMilkingDataAtProjectLevel(paramString, cattleCount,paramStringCattleCount) {

console.log(paramString);
console.log(paramStringCattleCount);

$('#milking_data_at_project_level').highcharts({
        credits: {
            enabled: false
        },
        chart: {
            zoomType: 'xy'
        },
        title: {
            text: 'Punjab-2020 cattle-wise milking production'
        },
        subtitle: {
            text: ''
        },
        xAxis: [{
            categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            crosshair: true
        }],
        yAxis: [{ // Primary yAxis
            labels: {
                format: '{value}lt',
                style: {
                    color: Highcharts.getOptions().colors[1]
                }
            },
            title: {
                text: 'Milk quantity (in litres)',
                style: {
                    color: Highcharts.getOptions().colors[1]
                }
            }
        }, { // Secondary yAxis
            title: {
                text: 'Milching Cattle',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            labels: {
                format: '{value}',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            opposite: true
        }],
        tooltip: {
            shared: true
        },
        legend: {
            layout: 'horizontal',
//            align: 'bottom',
//            x: 120,
            verticalAlign: 'bottom',
//            y: 100,
            floating: false,
            backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
        },
        series: [{
            name: 'Milk quantity (in litres)',
            type: 'column',
            yAxis: 1,
            data: paramString,
            tooltip: {
                valueSuffix: ' lt'
            }

        }, {
            name: 'Milching Cattle',
            type: 'spline',
            data: paramStringCattleCount,
            tooltip: {
                valueSuffix: ''
            }
        }]
    });
    
//    $('#milking_data_at_project_level').highcharts({
//        colors: ['#5CA793', '#A2B86C',
//        '#EBC844', '#EF8B2C', '#D94E1F','#6CA4C8','#BFAB52','#AA291A','#318E88','#29D2A5','#DB9047','#819356'],
//        title: {
//            text: '<text style="color:#333333;font-size:18px;fill:#333333;width:520px;"><tspan style="font-weight:bold;">Cattle-wise milking production</tspan></text>',
//            x: -20 //center
//        },
//        subtitle: {
////            text: 'Total cattle count : ' + cattleCount + '',
//            text: '',
//            x: -2
//        },
//        xAxis: {
//            categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
//                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
//        },
//        yAxis: 
//                [{ // Primary yAxis
//            labels: {
//                format: '{value}°C',
//                style: {
//                    color: Highcharts.getOptions().colors[1]
//                }
//            },
//            title: {
//                text: 'Temperature',
//                style: {
//                    color: Highcharts.getOptions().colors[1]
//                }
//            }
//        }, { // Secondary yAxis
//            title: {
//                text: 'Rainfall',
//                style: {
//                    color: Highcharts.getOptions().colors[0]
//                }
//            },
//            labels: {
//                format: '{value} mm',
//                style: {
//                    color: Highcharts.getOptions().colors[0]
//                }
//            },
//            opposite: true
//        }],
////                [{
////            title: {
////                text: 'Milk quantity (in litres)'
////            },
////            plotLines: [{
////                    value: 0,
////                    width: 1,
////                    color: '#808080'
////                }]
////        },{ // Secondary yAxis
////            title: {
////                text: 'Rainfall',
////                style: {
////                    color: Highcharts.getOptions().colors[0]
////                }
////            },
////            labels: {
////                format: '{value} mm',
////                style: {
////                    color: Highcharts.getOptions().colors[0]
////                }
////            },
////            opposite: true
////        }],
//        tooltip: {
//            valueSuffix: ' litres'
//        },
//        legend: {
//            layout: 'vertical',
//            align: 'right',
//            verticalAlign: 'middle',
//            borderWidth: 0
//        },
//        series: [
//            {
//                name: 'Cattle Count',
//                type: 'column',
//                data: paramStringCattleCount,
//                tooltip: {
//                    valueSuffix: '°C'
//                }
//            },
//            {
//                name: 'Milking quantity',
//                type: 'spline',
//                data: paramString
//            }],
//        credits: {
//            enabled: false
//        }
//    });
}



//function graphMilkingDataAtProjectLevel(paramString, cattleCount) {
//
//    $('#milking_data_at_project_level').highcharts({
//        colors: ['#5CA793', '#A2B86C',
//        '#EBC844', '#EF8B2C', '#D94E1F','#6CA4C8','#BFAB52','#AA291A','#318E88','#29D2A5','#DB9047','#819356'],
//        title: {
//            text: '<text style="color:#333333;font-size:18px;fill:#333333;width:520px;"><tspan style="font-weight:bold;">Cattle-wise milking production</tspan></text>',
//            x: -20 //center
//        },
//        subtitle: {
////            text: 'Total cattle count : ' + cattleCount + '',
//            text: '',
//            x: -2
//        },
//        xAxis: {
//            categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
//                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
//        },
//        yAxis: {
//            title: {
//                text: 'Milk quantity (in litres)'
//            },
//            plotLines: [{
//                    value: 0,
//                    width: 1,
//                    color: '#808080'
//                }]
//        },
//        tooltip: {
//            valueSuffix: ' litres'
//        },
//        legend: {
//            layout: 'vertical',
//            align: 'right',
//            verticalAlign: 'middle',
//            borderWidth: 0
//        },
//        series: [{
//                name: 'Milking quantity',
//                data: paramString
//            }],
//        credits: {
//            enabled: false
//        }
//    });
//}
function graphCattleWiseMilkingProduction(paramString, cattleCount) {
//console.log(paramString);
    $('#cattle_wise_milking_product').highcharts({
        colors: ['#5CA793', '#A2B86C',
        '#EBC844', '#EF8B2C', '#D94E1F','#6CA4C8','#BFAB52','#AA291A','#318E88','#29D2A5','#DB9047','#819356'],
    
        title: {
            text: '<text style="color:#333333;font-size:18px;fill:#333333;width:520px;"><tspan style="font-weight:bold;">Punjab-2020 cattle-productivity</tspan></text>',
            x: -20 //center
        },
        subtitle: {
//            text: 'Total cattle count : ' + cattleCount + '',
            text: '',
            x: -2
        },
        xAxis: {
            categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        },
        yAxis: {
            title: {
                text: 'Milk quantity (in litres)'
            },
            plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
        },
        tooltip: {
            valueSuffix: ' litres'
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle',
            borderWidth: 0
        },
        series: [{
                name: 'Milking average',
                data: paramString
            }],
        credits: {
            enabled: false
        }
    });
}


function graphCropProductionAcrossGraph(yearString, ConventionalKey, OrganicOtherKey, Punjab2020Key, FarmerCountArray) {

    $('#crop_production_across_graph').highcharts({
        credits: {
            enabled: false
        },
        chart: {
            zoomType: 'xy'
        },
        title: {
            text: 'Punjab-2020 crop production'
        },
        subtitle: {
            text: ''
        },
        xAxis: [{
            categories: yearString,
//                        ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
//                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            crosshair: true
        }],
        yAxis: [
            { // Secondary yAxis
                title: {
                    text: 'Production (in Quintal)',
                    style: {
                        color: Highcharts.getOptions().colors[1]
                    }
                },
                labels: {
                    format: '{value} Quintal',
                    style: {
                        color: Highcharts.getOptions().colors[1]
                    }
                },
                opposite: true
            },
            { // Primary yAxis
                labels: {
                    format: '{value}',
                    style: {
                        color: Highcharts.getOptions().colors[0]
                    }
                },
                title: {
                    text: 'Champion Farmer Count',
                    style: {
                        color: Highcharts.getOptions().colors[0]
                    }
                }
            }
        ],
        tooltip: {
            shared: true
        },
        legend: {
            layout: 'horizontal',
//            align: 'bottom',
//            x: 120,
            verticalAlign: 'bottom',
//            y: 100,
            floating: false,
            
//            //changehear
//            layout: 'horizontal',
//            align: 'left',
////            x: 120,
//            verticalAlign: 'bottom',
//            y: 100,
//            floating: false,
            backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
        },
        series: [{
            name: 'Champion Farmer Count',
            type: 'column',
            yAxis: 1,
            data: FarmerCountArray,
//                    [49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4],
            tooltip: {
                valueSuffix: ''
            }

        }, {
            name: 'Conventional',
            type: 'spline',
            color:"#894317",
            data: ConventionalKey,
            tooltip: {
                valueSuffix: ' Quintal'
            }
        }, {
            name: 'OrganicOther',
            type: 'spline',
            color: "#1b1789",
            data: OrganicOtherKey,
            tooltip: {
                valueSuffix: ' Quintal'
            }
        }, {
            name: 'Punjab 2020',
            type: 'spline',
            color : "#891776",
            data: Punjab2020Key,
            tooltip: {
                valueSuffix: ' Quintal'
            }
        }]
    });
}

//function graphCropProductionAcrossGraph(yearString, ConventionalKey, OrganicOtherKey, Punjab2020Key) {
//
//    $('#crop_production_across_graph').highcharts({
//        colors: ['#0D3C55', '#5CA793', '#A2B86C',
//        '#EBC844', '#EF8B2C', '#D94E1F','#6CA4C8','#BFAB52','#AA291A','#318E88','#29D2A5','#DB9047','#819356'],
//        title: {
//            text: '<span style="font-weight:bold;">Punjab-2020 crop production</span>',
//            x: -20 //center
//        },
//        xAxis: {
//            categories: yearString
//        },
//        yAxis: {
//            title: {
//                text: 'Production (in Quintal)'
//            },
//            plotLines: [{
//                    value: 0,
//                    width: 1,
//                    color: '#808080'
//                }]
//        },
//        tooltip: {
//            valueSuffix: ' Quintal'
//        },
//        legend: {
//            layout: 'vertical',
//            align: 'right',
//            verticalAlign: 'middle',
//            borderWidth: 0
//        },
//        series: [{
//                name: 'Conventional',
//                data: ConventionalKey
//            }, {
//                name: 'OrganicOther',
//                data: OrganicOtherKey
//            }, {
//                name: 'Punjab 2020',
//                data: Punjab2020Key
//            }],
//        credits: {
//            enabled: false
//        }
//    });
//}

/// suresh  
function graphAIsuccessDataRatioAnalysisdata(failure,success) {
//    console.log(failure);
//    var successArray = [];
//    for (var key in failure.data) {
//        successArray.push([key,parseInt(success.data[key])]);
//        //console.log(successArray);
//    }
    var failureArray = [];
    for (var key in failure.reason) {
        failureArray.push([key,parseInt(failure.reason[key])]);
//          console.log(failureArray);
    }
     $('#ai_success_ratio_analysis_graph_ai').highcharts({
         colors: ['#5CA793', '#A2B86C',
        '#EBC844', '#EF8B2C', '#D94E1F','#6CA4C8','#BFAB52','#AA291A','#318E88','#29D2A5','#DB9047','#819356'],
        chart: {
            type: 'pie'
        },
        title: {
            text: '<span style="font-weight:bold;">AI success ratio analysis</span>'
        },
        /*subtitle: {
         text: 'Click the slices to view versions. Source: netmarketshare.com.'
         },*/
        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    format: '{point.name} {point.percentage:.0f}%'
                }
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.0f}</b><br/>'
        },
        series: [{
                name: 'AI',
                colorByPoint: true,
                data: [
                    {
                        name : "success",
                        y : parseInt(success.count),
//                        drilldown : "success"
                    },
                    {
                        name : "failure",
                        y : parseInt(failure.count),
                        drilldown : "failure"
                    }
                ]
            }],
        drilldown: {
            
            series: [
                {
                name: 'failure',
                id: 'failure',
                data: failureArray
                }
            ]
        },
        credits: {
            enabled: false
        }
    });
}

function graphGetKitchenGardenAcrossYears(year,area){
//    console.log(year);
//    console.log(area);
    
           $('#kitchen_garden_across_year_project_level').highcharts({
          colors: ['#0D3C55','#5CA793', '#A2B86C',
        '#EBC844', '#EF8B2C', '#D94E1F','#6CA4C8','#BFAB52','#AA291A','#318E88','#29D2A5','#DB9047','#819356'],
            chart: {
                type: 'column'
            },
            title: {
                text: '<span style="font-weight:bold;">Area under kitchen garden</span>'
            },
            xAxis: {
                categories: [year],
                crosshair: true,
                title: {
                    text: 'Financial year'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Land Area(in mt sq)'
                }
            },
            tooltip: {
                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                        '<td style="padding:0"><b>{point.y:.1f} mt sq</b></td></tr>',
                footerFormat: '</table>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    pointPadding: 0.1,
                    borderWidth: 0
                }
            },
            series: [{
                    name: 'Area per household',
                    data: [parseFloat(area)]
                }],
            credits: {
                enabled: false
            }
        });
    
}



function showHelp(graph){
    $("#defaultModal #modal-body").html(getHelpText()[graph]);
    $('#defaultModal').modal();
    event.stopPropagation();
    event.stopImmediatePropagation(); 
    event.preventDefault();
}
function getHelpText(){
//    helpTexts = array();
    helpTexts = {};
   
    helpTexts['agri-1'] = "Graph shows data of land acreage utilized for crop cultivation in a particular crop type. You can view data for specific villages and champion farmer through the filters provided.";
    helpTexts['agri-2'] = "Graph shows data of the investment done in a particular year in crop cultivation. It lets you compare the input done in various categories for a specific crop, crop practice (convention, organic-other and Punjab-2020) till farmer level.";
    helpTexts['agri-3'] = " Graph shows data of land acreage utilized by champion farmers for a specific practice (convention, organic-others, Punjab-2020) in a particular year. You can view data for specific villages and champion farmer through the filters provided.";
    helpTexts['agri-4'] = " Graph shows data of average land utilized by the champion farmers for kitchen gardening. You can view data for specific villages and champion farmer through the filters provided.";
    helpTexts['agri-5'] = "Graph shows data of crop produced by champion farmers through various crop practices (convention, organic-others, Punjab-2020). The columns showcases champion farmers’ counts that have done the cultivation. You can view data for specific village, champion farmer and crop through the filters provided.";


    helpTexts['dairy-1'] = "Graph shows data for the cattle count in project Punjab-2020. This is a drill-down graph that provides cattle count breed-wise on the click of the specific cattle (cow and buffalo). You can view data for specific village, champion farmer and cattle type, i.e. born or purchased through the filters provided in a particular year.";
    helpTexts['dairy-2'] = "Graph shows data of the dairy related expenditures done by champion farmers. You can view the data for specific village and champion farmer through the filters provided.";
    helpTexts['dairy-3'] = "Graph shows monthly data of milk produced by cattle of champion farmers that are linked with Punjab-2020. The line showcases cattle counts that have yielded milk in particular year while the columns give the quantity of milk obtained from those cattle. You can view data for specific village, champion farmer and the cattle through the filters provided in a particular year.";
    helpTexts['dairy-4'] = "Graph shows monthly data of milking productivity by cattle of champion farmers that are linked with Punjab-2020. You can view data for specific village, champion farmer and the cattle through the filters provided in a particular year.";
    helpTexts['dairy-5'] = "Graph shows data of artificial insemination done on the cattle of champion and non-champion farmers in Punjab- 2020 project. It is a drill-down graph where on the click of failure it provides you the count of cattle having the insemination failed for the particular reasons. You can view data for specific AI service provider, cattle (cow and buffalo), and cattle breed.";
    return helpTexts;
}
