/*
 * Start: Commodities Primary Market Comparison
 */
    function CommoditiesPrimaryMarketComparison(dataPrice){ //data
      $(function () {
        Highcharts.chart('commoditiesPrimaryMarketComparison', {

            title: {
                text: 'City wise Price Trend'
            },
            credits: {
                enabled: false
            },
            subtitle: {
                text: ''
            },

            yAxis: {
                title: {
                    text: 'Commodity Price'
                }
            },
            xAxis: {
                categories: dataPrice.date
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle'
            },

            plotOptions: {
                line: {
                    dataLabels: {
                        enabled: true
                    },
                    enableMouseTracking: true
                }
            },

            series:dataPrice.series,

            responsive: {
                rules: [{
                    condition: {
                        maxWidth: 500
                    },
                    chartOptions: {
                        legend: {
                            layout: 'horizontal',
                            align: 'center',
                            verticalAlign: 'bottom'
                        }
                    }
                }]
            }

        });
    });
  }

  function averagePrimaryMarket(dataPrice){
    Highcharts.chart('commoditiesPrimaryMarketAverage', {
        credits: {
            enabled: false
        },
        chart: {
            type: 'column'
        },
        title: {
            text: 'City wise F&V Price Comparison'
        },
        subtitle: {
            text: ''
        },
        xAxis: {
            categories: dataPrice.categories,
            crosshair: true
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Commodity Price'
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.1f}</b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series:  dataPrice.series
    });
}


/*
 * End : ... 
 */

