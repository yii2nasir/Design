//common TinyMSCE for all crud where Text area is using
tinymce.init({
  selector: 'textarea',
  height: 500,
  menubar: false,
  plugins: [
    'advlist autolink lists link image charmap print preview anchor',
    'searchreplace visualblocks code fullscreen',
    'insertdatetime media table contextmenu paste code'
  ],
  toolbar: 'undo redo | bullist numlist',
  content_css: '//www.tinymce.com/css/codepen.min.css',
});