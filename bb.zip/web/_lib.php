<?php

class MyCommand{
    protected $db;
    protected $active_group = 'local';
    protected $link;
    function __construct(){
       // $this->db['local'] = array(
       }

       public function get($query){
        $com=new MyCommand;
        $connection = Yii::$app->getDb();
        $command = $connection->createCommand($query);
        $res=$command->execute();
        $res=$command->queryAll();
       // return $com->get($query);
        return $res;
        //return $this->result($this->query($query));
    }


}
class Libxx extends MyCommand {
    public $SID;
   function __construct($sid=null){
       parent::__construct();
       $this->SID=$sid;
   }  
   function email(){
       $q='SELECT `email` FROM `user` WHERE `username`="'.$this->SID.'"';
       return $this->get($q)[0]['email'];
   }

   function all_reports(){
        
   }
}
class Lib extends MyCommand{
    public $SID;
    protected $env='devlopmentx';
    protected $limit;
   function __construct($sid=null){
       parent::__construct();
       $this->SID=$sid;
       if($this->env=='devlopment'){
        $this->limit=' limit 0,2';
       }else{
        $this->limit='';
       }
   } 
    function check123($query){
        $com=new MyCommand;
        $connection = Yii::$app->getDb();
        $command = $connection->createCommand($query);
        $res=$command->execute();
        $res=$command->queryAll();
       // return $com->get($query);
        return $res;
    }

    function UserName($id){
        return $this->get('SELECT `name` FROM `users` WHERE `id`='.$id)[0]['name'];
    }

    function rpc_name($rpc_id){
        return $this->get('SELECT `rpc_name` FROM `rpc_centre` WHERE `id`= '.$rpc_id)[0]['rpc_name'];
    }
    function product_name($product_id){
        return $this->get('SELECT `name` FROM `product` WHERE `id`='.$product_id)[0]['name'];
    }
function allreq($id){
    return $this->get('SELECT * FROM `new_request` where unique_id="'.$id.'"');
}
    function newrequest($rpc){
        //echo 'SELECT * FROM `new_request`'.$rpc.$this->limit;exit;
       // return $this->get('SELECT * FROM `new_request`');

        return $this->get('SELECT * FROM `new_request`'.$rpc.$this->limit);
    }
    function incomequalitycheck($uniq_id){
        return $this->get('SELECT * FROM `incoming_qc_check` WHERE `unique_id` like "%'.$uniq_id.'%" and  overall_status!="Reject"'.$this->limit);
   
        //SELECT * FROM `incoming_qc_check` WHERE `batch_id` !="" or `overall_status`!="Reject"
    }
    function resultqc($income_check_id){
        return $this->get('SELECT * FROM `result_qc_check` WHERE `qc_check_id` ="'.$income_check_id.'"'.$this->limit);
    }

    function qc_pera($id){
        return $this->get('SELECT * FROM `qc_check_phy_chemical` WHERE `id`='.$id)[0];
    }

function fg_qc_check_mapper($uniq_id){
    return $this->get('SELECT * FROM `fg_qc_check_mapper` WHERE `fg_qc_uniq_id` like "%'.$uniq_id.'%"'.$this->limit);
}

    function fg_qc_check($uniq_id){
        return $this->get('SELECT * FROM `fg_qc_check` WHERE `batch_id` like "%'.$uniq_id.'%"'.$this->limit);
     }
     function fg_qc_result($fg_qc_check_id){
        return $this->get('SELECT * FROM `fg_check_result` WHERE `fg_qc_check_id` ="'.$fg_qc_check_id.'"'.$this->limit);
     }

     function cleaning($uniq_id){
        return $this->get('SELECT * FROM `cleaning` WHERE `id` ="'.$uniq_id.'"'.$this->limit);
     }
function cleaning_mapper($batchid){
    return $this->get('SELECT * FROM `cleaning_mapper` WHERE `batch_id` like "%'.$batchid.'%"'.$this->limit);
     
}
    function fumigation($fumigation_mapper_id){
        return $this->get('SELECT * FROM `fumigation` WHERE `id` ="'.$fumigation_mapper_id.'"'.$this->limit);
    }
    function fumigation_mapper($batch_id){
        return $this->get('SELECT * FROM `fumigation_mapper` WHERE `batch_id` like "%'.$batch_id.'%"'.$this->limit);
    }

    function supplier_name($supplier_id){
        @$return =$this->get('SELECT `name` FROM `supplier` WHERE `unique_id` ="'.$supplier_id.'"')[0]['name'];
        if($return!=''){
            return $return;
        }
    }

    function getfg_batch_num($result){ //use in test
        foreach($result as $v){
            $val[$v['id']]=$v['value'];
        }
        //echo "<pre>";print_r($val);exit;
        foreach($val as $bk=>$bn){
            if(strpos($bn, '-') !== false){
                return trim($bk);
            }
        } return '';
        //print_r($val);
    }

    function getfg_batch_name($bach_id){ 
        return $this->get('SELECT `value` FROM `fg_check_result` WHERE `id`="'.$bach_id.'"')[0]['value'];

    }

    function fg_batch_num($result){
        $val=[];
        foreach($result as $v){
            foreach($v['result'] as $va){
                $val[]=$va['value'];
            }
        }
        foreach($val as $bn){
            //$has_A = strpos($bn, '-') !== false;
            //$return='';
            if(strpos($bn, '-') !== false){
                return trim($bn);
            }
        }
        return '';//$val;
    }
}
?>

<?php
/*
$usr=new CheckAuth($_SESSION['login_info']['username']);
<?= $usr->email() ?>*/
?>
<?php
/*****
 * //echo $r->rpc_name(id=1); get rpc name
 * echo $r->product_name(id=1); product name getter
 * echo $r->supplier_name($id=1); get supplier name
 */

?>