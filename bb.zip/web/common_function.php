<?php

use app\models\UserLevels;
use yii\rest\Controller;
use yii\widgets\ActiveForm;
use yii\helpers\Url;
use app\models\UserLocationMapper;
use app\models\RpcCentre;
use yii\helpers\ArrayHelper;

function hideGetParams() {
    ?>
    <script>
        $(document).ready(function () {
            if (typeof window.history.pushState === 'function') {
                window.history.pushState({}, "Hide", '<?php echo $_SERVER['PHP_SELF']; ?>');
            }
        });
    </script>
    <?php
}

function getDateFormat($date,$format = "Y-m-d") {
   //Convert date format if date format correct, not empty, and not null ...
 if (preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/", $date)) {
     if (!empty($date) && !is_null($date)) {
         $newDateString = date($format, strtotime($date));
         return $newDateString;
     }
 } else {
     if(is_null($date)){
         return NULL;
     } else {
         return "Incorrect Date Format into Database";
     }

 }

}

function redirectWithPage($mthis, $arrayM) {

    if (isset($_SESSION['page']['controller']) &&
        $_SESSION['page']['controller'] == Yii::$app->controller->id &&
        isset($_SESSION['page']['page_number'])) {

        $arrayM['page'] = $_SESSION['page']['page_number'];
}

return $mthis->redirect($arrayM);
}

function pageNumberMapper($dataProvider) {

    $_SESSION['page'] = array();
    $_SESSION['page']['controller'] = Yii::$app->controller->id;
    $_SESSION['page']['action'] = Yii::$app->controller->action->id;
    $_SESSION['page']['page_number'] = $_GET['page'] = isset($_GET['page']) ? $_GET['page'] : '1';
}

function isTesting() {
    return false;
}

function excepPrintVariableGenerator() {

}

function getPositionForAllindiaGraphFromCharacter($column, $culumnNumber) {
    if ($culumnNumber != 0) {
        $position = ($culumnNumber * 8);
        for ($pi = 0; $pi < $position; $pi++) {
            $column++;
        }
    }

    return $column;
}

function hrefPost() {
    ?>

    <?php
//    $action = \yii\helpers\Url::to([$parameters['r']]);
    $action = "index.php";
    ?>

    <?php $form = ActiveForm::begin(['method' => "POST", 'id' => 'sf', 'action' => $action]); ?>
    <?php
    foreach ($parameters as $key => $value) {
        ?>
        <textarea name="<?php echo $key ?>" ><?php echo $value; ?></textarea>
        <?php
    }
    ?>
    <?php ActiveForm::end(); ?>

    <script>
        document.getElementById("sf").submit();
    </script>

    <?php
}

function redirectWithMethod($method = "GET", $parametersAsMethod = [], $parameterInURL = []) {
    ?>
    <div style="background: #000000;">
        <div style="display: none">

            <?php
            $action = \yii\helpers\Url::to($parameterInURL);
            ?>
            <?php $form = ActiveForm::begin(['method' => "POST", 'id' => 'sf', 'action' => $action]); ?>
            <?php
            foreach ($parametersAsMethod as $key => $value) {
                ?>
                <textarea name="<?php echo $key ?>" ><?php echo $value; ?></textarea>
                <?php
            }
            ?>
            <?php ActiveForm::end(); ?>

            <script>
                document.getElementById("sf").submit();
            </script>
        </div>
    </div>
    <?php
}

function showNotification($alert_title, $alert_message) {
    ?>

    <script>
        function pnotify()
        {
            new PNotify({
                title: '<?php echo $alert_title ?>',
                text: '<?php echo $alert_message; ?>',
                type: 'success',
                hide: true
            });

        }
        document.addEventListener('DOMContentLoaded', function () {
            pnotify();
        }, false);

    </script>
    <?php
}

function checkCurrentdateIsBetweenTwoDates($start_date, $end_date) {
    if ($start_date != "" && $end_date != "") {
        $paymentDate = date('Y-m-d');
        $paymentDate = date('Y-m-d', strtotime($paymentDate));
        ;
        //echo $paymentDate; // echos today! 
        $contractDateBegin = date('Y-m-d', strtotime($start_date));
        $contractDateEnd = date('Y-m-d', strtotime($end_date));

        if (($paymentDate > $contractDateBegin) && ($paymentDate < $contractDateEnd)) {
            return true;
        } else {
            return false;
        }
    }
    return false;
}

function checkCurrentdateIsGreaterSomeDate($end_date) {
    if ($end_date != "") {
        $paymentDate = date('Y-m-d');
        $paymentDate = date('Y-m-d', strtotime($paymentDate));
        ;
        //echo $paymentDate; // echos today! 
        $contractDateEnd = date('Y-m-d', strtotime($end_date));

        if (($paymentDate > $contractDateEnd)) {
            return true;
        } else {
            return false;
        }
    }
    return false;
}

function image_crop() {

//	 display_array($_FILES);
//	 exit;
    $valid_exts = array('jpeg', 'jpg', 'png', 'gif');
    $max_file_size = 100 * 1024; #image max size.
    $nw = $nh = 200; # image with # height
    if (!$_FILES['image_name']['error'] && $_FILES['image_name']['size'] < $max_file_size) {
        $ext = strtolower(pathinfo($_FILES['image_name']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, $valid_exts)) {
            $image_act_name = uniqid() . '.' . $ext;
            //echo $path;
            $path = 'uploads/' . $image_act_name;
            $size = getimagesize($_FILES['image_name']['tmp_name']);
            $x = (int) $_POST['x'];
            $y = (int) $_POST['y'];
            $w = (int) $_POST['w'] ? $_POST['w'] : $size[0];
            $h = (int) $_POST['h'] ? $_POST['h'] : $size[1];
            $data = file_get_contents($_FILES['image_name']['tmp_name']);
            $vImg = imagecreatefromstring($data);
            $dstImg = imagecreatetruecolor($nw, $nh);
            imagecopyresampled($dstImg, $vImg, 0, 0, $x, $y, $nw, $nh, $w, $h);
            imagejpeg($dstImg, $path);
            imagedestroy($dstImg);
            return $image_act_name;
            //echo "<img src='$path' />";
        }
    } else {
        echo 'file is too small or large';
//                
//            	 display_array($_FILES);
//            	 exit;
    }
}

function checkCurrentdateIsBeforeSomeDate($start_date) {
    if ($start_date != "") {
        $paymentDate = date('Y-m-d');
        $paymentDate = date('Y-m-d', strtotime($paymentDate));
        ;
        //echo $paymentDate; // echos today! 
        $contractDateBegin = date('Y-m-d', strtotime($start_date));

        if (($paymentDate < $contractDateBegin)) {
            return true;
        } else {
            return false;
        }
    }
    return false;
}

function getCurrentDatePositionFromStartAndEnd($start_date, $end_date) {

    if (checkCurrentdateIsBetweenTwoDates($start_date, $end_date) == true) {
        return "Ongoing";
    } else if (checkCurrentdateIsGreaterSomeDate($end_date) == true) {
        return "Completed";
    } else if (checkCurrentdateIsBeforeSomeDate($start_date) == true) {
        return "Not Started";
    }
}

function fillUserData($model, $column_name) {
    if (!$model->isNewRecord) {
        $pagerAuthenticationModels = app\models\PageAuthentications::find()->where(['level_id' => $model->id])->all();
        $columnValues = yii\helpers\ArrayHelper::getColumn($pagerAuthenticationModels, $column_name);
        return $columnValues;
    }
    return [];
}

function hideFields($model, $fieldsArray) {
    ?>

    <script>
        $(document).ready(function ()
        {

            <?php
//            $fieldsArray =  $model->nsdcFields();

            for ($i = 0; $i < count($fieldsArray); $i++) {
                ?>
                $(".field-<?php echo getCurrentControllerNameForFieldContainer() ?>-<?php echo $fieldsArray[$i] ?>").hide();
                <?php
            }
            ?>



            //        alert("Sdsds");
            //        var fields_containers =  $("div[class*='form-group field']");
            //        
            //        $("div[class*='form-group field']").filter(function(index)
            //        {
            //            alert($(this).);
            //        })

        })
    </script>
    <?php
}

function createUrls($actions, $module) {
    $actionssm = array();

    for ($i = 0; $i < count($actions); $i++) {
        $actionssm[$module . "/" . $actions[$i]] = ucfirst($actions[$i]);
    }

    return $actionssm;
}

function loadModelIfApproving($model) {
    if (isset($_POST['from_approvals']) && $_POST['from_approvals'] == "approvals") {
        $model->load(json_decode($_POST['model_string'], true));
    }
}

function getUndertrainingpeeriod() {
    return "45";
}

function getNotifyTo() {
    $action = Yii::$app->urlManager->parseRequest(Yii::$app->request);

    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }


    if (isset($_SESSION['login_info'])) {
        $loginModel = unserialize(serialize($_SESSION['login_info']));

        $pageAuthentications = app\models\PageAuthentications::find()
        ->where(['level_id' => $loginModel->user_level, 'authentication' => $action[0]])
        ->one();
        if ($pageAuthentications != null) {
            return $pageAuthentications->notify_to;
        }
    }

    return '';
}

function getApproveTo() {


    $action = Yii::$app->urlManager->parseRequest(Yii::$app->request);

    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }


    if (isset($_SESSION['login_info'])) {
        $loginModel = unserialize(serialize($_SESSION['login_info']));

        $pageAuthentications = app\models\PageAuthentications::find()
        ->where(['level_id' => $loginModel->user_level, 'authentication' => $action[0]])
        ->one();
        if ($pageAuthentications != null) {
            return $pageAuthentications->approve_to;
        }
    }

    return '';
}

function isUnderTrainning($model) {
    if (isset($model->graduation_status) && $model->graduation_status != "") {
        $returnwhat = true;
    }
}

function NSDCReadOnly($model, $fieldName, $enrollmentField = false, $trainingComplitionField = false) {
    if (isNSDCorAdmin() == true) {
        $returnwhat = false;
        return false;
    } else if (method_exists($model, 'nsdcFields') && in_array($fieldName, $model->nsdcFields()) && !isNSDC()) {
        $returnwhat = true;
    } else {
        $returnwhat = false;
    }


    if ($enrollmentField == true) {
        if ($model->graduation_status != "") {
            $returnwhat = true;
        }
    }

    if ($trainingComplitionField == true) {
        if ($model->graduation_status == "Graduate") {
            $returnwhat = true;
        }
    }


//    if($fieldName=='salutation')
//    {
//        display_array($returnwhat);
//        exit;
//    }
//    if(in_array($fieldName, $model->nsdcFields()) && isNSDCorAdmin())
//    {
//        $returnwhat = false;
//    }
//    else if(in_array($fieldName, $model->nsdcFields()) && !isNSDCorAdmin())
//    {
//        $returnwhat =  true;
//    }
//    else if(!in_array($fieldName, $model->nsdcFields()) && isNSDCorAdmin())
//    {
//        $returnwhat =  true;
//    }
//    else if(!in_array($fieldName, $model->nsdcFields()) && !isNSDCorAdmin())
//    {
//        $returnwhat =  false;
//    }


    return $returnwhat;
}

function display_array($array) {
    echo "<pre>";
    print_r($array);
    echo "</pre>";
}

function getUserLevel() {
    if (isset($_SESSION['login_info'])) {
        $user_level = $_SESSION['login_info']['level_id'];
        if ($user_level == 0) {
            return '{view} {update}{delete}';
        } elseif ($user_level == 33) {
            return '{view} {update}';
        } elseif ($user_level == 35) {
            return '{view}';
        } else {
            //echo "yes";exit;
            \Yii::$app->response->redirect(Url::to(["users/permission-denied"]));
        }
    }
}

function getLevelTypeArray() {
    $levelTypeArray = array();
    $levelTypeArray[] = 'CM';
    $levelTypeArray[] = 'Center Manager';
    $levelTypeArray[] = 'Partner';
    $levelTypeArray[] = 'Admin';
    return $levelTypeArray;
}

function checkAuthentication($this1) {
    $action = Yii::$app->controller->id . "/" . Yii::$app->controller->action->id;
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    if (isset($_SESSION['login_info'])) {
        $loginModel = unserialize(serialize($_SESSION['login_info']));
        $loginModel = \app\models\Users::find()->where(['id' => $loginModel->id])->one();
        // print_r($loginModel);exit;
        if (!isset($loginModel)) {
            yii\helpers\Url::to('users/login');
        } else {
            $pageAuthentications = app\models\PageAuthentications::find()->where(['level_id' => $loginModel->level_id, 'authentication' => $action])->one();
            if ($pageAuthentications == null) {
                $this1->redirect(['users/permission-denied']);
            }
            if ($loginModel->changed_password_once == "") {
                $this1->redirect(['users/change-password']);
            }
        }
    } else {
        $this1->redirect('index.php?r=users/login&goback=true');
    }
}

function checkAuthenticationPage($page) {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    if (isset($_SESSION['login_info'])) {
        $loginModel = unserialize(serialize($_SESSION['login_info']));
        $pageAuthentications = app\models\PageAuthentications::find()->where(['level_id' => $loginModel->user_level, 'authentication' => $page])->one();
        if ($pageAuthentications != null) {
            return true;
        }
    }

    return false;
}

function findModelName($controller){
  $explode = explode("-", $controller);
  $model = "";  
  foreach ($explode as $value) {
    $model .=ucfirst($value);
}
return $model;
}


function getUserId() {

    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    if (isset($_SESSION['login_info'])) {
        $loginModel = unserialize(serialize($_SESSION['login_info']));
        if ($loginModel) {
            return $loginModel->id;
        }
        return "";
    }
}


function getUserLevelID() {

    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    if (isset($_SESSION['login_info'])) {
        $loginModel = unserialize(serialize($_SESSION['login_info']));
        if ($loginModel) {
            return $loginModel->level_id;
        }
        return "";
    }
}

function yearCode($year){
    switch ($year) {
        case 2011:return "A";break;case 2012:return "B";break;
        case 2013:return "C";break;case 2014:return "D";break;
        case 2015:return "E";break;case 2016:return "F";break;
        case 2017:return "G";break;case 2018:return "H";break;
        case 2019:return "I";break;case 2020:return "J";break;
        case 2021:return "K";break;case 2022:return "L";break;
        case 2023:return "M";break;case 2024:return "N";break;
        case 2025:return "O";break;case 2026:return "P";break;
        case 2027:return "Q";break;case 2028:return "R";break;
        case 2029:return "S";break;case 2030:return "T";break;
    }
}

function getUserRpcCenterId() {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    if (isset($_SESSION['login_info'])) {
        $loginModel = unserialize(serialize($_SESSION['login_info']));
        if ($loginModel) {
             if($loginModel->level_id ==1){
               $RpcCenter =RpcCentre::find()->all();  
                return ArrayHelper::getColumn($RpcCenter, 'id');
             }else{
              $RpcCenter = UserLocationMapper::find()->where(['user_id'=>$loginModel->id])->all();
                return ArrayHelper::getColumn($RpcCenter, 'location_id');
             }
        }
        return "";
    }else{
        echo '<script>window.location="' . \yii\helpers\Url::to(['users/login']) . '";</script>';
                        exit;     
    }
}


?>
