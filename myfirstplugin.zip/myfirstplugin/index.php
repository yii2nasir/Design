<?php
/**
 * @package myfirst
 */
/*
Plugin Name: myfirst plugin
Plugin URI: hoststudioz.com
Description: .
Version: 4.1.1
Author: Nasir
Author URI: http://hoststudioz.com
License: GPLv2 or later
Text Domain: myfirst
*/

// Make sure we don't expose any info if called directly
$carform['submitForm1']='<form class="form-horizontal" METHOD="get">
 <fieldset>
 
 <!-- Form Name -->
 <legend>Form Name</legend>
 <input name="submitForm" type="hidden" value="2" >
   
 <!-- Text input-->
 <div class="form-group">
   <label class="col-md-4 control-label" for="textinput">Enter Your Car Number</label>  
   <div class="col-md-4">
   <input id="textinput" name="textinput" type="text" placeholder="Car Plate Number" class="form-control input-md" required="">
   <span class="help-block"> </span>  
   </div>
 </div>
 
 <!-- Button -->
 <div class="form-group">
   <label class="col-md-4 control-label" for="submitForm1"></label>
   <div class="col-md-4">
     <button id="submitForm1" name="submitForm1" class="btn btn-success">Submit</button>
   </div>
 </div>
 
 </fieldset>
 </form>
 ';

 $carform['submitForm2']='<form class="form-horizontal" METHOD="get">
 <fieldset>
 <input name="submitForm" type="hidden" value="3" >
 <!-- Form Name -->
 <legend>Form Name</legend>
 
 <!-- Text input-->
 <div class="form-group">
   <label class="col-md-4 control-label" for="textinput">Mileage </label>  
   <div class="col-md-4">
   <input id="textinput" name="textinput" type="text" placeholder="Mileage ?" class="form-control input-md" required="">
   <span class="help-block">Mileage </span>  
   </div>
 </div>
 
 <!-- Multiple Radios (inline) -->
 <div class="form-group">
   <label class="col-md-4 control-label" for="Previous Owner">Previous Owner</label>
   <div class="col-md-4"> 
     <label class="radio-inline" for="Previous Owner-0">
       <input type="radio" name="Previous Owner" id="Previous Owner-0" value="1" checked="checked">
       1
     </label> 
     <label class="radio-inline" for="Previous Owner-1">
       <input type="radio" name="Previous Owner" id="Previous Owner-1" value="2">
       2
     </label> 
     <label class="radio-inline" for="Previous Owner-2">
       <input type="radio" name="Previous Owner" id="Previous Owner-2" value="3">
       3
     </label> 
     <label class="radio-inline" for="Previous Owner-3">
       <input type="radio" name="Previous Owner" id="Previous Owner-3" value="4">
       4
     </label> 
     <label class="radio-inline" for="Previous Owner-4">
       <input type="radio" name="Previous Owner" id="Previous Owner-4" value="5">
       5+
     </label> 
     <label class="radio-inline" for="Previous Owner-5">
       <input type="radio" name="Previous Owner" id="Previous Owner-5" value="0">
       Don\'t Know
     </label>
   </div>
 </div>
 
 <!-- Multiple Radios (inline) -->
 <div class="form-group">
   <label class="col-md-4 control-label" for="radios">Services History</label>
   <div class="col-md-4"> 
     <label class="radio-inline" for="radios-0">
       <input type="radio" name="radios" id="radios-0" value="1" checked="checked">
       Full
     </label> 
     <label class="radio-inline" for="radios-1">
       <input type="radio" name="radios" id="radios-1" value="2">
       Some
     </label> 
     <label class="radio-inline" for="radios-2">
       <input type="radio" name="radios" id="radios-2" value="3">
       None
     </label> 
     <label class="radio-inline" for="radios-3">
       <input type="radio" name="radios" id="radios-3" value="4">
       First not due
     </label>
   </div>
 </div>
 
 <!-- Button -->
 <div class="form-group">
   <label class="col-md-4 control-label" for="Submitcarform2">Submit Detail</label>
   <div class="col-md-4">
     <button id="Submitcarform2" name="Submitcarform2" class="btn btn-success">Button</button>
   </div>
 </div>
 
 </fieldset>
 </form>
 ';


 $carform['submitForm3']='<form class="form-horizontal" METHOD="get">
 <fieldset>
 <input name="submitForm" type="hidden" value="4">
 <!-- Form Name -->
 <legend>Nearly there just a bit about you</legend>
 
 <!-- Text input-->
 <div class="form-group">
   <label class="col-md-4 control-label" for="name">Name</label>  
   <div class="col-md-4">
   <input id="name" name="name" type="text" placeholder="Name" class="form-control input-md" required="">
   <span class="help-block">Enter Your Name</span>  
   </div>
 </div>
 
 <!-- Text input-->
 <div class="form-group">
   <label class="col-md-4 control-label" for="email">email</label>  
   <div class="col-md-4">
   <input id="email" name="email" type="text" placeholder="Enter email" class="form-control input-md" required="">
   <span class="help-block">Email address</span>  
   </div>
 </div>
 
 <!-- Password input-->
 <div class="form-group">
   <label class="col-md-4 control-label" for="passwordinput">Password Input</label>
   <div class="col-md-4">
     <input id="passwordinput" name="passwordinput" type="password" placeholder="select Password" class="form-control input-md" required="">
     <span class="help-block">Password</span>
   </div>
 </div>
 
 <!-- Button -->
 <div class="form-group">
   <label class="col-md-4 control-label" for="submitForm" value="3"></label>
   <div class="col-md-4">
     <button id="submitForm3" name="submitForm3" class="btn btn-warning">Submit</button>
   </div>
 </div>
 
 </fieldset>
 </form>
 ';
if ( !function_exists( 'add_action' ) ) {
	echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
	//exit;
}

define( 'MYFIRST__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

class Myplugin{
	public $SID;
   function __construct($sid=null){
       //parent::__construct();
       $this->SID=$sid;
   }  
    public static function WP($obj=null){
        return new Myplugin($obj);
    }
   function form($par=null){
	   return "form function ->"."->".$par;
   }

   function phone($ph=null){
	return "email function ->".$this->SID."->".$par;
   }

   function searchform(){
       if(isset($_REQUEST)){
        if($_REQUEST['submitForm']==1){
            echo $carform['submitForm2'];
        }
       }elseif($_REQUEST['submitForm']==2){
        echo $carform['submitForm3'];
    }elseif($_REQUEST['submitForm']==3){
        echo "<h1>final completed</h1>";
        exit;
        //echo $carform['submitForm2'];
    }else{
        //echo $carform['submitForm1'];
       }
   }
}
/*********************************************************** */
function html_form_code() {
	echo '<form action="' . esc_url( $_SERVER['REQUEST_URI'] ) . '" method="post">';
	echo '<p>';
	echo 'Your Name (required) <br/>';
	echo '<input type="text" name="cf-name" pattern="[a-zA-Z0-9 ]+" value="' . ( isset( $_POST["cf-name"] ) ? esc_attr( $_POST["cf-name"] ) : '' ) . '" size="40" />';
	echo '</p>';
	echo '<p>';
	echo 'Your Email (required) <br/>';
	echo '<input type="email" name="cf-email" value="' . ( isset( $_POST["cf-email"] ) ? esc_attr( $_POST["cf-email"] ) : '' ) . '" size="40" />';
	echo '</p>';
	echo '<p>';
	echo 'Subject (required) <br/>';
	echo '<input type="text" name="cf-subject" pattern="[a-zA-Z ]+" value="' . ( isset( $_POST["cf-subject"] ) ? esc_attr( $_POST["cf-subject"] ) : '' ) . '" size="40" />';
	echo '</p>';
	echo '<p>';
	echo 'Your Message (required) <br/>';
	echo '<textarea rows="10" cols="35" name="cf-message">' . ( isset( $_POST["cf-message"] ) ? esc_attr( $_POST["cf-message"] ) : '' ) . '</textarea>';
	echo '</p>';
	echo '<p><input type="submit" name="cf-submitted" value="Send"></p>';
	echo '</form>';
}

function deliver_mail() {

	// if the submit button is clicked, send the email
	if ( isset( $_POST['cf-submitted'] ) ) {

		// sanitize form values
		$name    = sanitize_text_field( $_POST["cf-name"] );
		$email   = sanitize_email( $_POST["cf-email"] );
		$subject = sanitize_text_field( $_POST["cf-subject"] );
		$message = esc_textarea( $_POST["cf-message"] );

		// get the blog administrator's email address
		$to = get_option( 'admin_email' );

		$headers = "From: $name <$email>" . "\r\n";

		// If email has been process for sending, display a success message
		if ( wp_mail( $to, $subject, $message, $headers ) ) {
			echo '<div>';
			echo '<p>Thanks for contacting me, expect a response soon.</p>';
			echo '</div>';
		} else {
			echo 'An unexpected error occurred';
		}
	}
}

function cf_shortcode() {
	ob_start();
	deliver_mail();
	html_form_code();

	return ob_get_clean();
}

//add_action('init','html_form_code');

add_shortcode( 'p=1', 'html_form_code' );

