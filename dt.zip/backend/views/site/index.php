<?php

$this->title = "Dashboard";
echo "Welcome";
